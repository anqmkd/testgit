'use strict';

angular.module('myApp.application', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/application', {
	templateUrl: 'application/application.html',
	controller: 'applicationCtrl'
    }).
	when('/application/:id', {
	    templateUrl: 'application/detail.html',
	    controller: 'applicationDetailCtrl'
	});
}])

    .controller('applicationCtrl', ['$scope', function($scope) {
	$scope.apps = [
	    {id: 1, label: 'OS', name: 'os', ctime: '2015.06.01', uptime: '2015.06.02'},
	    {id: 2, label: 'OTA', name: 'ota', ctime: '2015.06.01', uptime: '2015.06.02'},
	];
    }])

    .controller('applicationDetailCtrl', ['$scope', function($scope) {
	
    }]);
