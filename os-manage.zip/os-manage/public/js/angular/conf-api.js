'use strict';

angular.module('myApp.api', [])
    .controller('apiCtrl', ['$scope', '$http', function($scope, $http) {
        $scope.del = function (event, key) {
            var dom = $(event.target);
            var id = dom.data('id');
            var data = $.param({id: id, key: key});

            $http({
                headers: {'Content-Type': 'application/x-www-form-urlencoded'},
                method: 'POST',
                url: '/conf/attributeDel',
                data: data
            }).success(function (data, status, header, config) {
                // @todo remove dom
                location.reload();
            }).error(function (data, status, header, config) {
            });
        };
    }]);


