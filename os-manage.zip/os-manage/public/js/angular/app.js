'use strict';

// Declare app level module which depends on views, and components
angular.module('myApp', [
    'ngRoute',
    'myApp.version',
]).
    config(['$routeProvider', function($routeProvider) {
        if (appInfo.versions[0]) {
            $routeProvider.otherwise({redirectTo: '/version/' + appInfo.versions[0].version});
        } else {
            $routeProvider.otherwise({redirectTo: '/version'});
        }
    }]);
