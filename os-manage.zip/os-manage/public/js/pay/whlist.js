jQuery(document).ready(function() {
    App.init();
    if (typeof TurnPage != 'undefined') WhiteList.getList();

    $("#form_whlist button").click(function(){
        WhiteList.getList();
    });
});

var WhiteList = {
    action:"",
    list_url:"/whlist/list",
    add_url:"/whlist/addWhite",
    edit_url:"/whlist/editWhite",
    del_url:"/whlist/delWhite",
    apk_url:"/whlist/apkWhite",
    getList:function(){
        var name = $("#form_whlist input[name='app_name']").val();
        var level_id = $("#select_app_id").val();
        var params = "app_name=" + name + "&level_id=" + level_id + "&page=" + TurnPage.page + "&page_count=" + TurnPage.pageCount;

        AjaxInterface.ajaxReq("POST", WhiteList.list_url, params, WhiteList.fnListBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },
    fnListBack:function(result){
        var data = $.parseJSON(result);
        var total_count = data.count;
        var list = data.list;
        var strH = '';
        for(var i=0; i < list.length; ++i){
            var flag = list[i]['nFlag'];
            var strFlagMsg = '';
            if(flag == 0){
                strFlagMsg = '<a href="javascript:WhiteList.updateFlag(' + list[i]['strId'] + ', 1 )" class="btn red"><i class="icon-remove icon-white"></i></a>';
            }else if(flag == 1){
                strFlagMsg = '<a href="javascript:WhiteList.updateFlag(' + list[i]['strId'] + ', 0 )" class="btn green"><i class="icon-ok icon-white"></i></a>';
            }
            strH += '<tr class="odd gradeX">' +
            '<td style="display:none;">' + list[i]['strId'] + '</td>' +
            '<td >' + list[i]['strName'] + '</td>' +
            '<td >' + list[i]['strPackage'] + '</td>' +
            '<td >' + list[i]['strActivity'] + '</td>' +
            '<td data-id="' + list[i]['nLevelId'] +'">' + list[i]['strLevelName'] + '</td>' +
            '<td >' + strFlagMsg + '</td>' +
            '<td class="t_tf"><span class="label label-success"><a href="javascript:void(0);" onclick="WhiteList.setEditData(this)">编辑</a></span>' +
            '&nbsp;&nbsp;<span class="label label-important"><a href="javascript:void(0);" onclick="WhiteList.setDelData(this)">删除</a></span></td>' +
            '</tr>';
        }
        $("#table_tbody").empty();
        $("#table_tbody").append(strH);
        TurnPage.showPage("page", WhiteList.getList, total_count);
        $("html, body").scrollTop(0);
    },
    setAddData:function(){
        WhiteList.action = 'add';
        $("#ext_activity").empty();
        $("#addbutton").click();
    },
    addWhiteList:function(){
        var strId = $("#tid").val();
        var strApkName = $("#apk_name").val();
        var strPackage = $("#package_name").val();
        var nLevelId = $("input[name='levels']:checked").val();
        if(strPackage == ""){
            $("#alertcontent").html("请添加应用包名");
            $("#alertbutton").click();
            return false;
        }

        //处理activity
        var strActivity = "";
        $("#ext_activity input").each(function(){
            if($(this).val() != ""){
                strActivity += $(this).val() + ",";
            }
        });
        strActivity = strActivity.substr(0, strActivity.length - 1);

        var strParam = "apk_name=" + strApkName + "&package_name=" + strPackage
             + "&apk_activity=" + strActivity + "&level_id=" + nLevelId;
        if(WhiteList.action == "add"){
            AjaxInterface.ajaxReq("POST", this.add_url, strParam, WhiteList.fnAddWhite, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
        }

        if(WhiteList.action == "edit"){
            strParam = strParam + "&id=" + strId;
            AjaxInterface.ajaxReq("POST", this.edit_url, strParam, WhiteList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
        }

        $("#add_close").click();

    },
    fnAddWhite:function(result){
        if(Math.ceil(result) == -1){
            $("#alertcontent").html("白名单已存在！");
            $("#alertbutton").click();
            return false;
        }
        if(!result){
            $("#alertcontent").html("添加失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("添加成功");
        $("#alertbutton").click();
        TurnPage.currentPage();
    },
    setDelData:function(obj){
        white_id = $(obj).parent().parent().parent().children().eq(0).text();
        $("#del_white_id").val(white_id);
        $("#delbutton").click();
    },
    delWhiteList:function(){
        var id = $("#del_white_id").val();
        var strParam = "id=" + id;
        AjaxInterface.ajaxReq("POST", this.del_url, strParam, WhiteList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },
    fnUpdateBack: function(result) {
        if (!result) {
            $("#alertcontent").html("操作失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("操作成功");
        $("#alertbutton").click();
        TurnPage.currentPage();
    },
    setEditData:function(obj){
        WhiteList.action='edit';
        var tid = $(obj).parent().parent().parent().children().eq(0).text();
        var name = $(obj).parent().parent().parent().children().eq(1).text();
        var package_name = $(obj).parent().parent().parent().children().eq(2).text();
        var activity = $(obj).parent().parent().parent().children().eq(3).text();
        var level_id = $(obj).parent().parent().parent().children().eq(4).attr("data-id");

        $("#tid").val(tid);
        $("#apk_name").val(name);
        $("#package_name").val(package_name);
        $("input[name='levels'][value='"+ level_id +"']").parent().addClass("checked");
        $("input[name='levels'][value!='"+ level_id +"']").parent().removeClass("checked");

        //处理activity字段
        if(activity != ""){
            var arrAct = activity.split(",");
            var strHtml = "";
            $.each(arrAct, function(key, value){
                strHtml += "<input type='text' class='m-wrap medium topMargin' value='"
                            + value + "' /><span class='help-inline fixSpan'><a href='javascript:void(0);' onclick='WhiteList.delExtActivity(this)'>删除</a></span>";
            });

            $("#ext_activity").empty();
            $("#ext_activity").append(strHtml);
        }

        $("#addbutton").click();
    },
    setApkConfig:function(){
        $("#r_add").click(function(){
            $("#div_secure_level").show();
        });

        $("#r_del").click(function(){
            $("#div_secure_level").hide();
        });

        if(!WhiteList.checkNum()){
            return false;
        }

        $("#configbutton").click();
    },
    configApkWhite:function(){
        var strStatus = $("input[name='r_status']:checked").val();
        var strLevelId = '';
        if(strStatus == "1"){
            strLevelId = $("input[name='levels']:checked").val();
        }

        if(strStatus == "1" && typeof(strLevelId) === "undefined"){
            alertModal("请选择应用安全级别！");
            return false;
        }

        var ids = "";
        $('input[name="td_checkbox"]:checked').each(function(){
            ids += $(this).val() + ",";
        });

        var strParam = "ids=" + ids + "&status=" + strStatus + "&level_id=" + strLevelId;
        AjaxInterface.ajaxReq("POST", this.apk_url, strParam, WhiteList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },
    checkNum:function(){
        var num = 0;
        $('input[name="td_checkbox"]:checked').each(function(){
            num ++;
        });
        if(num == 0){
            alertModal("请至少选择一条记录！");
            return false;
        }

        return true;
    },
    setExtActivity:function(){
        var activity = $("#apk_activity_add").val();
        if(activity == ""){
            $("#alertcontent").html("请输入增加的activity");
            $("#alertbutton").click();
            return;
        }
        var strHtml = "<input type='text' class='m-wrap medium topMargin' value='"
                + activity + "' /><span class='help-inline fixSpan'><a href='javascript:void(0);' onclick='WhiteList.delExtActivity(this)'>删除</a></span>";
        $("#ext_activity").append(strHtml);
        $("#apk_activity_add").val('');
    },
    delExtActivity:function(obj){
        $(obj).parent().prev().remove();
        $(obj).parent().remove();
    },
    updateFlag:function(id, value){
        var params = "id=" + id + "&value=" + value + "&type=1";
        AjaxInterface.ajaxReq("GET", "/whlist/updateflag", params, WhiteList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    }
};
