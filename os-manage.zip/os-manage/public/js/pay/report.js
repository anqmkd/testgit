jQuery(document).ready(function() {
  	App.init();
    TableManaged.init();
});

var ApkReport = {
  	action:"",
    apk_url:"/whlist/apkWhite",
    setApkConfig:function(){
      	$("#r_add").click(function(){
      		$("#div_secure_level").show();
      	});
      	
      	$("#r_del").click(function(){
      		$("#div_secure_level").hide();
      	});
      	
      	if(!ApkReport.checkNum()){
      		return false;
      	}
      	
      	$("#configbutton").click();
    },
    configApkWhite:function(){
      	var strStatus = $("input[name='r_status']:checked").val();
      	var strLevelId = '';
      	if(strStatus == "1"){
      		strLevelId = $("input[name='levels']:checked").val();
      	}
      	
      	if(strStatus == "1" && typeof(strLevelId) === "undefined"){
      		alertModal("请选择应用安全级别！");
		  	return false;
      	}
      	
      	var ids = "";
      	$('input[name="td_checkbox"]:checked').each(function(){
			ids += $(this).val() + ",";
		});
      	
      	var strParam = "ids=" + ids + "&status=" + strStatus + "&level_id=" + strLevelId;
      	AjaxInterface.ajaxReq("POST", this.apk_url, strParam, ApkReport.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },
    checkNum:function(){
      	var num = 0;
	    $('input[name="td_checkbox"]:checked').each(function(){
			num ++;
		});
	    if(num == 0){
		    alertModal("请至少选择一条记录！");
		    return false;
	    }

	    return true;
    },
    setExtActivity:function(){
        var activity = $("#apk_activity_add").val();
        if(activity == ""){
            $("#alertcontent").html("请输入增加的activity");
            $("#alertbutton").click();
            return;
        }
        var strHtml = "<input type='text' class='m-wrap medium topMargin' value='"
                + activity + "' /><span class='help-inline fixSpan'><a href='javascript:void(0);' onclick='WhiteList.delExtActivity(this)'>删除</a></span>";
        $("#ext_activity").append(strHtml);
        $("#apk_activity_add").val('');
    },
    delExtActivity:function(obj){
        $(obj).parent().prev().remove();
        $(obj).parent().remove();
    },
    fnUpdateBack: function(result) {
        if (!result) {
            $("#alertcontent").html("操作失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("操作成功");
        $("#alertbutton").click();
        window.location.reload();
    }
};
