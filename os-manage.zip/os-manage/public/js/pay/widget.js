jQuery(document).ready(function() {
  	App.init(); 
  	TableManaged.init();
});

var WidgetList = {
  	action:"",
    add_url:"/whlist/addWidget",
    edit_url:"/whlist/editWidget",
    del_url:"/whlist/delWidget",
    setAddData:function(){
        WidgetList.action = 'add';
		$("#addbutton").click();
    },
    addWidgetList:function(){
      	var strId = $("#tid").val();
        var strContent = $("#content").val();
        var nStatus = $("input[name='status']:checked").val();
        if(strContent == ""){
            $("#alertcontent").html("请添加widget显示内容");
            $("#alertbutton").click();
            return false;
        }

        var strParam = "content=" + strContent + "&status=" + nStatus;
        if(WidgetList.action == "add"){
       		AjaxInterface.ajaxReq("POST", this.add_url, strParam, WidgetList.fnAddWidget, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
        }
        
        if(WidgetList.action == "edit"){
        	strParam = strParam + "&id=" + strId;
       	    AjaxInterface.ajaxReq("POST", this.edit_url, strParam, WidgetList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
        }
        
    },
    fnAddWidget:function(result){
        if(!result){
            $("#alertcontent").html("添加失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("添加成功");
        $("#alertbutton").click();
        window.location.reload();
    },
    //setDelData:function(id, status_id){
    //    $("#del_status_id").val(status_id);
	 //   $("#del_white_id").val(id);
	 //   $("#delbutton").click();
    //},
    delWidgetList:function(id, status_id){
      	var strParam = "id=" + id + "&status=" + status_id;
        AjaxInterface.ajaxReq("POST", this.del_url, strParam, WidgetList.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },

    fnUpdateBack: function(result) {
        if (!result) {
            $("#alertcontent").html("操作失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("操作成功");
        $("#alertbutton").click();
        window.location.reload();
    },
    setEditData:function(obj){
        WidgetList.action='edit';
	    var tid = $(obj).parent().parent().parent().children().eq(0).text();
	    var content = $(obj).parent().parent().parent().children().eq(1).text();
	    var status_id = $(obj).parent().parent().parent().children().eq(2).attr("data-id");
	    
	    $("#tid").val(tid);
	    $("#content").val(content);
	    $("input[name='status'][value='"+ status_id +"']").parent().addClass("checked");
      	$("input[name='status'][value!='"+ status_id +"']").parent().removeClass("checked");
	    
	    $("#addbutton").click();
    }
};
