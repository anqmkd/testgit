jQuery(document).ready(function() {
  	App.init();

    $( "#start_picker, #end_picker" ).datepicker();
    var default_time = new Date().Format("yyyy-MM-dd");
    $("#start_picker, #end_picker").val(default_time);

    $("#btn_select").click(function(){
        TurnPage.page = 1;
        Claim.getList();
    });

    Claim.getList();
});

var Claim = {
    user_type:1,
    list_url:"/policy/user",
    status_url:"/policy/status",
    edit_url:"/policy/userupdate",
    getList:function(){
        var name = $("#form_activity input[name='user_name']").val();
        var phone = $("#form_activity input[name='user_phone']").val();
        var account = $("#form_activity input[name='user_account']").val();
        this.user_type = $("#select__id").val();
        var start_time = $("#start_picker").val();
        var end_time = $("#end_picker").val();
        var params = "user_name=" + name + "&user_phone=" + phone + "&user_account=" + account + "&user_id=" +
                        this.user_type + "&tStart=" + start_time + "&tEnd=" + end_time + "&page=" + TurnPage.page + "&page_count=" + TurnPage.pageCount;

        AjaxInterface.ajaxReq("POST", Claim.list_url, params, Claim.fnListBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    },
    fnListBack:function(result){
        var data = $.parseJSON(result);
        var total_count = data.total_count;
        var list = data.list;
        var strH = '';
        for(var i=0; i < list.length; ++i){
            strH += '<tr class="odd gradeX">' +
                    '<td style="display:none;">' + list[i]['strId'] + '</td>' +
                    '<td >' + list[i]['strUserName'] + '</td>' +
                    '<td >' + list[i]['strUserCard'] + '</td>' +
                    '<td >' + list[i]['strUserPhone'] + '</td>' +
                    '<td >' + list[i]['strUserAccount'] + '</td>' +
                    '<td >' + list[i]['strProduct'] + '</td>' +
                    '<td >' + list[i]['strDeviceId'] + '</td>' +
                    '<td class="t_po">' + list[i]['strOsVersion'] + '</td>' +
                    '<td class="t_tf">' + list[i]['strPhonePrice'] + '</td>' +
                    '<td >' + list[i]['tInsertTime'] + '</td>' +
                    '<td class="t_tf"><span class="label label-success"><a href="javascript:void(0);" onclick="Claim.setEditData(this)">编辑</a></span></td>' +
                    '</tr>';
        }
        $("#table_tbody").empty();
        $("#table_tbody").append(strH);
        if(Claim.user_type == 1){
            $(".t_po").show();
            $(".t_tf").hide();
            $(".portlet-title .actions a").hide();
        }else{
            $(".t_po").hide();
            $(".t_tf").show();
            $(".portlet-title .actions a").show();
        }
        TurnPage.showPage("page", Claim.getList, total_count);
        $("html, body").scrollTop(0);
    },
    fnUpdateBack: function(result) {
        if (!result) {
            $("#alertcontent").html("操作失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("操作成功");
        $("#alertbutton").click();
        TurnPage.currentPage();
    },
    exportExl:function(){
        var name = $("#form_activity input[name='user_name']").val();
        var phone = $("#form_activity input[name='user_phone']").val();
        var account = $("#form_activity input[name='user_account']").val();
        var user_type = $("#select__id").val();
        var start_time = $("#start_picker").val();
        var end_time = $("#end_picker").val();

        window.location.href = "/policy/export?user_name=" + name + "&user_phone=" + phone + "&user_account=" + account + "&user_id=" +
                                user_type + "&tStart=" + start_time + "&tEnd=" + end_time;
    },
    setEditData:function(obj){
        var tid = $(obj).parent().parent().parent().children().eq(0).text();
        var name = $(obj).parent().parent().parent().children().eq(1).text();
        var phone = $(obj).parent().parent().parent().children().eq(3).text();
        var price = $(obj).parent().parent().parent().children().eq(8).text();

        $("#tid").val(tid);
        $("#name").html(name);
        $("#phone").html(phone);
        $("#price").val(price);

        $("#addbutton").click();
    },
    updateInfo:function(){
        var strId = $("#tid").val();
        var strPrice = $("#price").val();
        if(strPrice == ""){
            $("#alertcontent").html("请填写调整后的手机价格");
            $("#alertbutton").click();
            return false;
        }

        var strParam = "price=" + strPrice + "&id=" + strId;
        AjaxInterface.ajaxReq("POST", this.edit_url, strParam, Claim.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);

        $("#add_close").click();
    }
};
