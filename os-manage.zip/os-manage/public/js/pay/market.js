jQuery(document).ready(function() {
  	App.init(); 
  	TableManaged.init();
});

var Market = {
    update_url:"/policy/updatemarket",
    update_flag_url:"/policy/updateflag",
    updateMarket:function(){
        if(confirm("该操作会从360应用市场更新本地数据，是否继续？")){
            AjaxInterface.ajaxReq("POST", this.update_url, '', Market.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
        }
    },
    fnUpdateBack: function(result) {
        if (!result) {
            $("#alertcontent").html("操作失败");
            $("#alertbutton").click();
            return false;
        }

        $("#alertcontent").html("操作成功");
        $("#alertbutton").click();
        window.location.reload();
    },
    updateFlag:function(id, value){
        var params = "id=" + id + "&value=" + value + "&type=1";
        AjaxInterface.ajaxReq("GET", this.update_flag_url, params, Market.fnUpdateBack, AjaxInterface.fnBeforSend, AjaxInterface.fnComplet);
    }
};
