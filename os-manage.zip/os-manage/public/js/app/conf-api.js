'use strict';
angular.module('myApp', ['myApp.api', '720kb.tooltips', 'MassAutoComplete', 'ui.tree', 'turn/stickyTableHeader']);
angular
    .module('myApp.api', ['ui.bootstrap','dialogs.main'])
    .config(function ($httpProvider) {
        // Use x-www-form-urlencoded Content-Type
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
        $httpProvider.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest';
        /**
         * The workhorse; converts an object to x-www-form-urlencoded serialization.
         * @param {Object} obj
         * @return {String}
         */
        var param = function(obj) {
            var query = '', name, value, fullSubName, subName, subValue, innerObj, i;

            for (name in obj) {
                value = obj[name];

                if (value instanceof Array) {
                    for(i=0; i<value.length; ++i) {
                        subValue = value[i];
                        fullSubName = name + '[' + i + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if(value instanceof Object) {
                    for (subName in value) {
                        subValue = value[subName];
                        fullSubName = name + '[' + subName + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if(value !== undefined && value !== null) {
                    query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
                }
            }

            return query.length ? query.substr(0, query.length - 1) : query;
        };

        // Override $http service's default transformRequest
        $httpProvider.defaults.transformRequest = [function(data) {
            return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
        }];
    })
    // .directive('ngConfirmClick', [
    //     function() {
    //         return {
    //             priority: -1,
    //             restrict: 'A',
    //             link: function(scope, element, attrs){
    //                 element.bind('click', function(e){
    //                     var message = attrs.ngConfirmClick;
    //                     if (message && !confirm(message)) {
    //                         e.stopImmediatePropagation();
    //                         e.preventDefault();
    //                     }
    //                 });
    //             }
    //         }
    //     }
    // ])
    .controller('apiCtrl', ['$scope', '$http', '$rootScope', '$timeout', 'dialogs', '$q', function($scope, $http, $rootScope, $timeout, dialogs, $q) {
        $scope.api = apiInfo;

        function getAttribute(key) {
            var attributes = apiInfo.attributes;
            for (var i in attributes) {
                if (attributes[i].key == key) {
                    return attributes[i];
                }
            }
            return [];
        }

        $scope.addAttribute = function () {
            var id = apiInfo.id;

            var dlg = dialogs.create('/tpl/conf/api/attribute.html', 'attributeDialogCtrl', {
                readonly: false,
                attribute: {
                    act: 'add',
                    type: 'strings'
                }
            }, {size: 'lg', keyboard: true, windowClass: 'attribute-class'});
        };

        // 编辑
        $scope.edit = function (event) {
            var dom = $(event.target);
            var id = dom.data('id');
            var key = dom.data('key');
            var data = {attribute: getAttribute(key)};

            data.id = id;
            data.readonly = true;

            var dlg = dialogs.create('/tpl/conf/api/attribute.html', 'attributeDialogCtrl', data, {size: 'lg', keyboard: true, windowClass: 'attribute-class'});
        };

        // 删除
        $scope.del = function (event) {
            var dom = $(event.target);
            var key = dom.data('key');
            var dlg = dialogs.confirm('删除字段', '确定删除这个字段吗？', {windowClass: 'confirm-class'});

            dlg.result.then(function (btn) {
                var dom = $(event.target);
                var id = dom.data('id');
                var data = {id: id, key: key};

                $http.post('/conf/attributeDel', data).success(function (data) {
                    if (data && data.status) {
                        dom.closest('tr').fadeOut('slow', function () {
                            $(this).remove();
                        });
                    } else {
                        dialogs.notify('Wrong', data.error);
                    }
                }).error(function (data) {
                    dialogs.notify('出错，请重试');
                });
            });
        };

        $scope.treeOptions = {
            dropped: function(event) {
                // 顺序没有变化
                if (event.dest.index == event.source.index) {
                    return false;
                }

                var dlg = dialogs.confirm('调整顺序', '确定按此顺序调整字段吗？', {windowClass: 'confirm-class'});
                dlg.result.then(function (btn) {
                    var keys = [];
                    var id = apiInfo.id;
                    for (var i in apiInfo.attributes) {
                        keys.push(apiInfo.attributes[i].key);
                    }

                    $http.post('/conf/attributeKeys', {id: id, keys: keys}).success(function (data) {
                        if (data && data.status) {
                            dialogs.notify('Success!', '修改成功', {windowClass: 'notify-class'});
                        } else {
                            dialogs.notify('Wrong', data.error);
                        }
                    }).error(function (data) {
                        dialogs.notify('出错，请重试');
                    });
                });
                return true;
            }
        };
    }])
    .config(function($translateProvider){
        $translateProvider.translations('en-US', {
            'strings': '字符串',
            'boolean': '布尔型',
            'enums': '枚举型',
            'int': '整型',
            'float': '浮点型',
            'machine': '机型',
            'package': '应用包',
            'district': '地区',
            DIALOGS_ERROR: "Error",
            DIALOGS_ERROR_MSG: "An unknown error has occurred.",
            DIALOGS_PLEASE_WAIT: "Please Wait",
            DIALOGS_PLEASE_WAIT_ELIPS: "Please Wait...",
            DIALOGS_PLEASE_WAIT_MSG: "Waiting on operation to complete.",
            DIALOGS_PERCENT_COMPLETE: "% Complete",
            DIALOGS_NOTIFICATION: "Notification",
            DIALOGS_NOTIFICATION_MSG: "Unknown application notification.",
            DIALOGS_CONFIRMATION: "Confirmation",
            DIALOGS_CONFIRMATION_MSG: "Confirmation required.",
            DIALOGS_OK: "OK",
            DIALOGS_CLOSE: "Close",
            DIALOGS_YES: "确定",
            DIALOGS_NO: "取消"
        });
    })
    .controller('attributeDialogCtrl', function($scope, $modalInstance, $http, dialogs, data) {
        //-- Variables --//
        for (var key in data) {
            $scope[key] = data[key];
        }

        $scope.primaryToggle = function (event) {
            var old = $scope.attribute.primary;

            if (!old) {
                $('input[name="require"]').prop('checked', 'checked');
                jQuery.uniform.update();
            }
        };

        //-- Methods --//
        $scope.cancel = function(event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }

            $modalInstance.dismiss('Canceled');
        }; // end cancel

        $scope.save = function() {
            var id = apiInfo.id;

            var enums = [];
            if ($scope.attribute.enums) {
                for (var i in $scope.attribute.enums) {
                    enums.push({label: $scope.attribute.enums[i].label, value: $scope.attribute.enums[i].value});
                }
            }

            var data = {
                id: id,
                key: $scope.attribute.key,
                label: $scope.attribute.label,
                desc: $scope.attribute.desc,
                type: $scope.attribute.type,
                require: $scope.attribute.require ? 1 : 0,
                download: $scope.attribute.download ? 1 : 0,
                primary: $scope.attribute.primary ? 1 : 0,
                filter: $scope.attribute.filter ? 1 : 0,
                filterContDef: $scope.attribute.filterContDef ? 1 : 0,
                enums: enums
            };

            var url = '/conf/attributeSet';
            if ($scope.attribute.act == 'add') {
                url = '/conf/attributeAdd';
            }

            $http.post(url, data).success(function (response) {
                if (response && response.status) {
                    location.reload();
                } else {
                    dialogs.error('Wrong!', response.error, {windowClass: 'error-class'});
                }
            }).error(function (response) {
                dialogs.error('Wrong!', '出错了，请重试', {windowClass: 'notify-class'});
            });
            //$modalInstance.close($scope.user.name);
        }; // end save

        $scope.addEnums = function (event) {
            event.preventDefault();
            event.stopPropagation();

            var dom = $(event.target);
            var tr = dom.closest('tr');
            var label = tr.find('input[name=label]').val();
            var value = tr.find('input[name=value]').val();

            if (label) {
                if (!$scope.attribute.enums) {
                    $scope.attribute.enums = [];
                }
                $scope.attribute.enums.push({label: label, value: value});
            }
        };

        $scope.delEnums = function (event) {
            event.preventDefault();
            event.stopPropagation();

            var dom = $(event.target);
            var tr = dom.closest('tr');
            var label = tr.find('input[name=label]').val();
            var value = tr.find('input[name=value]').val();

            if ($scope.attribute.enums) {
                var enums = $scope.attribute.enums;
                for (var i in enums) {
                    if (enums[i].label === label && enums[i].value === value) {
                        $scope.attribute.enums.splice(i, 1);
                    }
                }
            }
        };
    })

    .controller('rowCtrl', ['$scope', '$http', 'dialogs', '$timeout', '$q', function($scope, $http, dialogs, $timeout, $q) {
        $scope.api = apiInfo;
        $scope.rows = apiInfo.snapshot;
        var rows = $scope.rows;

        $scope.rowAdd = function (event) {
            var data = {id: $scope.api.id};
            var requirePass = true;

            $('#J-row-add .row-add input').each(function (_, v) {
                var value = $(v).val();
                data[$(v).attr('name')] = $(v).val();
                if (value == '' && $(v).attr('required')) {
                    requirePass = false;
                    return false;
                }
            });
            if (!requirePass) {
                return false;
            }
            $('#J-row-add .row-add select').each(function (_, v) {
                data[$(v).attr('name')] = $(v).val();;
            });

            $http.post('/conf/rowAdd', data).success(function (response) {
                if (response && response.status) {
                    //location.reload();
                    data._id = response.rowId;
                    delete data.id;
                    rows.unshift(data);
                    $('.row-add input,.row-add select').val('');
                } else {
                    dialogs.notify('出错啦!', response.error, {windowClass: 'notify-class'});
                }
            });
        };

        $scope.rowEdit = function (event) {
            event.preventDefault();
            event.stopPropagation();

            var id = apiInfo.id;
            var dom = $(event.target);
            var rowId = dom.data('id');
            var parentDom = dom.closest('tr');
            var row = {};
            var key;
            var requirePass = true;

            parentDom.find('.J-row-data').each(function (_, v) {
                key = $(v).data('key');
                var value = '';

                var hasInput = $(v).find('select,input,textarea').length ? true : false;
                if (hasInput) {
                    value = $.trim($(v).find('select,input,textarea').val());
                } else {
                    value = $.trim($(v).text());
                }

                row[key] = value;

                if (value == '' && $(v).data('require')) {
                    requirePass = false;
                    return false;
                }
            });

            if (!requirePass) {
                dialogs.notify('Wrong!', '请填写必填项', {windowClass: 'notify-class'});
                return false;
            }

            $http.post('/conf/rowSet', {id: id, rowId: rowId, row: row}).success(function (response) {
                if (response && response.status) {
                    dialogs.notify('Success!', '修改成功', {windowClass: 'notify-class'});
                } else {
                    dialogs.notify('出错啦!', response.error, {windowClass: 'notify-class'});
                }
            });

            return true;
        };

        $scope.rowDel = function (event) {
            var dlg = dialogs.confirm('删除数据', '确定删除这个数据吗？', {windowClass: 'confirm-class'});

            dlg.result.then(function (btn) {
                var dom = $(event.target);
                var rowId = dom.data('id');
                var id = apiInfo.id;
                var data = {id: id, rowId: rowId};

                $http.post('/conf/rowDel', data).success(function (data) {
                    if (data && data.status) {
                        dom.closest('tr').fadeOut('slow', function () {
                            // 删除数据
                            for (var i in rows) {
                                if (rows[i]._id == rowId) {
                                    rows.splice(i, 1);
                                }
                            }
                        });
                    } else {
                        console.log(data);
                    }
                }).error(function (data) {
                    dialogs.notify('出错啦!', '请重试', {windowClass: 'notify-class'});
                });
            });
        };

        function suggest_state(term) {
            var deferred = $q.defer();

            // Fake remote source using timeout
            $http.get('/machine/search?q=' + encodeURIComponent(term)).success(function (response) {
                if ($.isEmptyObject(response)) {
                    response = [{label: '无结果', value: ''}];
                }
                deferred.resolve(response);
            });

            return deferred.promise;
        }

        $scope.autocomplete_options = {
            suggest: suggest_state
        };

        $scope.package_autocomplete_options = {
            suggest: function (term) {
                var deferred = $q.defer();

                // Fake remote source using timeout
                $http.get('/package/search?q=' + encodeURIComponent(term)).success(function (response) {
                    if ($.isEmptyObject(response)) {
                        response = [{label: '无结果', value: ''}];
                    }
                    deferred.resolve(response);
                });

                return deferred.promise;
            }
        };

        $scope.district_autocomplete_options = {
            suggest: function (term) {
                var deferred = $q.defer();

                // Fake remote source using timeout
                $http.get('/conf/searchDistrict?q=' + encodeURIComponent(term)).success(function (response) {
                    if ($.isEmptyObject(response)) {
                        response = [{label: '无结果', value: ''}];
                    }
                    deferred.resolve(response);
                });

                return deferred.promise;
            }
        };
    }])
    .controller('checkCtrl', ['$scope', '$http', 'dialogs', '$timeout', '$q', function($scope, $http, dialogs, $timeout, $q) {
        $scope.check = apiInfo.checkPoint ? 1 : 0;

        $scope.api = apiInfo;
        $scope.checkSave = function () {
            event.preventDefault();
            event.stopPropagation();

            var id = apiInfo.id;

            var data = {
                id: id,
                check: $scope.check ? 1 : 0,
                time: $('#J-checkPoint-date').val() + ' ' + $('#J-checkPoint-time').val()
            };

            $http.post('/conf/checkSet', data).success(function (response) {
                if (response && response.status) {
                    dialogs.notify('Success!', '修改成功', {windowClass: 'notify-class'});
                } else {
                    dialogs.notify('出错啦!', response.error, {windowClass: 'notify-class'});
                }
            });

            return true;
        };
    }])
    .directive('attrtype', function () {
        return function ($scope, $element, $attrs) {
            var require = $scope.attr.require;
            var type = $attrs.attrtype;
            var key = $attrs.key;

            var html = '';
            var enums = [];

            switch (type) {
            case 'boolean':
                html = [
                    '<select class="form-control" name="',
                    key,
                    '">',
                    '<option value="true">true</option>',
                    '<option value="false">false</option>',
                    '</select>'
                ].join('');
                break;
            case 'machine':
                enums = machines;
            case 'enums':
                if (!enums || enums.length == 0) {
                    enums = $scope.$parent.attr.enums;
                }

                var options = [];

                options.push('<option value=""></option>');

                for (var i in enums) {
                    options.push([
                        '<option value="',
                        enums[i].value,
                        '">',
                        enums[i].label,
                        '</option>'
                    ].join(''));
                }

                html = [
                    '<select class="form-control" name="',
                    key,
                    '">',
                    options.join(''),
                    '</select>'
                ].join('');
                break;
            default:
                html = [
                    '<input ',
                    require ? ' required ' : '',
                    ' type="text" value="" style="width:80%;min-width:80px" name="',
                    key,
                    '" />'
                ].join('');
            }
            $($element).html(html);
        };
    })
    .directive('rowdata', function () {
        var func = function ($scope, $element, $attrs, ctrl, transclude) {
            var type = $attrs.type;
            var key = $attrs.key;

            $scope.type = type;
            $scope.key = key;
            var row = $scope.$parent.row;
            var attribute = $scope.$parent.attr;
            $scope.row = row;

            var html = '';
            var enums = [];

            if (attribute.primary || attribute.filter) {
                switch (type) {
                case 'enums':
                    var enums = $scope.$parent.attr.enums;
                    html = row[key];
                    for (var i = 0; i < enums.length; i++) {
                        if (enums[i].value == row[key]) {
                            html = enums[i].label + ' => ' + row[key];
                            break;
                        }
                    }
                    break;
                default:
                    html = row[key];
                }
                $element.parent().attr('contentEditable', 'false');
            } else {
                switch (type) {
                case 'boolean':
                    row[key] = angular.lowercase('' + row[key]) == 'true' ? true : false;
                    html = [
                        '<select class="form-control" name="',
                        key,
                        '" value="', row[key], '">',
                        '<option value="true"' , (row[key] ? ' selected ' : ''), '>true</option>',
                        '<option value="false"' , (!row[key] ? ' selected ' : ''), '>false</option>',
                        '</select>'
                    ].join('');
                    $element.parent().attr('contentEditable', 'false');
                    break;
                case 'machine':
                    enums = machines;
                case 'enums':
                    if (!enums || enums.length == 0) {
                        enums = $scope.$parent.attr.enums;
                    }

                    var options = [];

                    options.push('<option value=""></option>');

                    for (var i in enums) {
                        options.push([
                            '<option value="',
                            enums[i].value,
                            '"',
                            (row[key] === enums[i].value ? ' selected ' : ''),
                            '>',
                            enums[i].label,
                            '</option>'
                        ].join(''));
                    }

                    html = [
                        '<select class="form-control" name="',
                        key,
                        '" value="', row[key], '">',
                        options.join(''),
                        '</select>'
                    ].join('');
                    $element.parent().attr('contentEditable', 'false');
                    break;
                case 'machine':
                    return '';
                default:
                    html = [
                        row[key]
                    ].join('');
                }
            }

            $element.replaceWith(html);

            return html;
        };

        return {
            link: func,
            //templateUrl: '/tpl/conf/api/rowdata.html',
            restrict: 'E',
            replace: true
        };
    })
    // 该指令为了配合jquery的uniform使用
    .directive('input', function ($timeout) {
        return {
            restrict: 'E',
            require: '?ngModel',
            link: function (scope, element, attr, ngModel) {
                if (attr.ngModel && attr.noUniform === undefined) {
                    element.uniform({ useID: false });

                    scope.$watch(function () { return ngModel.$modelValue; }, function () {
                        $timeout(jQuery.uniform.update, 0);
                    });
                }
            }
        };
    });
