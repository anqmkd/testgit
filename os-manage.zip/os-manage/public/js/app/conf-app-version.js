'use strict';

angular
    .module('myApp.version', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/version', {
            templateUrl: '/tpl/conf/api-list.html',
            controller: 'versionCtrl'
        }).when('/version/:id', {
            templateUrl: '/tpl/conf/api-list.html',
            controller: 'versionCtrl'
        });
    }])

    .controller('versionCtrl', ['$scope', '$routeParams', '$http', '$rootScope', '$timeout', 'dialogs', function($scope, $routeParams, $http, $rootScope, $timeout, dialogs) {
        var versions = appInfo.versions;
        var version = null;

        for (var i in versions) {
            if (versions[i].version == $routeParams.id) {
                version = versions[i];
                break;
            }
        }

        $scope.version = version;
        $('.J-version-key').removeClass('current');
        $('.J-version-key').find('a[href="#/version/' + version.version + '"]').parent().addClass('current');

        $scope.add = function () {
            if (!$scope.version) {
                dialogs.error('Wrong!', '请先选择版本');
                return false;
            }
            var version = $scope.version.version;
            var dlg = dialogs.create('/tpl/conf/api/info.html', 'apiDialogCtrl', {version: version}, {size: 'lg', keyboard: true, windowClass: 'my-class'});
        };
    }])

    // 接口dialog
    .controller('apiDialogCtrl', ['$scope', '$modalInstance', '$http', 'dialogs', 'data', function($scope, $modalInstance, $http, dialogs, data) {

        //-- Variables --//
        $scope.api = {
            version: data.version,
            api: data.api,
            desc: data.desc,
            model: data.model || 'instruct'
        };

        var act = data && data.act ? data.act : 'Add';

        if (act == 'Clone') {
            $scope.api.api = data.api + '_clone';
            $scope.api.clonedApi = data.api;
        }

        //-- Methods --//
        $scope.cancel = function(event) {
            if (event) {
                event.stopPropagation();
                event.preventDefault();
            }

            $modalInstance.dismiss('Canceled');
        }; // end cancel

        $scope.save = function() {
            var id = appInfo._id.$id;
            var ename = appInfo.ename;

            var data = {
                id: id,
                ename: ename,
                version: $scope.api.version,
                api: $scope.api.api,
                clonedApi: $scope.api.clonedApi,
                desc: $scope.api.desc,
                model: $scope.api.model
            };

            var url = '/conf/api' + act;

            $http.post(url, data).success(function (response) {
                if (response && response.status) {
                    dialogs.notify('Success!', '操作成功').result.then(function () {
                        location.reload();
                    });
                } else {
                    dialogs.error('Wrong!', response.error);
                }
            }).error(function (response) {
                dialogs.error('Wrong!', '出错了，请重试');
            });

            return false;
        };
    }])
    .directive('input', function ($timeout) {
        return {
            restrict: 'E',
            require: '?ngModel',
            link: function (scope, element, attr, ngModel) {
                if (attr.type === 'radio' && attr.ngModel && attr.noUniform === undefined) {
                    element.uniform({ useID: false });

                    scope.$watch(function () { return ngModel.$modelValue }, function () {
                        $timeout(jQuery.uniform.update, 0);
                    });
                }
            }
        };
    });
