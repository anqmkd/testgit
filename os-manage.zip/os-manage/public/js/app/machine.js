'use strict';
angular.module('myApp', ['myApp.list', '720kb.tooltips']);
angular
    .module('myApp.list', ['ui.bootstrap','dialogs.main'])

    .config(function ($httpProvider) {
        // Use x-www-form-urlencoded Content-Type
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded;charset=utf-8';
        $httpProvider.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest';
        /**
         * The workhorse; converts an object to x-www-form-urlencoded serialization.
         * @param {Object} obj
         * @return {String}
         */
        var param = function(obj) {
            var query = '', name, value, fullSubName, subName, subValue, innerObj, i;

            for (name in obj) {
                value = obj[name];

                if (value instanceof Array) {
                    for(i=0; i<value.length; ++i) {
                        subValue = value[i];
                        fullSubName = name + '[' + i + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if(value instanceof Object) {
                    for (subName in value) {
                        subValue = value[subName];
                        fullSubName = name + '[' + subName + ']';
                        innerObj = {};
                        innerObj[fullSubName] = subValue;
                        query += param(innerObj) + '&';
                    }
                } else if(value !== undefined && value !== null) {
                    query += encodeURIComponent(name) + '=' + encodeURIComponent(value) + '&';
                }
            }

            return query.length ? query.substr(0, query.length - 1) : query;
        };

        // Override $http service's default transformRequest
        $httpProvider.defaults.transformRequest = [function(data) {
            return angular.isObject(data) && String(data) !== '[object File]' ? param(data) : data;
        }];
    })

    .config(function($translateProvider) {
        $translateProvider.translations('en-US', {
            DIALOGS_ERROR: "Error",
            DIALOGS_ERROR_MSG: "An unknown error has occurred.",
            DIALOGS_PLEASE_WAIT: "Please Wait",
            DIALOGS_PLEASE_WAIT_ELIPS: "Please Wait...",
            DIALOGS_PLEASE_WAIT_MSG: "Waiting on operation to complete.",
            DIALOGS_PERCENT_COMPLETE: "% Complete",
            DIALOGS_NOTIFICATION: "Notification",
            DIALOGS_NOTIFICATION_MSG: "Unknown application notification.",
            DIALOGS_CONFIRMATION: "Confirmation",
            DIALOGS_CONFIRMATION_MSG: "Confirmation required.",
            DIALOGS_OK: "OK",
            DIALOGS_CLOSE: "Close",
            DIALOGS_YES: "确定",
            DIALOGS_NO: "取消"
        });
    })

    .controller('listCtrl', ['$scope', '$http', '$rootScope', '$timeout', 'dialogs', function($scope, $http, $rootScope, $timeout, dialogs) {
        $scope.del = function (event, id) {
            var dlg = dialogs.confirm('删除机型', '真的确定删除这个机型吗？会丢失大量信息哦', {});
            var dom = $(event.target);

            dlg.result.then(function (btn) {
                var data = {id: id};
                $http.post('/machine/del', data).success(function (data) {
                    if (data && data.status) {
                        dom.closest('tr').fadeOut('slow', function () {
                            $(this).remove();
                        });
                    } else {
                        dialogs.notify('出错啦!', data.error);
                    }
                }).error(function (data) {
                    dialogs.notify('出错啦!', '请重试');
                });
            });
        };
    }]);
