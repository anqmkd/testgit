MassAutocomplete
================

Autocomplete for Angular.js applications with a lot to complete.

[http://hakib.github.io/MassAutocomplete](http://hakib.github.io/MassAutocomplete)
