#! /bin/bash

`curl 'http://api.os.qiku.com/tool/getdata'`