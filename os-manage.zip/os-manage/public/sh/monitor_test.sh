#! /bin/bash

`curl 'http://10.69.0.250/osapi/tool/getdata'`