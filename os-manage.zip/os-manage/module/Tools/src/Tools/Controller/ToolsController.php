<?php
namespace Tools\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;


use Service\PushTools\PushTools; 

class ToolsController extends AbstractActionController
{
	private $_tools;
	private $_mem;
	private $_pullRecord;
	
	public function indexAction()
    {
		$view =  new ViewModel();
		return $view;
    }
    
    public function memclearAction()
    {
    
    	$result = $this->getTools()->clearMemcache();
    	if(!$result){
    		$view =  new ViewModel(array('result'=>'clear failed'));
    	}else{
    		$view =  new ViewModel(array('result'=>'clear success'));
    	}
    	
    	return $view;
    }
    
    public function redisclearAction()
    {
    	$result = $this->getTools()->clearRedis();
    	if(!$result){
    		$view =  new ViewModel(array('result'=>'clear failed'));
    	}else{
    		$view =  new ViewModel(array('result'=>'clear success'));
    	}
    	   	 
    	return $view;
    }
    

    public function cmredisclearAction()
    {
    	$result = $this->getTools()->clearCheckMobileRedis();
    	if(!$result){
    		$view =  new ViewModel(array('result'=>'clear failed'));
    	}else{
    		$view =  new ViewModel(array('result'=>'clear success'));
    	}
    
    	return $view;
    }
    
    public function pushstatusAction()
    {
    	$strTaskid = $this->getRequest()->getQuery('taskid');
    	$strCid    = $this->getRequest()->getQuery('cid');
    	
    	$result = $this->getTools()->pushStatus($strTaskid, $strCid);
    	if($result === false){
    		$view =  new ViewModel(array('result'=>false));
    	}else{
    		$view =  new ViewModel(array('result'=>$result));
    	}
    
    	return $view;
    }
    
    public function getTools()
    {
    	if (!$this->_tools) {
	    	$this->_tools = new PushTools($this->getServiceLocator());
    	}    	
    	return $this->_tools;
    	
    }
}
