<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Tools\Controller\Tools' => 'Tools\Controller\ToolsController',
        ),
    ),
    
    'router' => array(
        'routes' => array(
            'tools' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/tools[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Tools\Controller\Tools',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'tools' => __DIR__ . '/../view/',
        ),
    ),
);