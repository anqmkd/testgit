<?php
namespace Policy\Controller;

use Service\Policy\APPMarket;
use Service\Policy\ClaimInfo;
use Service\Policy\PolicyUser;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;
use Service\fnlib\CZip;
use Service\fnlib\Des;
//use Service\fnlib\Tea;
use Service\Policy\TFPolicyUser;
use Service\Tools\Export;
use Service\Tools\Funcs;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Mvc\Controller\Plugin\Params;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;

use Zend\Mail\Transport;

class PolicyController extends AbstractActionController
{
    private $_policyuser;
    private $_tfpuser;
    private $_claiminfo;
    private $_market;
    private $_funcs;
	public  $dbAdapter;
	private $authUser;

	public function indexAction()
	{
		exit();
	}
	
	public function userAction()
	{
		try{
			$auth = new Auth();
			$result = $auth->roleAuth('Policy.policy.user', 'user');
			if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
				return $this->redirect()->toRoute('auth', array('controller'=>'auth',
						'action' => 'login'));
			}
			if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
				return $this->redirect()->toRoute('error', array('controller'=>'error',
						'action' => 'index',
						'id'	=> Error::YL_ERROR_NO_POWER,
				));
			}
			$this->authUser = $result;
			
			$request 	    = $this->getRequest();
            if($request->isPost()){
                $strUserName 	= $request->getPost()->get('user_name');
                $strUserPhone	    = $request->getPost()->get('user_phone');
                $strUserAccount	    = $request->getPost()->get('user_account');
                $strUserType    = $request->getPost()->get('user_id');
                $strUserType    = isset($strUserType)?$strUserType:'1';

                $tNowDate 	= date("Y-m-d", time());
                $tStart 		= $request->getPost()->get('tStart');
                $tEnd 			= $request->getPost()->get('tEnd');
                $tReqStart 		= isset($tStart)?$tStart:$tNowDate;
                $tReqEnd		= isset($tEnd)?$tEnd:$tNowDate;
                $tStartTime     = $tReqStart." 00:00:00";
                $tEndTime       = $tReqEnd." 23:59:59";

                $nPageNum = $request->getPost()->get('page');
                $nPageCount = $request->getPost()->get('page_count');


                $arrInfos = array();
                if($strUserType == '1'){
                    $policy = new PolicyUser();
                    $policy->setUserName($strUserName);
                    $policy->setUserPhone($strUserPhone);
                    $policy->setUserAccount($strUserAccount);
                    $strCondition = $policy->getCondition($tStartTime, $tEndTime);
                    $arrInfos = $this->getPolicyUserTable()->getPolicyUserInfo($strCondition, $nPageNum, $nPageCount);
                    $nCount = $this->getPolicyUserTable()->getCountList($strCondition);
                }elseif($strUserType == '2'){
                    $tfp = new TFPolicyUser();
                    $tfp->setUserName($strUserName);
                    $tfp->setUserPhone($strUserPhone);
                    $tfp->setUserAccount($strUserAccount);
                    $strCondition = $tfp->getCondition($tStartTime, $tEndTime);
                    $arrInfos = $this->getTFPolicyUserTable()->getUserInfo($strCondition, $nPageNum, $nPageCount);
                    $nCount = $this->getTFPolicyUserTable()->getCountList($strCondition);
                }

                foreach ($arrInfos as $info) {
                    foreach($info as $key=>$value){
                        if($key == 'strUserCard'){
                            $info->strUserCard = $this->getFuncs()->safeHideCard($value);
                        }
//                    if($key == 'strUserPhone'){
//                        $info->strUserPhone = $this->getFuncs()->safeHidePro($value);
//                    }
                    }
                }
            }else{
                $arrInfos = array();
                $strUserName = '';
                $strUserPhone = '';
                $strUserAccount = '';
                $strUserType = 1;
                $tReqStart = '';
                $tReqEnd = '';
                $view =  new ViewModel(array(
                    'lists' 		=> $arrInfos,
                    'username'      => $strUserName,
                    'userphone'	    => $strUserPhone,
                    'useraccount'   => $strUserAccount,
                    'usertype'      => $strUserType,
                    'starttime'     => $tReqStart,
                    'endtime'       => $tReqEnd,
                    'menu'			=> 'secpay',
                    'left'			=> 'policyuser'));

                return $view;
            }

            echo json_encode(array('result'=>true, 'total_count'=>$nCount, 'list'=>$arrInfos));
            exit();
					
		}catch(\Exception $e){
			Logs::write('PolicyController::userAction() exception, err:'
					.' message:'.$e->getMessage(), 'log');
		}
	}

    public function exportAction()
    {
        $request 	    = $this->getRequest();
        $strUserName 	= $request->getQuery('user_name');
        $strUserPhone	    = $request->getQuery('user_phone');
        $strUserAccount	    = $request->getQuery('user_account');
        $strUserType    = $request->getQuery('user_id');
        $strUserType    = isset($strUserType)?$strUserType:'1';
        if($strUserType == '1'){
            Logs::write("policy user info have not export", "log");
            exit();
        }

        $tNowDate 	= date("Y-m-d", time());
        $tStart 		= $request->getQuery()->get('tStart');
        $tEnd 			= $request->getQuery()->get('tEnd');
        $tReqStart 		= isset($tStart)?$tStart:$tNowDate;
        $tReqEnd		= isset($tEnd)?$tEnd:$tNowDate;
        $tStartTime     = $tReqStart." 00:00:00";
        $tEndTime       = $tReqEnd." 23:59:59";

        $tfp = new TFPolicyUser();
        $tfp->setUserName($strUserName);
        $tfp->setUserPhone($strUserPhone);
        $tfp->setUserAccount($strUserAccount);
        $strCondition = $tfp->getCondition($tStartTime, $tEndTime);
        $arrInfos = $this->getTFPolicyUserTable()->getUserInfo($strCondition, 1, 100000);

        $export = new Export();
        $export->exportReport(1, $arrInfos);
        exit();
    }

    public function marketAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.market', 'market');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request        = $this->getRequest();
            $strAppName     = $request->getQuery('app_name');
            $strAppName     = isset($strAppName)?$strAppName:'';

            $market = new APPMarket();
            $market->setAppName($strAppName);
            $strCondition = $market->getCondition();
            $arrList = $this->getAppMarketTable()->getAppList($strCondition);
            $view =  new ViewModel(array(
                'lists'         => $arrList,
                'appname'		=> $strAppName,
                'menu'			=> 'secpay',
                'left'			=> 'appmarket'));

            return $view;

        }catch(\Exception $e){
            Logs::write('PolicyController::marketAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }
    }

    public function updatemarketAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.market', 'market');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            passthru('/home/s/www/os-manage/public/sh/monitor.sh', $returnvalue);
            Logs::write("sh ret:".$returnvalue, "log");
            if ($returnvalue != 0){
                echo false;
                exit();
            }else{
                echo true;
                exit();
            }

        }catch (\Exception $e){
            Logs::write('PolicyController::updatemarketAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }
    }

	public function claimAction()
	{
		try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.claim', 'claim');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request 	    = $this->getRequest();
            $strUserAccount 	= $request->getQuery('user_account');
            $strUserPhone	    = $request->getQuery('user_phone');

            $claim = new ClaimInfo();
            $claim->setAccount($strUserAccount);
            $claim->setPhone($strUserPhone);
            $strCondition = $claim->getCondition();
			$arrInfo = $this->getClaimInfoTable()->getClaimInfo($strCondition);
            $view =  new ViewModel(array(
                'lists' 		=> $arrInfo,
                'userphone'	    => $strUserPhone,
                'useraccount'   => $strUserAccount,
                'menu'			=> 'secpay',
                'left'			=> 'claiminfo'));

            return $view;

		}catch (\Exception $e){
			Logs::write('PolicyController::claimAction() exception, err:'
					.' message:'.$e->getMessage(), 'log');
		}
	}

    public function detailsAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.claim', 'claim');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $id = $this->params("id");
            $arrDetail = array();
            $arrFiles = array();
            $arrLogs = array();

            $arrInfo = $this->getClaimInfoTable()->getClaimDetail($id);

            if(!empty($arrInfo)){
                foreach($arrInfo as $info){
                    if(!array_key_exists("report_num", $arrDetail) ){
                        $arrDetail["report_num"] = $info->strReportNum;
                        $arrDetail["name"] = $info->strName;
                        $arrDetail["account"] = $info->strAccount;
                        $arrDetail["c_money"] = $info->strClaimMoney;
                        $arrDetail["phone"] = $info->strPhone;
                        $arrDetail["qq"] = $info->strQQ;
                        $arrDetail["desc"] = $info->strDesc;
                        $arrDetail["applyTime"] = $info->tInsertTime;
                        $arrDetail["status"] = $info->nStatus;
                    }
                    if($info->nType == 5){
                        array_push($arrLogs, array("type"=>$info->nType, "path"=>$info->strFilePath));
                    }else{
                        array_push($arrFiles, array("type"=>$info->nType, "path"=>"https://manage.os.qiku.com/upload/".$info->strFilePath));
                    }
                }
            }

            $arrDetail["files"] = $arrFiles;
            $arrDetail["logs"] = $arrLogs;
            $view =  new ViewModel(array(
                'lists' 		=> $arrDetail,
                'menu'			=> 'secpay',
                'left'			=> 'claiminfo'));

            return $view;

        }catch (\Exception $e){
            Logs::write('PolicyController::detailAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }
    }

    public function dllogAction()
    {
        $auth = new Auth();
        $result = $auth->roleAuth('Policy.policy.claim', 'claim');
        if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
            return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                'action' => 'login'));
        }
        if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                'action' => 'index',
                'id'	=> Error::YL_ERROR_NO_POWER,
            ));
        }
        $this->authUser = $result;

        $request 	    = $this->getRequest();
        $strPath 	    = $request->getQuery('path');

        $this->_doZipFile($strPath);
        exit;
    }

    public function statusAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.claim', 'claim');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request 	    = $this->getRequest();
            $strReportNum 	= $request->getQuery('report_n');
            $nStatus	    = $request->getQuery('status');

            $claim = new ClaimInfo();
            $claim->setReportNum($strReportNum);
            $claim->setStatus($nStatus);
            $bRet = $this->getClaimInfoTable()->updateStatus($claim);
            if($bRet === false){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_EXCEPOTION,
                ));
            }

            return true;

        }catch (\Exception $e){
            Logs::write('PolicyController::statusAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }
    }
    public function updateflagAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.market', 'market');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request 	    = $this->getRequest();
            $nType 	    = $request->getQuery('type');
            $nValue	    = $request->getQuery('value');
            $strId      = $request->getQuery('id');

            $market = new APPMarket();
            if(empty($nType)){
                echo false;
                exit();
            }
            $market->setAppFlag($nValue);
            $market->setAppValid($nValue);
            $market->setId($strId);

            $bRet = $this->getAppMarketTable()->updateFlag($market, $nType);
            if($bRet === false){
                echo false;
                exit();
            }

            echo true;
            exit();
        }catch (\Exception $e){
            Logs::write('PolicyController::updateflagAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
            echo false;
            exit();
        }
    }
    public function userupdateAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Policy.policy.user', 'user');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request 	    = $this->getRequest();
            $strId 	        = $request->getPost()->get('id');
            $strPrice	    = $request->getPost()->get('price');

            $tfuser = new TFPolicyUser();
            $tfuser->setId($strId);
            $tfuser->setPhonePrice($strPrice);

            $bRet = $this->getTFPolicyUserTable()->updateUser($tfuser);
            if($bRet === false){
                echo false;
                exit();
            }

            echo true;
            exit();
        }catch (\Exception $e){
            Logs::write('PolicyController::userupdateAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
            echo false;
            exit();
        }
    }
//    public function testfileAction(){
//        $path = isset($_GET['path'])?$_GET['path']:'201508/testzip/riskinsurance.zip';
//        echo $this->_doZipFile($path);
//
//        exit();
//    }
    /**
     * @param $strFilePath
     * 解压ZIP文件，解密文件内容，再压缩
     * 返回文件路径
     */
    private function _doZipFile($strFilePath){
        $strTmpPath = "/home/s/www/os-manage/public/upload/";
        $strPath = $strTmpPath.$strFilePath;

        $zip = new CZip();
        $bRet = $zip->uncompressZip($strPath, $strTmpPath);
        if(!$bRet){
            Logs::write("uncomzip fail", "log");
            return '';
        }
        $strRiskTxtPath = $strTmpPath."/RiskInsuranceZIP/riskinsurance.txt";
        $strRecordTxtPath = $strTmpPath."/RiskInsuranceZIP/installedRecord.txt";
        $strNetTxtPath = $strTmpPath."/RiskInsuranceZIP/msafe_net.txt";
        $strSmsTxtPath = $strTmpPath."/RiskInsuranceZIP/msafe_sms.txt";
        if(!is_dir($strTmpPath."/newzip")){
            $result = mkdir($strTmpPath."/newzip", 0755, true);
            if (!$result) {
                Logs::write("Zip::MakeDesDir(): failed", "log");
                return false;
            }
        }
        $strDesRiskTxtPath = $strTmpPath."/newzip/newrisk.txt";
        $strDesRecordTxtPath = $strTmpPath."/newzip/newrecord.txt";
        $strDesNetTxtPath = $strTmpPath."/newzip/newnet.txt";
        $strDesSmsTxtPath = $strTmpPath."/newzip/newsms.txt";

        //处理设置和扫描记录文件
        $this->_doRiskFile($strRiskTxtPath, $strDesRiskTxtPath);
        //处理安装记录文件
        $this->_doRecordFile($strRecordTxtPath, $strDesRecordTxtPath);
        //处理网址文件
        $this->_doNetFile($strNetTxtPath, $strDesNetTxtPath);
        //处理短信文件
        $this->_doSMSFile($strSmsTxtPath, $strDesSmsTxtPath);

        $bResult = $zip->scanZipDir($strTmpPath."/newzip/", $strTmpPath."/new.zip");
        if($bResult === false){
            Logs::write("Zip::zipDir fail", "log");
            return false;
        }

        header('Location: https://manage.os.qiku.com/upload/new.zip');
        exit();
    }

    private function _doRiskFile($strRiskTxtPath, $strDesRiskTxtPath){
        $handle = fopen($strRiskTxtPath, "r");
        $newRisk = fopen($strDesRiskTxtPath, "w+");
        if ($handle) {
            while (!feof($handle)) {
                $line = fgets($handle);
                $arrLine = json_decode($line, true);
                unset($arrLine["_id"]);
                if(!empty($arrLine["nofakeapp"])){
                    $arrLine["nofakeapp"] = Des::decrypt_cbc(base64_decode($arrLine["nofakeapp"]), "qiku8888");
                }
                if(!empty($arrLine["openedvpn"])){
                    $arrLine["openedvpn"] = Des::decrypt_cbc(base64_decode($arrLine["openedvpn"]), "qiku8888");
                }
                if(!empty($arrLine["novirus"])){
                    $arrLine["novirus"] = Des::decrypt_cbc(base64_decode($arrLine["novirus"]), "qiku8888");
                }
                if(!empty($arrLine["btnok"])){
                    $arrLine["btnok"] = Des::decrypt_cbc(base64_decode($arrLine["btnok"]), "qiku8888");
                }
                if(!empty($arrLine["btncancel"])){
                    $arrLine["btncancel"] = Des::decrypt_cbc(base64_decode($arrLine["btncancel"]), "qiku8888");
                }
                if(!empty($arrLine["calltask"])){
                    $arrLine["calltask"] = Des::decrypt_cbc(base64_decode($arrLine["calltask"]), "qiku8888");
                }
                if(!empty($arrLine["entrySafeSpace"])){
                    $arrLine["entrySafeSpace"] = Des::decrypt_cbc(base64_decode($arrLine["entrySafeSpace"]), "qiku8888");
                }
                if(!empty($arrLine["enable360"])){
                    $arrLine["enable360"] = Des::decrypt_cbc(base64_decode($arrLine["enable360"]), "qiku8888");
                }

                $strRet = json_encode($arrLine);
                $arrKey = array("time", "risksystem", "safeguard","appcheck", "viruscheck", "wificheck", "mmscheck", "screenshot",
                    "wifilevel","switchpos","nofakeapp","openedvpn", "novirus","btnok","btncancel", "calltask", "entrySafeSpace", "enable360");
                $arrReplace = array("时间","设置中支付隔离系统开关", "默认系统支付安全保护", "仿冒应用检查", "病毒检测","wifi检测",
                    "交易短信保护","防止恶意截屏", "wifi等级","提示安装应用到支付域","非仿冒应用","开启wifi安全通道",
                    "非病毒应用","确定按钮","取消按钮","支付时的调用堆栈","进入了财产保护系统","安全卫士有效");
                $strNewRet = $this->_strReplace($strRet, $arrKey, $arrReplace, 0);

                if($newRisk){
                    fputs($newRisk, $strNewRet."\r\n");
                }

            }
            fclose($handle);
            fclose($newRisk);
        }
    }

    private function _doRecordFile($strRecordTxtPath, $strDesRecordTxtPath){
        $handle = fopen($strRecordTxtPath, "r");
        $newRecord = fopen($strDesRecordTxtPath, "w+");
        if ($handle) {
            while (!feof($handle)) {
                $line = fgets($handle);

                $arrKey = array("addtime", "removetime", "name","package", "sha1", "safeapp", "virus", "mark");
                $arrReplace = array("安装时间","卸载时间", "应用名", "包名", "哈希值","非仿冒应用","非病毒应用","是否扫描");
                $strNewRet = $this->_strReplace($line, $arrKey, $arrReplace, 0);

                if($newRecord){
                    fputs($newRecord, $strNewRet."\r\n");
                }

            }
            fclose($handle);
            fclose($newRecord);
        }
    }

    private function _doNetFile($strNetTxtPath, $strDesNetTxtPath){
        $handle = fopen($strNetTxtPath, "r");
        $newNet = fopen($strDesNetTxtPath, "w+");
        if ($handle) {
            while (!feof($handle)) {
                $line = fgets($handle);
//                $arrLine = json_decode($line, true);
//                unset($arrLine["_id"]);
//                if(!empty($arrLine["helper_net"])){
//                    $arrLine["helper_net"] = Des::decrypt_cbc(base64_decode($arrLine["helper_net"]), "qiku8888");
//                }
//
//                $strRet = json_encode($arrLine);
                $arrKey = array("type", "date_time", "helper_src","helper_net", "helper_action");
                $arrReplace = array("类型","时间", "拦截的url包名", "拦截的url", "url云端判定结果");
                $strNewRet = $this->_strReplace($line, $arrKey, $arrReplace, 0);

                if($newNet){
                    fputs($newNet, $strNewRet."\r\n");
                }

            }
            fclose($handle);
            fclose($newNet);
        }
    }

    private function _doSMSFile($strSmsTxtPath, $strDesSmsTxtPath){
        $handle = fopen($strSmsTxtPath, "r");
        $newSms = fopen($strDesSmsTxtPath, "w+");
        if ($handle) {
            while (!feof($handle)) {
                $line = fgets($handle);
//                $arrLine = json_decode($line, true);
//                unset($arrLine["_id"]);
//                if(!empty($arrLine["helper_from"])){
//                    $arrLine["helper_from"] = Des::decrypt_cbc(base64_decode($arrLine["helper_from"]), "qiku8888");
//                }
//                if(!empty($arrLine["helper_to"])){
//                    $arrLine["helper_to"] = Des::decrypt_cbc(base64_decode($arrLine["helper_to"]), "qiku8888");
//                }
//                if(!empty($arrLine["helper_content"])){
//                    $arrLine["helper_content"] = Des::decrypt_cbc(base64_decode($arrLine["helper_content"]), "qiku8888");
//                }
//
//                $strRet = json_encode($arrLine);
                $arrKey = array("type","helper_src", "date_time", "helper_from","helper_to","helper_content", "helper_action");
                $arrReplace = array("类型","来源记录","时间", "短信号码", "发往sim卡的imsi号", "短信内容","骚扰拦截识别结果");
                $strNewRet = $this->_strReplace($line, $arrKey, $arrReplace, 0);

                if($newSms){
                    fputs($newSms, $strNewRet."\r\n");
                }

            }
            fclose($handle);
            fclose($newSms);
        }
    }

    private function _strReplace($string,$keyArray,$replacement,$i){
        $result='';
        if($i<(count($keyArray))){
            $strSegArray=explode($keyArray[$i],$string);
            foreach ($strSegArray as $index=>$strSeg){
                $x=$i+1;
                if($index==(count($strSegArray)-1))
                    $result=$result.$this->_strReplace($strSeg,$keyArray,$replacement,$x);
                else
                    $result=$result.$this->_strReplace($strSeg,$keyArray,$replacement,$x).$replacement[$i];
            }
            return $result;
        }
        else{
            return $string;
        }
    }

    public function getPolicyUserTable()
    {
        if (!$this->_policyuser) {
            $sm = $this->getServiceLocator();
            $this->_policyuser = $sm->get('Service\Policy\PolicyUserTable');
        }
        return $this->_policyuser;
    }

    public function getTFPolicyUserTable()
    {
        if (!$this->_tfpuser) {
            $sm = $this->getServiceLocator();
            $this->_tfpuser = $sm->get('Service\Policy\TFPolicyUserTable');
        }
        return $this->_tfpuser;
    }

    public function getClaimInfoTable(){
        if(!$this->_claiminfo){
            $sm = $this->getServiceLocator();
            $this->_claiminfo = $sm->get('Service\Policy\ClaimInfoTable');
        }
        return $this->_claiminfo;
    }

    public function getAppMarketTable(){
        if(!$this->_market){
            $sm = $this->getServiceLocator();
            $this->_market = $sm->get('Service\Policy\APPMarketTable');
        }
        return $this->_market;
    }

    public function getFuncs()
    {
        if (!$this->_funcs) {
            $this->_funcs = new Funcs($this->getServiceLocator());
        }
        return $this->_funcs;
    }
	
	public function getAdapter()
	{
		if (!$this->dbAdapter) {
			$sm = $this->getServiceLocator();
			$this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		}
		return $this->dbAdapter;
	}
	
}
