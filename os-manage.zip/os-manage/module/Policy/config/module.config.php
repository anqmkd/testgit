<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Policy\Controller\Policy' => 'Policy\Controller\PolicyController',
        ),
    ),
    
    'router' => array(
        'routes' => array(
            'policy' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/policy[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Policy\Controller\policy',
                        'action'     => 'user',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Policy' => __DIR__ . '/../view/',
        ),
    ),
);