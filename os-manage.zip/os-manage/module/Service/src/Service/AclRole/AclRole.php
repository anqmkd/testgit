<?php
namespace Service\AclRole;

use Zend\Permissions\Acl\Acl;
use Zend\Permissions\Acl\Role\GenericRole as Role;
use Zend\Permissions\Acl\Resource\GenericResource as Resource;

class AclRole extends Acl
{
    public function __construct()
    {
        # add any role
        $this->addRole(new Role('any'));
        # guest
        $this->addRole(new Role('guest'));
        # staff
        $this->addRole(new Role('staff'), 'guest');
        # operator
        $this->addRole(new Role('operator'), 'staff');
        # test
        $this->addRole(new Role('test'), 'operator');
        $this->addRole(new Role('test_princ'), 'test');
        # dev
        $this->addRole(new Role('dev'), 'test');
        # admin
        $this->addRole(new Role('admin'), 'any');
        # add superadmin role
        $this->addRole(new Role('superadmin'), 'admin');

        $this->addResource(new Resource('Whlist'));
        $this->addResource(new Resource('Whlist.whlist'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.list'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.report'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.add'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.update'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.apk'), 'Whlist');
        $this->addResource(new Resource('Whlist.whlist.widget'), 'Whlist');

        $this->addResource(new Resource('Policy'));
        $this->addResource(new Resource('Policy.policy'), 'Policy');
        $this->addResource(new Resource('Policy.policy.user'), 'Policy');
        $this->addResource(new Resource('Policy.policy.market'), 'Policy');
        $this->addResource(new Resource('Policy.policy.claim'), 'Policy');

        $this->addResource(new Resource('Ota'));
        $this->addResource(new Resource('Ota.ota'), 'Ota');
        $this->addResource(new Resource('Ota.ota.index'), 'Ota');

        $this->addResource(new Resource('User'));
        $this->addResource(new Resource('User.user'), 'User');
        $this->addResource(new Resource('User.user.index'), 'User');
        $this->addResource(new Resource('User.user.change'), 'User');

        # machine resource
        $this->addResource('Conf');
        $this->addResource('Conf.data', 'Conf');
        $this->addResource('Machine');
        $this->addResource('Package');
        $this->addResource('Log');
        $this->addResource('Admin');
        $this->addResource('Admin.user', 'Admin');

        # staff
        $this->allow('staff', 'User');

        # superadmin
        $this->allow('any');

        $this->allow('superadmin', 'Admin');
        $this->deny(null, 'Admin');


        # guest
        $this->deny('guest');

        # operator
        $this->deny('operator', NULL, 'delete');
        $this->deny('operator', 'Conf', 'set');
        $this->allow('operator', 'User');
        $this->allow('operator', 'Package');
        $this->allow('operator', 'Log');
        $this->allow('operator', 'Conf');
        $this->allow('operator', 'Conf.data', 'set');
        $this->allow('operator', 'Conf.data', 'delete');
        $this->allow('operator', 'Machine');
        $this->allow('operator', 'Whlist');
        $this->allow('operator', 'Policy');

        # test
        $this->allow('test', 'Conf', 'set');
        $this->allow('test', NULL, 'delete');
    }
}