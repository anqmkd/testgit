<?php
namespace Service\IdCreater;

class IdCreater
{
	const YL_ID_MOBILE 	= 0;
	const YL_ID_PRODUCT = 1;
	const YL_ID_SETTING = 2;
	const YL_ID_TASK 	= 3;
	
	public $strName;
	public $strPrefix;
	public $nId;
	
	public function __construct()
	{
		$this->strName  = '';
		$this->strPrefix = '';
		$this->nId		= 0;
	}
	
	public function setName($nType)
	{
		$strName = '';
		switch ($nType){
			case IdCreater::YL_ID_PRODUCT:
				$strName = 'PRODUCT';break;
			case IdCreater::YL_ID_MOBILE:
				$strName = 'MOBILE';break;
			case IdCreater::YL_ID_SETTING:
				$strName = 'CONFIG';break;
			case IdCreater::YL_ID_TASK:
				$strName = 'TASK';break;
		}
		$this->strName = $strName;
	}
	
	public function setPrefix($strPrefix)
	{
		$this->strPrefix = $strPrefix;
	}
	
	public function exchangeArray($row)
	{
		$this->strName	= isset($row['name'])?$row['name']:'';
		$this->nId		= isset($row['identity'])?$row['identity']:'';
	}
	
	public function getNewIdentity(){
		$this->nId = $this->nId + 1;
		$num = sprintf("%07d", $this->nId);
		$identity = "CPUSH_".$this->strName."_".$num;
		return $identity;
	}
}