<?php
namespace Service\IdCreater;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql;
use Zend\Db\Sql\Select;

use Service\Logs\Logs;

class IdCreaterTable extends AbstractTableGateway
{
	protected $table = 'c_id';
	
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new IdCreater());
		
		$this->initialize();
	}
	
	public function setTable($strTable)
	{
		$this->table = $strTable;
	}
	
	public function lockTable()
	{
		try {
			$sql = 'LOCK TABLES '.$this->table.' WRITE';
			$this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
			
		}catch(Exception $e){
			Logs::write('IdCreaterTable::lockTable() error:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function unlockTable()
	{
		try {
			$sql = 'UNLOCK TABLES';
			$this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
				
		}catch(Exception $e){
			Logs::write('IdCreaterTable::unlockTable() error:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}

	public function getIdentity(IdCreater $idCreater){
		try {
			
			$select = $this->getSql()->select();
			$select->where(array('name' =>$idCreater->strName));
			$rowset = $this->selectWith($select);
			
			$rows = $rowset->current();
			
		}catch(Exception $e){
			Logs::write('IdCreaterTable::getIdentity() error:'.$e->getMessage(), 'log');
			return false;
		}
		return $rows;
	}
	
	public function updateIdentity(IdCreater $idCreater){
		try{
			if(!$idCreater){
				Logs::write('IdCreaterTable::updateIdentity():idCreater is null', 'log');
				return false;
			}
	
			$data = array(
					'identity' 		=> $idCreater->nId
			);
			
			$select = $this->getSql()->select();
			
			if(!$this->update($data, array('name' => $idCreater->strName))){
				Logs::write('IdCreaterTable::updateIdentity():update() failed', 'log');
				return false;
			}
	
		}catch(Exception $e){
			Logs::write('IdCreaterTable::updateIdentity() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function saveIdentity(IdCreater $idCreater){
		try{
			if(!$idCreater){
				Logs::write('IdCreaterTable::saveIdentity():mobile is null', 'log');
				return false;
			}
	
			$data = array(
					'name'		=> $idCreater->strName,
					'identity'	=> $idCreater->nId
			);
	
			if(!$this->insert($data)){
				Logs::write('IdCreaterTable::saveIdentity():insert() failed', 'log');
				return false;
			}
	
		}catch(Exception $e){
			Logs::write('IdCreaterTable::saveIdentity() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function createIdentity($nType)
	{
		$strId = '';
		$bCreater = true;
		$idCreater = new IdCreater();
		$idCreater->setName($nType);
			
		$this->lockTable();
		$idCreater = $this->getIdentity($idCreater);
		if(!$idCreater){
			$bCreater  = false;
			$idCreater = new IdCreater();
			$idCreater->setName($nType);
		}
		
		$strId = $idCreater->getNewIdentity();
		if(empty($strId)){
			return false;
		}
		if(!$bCreater){
			$bResult = $this->saveIdentity($idCreater);
			if(!$bResult){
				return false;
			}
		}else{
			$bResult = $this->updateIdentity($idCreater);
			if(!$bResult){
				return false;
			}
		}
		$this->unlockTable();
		return $strId;
	}
}