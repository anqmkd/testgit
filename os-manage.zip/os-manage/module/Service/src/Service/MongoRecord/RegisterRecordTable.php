<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;
use Service\ManagerFactory;
use Service\Mobile\Mobile;

class RegisterRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_register';
	}
	
	public function saveRecord(Mobile $mobile)
	{
		try {
			$datetime = date('Y-m-d H:i:s');
			$this->addIndex(array('cid'=>1, 'product'=>1, 'meid'=>1, 'cyid'=>1, 'insert_time'=>1));
			$result = $this->_mongo->insert($this->_collection, 
											array( 'cid'=>$mobile->strCid,
												   'product'=>$mobile->strProduct,
												   'meid'=>$mobile->strMeid,
												   'cyid'=>$mobile->strCyid,
												   'mac'=>$mobile->strMac,
												   'insert_time'=>$datetime));
			if($result === false){
				Logs::write('RegisterRecordTable::saveRecord():insert() failed', 'log');
				return false;
			}
			return true;
		}catch (Exception $e){
			Logs::write('RegisterRecordTable::saveRecord() exception, mongErr:'.$this->_getMongo()->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
}