<?php
namespace Service\MongoRecord;
use Service\fnlib\fnlib;
use Service\Mongo\MongoPHP;

class ControlRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{ 
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_set_record_'.date('Y-m-d');
	}
	
	public function saveRecord(ControlRecord $ctrlRecord)
	{
		try {
			$this->addIndex(array('insert_time'=>-1, 'meid'=>1, 'cid'=>1, 'product'=>1, 'software'=>1));
			
			$result = $this->_mongo->insert($this->_collection, fnlib::object_to_array($ctrlRecord));
				
			if($result === false){
				Logs::write('ControlRecordTable::saveRecord() failed', 'log');
				return false;
			}
			return true;
			
		}catch (Exception $e){
			Logs::write('ControlRecordTable::saveRecord() exception, mongErr:'.$this->_mongo->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
		}
		return false;
	}
}