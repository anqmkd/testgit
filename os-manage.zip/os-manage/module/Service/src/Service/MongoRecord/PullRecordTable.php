<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;
use Service\ManagerFactory;
use Service\Task\Task;

class PullRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_pull';
	}
	
	public function setCollection($collection)
	{
		$this->_collection = 'yl_cl_pull_'.$collection;
	}
	
	public function checkRecord($strTaskid, $strCid)
	{
		$this->setCollection($strTaskid);
		$result 	= $this->_mongo->select($this->_collection,
											array('cid'=>$strCid),
											array('status'));
//		Logs::write('PullRecord::checkRecord() result:'.json_encode($result), 'debug');
		if(is_array($result) && count($result) >= 1){
			$nStatus = $result[0]['status'];
			if($nStatus == 1){
				return true;
			}
		}
		
		return false;
	}
	
	public function getStatus($strTaskid, $strCid)
	{
		try {
			$datetime = date('Y-m-d H:i:s');
			$this->setCollection($strTaskid);
			$result 	= $this->_mongo->select($this->_collection,
												array('cid'=>$strCid),
												array('status','count'));
			//Logs::write('PullRecord::getStatus() result:'.json_encode($result), 'debug');
			if(is_array($result) && count($result) >= 1){
				return array('status'=>(int)$result[0]['status'],'count'=>(int)$result[0]['count']);
			}
			return false;
			
		}catch (Exception $e){
			Logs::write('PullRecord::getStatus() exception, mongErr:'.$this->_getMongo()->getError()
															.' err:'
															.' file:'.$e->getFile()
															.' line:'.$e->getLine()
															.' message:'.$e->getMessage()
															.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function getAllPullCount($strTaskid)
	{
		try {
			$this->setCollection($strTaskid);
			$count 	= $this->_mongo->count($this->_collection);
			//Logs::write('PullRecord::getAllPullCount() result:'.$result, 'debug');
			
			return $count;
				
		}catch (Exception $e){
			Logs::write('PullRecord::getAllPullCount() exception, mongErr:'.$this->_getMongo()->getError()
			.' err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
	}
	
	
	public function updateStatus($strTaskid, $strConditon, $nType = 1, $nReset = 0)
	{
		try {
			$datetime = date('Y-m-d H:i:s');
			$this->setCollection($strTaskid);
			if($nType == Task::YL_CPUSH_SEND_TYPE_SINGLE){
				$result = $this->_mongo->update($this->_collection,
												array('updatetime'=>$datetime,
														'status'=>$nReset),
												array('cid'=>$strConditon),
												'set');
			}
			if($nType == Task::YL_CPUSH_SEND_TYPE_GROUP){
				$result = $this->_mongo->update($this->_collection,
												array('updatetime'=>$datetime,
														'status'=>$nReset),
												array('product'=>$strConditon),
												'set');
			}
			
			if($result === false){
				Logs::write('PullRecord::updateStatus() failed', 'log');
				return false;
			}
			return true;
		}catch (Exception $e){
			Logs::write('PullRecord::updateStatus() exception, mongErr:'.$this->_getMongo()->getError()
																		.' err:'
																		.' file:'.$e->getFile()
																		.' line:'.$e->getLine()
																		.' message:'.$e->getMessage()
																		.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function saveRecord($strTaskid, $strCid, $strProduct)
	{
		try {
			$datetime = date('Y-m-d H:i:s');
			$this->setCollection($strTaskid);
			$result 	= $this->_mongo->select($this->_collection, 
												array('cid'=>$strCid), 
												array('count'));
			$nCount = 0;
			if(is_array($result) && count($result) >= 1){
				$nCount = $result[0]['count'];
			}
			if($nCount <= 0){
				$this->addIndex(array('cid'=>1, 'count'=>1, 'product'=>1));
				$result = $this->_mongo->insert($this->_collection, 
												array('cid'=>$strCid,
													   'product'=>$strProduct,
													   'count'=>1,
													   'status'=>1,
													   'inserttime'=>$datetime));
			}else{
				$result = $this->_mongo->update($this->_collection, 
												array('count'=>1), 
												array('cid'=>$strCid), 
												'inc');
				$result = $this->_mongo->update($this->_collection, 
												array('updatetime'=>$datetime, 'status'=>1), 
												array('cid'=>$strCid), 
												'set');
			}
			
			if($result === false){
				Logs::write('PullRecord::savePullRecord() failed', 'log');
				return false;
			}
			return true;
		}catch (Exception $e){
			Logs::write('PullRecord::savePullRecord() exception, mongErr:'.$this->_getMongo()->getError()
											.' err:'
											.' file:'.$e->getFile()
											.' line:'.$e->getLine()
											.' message:'.$e->getMessage()
											.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
		
	}
}