<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;

class ReceiptRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_receipt';
	}
	
	public function setCollection($collection)
	{
		$this->_collection = 'yl_cl_receipt_'.$collection;
	}
	
	public function alterReceipt($strTaskid, $strCid, $arrAction)
	{
		try{
			$datetime = date('Y-m-d H:i:s');
			$this->setCollection($strTaskid);
			$result 	= $this->_mongo->select($this->_collection, 
												array('cid'=>$strCid, 
													  'action'=>$arrAction['assignid']), 
												array('count'));
			if($result <= 0 || !$result){
				$this->addIndex(array('cid'=>1, 'count'=>1));
				$result = $this->_mongo->insert($this->_collection, 
												array('cid'		=> $strCid,
													  'count'		=> 1,
													  'type'	=> isset($arrAction['type'])?$arrAction['type']:0,
													  'assignid'=> isset($arrAction['assignid'])?$arrAction['assignid']:'',
													  'action'	=> isset($arrAction['action'])?$arrAction['action']:'',
													  'inserttime'=> date('Y-m-d H:i:s'),
													  'msgid'	=> isset($arrAction['messageid'])?$arrAction['messageid']:''));
			}else{
				$result = $this->_mongo->update($this->_collection, 
												array('count'=>1), 
												array('cid'=>$strCid, 'action'=>$arrAction['assignid']), 
												'inc');
				$result = $this->_mongo->update($this->_collection, 
												array('updatetime'=>date('Y-m-d H:i:s')), 
												array('cid'=>$strCid, 'action'=>$arrAction['assignid']), 'set');
			}
			if($result === false){
				Logs::write('ReceiptRecord::recordReceipt() failed', 'log');
				return false;
			}
			return  true;
		}catch (Exception $e){
			Logs::write('ReceiptRecord::recordReceipt() exception, mongErr:'.$this->_getMongo()->getError()
																	.' err:'
																	.' file:'.$e->getFile()
																	.' line:'.$e->getLine()
																	.' message:'.$e->getMessage()
																	.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function _getRecord($strProduct, $strCid, $arrAction)
	{
		
		$arrRecord = array('product' => $strProduct,
							'cid'		=> $strCid,
							'count'		=> 1,
							'inserttime'=> date('Y-m-d H:i:s'));

		if(isset($arrAction['type'])){
			$arrRecord['type'] = $arrAction['type'];
		}
		if(isset($arrAction['assignid'])){
			$arrRecord['assignid'] = $arrAction['assignid'];
		}
		if(isset($arrAction['action'])){
			$arrRecord['action'] = $arrAction['action'];
		}
		if(isset($arrAction['messageid'])){
			$arrRecord['msgid'] = $arrAction['messageid'];
		}
		if(isset($arrAction['CPABVersion'])){
			$arrRecord['cpabver'] = $arrAction['CPABVersion'];
		}
		return $arrRecord;
	}
	
	public function saveRecord($strTaskid, $strProduct, $strCid, $arrAction)
	{
		try{
			$this->setCollection($strTaskid);
			$this->addIndex(array('cid'=>1, 'count'=>1, 'action'=>1, 'product'=>1));
			
			$arrRecord = $this->_getRecord($strProduct, $strCid, $arrAction);
			$result = $this->_mongo->insert($this->_collection, $arrRecord);
			if($result === false){
				Logs::write('ReceiptRecord::saveRecord() failed', 'log');
				return false;
			}
			return true;
		}catch (Exception $e){
			Logs::write('ReceiptRecord::saveRecord() exception, mongErr:'.$this->_getMongo()->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function getAllReceiptCount($strTaskid)
	{
		try {
			$this->setCollection($strTaskid);
			$count 	= $this->_mongo->count($this->_collection, array('action'=>'action_receive'));
			
			return $count;
	
		}catch (Exception $e){
			Logs::write('ReceiptRecord::getAllReceiptCount() exception, mongErr:'.$this->_getMongo()->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function getAllReceiptAction($strTaskid)
	{
		try {
			$this->setCollection($strTaskid);
			$keys = array("action" => 1);
			$initial = array("count" => 0);
			$reduce = "function (obj, prev) { prev.count++; }";
			
			$result = $this->_mongo->group($this->_collection, $keys, $initial, $reduce);
				
			return $result;
	
		}catch (Exception $e){
			Logs::write('ReceiptRecord::getAllReceiptCount() exception, mongErr:'.$this->_getMongo()->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
}