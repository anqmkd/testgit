<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;
use Service\ManagerFactory;

abstract class MongoRecordTable
{
	protected $_collection;
	protected $_mongo;
	
	public function __construct($arrConfig)
	{
		$this->_collection = '';
		$this->_mongo	   = new MongoPHP($arrConfig);
	}
	
	public function addIndex($keys)
	{
		try{
			$result = $this->_mongo->getIndexInfo($this->_collection);
			if($result){
				return true;
			}
			foreach ($keys as $key => $value){
				if(is_array($value)){
					$index = $value;
				}else {
					$index = array($key=>$value);
				}
				$bResult = $this->_mongo->ensureIndex($this->_collection, $index);
				if(!$bResult){
					Logs::write('MongoRecordTable::addIndex():ensureIndex() failed, collection:'.$this->_collection, 'log');
					return false;
				}
			}	
			return true;
		}catch (Exception $e){
			Logs::write('MongoRecordTable::addIndex() exception, mongErr:'.$this->_mongo->getError()
					.' err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
		}
		return false;
	}
	
	
}