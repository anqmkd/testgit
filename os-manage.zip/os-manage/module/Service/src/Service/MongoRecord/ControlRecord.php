<?php
namespace Service\MongoRecord;

class ControlRecord
{
	public $cid;					//CPUSH唯一标识
	public $product;				//产品
	public $sn;						//手机标识
	public $imei;					//手机标识
	public $meid;					//手机标识
	public $imsi;					//手机标识
	public $mac;					//手机标识
	public $cyid;					//手机标识
	public $appver;					//应用版本
	public $cpabver;				//自升级版本
	public $version;				//系统外部版本
	public $software;				//系统内部版本
	public $cpbinfo;				//系统生产号
	public $buildtype;				//编译类型
	public $vertype;				//版本类型
	public $active;					//是否激活
	public $prover;					//协议版本
	public $provername;				//协议版本名
	public $oldtimemark;			//上次升级时间戳
	public $record;					//设置结果
	public $setid;					//设置ID
	public $insert_time;
	
	public function __construct()
	{
		$this->cid	    	= ''; 
		$this->product   	= ''; 
		$this->sn			= '';
		$this->imei			= '';
		$this->meid			= '';
		$this->imsi			= '';
		$this->mac			= '';
		$this->cyid			= '';
		$this->appver		= '';				
		$this->version		= '';
		$this->software		= '';
		$this->buildtype	= '';
		$this->vertype		= '';
		$this->active		= 0;
		$this->prover 		= '';
		$this->provername 	= '';
		$this->oldtimemark 	= '';
		$this->record		= '';
		$this->setid		= '';
		$this->insert_time	= date("Y-m-d H:i:s");
	}
	
	public function setRecord($strCid, $strProduct, 
							  $strSn, $strImei, $strMeid, $strImsi, $strMac, $strCyid,
							  $strAppVer, $strVerCpab, $strVersion, $strSoftware, $strCpbinfo,
							  $strBuildType, $strVertype,
							  $strProtocolVer, $strProtocolVerName, $strSetId,
							  $strOldTimeMark)
	{
		$this->cid		= $strCid;
		$this->product  = $strProduct;
		$this->sn		= $strSn;
		$this->imei		= $strImei;
		$this->meid		= $strMeid;
		$this->imsi		= $strImsi;
		$this->cyid		= $strCyid;
		$this->mac		= $strMac;
		$this->appver	= $strAppVer;
		$this->cpabver	= $strVerCpab;
		$this->version	= $strVersion;
		$this->software	= $strSoftware;
		$this->buildtype= $strBuildType;
		$this->vertype	= $strVertype;
		$this->prover	= $strProtocolVer;
		$this->provername = $strProtocolVerName;
		$this->oldtimemark = $strOldTimeMark;
		$this->setid		= $strSetId;
	}
	
	public function setResult($strRecord)
	{
		$this->record	= $strRecord;
	}
}