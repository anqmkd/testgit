<?php
namespace Service\Whlist;
class WhiteList extends ApkInfo
{	
    public $nLevelId;			//APK安全级别
    public $strLevelName;       //安全级别名称
    public $nFlag;              //固件版本标识
    
    const SECURE_LEVEL_0 = 0;		//未设置安全级别
    const SECURE_LEVEL_1 = 1;		//一级白名单
    const SECURE_LEVEL_2 = 2;		//二级白名单

    public $nType;
    public $nPage;
    public $nPageCount;
    public $nCount;
	
	public function __construct()
    {
        $this->nLevelId			= '';
        $this->strLevelName     = 0;
        $this->nFlag            = 1;
        $this->nCount            = 0;

    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
    	$this->strType		= isset($row['type'])?$row['type']:'';
        $this->strPackage	= isset($row['package'])?$row['package']:'';
        $this->strName		= isset($row['name'])?$row['name']:'';
    	$this->strVersion	= isset($row['version'])?$row['version']:'';
    	$this->nLevelId		= isset($row['level_id'])?$row['level_id']:'';
    	$this->strAttributeCode	= isset($row['attribute_code'])?$row['attribute_code']:'';
    	$this->strDownloadUrl	= isset($row['dl_url'])?$row['dl_url']:'';
    	$this->strIconUrl		= isset($row['icon_url'])?$row['icon_url']:'';
        $this->strMd5			= isset($row['md5'])?$row['md5']:'';
        $this->strSign			= isset($row['sign'])?$row['sign']:'';
        $this->strActivity		= isset($row['activity'])?$row['activity']:'';
        $this->strLevelName		= (int)isset($row['level_name'])?$row['level_name']:'';
    	$this->update_time		= isset($row['update_time'])?$row['update_time']:'';
        $this->nFlag		= isset($row['flag'])?$row['flag']:'';
        $this->nCount		    = isset($row['count'])?$row['count']:'';
    }
    
    public function setLevelId($nLevelId)
    {
    	$this->nLevelId = $nLevelId;
    }

    public function setId($strId){
        $this->strId = $strId;
    }
    public function setFlag($nFlag){
        $this->nFlag = $nFlag;
    }

    public function setType($nType){
        $this->nType = $nType;
    }
    public function setPageInfo($nPage, $nPageCount){
        $this->nPage = $nPage;
        $this->nPageCount = $nPageCount;
    }
    
    public function getCondition(){
    	$strCondition = '';
    	if ($this->nLevelId != -1){
    		$strCondition .= sprintf(" AND tb_qiku_apk_white_list.level_id = %d ", $this->nLevelId);
    	}
    	
    	if (!empty($this->strName)){
            $strLike = "%".$this->strName."%";
    		$strCondition .= sprintf(" AND name like '%s'", $strLike);
    	}
    	 
    	return $strCondition;
    }
    
}