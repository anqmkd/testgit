<?php
namespace Service\Whlist;
class SecureLevel
{	
	public $nLevelId;			//级别ID
	public $strLevelName;		//用户ID
	public $strNote;			//备注
	
	public function __construct()
    {
    	$this->nLevelId			= '';
		$this->strLevelName		= '';
		$this->strNote			= '';
    } 
	
    public function exchangeArray($row)
    {
    	$this->nLevelId			= isset($row['level_id'])?$row['level_id']:'';
    	$this->strLevelName		= isset($row['level_name'])?$row['level_name']:'';
    	$this->strNote			= isset($row['note'])?$row['note']:'';
    }  
    
    public function setParam($strLevelName, $strNote)
    {
    	$this->strLevelName		= $strLevelName;
    	$this->strNote			= $strNote;
    }
    
    public function getCondition($strBusinessId, $strUserId, $strRuleId = '', $nowTime = ''){
    	$strCondition = '';
    	 
    	return $strCondition;
    } 
    
}