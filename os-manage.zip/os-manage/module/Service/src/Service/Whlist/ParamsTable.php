<?php
namespace Service\Whlist;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class ParamsTable extends AbstractTableGateway
{
	protected $table = 'tb_qiku_global_param';
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new GParams());

		$this->initialize();
	}

	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function updateParamValue(GParams $param)
	{
		try{
			$data = array(
					'value'  		=> $param->strValue
			);
			if(!$this->update($data, array('name' => $param->strName))){
				Logs::write('ParamsTable::updateParamValue():update() failed', 'log');
				return false;
			}
		}catch(\Exception $e){
			Logs::write('ParamsTable::updateParamValue() exception, '
					.' message:'.$e->getMessage(), 'log');
					return false;
		}
		
		return true;
	}
	
	public function saveParam(GParams $param){
		try{			 
			$data = array(
					'name' 		=> $param->strName,
					'value' 	=> $param->strValue
			);
			 
			$result = $this->insert($data);
			if(!$result){
				Logs::write('ParamsTable::saveParam():insert() failed', 'log');
				return false;
			}
		}catch(\Exception $e){
			Logs::write('ParamsTable::saveParam() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function isHaveSameParam(GParams $param)
	{
		try {
			$strCondition = sprintf(" AND  name='%s' ",  $param->strName);
			$select = $this->getSql()->select();
			$select->where("1=1 ".$strCondition);
			$rowset = $this->selectWith($select);
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(\Exception $e){
			Logs::write('ParamsTable::isHaveSameParam() error:'
					.' message:'.$e->getMessage(), 'log');
					return false;
		}
		return $rows;
	}
	
}