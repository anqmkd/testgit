<?php
namespace Service\Whlist;
class GParams
{	
	public $strId;			    //table ID
    public $strName;          	//参数名称
    public $strValue;           //参数值
	public $nType;				//
	
	public function __construct()
    {
    	$this->strId		= '';
		$this->nType		= 0;
		$this->strValue		= '';
        $this->strName      = '';
    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
        $this->strValue		= isset($row['value'])?$row['value']:'';
        $this->strName		= isset($row['name'])?$row['name']:'';
    	$this->nType		= (int)isset($row['type'])?$row['type']:'';
    }
    
    public function setParamName($strName = "version")
    {
    	$this->strName = $strName;
    }
   
    public function setParamValue($strValue)
    {
    	$this->strValue = $strValue;
    }
    
}