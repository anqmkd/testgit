<?php
namespace Service\Whlist;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class WidgetListTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_apk_widget';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new WidgetList());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getWidgetList()
    {
        try {
            $select = $this->getSql()->select();
            $select->where('1=1 ');
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('WidgetListTable::getWidgetList() error:'
                                        .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function setWidgetStatus(WidgetList $list)
    {
        try {
            $data = array(
                'status'      => $list->nStatus,
                'update_time'   => $list->update_time
            );

            // update返回的是 affected rows数目，数据没修改的话，返回0
            if (!$this->update($data, array('id' => $list->strId))) {
                Logs::write('WidgetListTable::setWidgetStatus():update() failed', 'log');
                return false;
            }
        } catch(\Exception $e) {
            Logs::write('WidgetListTable::setWidgetStatus() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }

        return true;
    }

    public function saveWidget(WidgetList $list){
        try{
            $data = array(
                    'content'   => $list->strContent,
                    'status'      => $list->nStatus
            );

            $result = $this->insert($data);
            if(!$result){
                Logs::write('WidgetListTable::saveWidget():insert() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('WidgetListTable::saveWidget() exception, err:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }

    public function updateWidget(WidgetList $list)
    {
        try{
            $data = array(
                    'content'       => $list->strContent,
                    'status'      => (int)($list->nStatus),
                    'update_time'   => $list->update_time
            );

            if(!$this->update($data, array('id' => $list->strId))){
                Logs::write('WidgetListTable::updateWidget():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('WidgetListTable::updateWidget() exception, '
                    .' message:'.$e->getMessage(), 'log');
                    return false;
        }
        return true;
    }
}