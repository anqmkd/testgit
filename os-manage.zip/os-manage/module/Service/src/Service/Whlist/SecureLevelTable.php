<?php
namespace Service\Whlist;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class SecureLevelTable extends AbstractTableGateway
{
	protected $table = 'tb_qiku_secure_level';
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new SecureLevel());

		$this->initialize();
	}

	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getAllLevelInfo()
	{
		try {
			$select = $this->getSql()->select();
			$select->where("1=1 ");
			$rowset = $this->selectWith($select);
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(\Exception $e){
			Logs::write('SecureLevelTable::getAllLevelInfo() error:'
					.' message:'.$e->getMessage(), 'log');
					return false;
		}
		return $rows;
	}
}