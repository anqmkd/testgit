<?php
namespace Service\Whlist;
class ApkInfo
{	
	public $strId;			    //table ID
    public $strName;          	//APK名称
    public $strPackage;			//APK包名
    public $strVersion;         //APK版本号
    public $strType;			//APK类型
	public $strAttributeCode;	//特征码
	public $strIconUrl;			//APK icon地址
	public $strDownloadUrl;		//APK下载地址
	public $strMd5;				//APK Md5
    public $strSign;            //签名
    public $strActivity;        //支付activity
	public $update_time;		//更新时间
	
	public function __construct()
    {
    	$this->strId			= '';
    	$this->strType			= '';
		$this->strName			= '';
		$this->strPackage		= '';
        $this->strVersion      	= '';
        $this->strAttributeCode	= '';
        $this->strDownloadUrl	= '';
        $this->strIconUrl		= '';
        $this->strMd5			= '';
        $this->strSign          = '';
        $this->strActivity     = '';
		$this->update_time		= date('Y-m-d H:i:s');
    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
    	$this->strType		= isset($row['type'])?$row['type']:'';
        $this->strPackage	= isset($row['package'])?$row['package']:'';
        $this->strName		= isset($row['name'])?$row['name']:'';
    	$this->strVersion	= isset($row['version'])?$row['version']:'';
    	$this->strAttributeCode	= isset($row['attribute_code'])?$row['attribute_code']:'';
    	$this->strDownloadUrl	= isset($row['dl_url'])?$row['dl_url']:'';
    	$this->strIconUrl		= isset($row['icon_url'])?$row['icon_url']:'';
    	$this->strMd5			= isset($row['md5'])?$row['md5']:'';
    	$this->update_time		= isset($row['update_time'])?$row['update_time']:'';
    }
    
    public function setId($strId){
    	$this->strId = $strId;
    }
    
    public function setPackage($strPackageName){
    	$this->strPackage = trim($strPackageName);
    }
    
    public function setApkName($strApkName){
    	$this->strName = $strApkName;
    }
    
    public function setVersion($strVersion){
    	$this->strVersion = $strVersion;
    }
    
    public function setApkMd5($strMd5){
    	$this->strMd5 = $strMd5;
    }

    public function setApkActivity($strActivity){
        $this->strActivity = $strActivity;
    }
    
}