<?php
namespace Service\Whlist;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class ApkListTable extends AbstractTableGateway
{
	protected $table = 'tb_qiku_apk_list';
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new ApkList());

		$this->initialize();
	}

	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getApkList($strCondition)
	{
		try {
			$select = $this->getSql()->select();
			$select->where('1=1 '.$strCondition);
            $select->order("insert_time desc");
			$rowset = $this->selectWith($select);
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(\Exception $e){
			Logs::write('ApkListTable::getApkList() error:'
					.' message:'.$e->getMessage(), 'log');
					return false;
		}
		return $rows;
	}
	
	public function setStatus(ApkList $apk)
	{
		try{
			$data = array(
					'status'  		=> $apk->nStatus,
					'update_time' 	=> $apk->update_time
			);
			if(!$this->update($data, array('id' => $apk->strId))){
				Logs::write('ApkListTable::setStatus():update() failed', 'log');
				return false;
			}
		}catch(\Exception $e){
			Logs::write('ApkListTable::setStatus() exception, '
					.' message:'.$e->getMessage(), 'log');
					return false;
		}
		return true;
	}
	
	
	
}