<?php
namespace Service\Whlist;
class ApkList extends ApkInfo
{
    public $nStatus;
    
    const APK_STATUS_0 = "0";		//待处理
    const APK_STATUS_1 = "1";		//已添加
    const APK_STATUS_2 = "2";		//无效

    public function __construct(){
        $this->nStatus = "";
    }

    public function exchangeArray($row)
    {
        $this->strId		= isset($row['id'])?$row['id']:'';
    	$this->strType		= isset($row['type'])?$row['type']:'';
        $this->strPackage	= isset($row['package'])?$row['package']:'';
        $this->strName		= isset($row['name'])?$row['name']:'';
    	$this->strVersion	= isset($row['version'])?$row['version']:'';
    	$this->nStatus		= isset($row['status'])?$row['status']:'';
    	$this->strAttributeCode	= isset($row['attribute_code'])?$row['attribute_code']:'';
    	$this->strDownloadUrl	= isset($row['dl_url'])?$row['dl_url']:'';
    	$this->strIconUrl		= isset($row['icon_url'])?$row['icon_url']:'';
    	$this->strMd5			= isset($row['md5'])?$row['md5']:'';
        $this->strSign			= isset($row['sign'])?$row['sign']:'';
        $this->strActivity		= isset($row['activity'])?$row['activity']:'';
    	$this->update_time		= isset($row['update_time'])?$row['update_time']:'';
    }

    public function setApkStatus($nStatus){
        $this->nStatus = $nStatus;
    }

    public function getCondition(){
    	$strCondition = '';
    	if (($this->nStatus != -1 && !empty($this->nStatus)) || $this->nStatus == "0"){
    		$strCondition .= sprintf(" AND tb_qiku_apk_list.status = %d ", $this->nStatus);
    	}
    	 
    	if (!empty($this->strName)){
            $strLike = "%".$this->strName."%";
    		$strCondition .= sprintf(" AND name like '%s'", $strLike);
    	}
    	
    	if (!empty($this->strId)){
    		$strCondition .= sprintf(" AND id = %d", $this->strId);
    	}
    
    	return $strCondition;
    }
}