<?php
namespace Service\Whlist;
class WidgetList
{
    public $strId;              //table id
    public $strContent;			//widget内容
    public $nStatus;            //状态 0 默认 1 显示 2 隐藏
    public $update_time;           //更新时间
    public $insert_time;            //插入时间
    
    const STATUS_0 = 0;		//无效
    const STATUS_1 = 1;		//显示
    const STATUS_2 = 2;		//隐藏
	
	public function __construct()
    {
        $this->strId = '';
        $this->strContent			= '';
        $this->nStatus     = 0;
        $this->insert_time = '';
        $this->update_time = date("Y-m-d H:i:s", time());
    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
    	$this->strContent		= isset($row['content'])?$row['content']:'';
        $this->nStatus	= isset($row['status'])?$row['status']:0;
    	$this->update_time		= isset($row['update_time'])?$row['update_time']:'';
        $this->insert_time		= isset($row['insert_time'])?$row['insert_time']:'';
    }

    public function setId($id)
    {
        $this->strId = $id;
    }
    
    public function setStatus($nStatus)
    {
    	$this->nStatus = $nStatus;
    }

    public function setContent($strContent){
        $this->strContent = $strContent;
    }
    
    public function getCondition(){
    	$strCondition = '';
    	 
    	return $strCondition;
    }
    
}