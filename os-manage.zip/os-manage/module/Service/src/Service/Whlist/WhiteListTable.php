<?php
namespace Service\Whlist;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class WhiteListTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_apk_white_list';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new WhiteList());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getWhiteList($strCondition, $nPageNum, $nPageCount)
    {
        try {
            $offset = ($nPageNum -1)*$nPageCount;
            $select = $this->getSql()->select();
            $select->join(array("level"=>"tb_qiku_secure_level"), "tb_qiku_apk_white_list.level_id = level.level_id", array("level_name"), $select::JOIN_LEFT);
            $select->where('1=1 '.$strCondition);
            $select->order('id asc');
            $select->offset($offset);
            $select->limit($nPageCount);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('WhiteListTable::getWhiteList() error:'
                                        .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function getCountList($strCondition = '')
    {
        try {
            $select = $this->getSql()->select();
            $select->columns(array('count'=>new Expression('COUNT(*)')), false);
            $select->where('1=1 '.$strCondition);
            $rowset = $this->selectWith($select);
            $row = $rowset->current();
            $nCount = $row->nCount;
        }catch(\Exception $e){
            Logs::write('WhiteListTable::getCountList() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $nCount;
    }

    public function isHaveSameRecord(WhiteList $list)
    {
        try {
            $strCondition = sprintf(" AND package = '%s' ", $list->strPackage);
            $select = $this->getSql()->select();
            $select->where("1=1 ".$strCondition);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('WhiteListTable::isHaveSameRecord() error:'
                    .' message:'.$e->getMessage(), 'log');
                    return false;
        }
        return $rows;
    }

    public function setApkLevel(WhiteList $list)
    {
        try {
            $data = array(
                'level_id'      => $list->nLevelId,
                'update_time'   => $list->update_time
            );

            // update返回的是 affected rows数目，数据没修改的话，返回0
            if (!$this->update($data, array('id' => $list->strId))) {
                Logs::write('WhiteListTable::setApkLevel():update() failed', 'log');
                return false;
            }
        } catch(\Exception $e) {
            Logs::write('WhiteListTable::setApkLevel() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }

        return true;
    }

    public function saveApkWhite(WhiteList $list){
        try{
            $data = array(
                    'package'   => $list->strPackage,
                    'name'      => $list->strName,
                    'level_id'  => $list->nLevelId,
                    'version'	=> $list->strVersion,
                    'md5'		=> $list->strMd5,
                    'activity'=> $list->strActivity
            );

            $result = $this->insert($data);
            if(!$result){
                Logs::write('WhiteListTable::saveApkWhite():insert() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('WhiteListTable::saveApkWhite() exception, err:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }

    public function updateWhite(WhiteList $list)
    {
        try{
            $data = array(
                    'package'       => $list->strPackage,
                    'name'      => $list->strName,
                    'level_id'  => $list->nLevelId,
                    'version'       => $list->strVersion,
                    'md5'           => $list->strMd5,
                    'activity'    => $list->strActivity,
                    'update_time'   => $list->update_time
            );
            if(!$this->update($data, array('id' => $list->strId))){
                Logs::write('WhiteListTable::updateWhite():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('WhiteListTable::updateWhite() exception, '
                    .' message:'.$e->getMessage(), 'log');
                    return false;
        }
        return true;
    }

    public function updateFlag(WhiteList $info){
        try{
            $data = array();
            if($info->nType == 1){
                $data['flag'] = $info->nFlag;
            }

            if(!$this->update($data, array('id' => $info->strId))){
                Logs::write('WhiteListTable::updateFlag():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('WhiteListTable::updateFlag() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }
}