<?php
namespace Service\Templet;

use Zend\Text\Table\Table;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class CardInfoTable extends AbstractTableGateway
{
	protected $table = 'tb_yl_browser_templet_info';
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new TempletInfo());

		$this->initialize();
	}

	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getCardListAndSort()
	{
		try {			
			$select = $this->getSql()->select();
            $select->join(array("co"=>"tb_yl_browser_card_order"), "tb_yl_browser_card_info.card_id = co.card_id", array(), $select::JOIN_LEFT);
			$select->where('1=1 AND tb_yl_browser_card_info.status != 0');
			$select->order('order ASC');
			$rowset = $this->selectWith($select);
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('CardInfoTable::getCardListAndSort() error:'
										.' file:'.$e->getFile()
										.' line:'.$e->getLine()
										.' message:'.$e->getMessage()
										.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
		return $rows;
	}
	
	public function isHaveSameCard(CardInfo $card)
	{
		try {
            $strCondition = sprintf(" AND (card_id = '%s' OR name='%s' )", $card->strCardId, $card->strName);
			$select = $this->getSql()->select();
			$select->where("1=1 ".$strCondition);
			$rowset = $this->selectWith($select);
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('CardInfoTable::isHaveSameCard() error:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
		return $rows;
	}
	
	public function setStatus(CardInfo $card)
	{
		try{
			$data = array(
					'status'  		=> $card->nStatus,
                    'update_time' => $card->update_time
			);
			if(!$this->update($data, array('card_id' => $card->strCardId))){
				Logs::write('CardInfoTable::setStatus():update() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('CardInfoTable::setStatus() exception, '
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace'.$e->getTraceAsString(), 'log');
					return false;
		}
		return true;
	}
	
	public function saveCard(CardInfo $card){
		try{			 
			$data = array(
					'card_id' 	=> $card->strCardId,
					'name' 	=> $card->strName,
					'status' 	=> $card->nStatus
			);
			 
			$result = $this->insert($data);
			if(!$result){
				Logs::write('CardInfoTable::saveCard():insert() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('CardInfoTable::saveCard() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function updateResource(Source $source){
		try{
			$data = array(
					'title'			=> $source->strTitle,
					'content'		=> $source->strContent,
					'url'			=> $source->strUrl,
					'status'		=> $source->nStatus,
			);
	
			if(!$this->update($data, array('id' => $source->strId))){
				Logs::write('SourceTable::updateResource():update() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('SourceTable::updateResource() exception,  err:'
						.' file:'.$e->getFile()
						.' line:'.$e->getLine()
						.' message:'.$e->getMessage()
						.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
		return true;
	}
	
}