<?php
namespace Service\Templet;
class CardTempletInfo
{	
	public $strId;			    //Table ID
    public $strCardId;          //卡片ID
    public $strTempletId;       //模板ID
	public $nValid;			    //有效性：0 无效 1 使用中
	public $update_time;		//更新时间
	
	public $strTempletName;
	public $strTempletUrl;
	public $strTempletNote;

	public function __construct()
    {
    	$this->strId		= '';
		$this->strCardId	= '';
		$this->strTempletId	= '';
        $this->nValid      	= 0;
		$this->update_time	= date('Y-m-d H:i:s');
		
		$this->strTempletName = '';
		$this->strTempletNote = '';
		$this->strTempletUrl = '';
    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
        $this->nValid		= isset($row['valid'])?$row['valid']:'';
        $this->strCardId	= isset($row['card_id'])?$row['card_id']:'';
    	$this->strTempletId	= isset($row['templet_id'])?$row['templet_id']:'';
        $this->strTempletName	= isset($row['templet_name'])?$row['templet_name']:'';
    	$this->strTempletNote	= isset($row['note'])?$row['note']:'';
    	$this->strTempletUrl	= isset($row['url'])?$row['url']:'';
    	$this->update_time	= isset($row['update_time'])?$row['update_time']:'';
    	
    	$this->strTempletUrl = "http://browser_card.yl.com/".$this->strTempletUrl;
    }
    
    public function setCardId($strCardId)
    {
    	$this->strCardId = $strCardId;
    }
    
    public function setValid($nValid)
    {
    	$this->nValid = $nValid;
    }
    
    public function getCondition($strCardId, $nValid = 0){
    	$strCondition = '';
    	if ($nValid == 0){
    		$strCondition .= sprintf(" AND tb_yl_browser_card_templet.card_id = '%s' ", $strCardId);
    	}else{
    		$strCondition .= sprintf(" AND tb_yl_browser_card_templet.card_id = '%s' AND tb_yl_browser_card_templet.valid = %d ", $strCardId, $nValid);
    	}
    	
		return $strCondition;
    }
    
}