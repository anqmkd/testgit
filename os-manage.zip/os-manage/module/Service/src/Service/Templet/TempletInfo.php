<?php
namespace Service\Templet;
class TempletInfo
{	
	public $strId;			    //模板ID
    public $strType;            //模板类型
    public $strName;            //模板名称
	public $strUrl;			    //模板地址
	public $strNote;			//备注
	public $update_time;		//更新时间

	public function __construct()
    {
    	$this->strId		= '';
		$this->strType		= 0;
		$this->strName		= '';
        $this->strUrl      	= '';
        $this->strNote		= '';
		$this->update_time	= date('Y-m-d H:i:s');
    } 
	
    public function exchangeArray($row)
    {
    	$this->strId		= isset($row['id'])?$row['id']:'';
        $this->strType		= isset($row['type'])?$row['type']:'';
        $this->strName		= isset($row['name'])?$row['name']:'';
    	$this->strUrl		= isset($row['url'])?$row['url']:'';
        $this->strNote		= isset($row['note'])?$row['note']:'';
    	$this->update_time	= isset($row['update_time'])?$row['update_time']:'';
    }
    
    public function setCardId($strCardId)
    {
    	$this->strCardId = $strCardId;
    }
   
    public function setCardInfo($strName,  $nStatus)
    {
    	$this->strName 	= $strName;
    	$this->nStatus 	= $nStatus;
    }
    
    public function setStats($nStats)
    {
    	$this->nStatus = $nStats;
    }
    
    public function getTaskCondition($strAppid, $tSTime, $tETime, $tValid){
    	$strCondition = '';
    	if (!empty($strAppid)){
    		$strCondition .= sprintf(" AND c_task.appid = '%s' ", $strAppid);
    	}
    	 
    	if (!empty($tSTime)) {
    		$strCondition .= sprintf(" AND c_task.insert_time >= '%s'", $tSTime);
    	}
    	 
    	if (!empty($tETime)) {
    		$strCondition .= sprintf(" AND c_task.insert_time <= '%s'", $tETime);
    	}
    	
    	$strCondition .= sprintf(" AND c_task.valid = %d", $tValid);
    	 
    	return $strCondition;
    }
    
}