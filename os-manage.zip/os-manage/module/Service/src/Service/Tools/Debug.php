<?php

namespace Service\Tools;

/**
 * 输出调试信息，根据外界参数xdebug
 */

use Data\Verify as D;

class Debug
{
    // 流程位置
    const FLOW = 'manage';

    // debug级别：打印最重要的, step/时间
    const DEBUG_IMPORTANT = 1;

    // debug级别：打印普通信息, step/时间/配置/结果
    const DEBUG_NORMAL = 2;

    // debug级别：全部打印, step/时间/配置/结果/自定义信息
    const DEBUG_ALL = 3;

    // 普通信息
    private static $info = [];
    // 时间
    private static $time = [];
    // 步骤
    private static $step = [];
    // 配置
    private static $config = [];
    // 结果
    private static $result = [];
    // 最后的时间点
    private static $lastTime = null;

    /**
     * 导出
     * @param Enum $level debug级别, 默认全部打印
     * @param Boolean $echo 是否echo打印, 默认true
     */
    public static function export($level = self::DEBUG_ALL, $echo = true)
    {
        switch ($level) {
        case self::DEBUG_IMPORTANT:
            $output = [
                'step' => self::$step,
                'time' => self::$time
            ];
            break;
        case self::DEBUG_NORMAL:
            $output = [
                'step' => self::$step,
                'time' => self::$time,
                'config' => self::$config,
                'result' => self::$result
            ];
            break;
        case self::DEBUG_ALL:
        default:
            $output = [
                'step' => self::$step,
                'time' => self::$time,
                'config' => self::$config,
                'info' => self::$info,
                'result' => self::$result
            ];
        }

        if ($echo) {
            echo json_encode([self::FLOW => $output]);
        }

        return $output;
    }

    /**
     * 输入debug信息
     * @param string $mark
     * @param string/array $msg
     */
    public static function inport($msg)
    {
        return self::info($msg);
    }

    /**
     * 和inport同等，推荐使用info
     */
    public static function info($msg)
    {
        self::$info[] = $msg;

        return true;
    }

    /**
     * 引入关键步骤
     */
    public static function step($msg)
    {
        self::$step[] = $msg;

        return true;
    }

    /**
     * 引入配置信息
     */
    public static function config($tip, $value)
    {
        D::set(self::$config, $tip, $value);

        return true;
    }

    public static function result($msg)
    {
        self::$result[] = $msg;

        return true;
    }

    public static function time($tip)
    {
        $time =  intval((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000);
        $use = 0;
        if (!is_null(self::$lastTime)) {
            $use = $time - self::$lastTime;
        }

        self::$lastTime = $time;

        D::set(self::$time, $tip, [
                'use' => $use,
            'begin' => $time
            ]
        );

        return true;
    }

    public static function timeBegin($tip)
    {
        $timePoint = intval((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000);
        D::set(self::$time, $tip . '.begin', $timePoint);
        self::$lastTime = D::get(self::$time, $tip . '.begin');
    }

    public static function timeEnd($tip)
    {
        $timePoint = intval((microtime(true) - $_SERVER['REQUEST_TIME_FLOAT']) * 1000);
        D::set(self::$time, $tip . '.end', $timePoint);
        D::set(self::$time, $tip . '.use', D::get(self::$time, $tip . '.end') - D::get(self::$time, $tip . '.begin'));
        self::$lastTime = D::get(self::$time, $tip . '.end');
    }

    public static function recordToLog()
    {
        return true ;
    }
}