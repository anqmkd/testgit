<?php

// a simple foreach() to traverse the SPL class names
function searchSplClass()
{
	foreach(spl_classes() as $key=>$value)
	{
		echo $key.' -&gt; '.$value.'<br />';
	}	
}

function searchDir()
{
	try{
		/*** class create new DirectoryIterator Object ***/
		foreach ( new DirectoryIterator('./') as $Item )
		{
			echo $Item.'<br />';
		}
	}
	/*** if an exception is thrown, catch it here ***/
	catch(Exception $e){
		echo 'No files Found!<br />';
	}
}

require_once 'ApkTools.php';
function tools_unit_test()
{
	$arrApkParam = ApkTools::getApkParam('d:/apktools/', 'd:/apktools/a.apk');
	if(isset($arrApkParam['icon'])){

		$iconFile = ApkTools::getAkpIcon('d:/apktools/', $arrApkParam['icon']);
	}
}
tools_unit_test();
?>