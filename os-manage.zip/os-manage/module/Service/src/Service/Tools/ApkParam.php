<?php
namespace Service\Tools;

class ApkParam
{
	private $_package;					//包名信息
	private $_versionCode;				//版本代码
	private $_versionName;				//版本名字
	private $_filename;					//apk文件名字
	private $_thumbimg;					//图片信息
	
	public function __construct(){
		$this->_package 	= '';
		$this->_versionCode = '';
		$this->_versionName = '';
		$this->_filename 	= '';
		$this->_thumbimg 	= '';
	}
	
	public function setApkParam($arrParam){
		$this->_package 	= $arrParam['package'];
		$this->_versionCode = $arrParam['versionCode'];
		$this->_versionName = $arrParam['versionName'];
		$this->_filename 	= $arrParam['filename'];
		$this->_thumbimg 	= $arrParam['thumbimg'];
		
	}
	
	public function getPackage(){
		$result = $this->_package;
		return $result;
	}
	
	public function getVersionCode(){
		$result = $this->_versionCode;
		return $result;
	}
	
	public function getVersionName(){
		$result = $this->_versionName;
		return $result;
	}
	
	public function getFileName(){
		$result = $this->_filename;
		return $result;
	}
	
	public function getThumbImg(){
		$result = $this->_thumbimg;
		return $result;
	}
	
}