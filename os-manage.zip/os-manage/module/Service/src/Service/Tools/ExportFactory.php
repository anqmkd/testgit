<?php
namespace Service\Tools;
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/9/8
 * Time: 15:46
 */
class ExportFactory
{
    public function __construct(){

    }

    public function getExportHeader($arrData){
        $i = 0;
        foreach ($arrData as $row){
            $temp = array_keys($row);
            foreach ($temp as $key){
                $arr_header[$this->_getHeaderTitle($i)] = $this->_getChineseTitle($key);
                ++ $i;
            }
            break;
        }

        return $arr_header;
    }

    private function _getHeaderTitle($title){
        switch($title){
            case 0:
                return 'A1';
                break;
            case 1:
                return 'B1';
                break;
            case 2:
                return 'C1';
                break;
            case 3:
                return 'D1';
                break;
            case 4:
                return 'E1';
                break;
            case 5:
                return 'F1';
                break;
            case 6:
                return 'G1';
                break;
            case 7:
                return 'H1';
                break;
            case 8:
                return 'I1';
                break;
            case 9:
                return 'J1';
                break;
            case 10:
                return 'K1';
                break;
            case 11:
                return 'L1';
                break;
            case 12:
                return 'M1';
                break;
            case 13:
                return 'N1';
                break;
            case 14:
                return 'O1';
                break;
            case 15:
                return 'P1';
                break;
            case 16:
                return 'Q1';
                break;
            case 17:
                return 'R1';
                break;
            case 18:
                return 'S1';
                break;
            case 19:
                return 'T1';
                break;
            case 20:
                return 'U1';
                break;
            case 21:
                return 'V1';
                break;
            case 22:
                return 'W1';
                break;
            case 23:
                return 'X1';
                break;
            case 24:
                return 'Y1';
                break;
            case 25:
                return 'Z1';
                break;
            default:
                break;
        }
    }
    private function _getChineseTitle($title){
        switch($title){
            case 'name':
                return '姓名';
                break;
            case 'id_card':
                return '身份证';
                break;
            case 'phone':
                return '手机号';
                break;
            case 'deviceid':
                return '终端标识';
                break;
            case 'price':
                return '手机价格';
                break;
            case 'insert_time':
                return '开通时间';
                break;
            default:
                break;
        }
    }

    public function getXlsName($type){
        $report = $this->setTitle($type);
        $t = date("ymdHis");
        return $t.'_'.$report;
    }

    function setTitle($type){
        switch ($type){
            case 1:
                $name = '盗抢险用户信息';
                break;
            default:
                break;
        }

        return $name;
    }
}