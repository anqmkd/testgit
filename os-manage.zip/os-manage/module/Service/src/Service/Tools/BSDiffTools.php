<?php
namespace Service\Tools;

use Service\Logs\Logs;
use Exception;
/**
 * apk差分包制作工具类
 * @author liangweiwei
 * @since 2012-01-13
 *
 */
class BSDiffTools {
	const FILE_NOT_EXIST_EXP = " is not exist!!!";
	const FILE_EXT_WRONG_EXP = "Extension of the file is not ";

	/**
	 * 制作差分包的win32程序路径
	 */
	private $bsdiffPath;

	public function __construct($bsdiffPath) {
		$this->bsdiffPath = $bsdiffPath;
		$this->checkFileExist($bsdiffPath);
	}

	public function setBSDiffPath($bsdiffPath) {
		$this->bsdiffPath = $bsdiffPath;
		$this->checkFileExist($bsdiffPath);
	}

	public function getBSDiffPath() {
		return $this->bsdiffPath;
	}

	/**
	 * 创建差分包的功能函数
	 * @return boolean
	 */
	public function createPatch($oldApkPath, $newApkPath, $patchPath) {
		try {
			$this->checkApkFile($oldApkPath, $newApkPath);
		} catch(Exception $e) {
			Logs::write('BSDiffTools::createPatch():checkApkFile() failed', 'log');
			return false;
		}
		$command = $this->createCommand($oldApkPath, $newApkPath, $patchPath);
		exec($command, $out, $status);
		if($status != 0){
			return false;
		}
		return true;
	}

	/**
	 * 检查是apk文件有效性
	 */
	private function checkApkFile($oldApkPath, $newApkPath) {
		$this->checkFileExist($oldApkPath);
		$this->checkFileExist($newApkPath);
		$this->checkFileExtension($oldApkPath, "apk");
		$this->checkFileExtension($newApkPath, "apk");
	}

	/**
	 * 检查文件是否存在
	 */
	private function checkFileExist($filepath) {
		if(!file_exists($filepath)) {
			throw new Exception($filepath.self::FILE_NOT_EXIST_EXP);
		}
	}

	/**
	 * 检查文件后缀是否为apk
	 */
	private function checkFileExtension($filepath, $extName)
	{
		$info = pathinfo($filepath);
		if($info['extension'] != $extName) {
			throw new Exception(self::FILE_EXT_WRONG_EXP.$extName);
		}
	}

	private function createCommand($oldApkPath, $newApkPath, $patchPath) {
		return $this->bsdiffPath." ".$oldApkPath." ".$newApkPath." ".$patchPath;
	}
}
?>