<?php
namespace Service\Tools;

use Service\Logs\Logs;
use Zend\ServiceManager\ServiceLocatorInterface;
use Service\ManagerFactory;

class Funcs
{
	private $_sm;
	
	public function __construct(ServiceLocatorInterface $sm)
	{
		$this->_sm = $sm;
	}
	
	/**
	  * @name Curl 数据
	  */
	public function curl_data($url, $vars, $cookie='', $method = 0){
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	
		if($method == 0){
			if(!empty($vars)){
				$url = $url.'?'.$vars;
			}
		}elseif ($method == 1){
			curl_setopt($ch, CURLOPT_POST, 1);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $vars);
		}
	
		curl_setopt($ch, CURLOPT_URL, $url);
		if (!empty($cookie)){
			curl_setopt($ch, CURLOPT_COOKIE, $cookie);
		}
	
		if(strstr($url,'https://')){
			curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
			curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
		}
	
		$curl_result = curl_exec($ch);
		curl_close($ch);
	
		return $curl_result;
	}
	
	
	/**
	 * 跳转接口
	 * @param unknown_type $arrData 参数数组
	 * @param unknown_type $strUrl	请求URL
	 * @param unknown_type $strCookie	cookie，默认为空
	 * @param unknown_type $nMethod		请求方法，默认是0（GET） 1（POST）
	 * @param unknown_type $bHeader     是否要求返回header，默认是false
	 * @return unknown
	 */
	
	public function skip_curl($arrData, $strUrl, $strCookie = '', $nMethod = 0, $bHeader = false){
		$jsonData = json_encode($arrData);
		$urlData = 'method='.$nMethod.'&url='.$strUrl.'&data='.urlencode($jsonData).'&cookie='.urlencode($strCookie);
	
		if ($bHeader){
			$urlData .= '&action=headinfo';
		}else{
			$urlData .= '&action=requestinfo';
		}
	
		$jsonResult = $this->curl_data(UserScore::URL_SKIP_URL, $urlData);
	
		return $jsonResult;
	}

    public function safeHidePro($str){
        if(empty($str)){
            return $str;
        }

        if(strlen($str) == 11){
            return substr_replace($str, "****", 3, 4);
        }else{
            return $str;
        }
    }

    public function safeHideCard($str){
        if(empty($str)){
            return $str;
        }

        if(strlen($str) == 15 ){
            return substr_replace($str, "********",3,8);
        }elseif(strlen($str) == 18){
            return substr_replace($str, "***********",3,11);
        }else{
            return $str;
        }
    }
}