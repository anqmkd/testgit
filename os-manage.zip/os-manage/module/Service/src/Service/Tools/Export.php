<?php
namespace Service\Tools;
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/9/8
 * Time: 15:41
 */

use Service\Logs\Logs;
class Export
{

    public function exportReport($type, $arrData){
        try{
            $factory = new ExportFactory();
            $name = $factory->getXlsName($type);

            header("Content-Type: application/vnd.ms-excel;charset=UTF-8");
            header("Content-Disposition: attachment; filename=".$name.".xls");
            header("Pragma: no-cache");
            header("Expires: 0");

            $table = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">
                    <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
                    <html>
                        <head>
                        <meta http-equiv="Content-type" content="text/html;charset=UTF-8" />
                        <style id="Classeur1_16681_Styles"></style>
                        </head>
                        <body>
                            <div id="Classeur1_16681" align=center x:publishsource="Excel">
                                <table x:str border=1 cellpadding=1 cellspacing=1 width=100% style="border-collapse: collapse">
                                <tr>';

            $table .= '<td><b>姓名</b></td>';
            $table .= '<td><b>身份证</b></td>';
            $table .= '<td><b>手机号</b></td>';
            $table .= '<td><b>手机型号</b></td>';
            $table .= '<td><b>手机标识</b></td>';
            $table .= '<td><b>手机价格</b></td>';
            $table .= '<td><b>开启时间</b></td>';
            $table .= '</tr>';
            foreach ($arrData as $info) {
                $table .= '<tr>'.
                        '<td class=xl2216681 nowrap>'.$info->strUserName.'</td>'.
                        '<td style="vnd.ms-excel.numberformat:@" nowrap>'.$info->strUserCard.'</td>'.
                        '<td style="vnd.ms-excel.numberformat:@" nowrap>'.$info->strUserPhone.'</td>'.
                        '<td class=xl2216681 nowrap>'.$info->strProduct.'</td>'.
                        '<td style="vnd.ms-excel.numberformat:@" nowrap>'.$info->strDeviceId.'</td>'.
                        '<td class=xl2216681 nowrap>'.$info->strPhonePrice.'</td>'.
                        '<td style="vnd.ms-excel.numberformat:@" nowrap>'.$info->tInsertTime.'</td>';
            }
            $table .= '</tr>';
            $table .= '</table></div>';
            $table .= '</body></html>';

            echo $table;

        }catch(\Exception $e){
            Logs::write("Export::exportReport(): excepton error:".$e->getMessage(), "log");
            return false;
        }
        return true;
    }
}