<?php
namespace Service\Tools;
use Service\fnlib\fnlib;
use Service\Logs\Logs;

class ApkTools
{
	public function __construct(){
	}

	public static function unzip($dir, $apktools, $file){
		try{
			if(file_exists($dir.'package')){
				$result = fnlib::remove_file_path($dir.'package');
				if(!$result){
					Logs::write('ApkTooks::unzip():remove_file_path() failed', 'log');
					return false;
				}
			}
			
			$stringsXML_exists 	= false;
			$result 			= array();
			
			//针对UC的APK包或其类似的APK包，解压一次并不能完全得到strings.xml文件或相关文件。目前只有采用这个办法了。
			//系统cmd下有时可以，有时也不可以。哎~
			//for($i = 0; $i < 5; $i++){
				$result = exec('java -jar '.$apktools.' d -f '.$file.' '.$dir.'package', $verList, $verRet);
			//}
		}catch(Exception $e){
			Logs::write('ApkTooks::unzip():exception error:'.$e->getMessage(),'log');
		}
		return true;
	}
	
	public static function parseXml($xmlContent, $arrField){
		$returnVal = array();
		foreach ($arrField as $field => $value){
			if(preg_match('/'.$value.'\"([^\"]*)\"/i',$xmlContent, $req)){			
				$returnVal[$field] = $req[1];
			}
		}
		return $returnVal;
	}
	
	public function getUnique(){
		list($msec,$sec) = explode(" ",microtime());
		return $sec.strval($msec*1000000).rand(100,999);
	}
	
	public static function getApkParam($dir, $apktools, $file){
		$xml_file 	= array();
		
		$xml_file 	= self::unzip($dir, $apktools, $file);		
		if($xml_file === false){
			Logs::write('ApkTooks::getApkParam():unzip() failed', 'log');
			return false;
		}
		
		$stringXmlFile = $dir.'package/res/values/strings.xml';
		if (!file_exists($stringXmlFile)){
			Logs::write('ApkTooks::getApkParam():string.xml is not exist', 'log');
			return false;
		}
		
		$mainfestXmlFile 	= $dir.'package/AndroidManifest.xml';
		if(!file_exists($mainfestXmlFile)){
			Logs::write('ApkTools::getApkParam():androidMainfest.xml is not exist ', 'log');
			return false;
		}
		
		$arrApkConfig = array('package'		=> 'package=',
							'versionCode'	=> 'versionCode=',
							'versionName'	=> 'versionName=',);
		
		$AndroidManifestXML = file_get_contents($mainfestXmlFile);
		//提取版本信息
		$arrApkVerParam 	= self::parseXml($AndroidManifestXML, $arrApkConfig);
		//提取应用名称
		$label= null;
		if(preg_match('/<application[\s\S]*? android:label="@string\/([^"]*)"/i',$AndroidManifestXML, $label)){
			if(count($label) >= 2 ){
				$arrApkVerParam['lable'] = $label[1];
				$stringXml = file_get_contents($stringXmlFile);
				$name = null;
				if(preg_match('/<string name=\"'.$label[1].'\">([^<]*)<\/string>/',$stringXml, $name)){
					if(count($name) >= 2){
						$arrApkVerParam['name'] = $name[1];
					}
				}
			}
		}
		
		//提取图标
		if(preg_match('/<application[\s\S]*? android:icon="@drawable\/([^"]*)"/i',$AndroidManifestXML, $icon)){
			if(count($icon) >=2 ){
				$arrApkVerParam['icon'] = $icon[1];
			}
		}
		return $arrApkVerParam;
	}
	
	public static function getAkpIcon($dir, $iconName)
	{
		$tmpArr[0]=0;
		$tmpArr[1]=0;
		$tmpArr[2]='drawable';
		
		$dirs = opendir($dir.'package/res');
		
		//查找最大的图片
		while($file = readdir($dirs)){
			$drawable_folder = array();
			preg_match('/(drawable(-.*?dpi)?)/i', $file, $drawable_folder);
			if(count($drawable_folder) == 0){
				continue;
			}
			$iconPath = $dir.'package/res/'.$drawable_folder[1].'/'.$iconName.'.png';
			
			if(!file_exists($iconPath)){
				continue;
			}
			
			$iconInfo = getimagesize($iconPath);
			if($iconInfo[0] > $tmpArr[0] 
				&& $iconInfo[1] > $tmpArr[1]){
				$tmpArr[0] = $iconInfo[0];
				$tmpArr[1] = $iconInfo[1];
				$tmpArr[2] = $drawable_folder[1];
			}
		}
		$iconFile = $dir.'package/res/'.$tmpArr[2].'/'.$iconName.'.png';
		if(!file_exists($iconFile)){
			Logs::write('ApkTools::GetApkIcon():iconFile is not exit', 'log');
			return false;
		}
		
		return $iconFile;
	}
}
