<?php

return array (
    '北京市' =>
    array (
        'name' => '北京市',
        'spell' =>
        array (
            0 => 'beijingshi',
            1 => 'bj',
        ),
        'alias' =>
        array (
            0 => '北京市',
        ),
        'capital' => '北京',
        'special' => true,
        'cities' =>
        array (
            '北京' =>
            array (
                'name' => '北京',
                'citycode' => '010',
                'x' => '116.397945',
                'y' => '39.90817',
                'spell' => ['beijing', 'bj'],
                'cityid' => '110000',
                'special' => true,
                'alias' =>
                array (
                    0 => '北京',
                ),
            ),
        ),
    ),
    '天津市' =>
    array (
        'name' => '天津市',
        'spell' =>
        array (
            0 => 'tianjinshi',
            1 => 'tj',
        ),
        'alias' =>
        array (
            0 => '天津市',
        ),
        'capital' => '天津',
        'special' => true,
        'cities' =>
        array (
            '天津' =>
            array (
                'name' => '天津',
                'citycode' => '022',
                'x' => '117.188904',
                'y' => '39.126015',
                'spell' => ['tianjin', 'tj'],
                'cityid' => '120000',
                'special' => true,
                'alias' =>
                array (
                    0 => '天津',
                ),
            ),
        ),
    ),
    '上海市' =>
    array (
        'name' => '上海市',
        'spell' =>
        array (
            0 => 'shanghaishi',
            1 => 'sh',
        ),
        'alias' =>
        array (
            0 => '上海市',
        ),
        'capital' => '上海',
        'special' => true,
        'cities' =>
        array (
            '上海' =>
            array (
                'name' => '上海',
                'citycode' => '021',
                'x' => '121.472770',
                'y' => '31.232414',
                'spell' => ['shanghai', 'sh'],
                'cityid' => '310000',
                'special' => true,
                'alias' =>
                array (
                    0 => '上海',
                ),
            ),
        ),
    ),
    '重庆市' =>
    array (
        'name' => '重庆市',
        'spell' =>
        array (
            0 => 'chongqingshi',
            1 => 'cq',
        ),
        'alias' =>
        array (
            0 => '重庆市',
        ),
        'capital' => '重庆',
        'special' => true,
        'cities' =>
        array (
            '重庆' =>
            array (
                'name' => '重庆',
                'citycode' => '023',
                'x' => '106.501575',
                'y' => '29.533676',
                'spell' => ['chongqing', 'cq'],
                'alias' =>
                array (
                    0 => '重庆',
                ),
                'cityid' => '500000',
                'special' => true,
            ),
        ),
    ),
    '安徽省' =>
    array (
        'name' => '安徽省',
        'spell' =>
        array (
            0 => 'anhuisheng',
            1 => 'ah',
        ),
        'alias' =>
        array (
            0 => '安徽',
            1 => '安徽省',
        ),
        'capital' => '合肥',
        'cities' =>
        array (
            '合肥' =>
            array (
                'name' => '合肥',
                'citycode' => '0551',
                'x' => '117.295755',
                'y' => '31.869345',
                'spell' =>
                array (
                    0 => 'hefei', 'hf'
                ),
                'cityid' => '340100',
                'alias' =>
                array (
                    0 => '合肥',
                ),
            ),
            '蚌埠' =>
            array (
                'name' => '蚌埠',
                'citycode' => '0552',
                'x' => '117.401746',
                'y' => '32.930236',
                'spell' =>
                array (
                    0 => 'bengbu', 'bb'
                ),
                'cityid' => '340300',
                'alias' =>
                array (
                    0 => '蚌埠',
                ),
            ),
            '芜湖' =>
            array (
                'name' => '芜湖',
                'citycode' => '0553',
                'x' => '118.375749',
                'y' => '31.327276',
                'spell' =>
                array (
                    0 => 'wuhu', 'wh'
                ),
                'cityid' => '340200',
                'alias' =>
                array (
                    0 => '芜湖',
                ),
            ),
            '马鞍山' =>
            array (
                'name' => '马鞍山',
                'citycode' => '0555',
                'x' => '118.502033',
                'y' => '31.692997',
                'spell' =>
                array (
                    0 => 'maanshan', 'mas'
                ),
                'cityid' => '340500',
                'alias' =>
                array (
                    0 => '马鞍山',
                ),
            ),
            '安庆' =>
            array (
                'name' => '安庆',
                'citycode' => '0556',
                'x' => '117.050875',
                'y' => '30.527001',
                'spell' =>
                array (
                    0 => 'anqing', 'aq'
                ),
                'cityid' => '340800',
                'alias' =>
                array (
                    0 => '安庆',
                ),
            ),
            '黄山' =>
            array (
                'name' => '黄山',
                'citycode' => '0559',
                'x' => '118.305423',
                'y' => '29.712603',
                'spell' =>
                array (
                    0 => 'huangshan', 'hs'
                ),
                'cityid' => '341000',
                'alias' =>
                array (
                    0 => '黄山',
                ),
            ),
            '巢湖' =>
            array (
                'name' => '巢湖',
                'citycode' => '0565',
                'x' => '117.87003',
                'y' => '31.600863',
                'spell' =>
                array (
                    0 => 'chaohu', 'ch'
                ),
                'cityid' => '341400',
                'alias' =>
                array (
                    0 => '巢湖',
                ),
            ),
            '亳州' =>
            array (
                'name' => '亳州',
                'citycode' => '0558',
                'x' => '115.782566',
                'y' => '33.869595',
                'spell' =>
                array (
                    0 => 'bozhou', 'bz'
                ),
                'cityid' => '341600',
                'alias' =>
                array (
                    0 => '亳州',
                ),
            ),
            '六安' =>
            array (
                'name' => '六安',
                'citycode' => '0564',
                'x' => '116.491465',
                'y' => '31.742631',
                'spell' =>
                array (
                    0 => 'liuan', 'la'
                ),
                'cityid' => '341500',
                'alias' =>
                array (
                    0 => '六安',
                ),
            ),
            '宣城' =>
            array (
                'name' => '宣城',
                'citycode' => '0563',
                'x' => '118.754739',
                'y' => '30.946851',
                'spell' =>
                array (
                    0 => 'xuancheng', 'xc'
                ),
                'cityid' => '341800',
                'alias' =>
                array (
                    0 => '宣城',
                ),
            ),
            '宿州' =>
            array (
                'name' => '宿州',
                'citycode' => '0557',
                'x' => '116.98374',
                'y' => '33.638056',
                'spell' =>
                array (
                    0 => 'suzhou', 'sz'
                ),
                'cityid' => '341300',
                'alias' =>
                array (
                    0 => '宿州',
                ),
            ),
            '池州' =>
            array (
                'name' => '池州',
                'citycode' => '0566',
                'x' => '117.489459',
                'y' => '30.65573',
                'spell' =>
                array (
                    0 => 'chizhou', 'cz'
                ),
                'cityid' => '341700',
                'alias' =>
                array (
                    0 => '池州',
                ),
            ),
            '淮北' =>
            array (
                'name' => '淮北',
                'citycode' => '0561',
                'x' => '116.792507',
                'y' => '33.968986',
                'spell' =>
                array (
                    0 => 'huaibei', 'hb'
                ),
                'cityid' => '340600',
                'alias' =>
                array (
                    0 => '淮北',
                ),
            ),
            '淮南' =>
            array (
                'name' => '淮南',
                'citycode' => '0554',
                'x' => '116.999684',
                'y' => '32.638282',
                'spell' =>
                array (
                    0 => 'huainan', 'hn'
                ),
                'cityid' => '340400',
                'alias' =>
                array (
                    0 => '淮南',
                ),
            ),
            '滁州' =>
            array (
                'name' => '滁州',
                'citycode' => '0550',
                'x' => '118.318179',
                'y' => '32.301076',
                'spell' =>
                array (
                    0 => 'chuzhou', 'cz'
                ),
                'cityid' => '341100',
                'alias' =>
                array (
                    0 => '滁州',
                ),
            ),
            '铜陵' =>
            array (
                'name' => '铜陵',
                'citycode' => '0562',
                'x' => '117.810804',
                'y' => '30.944574',
                'spell' =>
                array (
                    0 => 'tongling', 'tl'
                ),
                'cityid' => '340700',
                'alias' =>
                array (
                    0 => '铜陵',
                ),
            ),
            '阜阳' =>
            array (
                'name' => '阜阳',
                'citycode' => '1558',
                'x' => '115.819778',
                'y' => '32.897102',
                'spell' =>
                array (
                    0 => 'fuyang', 'fy'
                ),
                'cityid' => '341200',
                'alias' =>
                array (
                    0 => '阜阳',
                ),
            ),
        ),
    ),
    '福建省' =>
    array (
        'name' => '福建省',
        'spell' =>
        array (
            0 => 'fujiansheng',
            1 => 'fj',
        ),
        'alias' =>
        array (
            0 => '福建',
            1 => '福建省',
        ),
        'capital' => '福州',
        'cities' =>
        array (
            '福州' =>
            array (
                'name' => '福州',
                'citycode' => '0591',
                'x' => '119.304142',
                'y' => '26.074733',
                'spell' =>
                array (
                    0 => 'fuzhou', 'fz'
                ),
                'cityid' => '350100',
                'alias' =>
                array (
                    0 => '福州',
                ),
            ),
            '厦门' =>
            array (
                'name' => '厦门',
                'citycode' => '0592',
                'x' => '118.109469',
                'y' => '24.488826',
                'spell' =>
                array (
                    0 => 'xiamen', 'xm'
                ),
                'cityid' => '350200',
                'alias' =>
                array (
                    0 => '厦门',
                ),
            ),
            '宁德' =>
            array (
                'name' => '宁德',
                'citycode' => '0593',
                'x' => '119.548826',
                'y' => '26.6516',
                'spell' =>
                array (
                    0 => 'ningde', 'nd'
                ),
                'cityid' => '350900',
                'alias' =>
                array (
                    0 => '宁德',
                ),
            ),
            '莆田' =>
            array (
                'name' => '莆田',
                'citycode' => '0594',
                'x' => '119.005842',
                'y' => '25.435659',
                'spell' =>
                array (
                    0 => 'putian', 'pt'
                ),
                'cityid' => '350300',
                'alias' =>
                array (
                    0 => '莆田',
                ),
            ),
            '泉州' =>
            array (
                'name' => '泉州',
                'citycode' => '0595',
                'x' => '118.584515',
                'y' => '24.9295',
                'spell' =>
                array (
                    0 => 'quanzhou', 'qz'
                ),
                'cityid' => '350500',
                'alias' =>
                array (
                    0 => '泉州',
                ),
            ),
            '漳州' =>
            array (
                'name' => '漳州',
                'citycode' => '0596',
                'x' => '117.665987',
                'y' => '24.51235',
                'spell' =>
                array (
                    0 => 'zhangzhou', 'zz'
                ),
                'cityid' => '350600',
                'alias' =>
                array (
                    0 => '漳州',
                ),
            ),
            '三明' =>
            array (
                'name' => '三明',
                'citycode' => '0598',
                'x' => '117.6404',
                'y' => '26.268056',
                'spell' =>
                array (
                    0 => 'sanming', 'sm'
                ),
                'cityid' => '350400',
                'alias' =>
                array (
                    0 => '三明',
                ),
            ),
            '南平' =>
            array (
                'name' => '南平',
                'citycode' => '0599',
                'x' => '118.178598',
                'y' => '26.63989',
                'spell' =>
                array (
                    0 => 'nanping', 'np'
                ),
                'cityid' => '350700',
                'alias' =>
                array (
                    0 => '南平',
                ),
            ),
            '龙岩' =>
            array (
                'name' => '龙岩',
                'citycode' => '0597',
                'x' => '117.032561',
                'y' => '25.094579',
                'spell' =>
                array (
                    0 => 'longyan', 'ly'
                ),
                'cityid' => '350800',
                'alias' =>
                array (
                    0 => '龙岩',
                ),
            ),
        ),
    ),
    '广东省' =>
    array (
        'name' => '广东省',
        'spell' =>
        array (
            0 => 'guangdongsheng',
            1 => 'gd',
        ),
        'alias' =>
        array (
            0 => '广东',
            1 => '广东省',
        ),
        'capital' => '广州',
        'cities' =>
        array (
            '广州' =>
            array (
                'name' => '广州',
                'citycode' => '020',
                'x' => '113.281089',
                'y' => '23.123565',
                'spell' =>
                array (
                    0 => 'guangzhou', 'gz'
                ),
                'cityid' => '440100',
                'alias' =>
                array (
                    0 => '广州',
                ),
            ),
            '深圳' =>
            array (
                'name' => '深圳',
                'citycode' => '0755',
                'x' => '114.081035',
                'y' => '22.545100',
                'spell' =>
                array (
                    0 => 'shenzhen', 'sz'
                ),
                'cityid' => '440300',
                'alias' =>
                array (
                    0 => '深圳',
                ),
            ),
            '珠海' =>
            array (
                'name' => '珠海',
                'citycode' => '0756',
                'x' => '113.583787',
                'y' => '22.260742',
                'spell' =>
                array (
                    0 => 'zhuhai', 'zh'
                ),
                'cityid' => '440400',
                'alias' =>
                array (
                    0 => '珠海',
                ),
            ),
            '佛山' =>
            array (
                'name' => '佛山',
                'citycode' => '0757',
                'x' => '113.121489',
                'y' => '23.030498',
                'spell' =>
                array (
                    0 => 'foshan', 'fs'
                ),
                'cityid' => '440600',
                'alias' =>
                array (
                    0 => '佛山',
                ),
            ),
            '肇庆' =>
            array (
                'name' => '肇庆',
                'citycode' => '0758',
                'x' => '112.475722',
                'y' => '23.07338',
                'spell' =>
                array (
                    0 => 'zhaoqing', 'zq'
                ),
                'cityid' => '441200',
                'alias' =>
                array (
                    0 => '肇庆',
                ),
            ),
            '汕头' =>
            array (
                'name' => '汕头',
                'citycode' => '0754',
                'x' => '116.723734',
                'y' => '23.360103',
                'spell' =>
                array (
                    0 => 'shantou', 'st'
                ),
                'cityid' => '440500',
                'alias' =>
                array (
                    0 => '汕头',
                ),
            ),
            '湛江' =>
            array (
                'name' => '湛江',
                'citycode' => '0759',
                'x' => '110.420573',
                'y' => '21.198859',
                'spell' =>
                array (
                    0 => 'zhanjiang', 'zj'
                ),
                'cityid' => '440800',
                'alias' =>
                array (
                    0 => '湛江',
                ),
            ),
            '中山' =>
            array (
                'name' => '中山',
                'citycode' => '0760',
                'x' => '113.371543',
                'y' => '22.524999',
                'spell' =>
                array (
                    0 => 'zhongshan', 'zs'
                ),
                'cityid' => '442000',
                'alias' =>
                array (
                    0 => '中山',
                ),
            ),
            '潮州' =>
            array (
                'name' => '潮州',
                'citycode' => '0768',
                'x' => '116.642006',
                'y' => '23.671306',
                'spell' =>
                array (
                    0 => 'chaozhou', 'cz'
                ),
                'cityid' => '445100',
                'alias' =>
                array (
                    0 => '潮州',
                ),
            ),
            '东莞' =>
            array (
                'name' => '东莞',
                'citycode' => '0769',
                'x' => '113.761601',
                'y' => '23.048838',
                'spell' =>
                array (
                    0 => 'dongguan', 'dg'
                ),
                'cityid' => '441900',
                'alias' =>
                array (
                    0 => '东莞',
                ),
            ),
            '汕尾' =>
            array (
                'name' => '汕尾',
                'citycode' => '0660',
                'x' => '115.371095',
                'y' => '22.784192',
                'spell' =>
                array (
                    0 => 'shanwei', 'sw'
                ),
                'cityid' => '441500',
                'alias' =>
                array (
                    0 => '汕尾',
                ),
            ),
            '阳江' =>
            array (
                'name' => '阳江',
                'citycode' => '0662',
                'x' => '111.983625',
                'y' => '21.871951',
                'spell' =>
                array (
                    0 => 'yangjiang', 'yj'
                ),
                'cityid' => '441700',
                'alias' =>
                array (
                    0 => '阳江',
                ),
            ),
            '揭阳' =>
            array (
                'name' => '揭阳',
                'citycode' => '0663',
                'x' => '116.369784',
                'y' => '23.527561',
                'spell' =>
                array (
                    0 => 'jieyang', 'jy'
                ),
                'cityid' => '445200',
                'alias' =>
                array (
                    0 => '揭阳',
                ),
            ),
            '茂名' =>
            array (
                'name' => '茂名',
                'citycode' => '0668',
                'x' => '110.924718',
                'y' => '21.662735',
                'spell' =>
                array (
                    0 => 'maoming', 'mm'
                ),
                'cityid' => '440900',
                'alias' =>
                array (
                    0 => '茂名',
                ),
            ),
            '江门' =>
            array (
                'name' => '江门',
                'citycode' => '0750',
                'x' => '113.0809021',
                'y' => '22.58865439',
                'spell' =>
                array (
                    0 => 'jiangmen', 'jm'
                ),
                'cityid' => '440700',
                'alias' =>
                array (
                    0 => '江门',
                ),
            ),
            '韶关' =>
            array (
                'name' => '韶关',
                'citycode' => '0751',
                'x' => '113.598431',
                'y' => '24.802397',
                'spell' =>
                array (
                    0 => 'shaoguan', 'sg'
                ),
                'cityid' => '440200',
                'alias' =>
                array (
                    0 => '韶关',
                ),
            ),
            '惠州' =>
            array (
                'name' => '惠州',
                'citycode' => '0752',
                'x' => '114.417429',
                'y' => '23.08961',
                'spell' =>
                array (
                    0 => 'huizhou', 'hz'
                ),
                'cityid' => '441300',
                'alias' =>
                array (
                    0 => '惠州',
                ),
            ),
            '梅州' =>
            array (
                'name' => '梅州',
                'citycode' => '0753',
                'x' => '116.117867',
                'y' => '24.298771',
                'spell' =>
                array (
                    0 => 'meizhou', 'mz'
                ),
                'cityid' => '441400',
                'alias' =>
                array (
                    0 => '梅州',
                ),
            ),
            '云浮' =>
            array (
                'name' => '云浮',
                'citycode' => '0766',
                'x' => '112.04402',
                'y' => '22.929373',
                'spell' =>
                array (
                    0 => 'yunfu', 'yf'
                ),
                'cityid' => '445300',
                'alias' =>
                array (
                    0 => '云浮',
                ),
            ),
            '河源' =>
            array (
                'name' => '河源',
                'citycode' => '0762',
                'x' => '114.697479',
                'y' => '23.750344',
                'spell' =>
                array (
                    0 => 'heyuan', 'hy'
                ),
                'cityid' => '441600',
                'alias' =>
                array (
                    0 => '河源',
                ),
            ),
            '清远' =>
            array (
                'name' => '清远',
                'citycode' => '0763',
                'x' => '113.045465',
                'y' => '23.688233',
                'spell' =>
                array (
                    0 => 'qingyuan', 'qy'
                ),
                'cityid' => '441800',
                'alias' =>
                array (
                    0 => '清远',
                ),
            ),
        ),
    ),
    '广西壮族自治区' =>
    array (
        'name' => '广西壮族自治区',
        'spell' =>
        array (
            0 => 'guangxizhuangzuzizhiqu',
            1 => 'gx',
        ),
        'alias' =>
        array (
            0 => '广西',
            1 => '广西省',
            2 => '广西壮族自治区',
        ),
        'capital' => '南宁',
        'cities' =>
        array (
            '南宁' =>
            array (
                'name' => '南宁',
                'citycode' => '0771',
                'x' => '108.317081',
                'y' => '22.806264',
                'spell' =>
                array (
                    0 => 'nanning', 'nn'
                ),
                'cityid' => '450100',
                'alias' =>
                array (
                    0 => '南宁',
                ),
            ),
            '柳州' =>
            array (
                'name' => '柳州',
                'citycode' => '0772',
                'x' => '109.412608',
                'y' => '24.306754',
                'spell' =>
                array (
                    0 => 'liuzhou', 'lz'
                ),
                'cityid' => '450200',
                'alias' =>
                array (
                    0 => '柳州',
                ),
            ),
            '桂林' =>
            array (
                'name' => '桂林',
                'citycode' => '0773',
                'x' => '110.284867',
                'y' => '25.282673',
                'spell' =>
                array (
                    0 => 'guilin', 'gl'
                ),
                'cityid' => '450300',
                'alias' =>
                array (
                    0 => '桂林',
                ),
            ),
            '北海' =>
            array (
                'name' => '北海',
                'citycode' => '0779',
                'x' => '109.122975',
                'y' => '21.478775',
                'spell' =>
                array (
                    0 => 'beihai', 'bh'
                ),
                'cityid' => '450500',
                'alias' =>
                array (
                    0 => '北海',
                ),
            ),
            '防城港' =>
            array (
                'name' => '防城港',
                'citycode' => '0770',
                'x' => '108.350921',
                'y' => '21.623428',
                'spell' =>
                array (
                    0 => 'fangchenggang', 'fcg'
                ),
                'cityid' => '450600',
                'alias' =>
                array (
                    0 => '防城港',
                ),
            ),
            '崇左' =>
            array (
                'name' => '崇左',
                'citycode' => '1771',
                'x' => '107.339455',
                'y' => '22.424819',
                'spell' =>
                array (
                    0 => 'chongzuo', 'cz'
                ),
                'cityid' => '451400',
                'alias' =>
                array (
                    0 => '崇左',
                ),
            ),
            '来宾' =>
            array (
                'name' => '来宾',
                'citycode' => '1772',
                'x' => '109.221785',
                'y' => '23.735056',
                'spell' =>
                array (
                    0 => 'laibin', 'lb'
                ),
                'cityid' => '451300',
                'alias' =>
                array (
                    0 => '来宾',
                ),
            ),
            '梧州' =>
            array (
                'name' => '梧州',
                'citycode' => '0774',
                'x' => '111.304464',
                'y' => '23.503557',
                'spell' =>
                array (
                    0 => 'wuzhou', 'wz'
                ),
                'cityid' => '450400',
                'alias' =>
                array (
                    0 => '梧州',
                ),
            ),
            '河池' =>
            array (
                'name' => '河池',
                'citycode' => '0778',
                'x' => '108.061878',
                'y' => '24.697204',
                'spell' =>
                array (
                    0 => 'hechi', 'hc'
                ),
                'cityid' => '451200',
                'alias' =>
                array (
                    0 => '河池',
                ),
            ),
            '玉林' =>
            array (
                'name' => '玉林',
                'citycode' => '0775',
                'x' => '110.150712',
                'y' => '22.625526',
                'spell' =>
                array (
                    0 => 'yulin', 'yl'
                ),
                'cityid' => '450900',
                'alias' =>
                array (
                    0 => '玉林',
                ),
            ),
            '贵港' =>
            array (
                'name' => '贵港',
                'citycode' => '1755',
                'x' => '109.606106',
                'y' => '23.093866',
                'spell' =>
                array (
                    0 => 'guigang', 'gg'
                ),
                'cityid' => '450800',
                'alias' =>
                array (
                    0 => '贵港',
                ),
            ),
            '贺州' =>
            array (
                'name' => '贺州',
                'citycode' => '1774',
                'x' => '111.562853',
                'y' => '24.42791',
                'spell' =>
                array (
                    0 => 'hezhou', 'hz'
                ),
                'cityid' => '451100',
                'alias' =>
                array (
                    0 => '贺州',
                ),
            ),
            '钦州' =>
            array (
                'name' => '钦州',
                'citycode' => '0777',
                'x' => '108.608717',
                'y' => '21.950857',
                'spell' =>
                array (
                    0 => 'qinzhou', 'qz'
                ),
                'cityid' => '450700',
                'alias' =>
                array (
                    0 => '钦州',
                ),
            ),
            '百色' =>
            array (
                'name' => '百色',
                'citycode' => '0776',
                'x' => '106.618609',
                'y' => '23.90188',
                'spell' =>
                array (
                    0 => 'baise', 'bs'
                ),
                'cityid' => '451000',
                'alias' =>
                array (
                    0 => '百色',
                ),
            ),
        ),
    ),
    '贵州省' =>
    array (
        'name' => '贵州省',
        'spell' =>
        array (
            0 => 'guizhousheng',
            1 => 'gz',
        ),
        'alias' =>
        array (
            0 => '贵州',
            1 => '贵州省',
        ),
        'capital' => '贵阳',
        'cities' =>
        array (
            '贵阳' =>
            array (
                'name' => '贵阳',
                'citycode' => '0851',
                'x' => '106.708617',
                'y' => '26.567955',
                'spell' =>
                array (
                    0 => 'guiyang', 'gy'
                ),
                'cityid' => '520100',
                'alias' =>
                array (
                    0 => '贵阳',
                ),
            ),
            '安顺' =>
            array (
                'name' => '安顺',
                'citycode' => '0853',
                'x' => '105.927065',
                'y' => '26.257272',
                'spell' =>
                array (
                    0 => 'anshun', 'as'
                ),
                'cityid' => '520400',
                'alias' =>
                array (
                    0 => '安顺',
                ),
            ),
            '毕节' =>
            array (
                'name' => '毕节',
                'citycode' => '0857',
                'x' => '105.288395',
                'y' => '27.303223',
                'spell' =>
                array (
                    0 => 'bijie', 'bj'
                ),
                'alias' =>
                array (
                    0 => '毕节',
                ),
                'cityid' => '522401',
            ),
            '遵义' =>
            array (
                'name' => '遵义',
                'citycode' => '0852',
                'x' => '106.931225',
                'y' => '27.692611',
                'spell' =>
                array (
                    0 => 'zunyi', 'zy'
                ),
                'cityid' => '520300',
                'alias' =>
                array (
                    0 => '遵义',
                ),
            ),
            '铜仁' =>
            array (
                'name' => '铜仁',
                'citycode' => '0856',
                'x' => '109.187656',
                'y' => '27.71841',
                'spell' =>
                array (
                    0 => 'tongren', 'tr'
                ),
                'alias' =>
                array (
                    0 => '铜仁',
                ),
                'cityid' => '522201',
            ),
            '黔东南苗族侗族自治州' =>
            array (
                'name' => '黔东南苗族侗族自治州',
                'citycode' => '0855',
                'x' => '107.981006',
                'y' => '26.583065',
                'spell' =>
                array (
                    0 => 'qiandongnan', 'qdn'
                ),
                'cityid' => '522600',
                'alias' =>
                array (
                    0 => '黔东南苗族侗族自治州',
                ),
            ),
            '黔南布依族苗族自治州' =>
            array (
                'name' => '黔南布依族苗族自治州',
                'citycode' => '0854',
                'x' => '107.511291',
                'y' => '26.283035',
                'spell' =>
                array (
                    0 => 'qiannan', 'qn'
                ),
                'cityid' => '522700',
                'alias' =>
                array (
                    0 => '黔南布依族苗族自治州',
                ),
            ),
            '六盘水' =>
            array (
                'name' => '六盘水',
                'citycode' => '0858',
                'x' => '104.830414',
                'y' => '26.593174',
                'spell' =>
                array (
                    0 => 'liupanshui', 'lps'
                ),
                'cityid' => '520200',
                'alias' =>
                array (
                    0 => '六盘水',
                ),
            ),
            '黔西南布依族苗族自治州' =>
            array (
                'name' => '黔西南布依族苗族自治州',
                'citycode' => '0859',
                'x' => '104.905089',
                'y' => '25.088066',
                'spell' =>
                array (
                    0 => 'qianxinan', 'qxn'
                ),
                'cityid' => '522300',
                'alias' =>
                array (
                    0 => '黔西南布依族苗族自治州',
                ),
            ),
        ),
    ),
    '甘肃省' =>
    array (
        'name' => '甘肃省',
        'spell' =>
        array (
            0 => 'gansusheng',
            1 => 'gs',
        ),
        'alias' =>
        array (
            0 => '甘肃',
            1 => '甘肃省',
        ),
        'capital' => '兰州',
        'cities' =>
        array (
            '兰州' =>
            array (
                'name' => '兰州',
                'citycode' => '0931',
                'x' => '103.835149',
                'y' => '36.059885',
                'spell' =>
                array (
                    0 => 'lanzhou', 'lz'
                ),
                'cityid' => '620100',
                'alias' =>
                array (
                    0 => '兰州',
                ),
            ),
            '天水' =>
            array (
                'name' => '天水',
                'citycode' => '0938',
                'x' => '105.701624',
                'y' => '34.587464',
                'spell' =>
                array (
                    0 => 'tianshui', 'ts'
                ),
                'cityid' => '620500',
                'alias' =>
                array (
                    0 => '天水',
                ),
            ),
            '定西' =>
            array (
                'name' => '定西',
                'citycode' => '0932',
                'x' => '104.621884',
                'y' => '35.585199',
                'spell' =>
                array (
                    0 => 'dingxi', 'dx'
                ),
                'cityid' => '621100',
                'alias' =>
                array (
                    0 => '定西',
                ),
            ),
            '平凉' =>
            array (
                'name' => '平凉',
                'citycode' => '0933',
                'x' => '106.725239',
                'y' => '35.509738',
                'spell' =>
                array (
                    0 => 'pingliang','pl'
                ),
                'cityid' => '620800',
                'alias' =>
                array (
                    0 => '平凉',
                ),
            ),
            '庆阳' =>
            array (
                'name' => '庆阳',
                'citycode' => '0934',
                'x' => '107.861502',
                'y' => '35.934416',
                'spell' =>
                array (
                    0 => 'qingyang', 'qy'
                ),
                'cityid' => '621000',
                'alias' =>
                array (
                    0 => '庆阳',
                ),
            ),
            '张掖' =>
            array (
                'name' => '张掖',
                'citycode' => '0936',
                'x' => '100.450868',
                'y' => '38.930961',
                'spell' =>
                array (
                    0 => 'zhangye', 'zy'
                ),
                'cityid' => '620700',
                'alias' =>
                array (
                    0 => '张掖',
                ),
            ),
            '武威' =>
            array (
                'name' => '武威',
                'citycode' => '1935',
                'x' => '102.633556',
                'y' => '37.931678',
                'spell' =>
                array (
                    0 => 'wuwei', 'ww'
                ),
                'cityid' => '620600',
                'alias' =>
                array (
                    0 => '武威',
                ),
            ),
            '白银' =>
            array (
                'name' => '白银',
                'citycode' => '0943',
                'x' => '104.150662',
                'y' => '36.550632',
                'spell' =>
                array (
                    0 => 'baiyin', 'by'
                ),
                'cityid' => '620400',
                'alias' =>
                array (
                    0 => '白银',
                ),
            ),
            '酒泉' =>
            array (
                'name' => '酒泉',
                'citycode' => '0937',
                'x' => '98.513877',
                'y' => '39.756293',
                'spell' =>
                array (
                    0 => 'jiuquan', 'jq'
                ),
                'cityid' => '620900',
                'alias' =>
                array (
                    0 => '酒泉',
                ),
            ),
            '金昌' =>
            array (
                'name' => '金昌',
                'citycode' => '0935',
                'x' => '102.175083',
                'y' => '38.476375',
                'spell' =>
                array (
                    0 => 'jinchang', 'jc'
                ),
                'cityid' => '620300',
                'alias' =>
                array (
                    0 => '金昌',
                ),
            ),
            '陇南' =>
            array (
                'name' => '陇南',
                'citycode' => '2935',
                'x' => '104.933657',
                'y' => '33.469543',
                'spell' =>
                array (
                    0 => 'longnan', 'ln'
                ),
                'cityid' => '621200',
                'alias' =>
                array (
                    0 => '陇南',
                ),
            ),
            '临夏回族自治州' =>
            array (
                'name' => '临夏回族自治州',
                'citycode' => '0930',
                'x' => '103.201083',
                'y' => '35.591386',
                'spell' =>
                array (
                    0 => 'linxia', 'lx'
                ),
                'cityid' => '622900',
                'alias' =>
                array (
                    0 => '临夏回族自治州',
                ),
            ),
            '甘南藏族自治州' =>
            array (
                'name' => '甘南藏族自治州',
                'citycode' => '0941',
                'x' => '102.904743',
                'y' => '34.981601',
                'spell' =>
                array (
                    0 => 'gannan', 'gn'
                ),
                'cityid' => '623000',
                'alias' =>
                array (
                    0 => '甘南藏族自治州',
                ),
            ),
            '嘉峪关' =>
            array (
                'name' => '嘉峪关',
                'citycode' => '1937',
                'x' => '98.278458',
                'y' => '39.7845',
                'spell' =>
                array (
                    0 => 'jiayuguan', 'jyg'
                ),
                'cityid' => '620200',
                'alias' =>
                array (
                    0 => '嘉峪关',
                ),
            ),
        ),
    ),
    '河北省' =>
    array (
        'name' => '河北省',
        'spell' =>
        array (
            0 => 'hebeisheng',
            1 => 'hb',
        ),
        'alias' =>
        array (
            0 => '河北',
            1 => '河北省',
        ),
        'capital' => '石家庄',
        'cities' =>
        array (
            '邯郸' =>
            array (
                'name' => '邯郸',
                'citycode' => '0310',
                'x' => '114.4892',
                'y' => '36.599421',
                'spell' =>
                array (
                    0 => 'handan','hd'
                ),
                'cityid' => '130400',
                'alias' =>
                array (
                    0 => '邯郸',
                ),
            ),
            '石家庄' =>
            array (
                'name' => '石家庄',
                'citycode' => '0311',
                'x' => '114.500862',
                'y' => '38.048504',
                'spell' =>
                array (
                    0 => 'shijiazhuang', 'sjz'
                ),
                'cityid' => '130100',
                'alias' =>
                array (
                    0 => '石家庄',
                ),
            ),
            '保定' =>
            array (
                'name' => '保定',
                'citycode' => '0312',
                'x' => '115.466485',
                'y' => '38.879863',
                'spell' =>
                array (
                    0 => 'baoding', 'bd'
                ),
                'cityid' => '130600',
                'alias' =>
                array (
                    0 => '保定',
                ),
            ),
            '张家口' =>
            array (
                'name' => '张家口',
                'citycode' => '0313',
                'x' => '114.889851',
                'y' => '40.826215',
                'spell' =>
                array (
                    0 => 'zhangjiakou','zjk'
                ),
                'cityid' => '130700',
                'alias' =>
                array (
                    0 => '张家口',
                ),
            ),
            '承德' =>
            array (
                'name' => '承德',
                'citycode' => '0314',
                'x' => '117.934555',
                'y' => '40.995466',
                'spell' =>
                array (
                    0 => 'chengde', 'cd'
                ),
                'cityid' => '130800',
                'alias' =>
                array (
                    0 => '承德',
                ),
            ),
            '唐山' =>
            array (
                'name' => '唐山',
                'citycode' => '0315',
                'x' => '118.16733',
                'y' => '39.63528',
                'spell' =>
                array (
                    0 => 'tangshan', 'ts'
                ),
                'cityid' => '130200',
                'alias' =>
                array (
                    0 => '唐山',
                ),
            ),
            '廊坊' =>
            array (
                'name' => '廊坊',
                'citycode' => '0316',
                'x' => '116.706334',
                'y' => '39.530844',
                'spell' =>
                array (
                    0 => 'langfang', 'lf'
                ),
                'cityid' => '131000',
                'alias' =>
                array (
                    0 => '廊坊',
                ),
            ),
            '秦皇岛' =>
            array (
                'name' => '秦皇岛',
                'citycode' => '0335',
                'x' => '119.589566',
                'y' => '39.947894',
                'spell' =>
                array (
                    0 => 'qinhuangdao', 'qhd'
                ),
                'cityid' => '130300',
                'alias' =>
                array (
                    0 => '秦皇岛',
                ),
            ),
            '沧州' =>
            array (
                'name' => '沧州',
                'citycode' => '0317',
                'x' => '116.866066',
                'y' => '38.312442',
                'spell' =>
                array (
                    0 => 'cangzhou', 'cz'
                ),
                'cityid' => '130900',
                'alias' =>
                array (
                    0 => '沧州',
                ),
            ),
            '衡水' =>
            array (
                'name' => '衡水',
                'citycode' => '0318',
                'x' => '115.698494',
                'y' => '37.735364',
                'spell' =>
                array (
                    0 => 'hengshui','hs'
                ),
                'cityid' => '131100',
                'alias' =>
                array (
                    0 => '衡水',
                ),
            ),
            '邢台' =>
            array (
                'name' => '邢台',
                'citycode' => '0319',
                'x' => '114.50431',
                'y' => '37.071685',
                'spell' =>
                array (
                    0 => 'xingtai','xt'
                ),
                'cityid' => '130500',
                'alias' =>
                array (
                    0 => '邢台',
                ),
            ),
        ),
    ),
    '河南省' =>
    array (
        'name' => '河南省',
        'spell' =>
        array (
            0 => 'henansheng',
            1 => 'hn',
        ),
        'alias' =>
        array (
            0 => '河南',
            1 => '河南省',
        ),
        'capital' => '郑州',
        'cities' =>
        array (
            '郑州' =>
            array (
                'name' => '郑州',
                'citycode' => '0371',
                'x' => '113.66304',
                'y' => '34.761869',
                'spell' =>
                array (
                    0 => 'zhengzhou','zz'
                ),
                'cityid' => '410100',
                'alias' =>
                array (
                    0 => '郑州',
                ),
            ),
            '安阳' =>
            array (
                'name' => '安阳',
                'citycode' => '0372',
                'x' => '114.346097',
                'y' => '36.111206',
                'spell' =>
                array (
                    0 => 'anyang', 'ay'
                ),
                'cityid' => '410500',
                'alias' =>
                array (
                    0 => '安阳',
                ),
            ),
            '新乡' =>
            array (
                'name' => '新乡',
                'citycode' => '0373',
                'x' => '113.88989',
                'y' => '35.301549',
                'spell' =>
                array (
                    0 => 'xinxiang', 'xx'
                ),
                'cityid' => '410700',
                'alias' =>
                array (
                    0 => '新乡',
                ),
            ),
            '许昌' =>
            array (
                'name' => '许昌',
                'citycode' => '0374',
                'x' => '113.832242',
                'y' => '34.022153',
                'spell' =>
                array (
                    0 => 'xuchang', 'xc'
                ),
                'cityid' => '411000',
                'alias' =>
                array (
                    0 => '许昌',
                ),
            ),
            '平顶山' =>
            array (
                'name' => '平顶山',
                'citycode' => '0375',
                'x' => '113.303552',
                'y' => '33.727391',
                'spell' =>
                array (
                    0 => 'pingdingshan', 'pds'
                ),
                'cityid' => '410400',
                'alias' =>
                array (
                    0 => '平顶山',
                ),
            ),
            '开封' =>
            array (
                'name' => '开封',
                'citycode' => '0378',
                'x' => '114.340217',
                'y' => '34.78931',
                'spell' =>
                array (
                    0 => 'kaifeng', 'kf'
                ),
                'cityid' => '410200',
                'alias' =>
                array (
                    0 => '开封',
                ),
            ),
            '洛阳' =>
            array (
                'name' => '洛阳',
                'citycode' => '0379',
                'x' => '112.400527',
                'y' => '34.656681',
                'spell' =>
                array (
                    0 => 'luoyang','ly'
                ),
                'cityid' => '410300',
                'alias' =>
                array (
                    0 => '洛阳',
                ),
            ),
            '焦作' =>
            array (
                'name' => '焦作',
                'citycode' => '0391',
                'x' => '113.227668',
                'y' => '35.233765',
                'spell' =>
                array (
                    0 => 'jiaozuo', 'jz'
                ),
                'cityid' => '410800',
                'alias' =>
                array (
                    0 => '焦作',
                ),
            ),
            '三门峡' =>
            array (
                'name' => '三门峡',
                'citycode' => '0398',
                'x' => '111.191508',
                'y' => '34.775773',
                'spell' =>
                array (
                    0 => 'sanmenxia', 'smx'
                ),
                'cityid' => '411200',
                'alias' =>
                array (
                    0 => '三门峡',
                ),
            ),
            '信阳' =>
            array (
                'name' => '信阳',
                'citycode' => '0376',
                'x' => '114.075236',
                'y' => '32.123998',
                'spell' =>
                array (
                    0 => 'xinyang', 'xy'
                ),
                'cityid' => '411500',
                'alias' =>
                array (
                    0 => '信阳',
                ),
            ),
            '南阳' =>
            array (
                'name' => '南阳',
                'citycode' => '0377',
                'x' => '112.534039',
                'y' => '32.99929',
                'spell' =>
                array (
                    0 => 'nanyang', 'ny'
                ),
                'cityid' => '411300',
                'alias' =>
                array (
                    0 => '南阳',
                ),
            ),
            '周口' =>
            array (
                'name' => '周口',
                'citycode' => '0394',
                'x' => '114.653046',
                'y' => '33.616581',
                'spell' =>
                array (
                    0 => 'zhoukou', 'zk'
                ),
                'cityid' => '411600',
                'alias' =>
                array (
                    0 => '周口',
                ),
            ),
            '商丘' =>
            array (
                'name' => '商丘',
                'citycode' => '0370',
                'x' => '115.651452',
                'y' => '34.438929',
                'spell' =>
                array (
                    0 => 'shangqiu', 'sq'
                ),
                'cityid' => '411400',
                'alias' =>
                array (
                    0 => '商丘',
                ),
            ),
            '济源' =>
            array (
                'name' => '济源',
                'citycode' => '1391',
                'x' => '112.588118',
                'y' => '35.090328',
                'spell' =>
                array (
                    0 => 'jiyuan', 'jy'
                ),
                'cityid' => '419001',
                'alias' =>
                array (
                    0 => '济源',
                ),
            ),
            '漯河' =>
            array (
                'name' => '漯河',
                'citycode' => '0395',
                'x' => '114.035996',
                'y' => '33.56728',
                'spell' =>
                array (
                    0 => 'luohe', 'lh'
                ),
                'cityid' => '411100',
                'alias' =>
                array (
                    0 => '漯河',
                ),
            ),
            '濮阳' =>
            array (
                'name' => '濮阳',
                'citycode' => '0393',
                'x' => '115.029276',
                'y' => '35.763215',
                'spell' =>
                array (
                    0 => 'puyang', 'py'
                ),
                'cityid' => '410900',
                'alias' =>
                array (
                    0 => '濮阳',
                ),
            ),
            '驻马店' =>
            array (
                'name' => '驻马店',
                'citycode' => '0396',
                'x' => '114.028018',
                'y' => '32.983172',
                'spell' =>
                array (
                    0 => 'zhumadian', 'zmd'
                ),
                'cityid' => '411700',
                'alias' =>
                array (
                    0 => '驻马店',
                ),
            ),
            '鹤壁' =>
            array (
                'name' => '鹤壁',
                'citycode' => '0392',
                'x' => '114.297033',
                'y' => '35.748107',
                'spell' =>
                array (
                    0 => 'hebi', 'hb'
                ),
                'cityid' => '410600',
                'alias' =>
                array (
                    0 => '鹤壁',
                ),
            ),
        ),
    ),
    '湖北省' =>
    array (
        'name' => '湖北省',
        'spell' =>
        array (
            0 => 'hubeisheng',
            1 => 'hb',
        ),
        'alias' =>
        array (
            0 => '湖北',
            1 => '湖北省',
        ),
        'capital' => '武汉',
        'cities' =>
        array (
            '武汉' =>
            array (
                'name' => '武汉',
                'citycode' => '027',
                'x' => '114.299388',
                'y' => '30.584318',
                'spell' =>
                array (
                    0 => 'wuhan', 'wh'
                ),
                'cityid' => '420100',
                'alias' =>
                array (
                    0 => '武汉',
                ),
            ),
            '襄阳' =>
            array (
                'name' => '襄阳',
                'citycode' => '0710',
                'x' => '112.13526',
                'y' => '32.062019',
                'spell' =>
                array (
                    0 => 'xiangyang', 'xy'
                ),
                'cityid' => '420600',
                'alias' =>
                array (
                    0 => '襄阳',
                ),
            ),
            '鄂州' =>
            array (
                'name' => '鄂州',
                'citycode' => '0711',
                'x' => '114.903679',
                'y' => '30.389795',
                'spell' =>
                array (
                    0 => 'ezhou','ez'
                ),
                'cityid' => '420700',
                'alias' =>
                array (
                    0 => '鄂州',
                ),
            ),
            '黄石' =>
            array (
                'name' => '黄石',
                'citycode' => '0714',
                'x' => '115.053817',
                'y' => '30.212354',
                'spell' =>
                array (
                    0 => 'huangshi', 'hs'
                ),
                'cityid' => '420200',
                'alias' =>
                array (
                    0 => '黄石',
                ),
            ),
            '荆州' =>
            array (
                'name' => '荆州',
                'citycode' => '0716',
                'x' => '112.245363',
                'y' => '30.325221',
                'spell' =>
                array (
                    0 => 'jingzhou','jz'
                ),
                'cityid' => '421000',
                'alias' =>
                array (
                    0 => '荆州',
                ),
            ),
            '宜昌' =>
            array (
                'name' => '宜昌',
                'citycode' => '0717',
                'x' => '111.294857',
                'y' => '30.701171',
                'spell' =>
                array (
                    0 => 'yichang','yc'
                ),
                'cityid' => '420500',
                'alias' =>
                array (
                    0 => '宜昌',
                ),
            ),
            '十堰' =>
            array (
                'name' => '十堰',
                'citycode' => '0719',
                'x' => '110.782005',
                'y' => '32.655306',
                'spell' =>
                array (
                    0 => 'shiyan', 'sy'
                ),
                'cityid' => '420300',
                'alias' =>
                array (
                    0 => '十堰',
                ),
            ),
            '荆门' =>
            array (
                'name' => '荆门',
                'citycode' => '0724',
                'x' => '112.196178',
                'y' => '31.027741',
                'spell' =>
                array (
                    0 => 'jingmen', 'jm'
                ),
                'cityid' => '420800',
                'alias' =>
                array (
                    0 => '荆门',
                ),
            ),
            '仙桃' =>
            array (
                'name' => '仙桃',
                'citycode' => '0728',
                'x' => '113.453157',
                'y' => '30.364578',
                'spell' =>
                array (
                    0 => 'xiantao', 'xt'
                ),
                'cityid' => '429004',
                'alias' =>
                array (
                    0 => '仙桃',
                ),
            ),
            '咸宁' =>
            array (
                'name' => '咸宁',
                'citycode' => '0715',
                'x' => '114.335653',
                'y' => '29.833699',
                'spell' =>
                array (
                    0 => 'xianning', 'xn'
                ),
                'cityid' => '421200',
                'alias' =>
                array (
                    0 => '咸宁',
                ),
            ),
            '天门' =>
            array (
                'name' => '天门',
                'citycode' => '1728',
                'x' => '113.163919',
                'y' => '30.651286',
                'spell' =>
                array (
                    0 => 'tianmen','tm'
                ),
                'cityid' => '429006',
                'alias' =>
                array (
                    0 => '天门',
                ),
            ),
            '孝感' =>
            array (
                'name' => '孝感',
                'citycode' => '0712',
                'x' => '113.91853',
                'y' => '30.924648',
                'spell' =>
                array (
                    0 => 'xiaogan','xg'
                ),
                'cityid' => '420900',
                'alias' =>
                array (
                    0 => '孝感',
                ),
            ),
            '潜江' =>
            array (
                'name' => '潜江',
                'citycode' => '2728',
                'x' => '112.894485',
                'y' => '30.419843',
                'spell' =>
                array (
                    0 => 'qianjiang','qj'
                ),
                'cityid' => '429005',
                'alias' =>
                array (
                    0 => '潜江',
                ),
            ),
            '随州' =>
            array (
                'name' => '随州',
                'citycode' => '0722',
                'x' => '113.375497',
                'y' => '31.716709',
                'spell' =>
                array (
                    0 => 'suizhou','sz'
                ),
                'cityid' => '421300',
                'alias' =>
                array (
                    0 => '随州',
                ),
            ),
            '黄冈' =>
            array (
                'name' => '黄冈',
                'citycode' => '0713',
                'x' => '114.875451',
                'y' => '30.446458',
                'spell' =>
                array (
                    0 => 'huanggang','hg'
                ),
                'cityid' => '421100',
                'alias' =>
                array (
                    0 => '黄冈',
                ),
            ),
            '神农架林区' =>
            array (
                'name' => '神农架林区',
                'citycode' => '1719',
                'x' => '110.676105',
                'y' => '31.744802',
                'spell' =>
                array (
                    0 => 'shennongjia','snj'
                ),
                'cityid' => '429021',
                'alias' =>
                array (
                    0 => '神农架林区',
                ),
            ),
            '恩施土家族苗族自治州' =>
            array (
                'name' => '恩施土家族苗族自治州',
                'citycode' => '0718',
                'x' => '109.482345',
                'y' => '30.289919',
                'spell' =>
                array (
                    0 => 'enshi','es'
                ),
                'cityid' => '422800',
                'alias' =>
                array (
                    0 => '恩施土家族苗族自治州',
                ),
            ),
        ),
    ),
    '湖南省' =>
    array (
        'name' => '湖南省',
        'spell' =>
        array (
            0 => 'hunansheng',
            1 => 'hn',
        ),
        'alias' =>
        array (
            0 => '湖南',
            1 => '湖南省',
        ),
        'capital' => '长沙',
        'cities' =>
        array (
            '岳阳' =>
            array (
                'name' => '岳阳',
                'citycode' => '0730',
                'x' => '113.108197',
                'y' => '29.366316',
                'spell' =>
                array (
                    0 => 'yueyang','yy'
                ),
                'cityid' => '430600',
                'alias' =>
                array (
                    0 => '岳阳',
                ),
            ),
            '长沙' =>
            array (
                'name' => '长沙',
                'citycode' => '0731',
                'x' => '112.977851',
                'y' => '28.193134',
                'spell' =>
                array (
                    0 => 'changsha','cs'
                ),
                'cityid' => '430100',
                'alias' =>
                array (
                    0 => '长沙',
                ),
            ),
            '湘潭' =>
            array (
                'name' => '湘潭',
                'citycode' => '0732',
                'x' => '112.911451',
                'y' => '27.858647',
                'spell' =>
                array (
                    0 => 'xiangtan','xt'
                ),
                'cityid' => '430300',
                'alias' =>
                array (
                    0 => '湘潭',
                ),
            ),
            '株洲' =>
            array (
                'name' => '株洲',
                'citycode' => '0733',
                'x' => '113.149446',
                'y' => '27.840644',
                'spell' =>
                array (
                    0 => 'zhuzhou','zz'
                ),
                'cityid' => '430200',
                'alias' =>
                array (
                    0 => '株洲',
                ),
            ),
            '衡阳' =>
            array (
                'name' => '衡阳',
                'citycode' => '0734',
                'x' => '112.612227',
                'y' => '26.89625',
                'spell' =>
                array (
                    0 => 'hengyang','hy'
                ),
                'cityid' => '430400',
                'alias' =>
                array (
                    0 => '衡阳',
                ),
            ),
            '常德' =>
            array (
                'name' => '常德',
                'citycode' => '0736',
                'x' => '111.702672',
                'y' => '29.036636',
                'spell' =>
                array (
                    0 => 'changde', 'cd'
                ),
                'cityid' => '430700',
                'alias' =>
                array (
                    0 => '常德',
                ),
            ),
            '张家界' =>
            array (
                'name' => '张家界',
                'citycode' => '0744',
                'x' => '110.47699',
                'y' => '29.119677',
                'spell' =>
                array (
                    0 => 'zhangjiajie','zjj'
                ),
                'cityid' => '430800',
                'alias' =>
                array (
                    0 => '张家界',
                ),
            ),
            '娄底' =>
            array (
                'name' => '娄底',
                'citycode' => '0738',
                'x' => '111.998225',
                'y' => '27.725857',
                'spell' =>
                array (
                    0 => 'loudi','ld'
                ),
                'cityid' => '431300',
                'alias' =>
                array (
                    0 => '娄底',
                ),
            ),
            '怀化' =>
            array (
                'name' => '怀化',
                'citycode' => '0745',
                'x' => '109.976748',
                'y' => '27.548367',
                'spell' =>
                array (
                    0 => 'huaihua','hh'
                ),
                'cityid' => '431200',
                'alias' =>
                array (
                    0 => '怀化',
                ),
            ),
            '永州' =>
            array (
                'name' => '永州',
                'citycode' => '0746',
                'x' => '111.607916',
                'y' => '26.438047',
                'spell' =>
                array (
                    0 => 'yongzhou','yz'
                ),
                'cityid' => '431100',
                'alias' =>
                array (
                    0 => '永州',
                ),
            ),
            '益阳' =>
            array (
                'name' => '益阳',
                'citycode' => '0737',
                'x' => '112.355542',
                'y' => '28.579975',
                'spell' =>
                array (
                    0 => 'yiyang','yy'
                ),
                'cityid' => '430900',
                'alias' =>
                array (
                    0 => '益阳',
                ),
            ),
            '邵阳' =>
            array (
                'name' => '邵阳',
                'citycode' => '0739',
                'x' => '111.467273',
                'y' => '27.237143',
                'spell' =>
                array (
                    0 => 'shaoyang','sy'
                ),
                'cityid' => '430500',
                'alias' =>
                array (
                    0 => '邵阳',
                ),
            ),
            '郴州' =>
            array (
                'name' => '郴州',
                'citycode' => '0735',
                'x' => '113.032112',
                'y' => '25.796842',
                'spell' =>
                array (
                    0 => 'chenzhou','cz'
                ),
                'cityid' => '431000',
                'alias' =>
                array (
                    0 => '郴州',
                ),
            ),
            '湘西土家族苗族自治州' =>
            array (
                'name' => '湘西土家族苗族自治州',
                'citycode' => '0743',
                'x' => '109.600623',
                'y' => '27.947218',
                'spell' =>
                array (
                    0 => 'xiangxi', 'xx'
                ),
                'cityid' => '433100',
                'alias' =>
                array (
                    0 => '湘西土家族苗族自治州',
                ),
            ),
        ),
    ),
    '黑龙江省' =>
    array (
        'name' => '黑龙江省',
        'spell' =>
        array (
            0 => 'heilongjiangsheng',
            1 => 'hlj',
        ),
        'alias' =>
        array (
            0 => '黑龙江',
            1 => '黑龙江省',
        ),
        'capital' => '哈尔滨',
        'cities' =>
        array (
            '哈尔滨' =>
            array (
                'name' => '哈尔滨',
                'citycode' => '0451',
                'x' => '126.652187',
                'y' => '45.761273',
                'spell' =>
                array (
                    0 => 'haerbin','heb'
                ),
                'cityid' => '230100',
                'alias' =>
                array (
                    0 => '哈尔滨',
                ),
            ),
            '齐齐哈尔' =>
            array (
                'name' => '齐齐哈尔',
                'citycode' => '0452',
                'x' => '123.937168',
                'y' => '47.341587',
                'spell' =>
                array (
                    0 => 'qiqihaer','qqhe'
                ),
                'cityid' => '230200',
                'alias' =>
                array (
                    0 => '齐齐哈尔',
                ),
            ),
            '牡丹江' =>
            array (
                'name' => '牡丹江',
                'citycode' => '0453',
                'x' => '129.622739',
                'y' => '44.584756',
                'spell' =>
                array (
                    0 => 'mudanjiang','mdj'
                ),
                'cityid' => '231000',
                'alias' =>
                array (
                    0 => '牡丹江',
                ),
            ),
            '大庆' =>
            array (
                'name' => '大庆',
                'citycode' => '0459',
                'x' => '125.094265',
                'y' => '46.588327',
                'spell' =>
                array (
                    0 => 'daqing','dq'
                ),
                'cityid' => '230600',
                'alias' =>
                array (
                    0 => '大庆',
                ),
            ),
            '佳木斯' =>
            array (
                'name' => '佳木斯',
                'citycode' => '0454',
                'x' => '130.36958',
                'y' => '46.807458',
                'spell' =>
                array (
                    0 => 'jiamusi','jms'
                ),
                'cityid' => '230800',
                'alias' =>
                array (
                    0 => '佳木斯',
                ),
            ),
            '七台河' =>
            array (
                'name' => '七台河',
                'citycode' => '0464',
                'x' => '131.007893',
                'y' => '45.771909',
                'spell' =>
                array (
                    0 => 'qitaihe','qth'
                ),
                'cityid' => '230900',
                'alias' =>
                array (
                    0 => '七台河',
                ),
            ),
            '伊春' =>
            array (
                'name' => '伊春',
                'citycode' => '0458',
                'x' => '128.901147',
                'y' => '47.72473',
                'spell' =>
                array (
                    0 => 'yichun','yc'
                ),
                'cityid' => '230700',
                'alias' =>
                array (
                    0 => '伊春',
                ),
            ),
            '双鸭山' =>
            array (
                'name' => '双鸭山',
                'citycode' => '0469',
                'x' => '131.159897',
                'y' => '46.646949',
                'spell' =>
                array (
                    0 => 'shuangyashan','sys'
                ),
                'cityid' => '230500',
                'alias' =>
                array (
                    0 => '双鸭山',
                ),
            ),
            '大兴安岭地区' =>
            array (
                'name' => '大兴安岭地区',
                'citycode' => '0457',
                'x' => '124.397369',
                'y' => '51.673664',
                'spell' =>
                array (
                    0 => 'daxinganling','dxal'
                ),
                'cityid' => '232700',
                'alias' =>
                array (
                    0 => '大兴安岭地区',
                ),
            ),
            '绥化' =>
            array (
                'name' => '绥化',
                'citycode' => '0455',
                'x' => '126.990389',
                'y' => '46.636975',
                'spell' =>
                array (
                    0 => 'suihua','sh'
                ),
                'cityid' => '231200',
                'alias' =>
                array (
                    0 => '绥化',
                ),
            ),
            '鸡西' =>
            array (
                'name' => '鸡西',
                'citycode' => '0467',
                'x' => '130.969855',
                'y' => '45.29516',
                'spell' =>
                array (
                    0 => 'jixi','jx'
                ),
                'cityid' => '230300',
                'alias' =>
                array (
                    0 => '鸡西',
                ),
            ),
            '鹤岗' =>
            array (
                'name' => '鹤岗',
                'citycode' => '0468',
                'x' => '130.278546',
                'y' => '47.331056',
                'spell' =>
                array (
                    0 => 'hegang','hg'
                ),
                'cityid' => '230400',
                'alias' =>
                array (
                    0 => '鹤岗',
                ),
            ),
            '黑河' =>
            array (
                'name' => '黑河',
                'citycode' => '0456',
                'x' => '127.500942',
                'y' => '50.247889',
                'spell' =>
                array (
                    0 => 'heihe','hh'
                ),
                'cityid' => '231100',
                'alias' =>
                array (
                    0 => '黑河',
                ),
            ),
        ),
    ),
    '海南省' =>
    array (
        'name' => '海南省',
        'spell' =>
        array (
            0 => 'hainansheng',
            1 => 'hn',
        ),
        'alias' =>
        array (
            0 => '海南',
            1 => '海南省',
        ),
        'capital' => '海口',
        'cities' =>
        array (
            '海口' =>
            array (
                'name' => '海口',
                'citycode' => '0898',
                'x' => '110.320198',
                'y' => '20.032303',
                'spell' =>
                array (
                    0 => 'haikou','hk'
                ),
                'cityid' => '460100',
                'alias' =>
                array (
                    0 => '海口',
                ),
            ),
            '三亚' =>
            array (
                'name' => '三亚',
                'citycode' => '0899',
                'x' => '109.513615',
                'y' => '18.235517',
                'spell' =>
                array (
                    0 => 'sanya','sy'
                ),
                'cityid' => '460200',
                'alias' =>
                array (
                    0 => '三亚',
                ),
            ),
            '三沙' =>
            array (
                'name' => '三沙',
                'citycode' => '010',
                'x' => '112.33357',
                'y' => '16.83274',
                'spell' =>
                array (
                    0 => 'sansha','ss'
                ),
                'cityid' => '460300',
                'alias' =>
                array (
                    0 => '三沙',
                ),
            ),
            '白沙黎族自治县' =>
            array (
                'name' => '白沙黎族自治县',
                'citycode' => '0802',
                'x' => '109.448045',
                'y' => '19.227325',
                'spell' =>
                array (
                    0 => 'baisha','bs'
                ),
                'cityid' => '469025',
                'alias' =>
                array (
                    0 => '白沙黎族自治县',
                ),
            ),
            '保亭黎族苗族自治县' =>
            array (
                'name' => '保亭黎族苗族自治县',
                'citycode' => '0801',
                'x' => '109.697072',
                'y' => '18.640988',
                'spell' =>
                array (
                    0 => 'baoting','bt'
                ),
                'cityid' => '469029',
                'alias' =>
                array (
                    0 => '保亭黎族苗族自治县',
                ),
            ),
            '昌江黎族自治县' =>
            array (
                'name' => '昌江黎族自治县',
                'citycode' => '0803',
                'x' => '109.052755',
                'y' => '19.260048',
                'spell' =>
                array (
                    0 => 'changjiang','cj'
                ),
                'cityid' => '469026',
                'alias' =>
                array (
                    0 => '昌江黎族自治县',
                ),
            ),
            '澄迈县' =>
            array (
                'name' => '澄迈县',
                'citycode' => '0804',
                'x' => '110.006083',
                'y' => '19.734501',
                'spell' =>
                array (
                    0 => 'chengmai','cm'
                ),
                'cityid' => '469023',
                'alias' =>
                array (
                    0 => '澄迈县',
                ),
            ),
            '定安县' =>
            array (
                'name' => '定安县',
                'citycode' => '0806',
                'x' => '110.446603',
                'y' => '19.472789',
                'spell' =>
                array (
                    0 => 'dingan','da'
                ),
                'cityid' => '469021',
                'alias' =>
                array (
                    0 => '定安县',
                ),
            ),
            '东方' =>
            array (
                'name' => '东方',
                'citycode' => '0807',
                'x' => '108.642583',
                'y' => '19.102837',
                'spell' =>
                array (
                    0 => 'dongfang','df'
                ),
                'cityid' => '469007',
                'alias' =>
                array (
                    0 => '东方',
                ),
            ),
            '东沙群岛' =>
            array (
                'name' => '东沙群岛',
                'citycode' => '0808',
                'x' => '116.9178',
                'y' => '20.670523',
                'spell' =>
                array (
                    0 => 'dongshaqundao','dsqd'
                ),
                'cityid' => '0',
                'alias' =>
                array (
                    0 => '东沙群岛',
                ),
            ),
            '乐东黎族自治县' =>
            array (
                'name' => '乐东黎族自治县',
                'citycode' => '2802',
                'x' => '109.175406',
                'y' => '18.752108',
                'spell' =>
                array (
                    0 => 'ledong','ld'
                ),
                'cityid' => '469027',
                'alias' =>
                array (
                    0 => '乐东黎族自治县',
                ),
            ),
            '临高县' =>
            array (
                'name' => '临高县',
                'citycode' => '1896',
                'x' => '109.685961',
                'y' => '19.912147',
                'spell' =>
                array (
                    0 => 'lingao','lg'
                ),
                'cityid' => '469024',
                'alias' =>
                array (
                    0 => '临高县',
                ),
            ),
            '陵水黎族自治县' =>
            array (
                'name' => '陵水黎族自治县',
                'citycode' => '0809',
                'x' => '110.043359',
                'y' => '18.507404',
                'spell' =>
                array (
                    0 => 'lingshui','ls'
                ),
                'cityid' => '469028',
                'alias' =>
                array (
                    0 => '陵水黎族自治县',
                ),
            ),
            '南沙群岛' =>
            array (
                'name' => '南沙群岛',
                'citycode' => '1891',
                'x' => '116.626238',
                'y' => '11.323754',
                'spell' =>
                array (
                    0 => 'nanshaqundao','nsqd'
                ),
                'cityid' => '460322',
                'alias' =>
                array (
                    0 => '南沙群岛',
                ),
            ),
            '琼海' =>
            array (
                'name' => '琼海',
                'citycode' => '1894',
                'x' => '110.458306',
                'y' => '19.244303',
                'spell' =>
                array (
                    0 => 'qionghai','qh'
                ),
                'cityid' => '469002',
                'alias' =>
                array (
                    0 => '琼海',
                ),
            ),
            '琼中黎族苗族自治县' =>
            array (
                'name' => '琼中黎族苗族自治县',
                'citycode' => '1899',
                'x' => '109.812343',
                'y' => '19.266923',
                'spell' =>
                array (
                    0 => 'qiongzhong','qz'
                ),
                'cityid' => '469030',
                'alias' =>
                array (
                    0 => '琼中黎族苗族自治县',
                ),
            ),
            '屯昌县' =>
            array (
                'name' => '屯昌县',
                'citycode' => '1892',
                'x' => '110.097988',
                'y' => '19.364122',
                'spell' =>
                array (
                    0 => 'tunchang','tc'
                ),
                'cityid' => '469022',
                'alias' =>
                array (
                    0 => '屯昌县',
                ),
            ),
            '万宁' =>
            array (
                'name' => '万宁',
                'citycode' => '1898',
                'x' => '110.384818',
                'y' => '18.805524',
                'spell' =>
                array (
                    0 => 'wanning','wn'
                ),
                'cityid' => '469006',
                'alias' =>
                array (
                    0 => '万宁',
                ),
            ),
            '文昌' =>
            array (
                'name' => '文昌',
                'citycode' => '1893',
                'x' => '110.723736',
                'y' => '19.628654',
                'spell' =>
                array (
                    0 => 'wenchang','wc'
                ),
                'cityid' => '469005',
                'alias' =>
                array (
                    0 => '文昌',
                ),
            ),
            '五指山' =>
            array (
                'name' => '五指山',
                'citycode' => '1897',
                'x' => '109.516686',
                'y' => '18.775979',
                'spell' =>
                array (
                    0 => 'wuzhishan','wzs'
                ),
                'cityid' => '469001',
                'alias' =>
                array (
                    0 => '五指山',
                ),
            ),
            '西沙群岛' =>
            array (
                'name' => '西沙群岛',
                'citycode' => '1895',
                'x' => '111.583545',
                'y' => '16.464052',
                'spell' =>
                array (
                    0 => 'xishaqundao','xsqd'
                ),
                'cityid' => '460321',
                'alias' =>
                array (
                    0 => '西沙群岛',
                ),
            ),
            '中沙群岛' =>
            array (
                'name' => '中沙群岛',
                'citycode' => '2801',
                'x' => '114.466203',
                'y' => '15.592741',
                'spell' =>
                array (
                    0 => 'zhongshaqundao','zsqd'
                ),
                'cityid' => '460323',
                'alias' =>
                array (
                    0 => '中沙群岛',
                ),
            ),
            '儋州' =>
            array (
                'name' => '儋州',
                'citycode' => '0805',
                'x' => '109.58097',
                'y' => '19.519671',
                'spell' =>
                array (
                    0 => 'danzhou','dz'
                ),
                'cityid' => '469003',
                'alias' =>
                array (
                    0 => '儋州',
                ),
            ),
        ),
    ),
    '吉林省' =>
    array (
        'name' => '吉林省',
        'spell' =>
        array (
            0 => 'jilinsheng',
            1 => 'jl',
        ),
        'alias' =>
        array (
            0 => '吉林',
            1 => '吉林省',
        ),
        'capital' => '长春',
        'cities' =>
        array (
            '长春' =>
            array (
                'name' => '长春',
                'citycode' => '0431',
                'x' => '125.320406',
                'y' => '43.885201',
                'spell' =>
                array (
                    0 => 'changchun','cc'
                ),
                'cityid' => '220100',
                'alias' =>
                array (
                    0 => '长春',
                ),
            ),
            '吉林' =>
            array (
                'name' => '吉林',
                'citycode' => '0432',
                'x' => '126.571344',
                'y' => '43.845837',
                'spell' =>
                array (
                    0 => 'jilin','jl'
                ),
                'cityid' => '220200',
                'alias' =>
                array (
                    0 => '吉林',
                ),
            ),
            '四平' =>
            array (
                'name' => '四平',
                'citycode' => '0434',
                'x' => '124.39796',
                'y' => '43.17251',
                'spell' =>
                array (
                    0 => 'siping','sp'
                ),
                'cityid' => '220300',
                'alias' =>
                array (
                    0 => '四平',
                ),
            ),
            '延边朝鲜族自治州' =>
            array (
                'name' => '延边朝鲜族自治州',
                'citycode' => '1433',
                'x' => '129.4976548',
                'y' => '42.89415201',
                'spell' =>
                array (
                    0 => 'yanbian','yb'
                ),
                'cityid' => '222400',
                'alias' =>
                array (
                    0 => '延边朝鲜族自治州',
                ),
            ),
            '松原' =>
            array (
                'name' => '松原',
                'citycode' => '0438',
                'x' => '124.823864',
                'y' => '45.140898',
                'spell' =>
                array (
                    0 => 'songyuan','sy'
                ),
                'cityid' => '220700',
                'alias' =>
                array (
                    0 => '松原',
                ),
            ),
            '白城' =>
            array (
                'name' => '白城',
                'citycode' => '0436',
                'x' => '122.838152',
                'y' => '45.620365',
                'spell' =>
                array (
                    0 => 'baicheng','bc'
                ),
                'cityid' => '220800',
                'alias' =>
                array (
                    0 => '白城',
                ),
            ),
            '白山' =>
            array (
                'name' => '白山',
                'citycode' => '0439',
                'x' => '126.423844',
                'y' => '41.940109',
                'spell' =>
                array (
                    0 => 'baishan','bs'
                ),
                'cityid' => '220600',
                'alias' =>
                array (
                    0 => '白山',
                ),
            ),
            '辽源' =>
            array (
                'name' => '辽源',
                'citycode' => '0437',
                'x' => '125.144516',
                'y' => '42.905805',
                'spell' =>
                array (
                    0 => 'liaoyuan','ly'
                ),
                'cityid' => '220400',
                'alias' =>
                array (
                    0 => '辽源',
                ),
            ),
            '通化' =>
            array (
                'name' => '通化',
                'citycode' => '0435',
                'x' => '125.940166',
                'y' => '41.729173',
                'spell' =>
                array (
                    0 => 'tonghua','th'
                ),
                'cityid' => '220500',
                'alias' =>
                array (
                    0 => '通化',
                ),
            ),
        ),
    ),
    '江苏省' =>
    array (
        'name' => '江苏省',
        'spell' =>
        array (
            0 => 'jiangsusheng',
            1 => 'js',
        ),
        'alias' =>
        array (
            0 => '江苏',
            1 => '江苏省',
        ),
        'capital' => '南京',
        'cities' =>
        array (
            '南京' =>
            array (
                'name' => '南京',
                'citycode' => '025',
                'x' => '118.764788',
                'y' => '32.043700',
                'spell' =>
                array (
                    0 => 'nanjing','nj'
                ),
                'cityid' => '320100',
                'alias' =>
                array (
                    0 => '南京',
                ),
            ),
            '无锡' =>
            array (
                'name' => '无锡',
                'citycode' => '0510',
                'x' => '120.297543',
                'y' => '31.574307',
                'spell' =>
                array (
                    0 => 'wuxi','wx'
                ),
                'cityid' => '320200',
                'alias' =>
                array (
                    0 => '无锡',
                ),
            ),
            '镇江' =>
            array (
                'name' => '镇江',
                'citycode' => '0511',
                'x' => '119.442429',
                'y' => '32.211045',
                'spell' =>
                array (
                    0 => 'zhenjiang','zj'
                ),
                'cityid' => '321100',
                'alias' =>
                array (
                    0 => '镇江',
                ),
            ),
            '苏州' =>
            array (
                'name' => '苏州',
                'citycode' => '0512',
                'x' => '120.63869',
                'y' => '31.320548',
                'spell' =>
                array (
                    0 => 'suzhou','sz'
                ),
                'cityid' => '320500',
                'alias' =>
                array (
                    0 => '苏州',
                ),
            ),
            '南通' =>
            array (
                'name' => '南通',
                'citycode' => '0513',
                'x' => '120.870434',
                'y' => '32.011623',
                'spell' =>
                array (
                    0 => 'nantong','nt'
                ),
                'cityid' => '320600',
                'alias' =>
                array (
                    0 => '南通',
                ),
            ),
            '扬州' =>
            array (
                'name' => '扬州',
                'citycode' => '0514',
                'x' => '119.412865',
                'y' => '32.419474',
                'spell' =>
                array (
                    0 => 'yangzhou','yz'
                ),
                'cityid' => '321000',
                'alias' =>
                array (
                    0 => '扬州',
                ),
            ),
            '盐城' =>
            array (
                'name' => '盐城',
                'citycode' => '0515',
                'x' => '120.139212',
                'y' => '33.37938',
                'spell' =>
                array (
                    0 => 'yancheng','yc'
                ),
                'cityid' => '320900',
                'alias' =>
                array (
                    0 => '盐城',
                ),
            ),
            '徐州' =>
            array (
                'name' => '徐州',
                'citycode' => '0516',
                'x' => '117.173953',
                'y' => '34.258579',
                'spell' =>
                array (
                    0 => 'xuzhou','xz'
                ),
                'cityid' => '320300',
                'alias' =>
                array (
                    0 => '徐州',
                ),
            ),
            '连云港' =>
            array (
                'name' => '连云港',
                'citycode' => '0518',
                'x' => '119.172831',
                'y' => '34.595894',
                'spell' =>
                array (
                    0 => 'lianyungang','lyg'
                ),
                'cityid' => '320700',
                'alias' =>
                array (
                    0 => '连云港',
                ),
            ),
            '常州' =>
            array (
                'name' => '常州',
                'citycode' => '0519',
                'x' => '119.944134',
                'y' => '31.771131',
                'spell' =>
                array (
                    0 => 'changzhou','cz'
                ),
                'cityid' => '320400',
                'alias' =>
                array (
                    0 => '常州',
                ),
            ),
            '泰州' =>
            array (
                'name' => '泰州',
                'citycode' => '0523',
                'x' => '119.920847',
                'y' => '32.461662',
                'spell' =>
                array (
                    0 => 'taizhou','tz'
                ),
                'cityid' => '321200',
                'alias' =>
                array (
                    0 => '泰州',
                ),
            ),
            '宿迁' =>
            array (
                'name' => '宿迁',
                'citycode' => '0527',
                'x' => '118.296656',
                'y' => '33.953872',
                'spell' =>
                array (
                    0 => 'suqian','sq'
                ),
                'cityid' => '321300',
                'alias' =>
                array (
                    0 => '宿迁',
                ),
            ),
            '淮安' =>
            array (
                'name' => '淮安',
                'citycode' => '0517',
                'x' => '119.015451',
                'y' => '33.611977',
                'spell' =>
                array (
                    0 => 'huaian','ha'
                ),
                'cityid' => '320800',
                'alias' =>
                array (
                    0 => '淮安',
                ),
            ),
        ),
    ),
    '江西省' =>
    array (
        'name' => '江西省',
        'spell' =>
        array (
            0 => 'jiangxisheng',
            1 => 'jx',
        ),
        'alias' =>
        array (
            0 => '江西',
            1 => '江西省',
        ),
        'capital' => '南昌',
        'cities' =>
        array (
            '南昌' =>
            array (
                'name' => '南昌',
                'citycode' => '0791',
                'x' => '115.897365',
                'y' => '28.678757',
                'spell' =>
                array (
                    0 => 'nanchang','nc'
                ),
                'cityid' => '360100',
                'alias' =>
                array (
                    0 => '南昌',
                ),
            ),
            '九江' =>
            array (
                'name' => '九江',
                'citycode' => '0792',
                'x' => '115.990395',
                'y' => '29.715566',
                'spell' =>
                array (
                    0 => 'jiujiang','jj'
                ),
                'cityid' => '360400',
                'alias' =>
                array (
                    0 => '九江',
                ),
            ),
            '景德镇' =>
            array (
                'name' => '景德镇',
                'citycode' => '0798',
                'x' => '117.214898',
                'y' => '29.293986',
                'spell' =>
                array (
                    0 => 'jingdezhen','jdz'
                ),
                'cityid' => '360200',
                'alias' =>
                array (
                    0 => '景德镇',
                ),
            ),
            '吉安' =>
            array (
                'name' => '吉安',
                'citycode' => '0796',
                'x' => '114.986707',
                'y' => '27.113638',
                'spell' =>
                array (
                    0 => 'jian','ja'
                ),
                'cityid' => '360800',
                'alias' =>
                array (
                    0 => '吉安',
                ),
            ),
            '宜春' =>
            array (
                'name' => '宜春',
                'citycode' => '0795',
                'x' => '114.398837',
                'y' => '27.806806',
                'spell' =>
                array (
                    0 => 'yichun','yc'
                ),
                'cityid' => '360900',
                'alias' =>
                array (
                    0 => '宜春',
                ),
            ),
            '抚州' =>
            array (
                'name' => '抚州',
                'citycode' => '0794',
                'x' => '116.362755',
                'y' => '27.979277',
                'spell' =>
                array (
                    0 => 'fuzhou','fz'
                ),
                'cityid' => '361000',
                'alias' =>
                array (
                    0 => '抚州',
                ),
            ),
            '新余' =>
            array (
                'name' => '新余',
                'citycode' => '0790',
                'x' => '114.918109',
                'y' => '27.816319',
                'spell' =>
                array (
                    0 => 'xinyu','xy'
                ),
                'cityid' => '360500',
                'alias' =>
                array (
                    0 => '新余',
                ),
            ),
            '萍乡' =>
            array (
                'name' => '萍乡',
                'citycode' => '0799',
                'x' => '113.852044',
                'y' => '27.622726',
                'spell' =>
                array (
                    0 => 'pingxiang','px'
                ),
                'cityid' => '360300',
                'alias' =>
                array (
                    0 => '萍乡',
                ),
            ),
            '赣州' =>
            array (
                'name' => '赣州',
                'citycode' => '0797',
                'x' => '114.942269',
                'y' => '25.855261',
                'spell' =>
                array (
                    0 => 'ganzhou','gz'
                ),
                'cityid' => '360700',
                'alias' =>
                array (
                    0 => '赣州',
                ),
            ),
            '鹰潭' =>
            array (
                'name' => '鹰潭',
                'citycode' => '0701',
                'x' => '117.033707',
                'y' => '28.239408',
                'spell' =>
                array (
                    0 => 'yingtan','yt'
                ),
                'cityid' => '360600',
                'alias' =>
                array (
                    0 => '鹰潭',
                ),
            ),
            '上饶' =>
            array (
                'name' => '上饶',
                'citycode' => '0793',
                'x' => '117.968869',
                'y' => '28.445636',
                'spell' =>
                array (
                    0 => 'shangrao','sr'
                ),
                'cityid' => '361100',
                'alias' =>
                array (
                    0 => '上饶',
                ),
            ),
        ),
    ),
    '辽宁省' =>
    array (
        'name' => '辽宁省',
        'spell' =>
        array (
            0 => 'liaoningsheng',
            1 => 'ln',
        ),
        'alias' =>
        array (
            0 => '辽宁',
            1 => '辽宁省',
        ),
        'capital' => '沈阳',
        'cities' =>
        array (
            '沈阳' =>
            array (
                'name' => '沈阳',
                'citycode' => '024',
                'x' => '123.429205',
                'y' => '41.794511',
                'spell' =>
                array (
                    0 => 'shenyang','sy'
                ),
                'cityid' => '210100',
                'alias' =>
                array (
                    0 => '沈阳',
                ),
            ),
            '大连' =>
            array (
                'name' => '大连',
                'citycode' => '0411',
                'x' => '121.618144',
                'y' => '38.913287',
                'spell' =>
                array (
                    0 => 'dalian','dl'
                ),
                'cityid' => '210200',
                'alias' =>
                array (
                    0 => '大连',
                ),
            ),
            '鞍山' =>
            array (
                'name' => '鞍山',
                'citycode' => '0412',
                'x' => '123.002341',
                'y' => '41.11576',
                'spell' =>
                array (
                    0 => 'anshan','as'
                ),
                'cityid' => '210300',
                'alias' =>
                array (
                    0 => '鞍山',
                ),
            ),
            '抚顺' =>
            array (
                'name' => '抚顺',
                'citycode' => '0413',
                'x' => '123.924361',
                'y' => '41.867771',
                'spell' =>
                array (
                    0 => 'fushun','fs'
                ),
                'cityid' => '210400',
                'alias' =>
                array (
                    0 => '抚顺',
                ),
            ),
            '本溪' =>
            array (
                'name' => '本溪',
                'citycode' => '0414',
                'x' => '123.770479',
                'y' => '41.290683',
                'spell' =>
                array (
                    0 => 'benxi','bx'
                ),
                'cityid' => '210500',
                'alias' =>
                array (
                    0 => '本溪',
                ),
            ),
            '丹东' =>
            array (
                'name' => '丹东',
                'citycode' => '0415',
                'x' => '124.39458',
                'y' => '40.127194',
                'spell' =>
                array (
                    0 => 'dandong','dd'
                ),
                'cityid' => '210600',
                'alias' =>
                array (
                    0 => '丹东',
                ),
            ),
            '锦州' =>
            array (
                'name' => '锦州',
                'citycode' => '0416',
                'x' => '121.147688',
                'y' => '41.126092',
                'spell' =>
                array (
                    0 => 'jinzhou','jz'
                ),
                'cityid' => '210700',
                'alias' =>
                array (
                    0 => '锦州',
                ),
            ),
            '营口' =>
            array (
                'name' => '营口',
                'citycode' => '0417',
                'x' => '122.250182',
                'y' => '40.671616',
                'spell' =>
                array (
                    0 => 'yingkou','yk'
                ),
                'cityid' => '210800',
                'alias' =>
                array (
                    0 => '营口',
                ),
            ),
            '辽阳' =>
            array (
                'name' => '辽阳',
                'citycode' => '0419',
                'x' => '123.179139',
                'y' => '41.277778',
                'spell' =>
                array (
                    0 => 'liaoyang','ly'
                ),
                'cityid' => '211000',
                'alias' =>
                array (
                    0 => '辽阳',
                ),
            ),
            '盘锦' =>
            array (
                'name' => '盘锦',
                'citycode' => '0427',
                'x' => '122.07105',
                'y' => '41.118808',
                'spell' =>
                array (
                    0 => 'panjin','pj'
                ),
                'cityid' => '211100',
                'alias' =>
                array (
                    0 => '盘锦',
                ),
            ),
            '葫芦岛' =>
            array (
                'name' => '葫芦岛',
                'citycode' => '0429',
                'x' => '120.856212',
                'y' => '40.748111',
                'spell' =>
                array (
                    0 => 'huludao','hld'
                ),
                'cityid' => '211400',
                'alias' =>
                array (
                    0 => '葫芦岛',
                ),
            ),
            '朝阳' =>
            array (
                'name' => '朝阳',
                'citycode' => '0421',
                'x' => '120.450369',
                'y' => '41.573524',
                'spell' =>
                array (
                    0 => 'chaoyang','cy'
                ),
                'cityid' => '211300',
                'alias' =>
                array (
                    0 => '朝阳',
                ),
            ),
            '铁岭' =>
            array (
                'name' => '铁岭',
                'citycode' => '0410',
                'x' => '123.84254',
                'y' => '42.286685',
                'spell' =>
                array (
                    0 => 'tieling','tl'
                ),
                'cityid' => '211200',
                'alias' =>
                array (
                    0 => '铁岭',
                ),
            ),
            '阜新' =>
            array (
                'name' => '阜新',
                'citycode' => '0418',
                'x' => '121.653899',
                'y' => '42.014315',
                'spell' =>
                array (
                    0 => 'fuxin','fx'
                ),
                'cityid' => '210900',
                'alias' =>
                array (
                    0 => '阜新',
                ),
            ),
        ),
    ),
    '内蒙古自治区' =>
    array (
        'name' => '内蒙古自治区',
        'spell' =>
        array (
            0 => 'neimengguzizhiqu',
            1 => 'nmg',
        ),
        'alias' =>
        array (
            0 => '内蒙古',
            1 => '内蒙',
            2 => '内蒙古自治区',
        ),
        'capital' => '呼和浩特',
        'cities' =>
        array (
            '呼和浩特' =>
            array (
                'name' => '呼和浩特',
                'citycode' => '0471',
                'x' => '111.66665',
                'y' => '40.808262',
                'spell' =>
                array (
                    0 => 'huhehaote','hhht'
                ),
                'cityid' => '150100',
                'alias' =>
                array (
                    0 => '呼和浩特',
                ),
            ),
            '包头' =>
            array (
                'name' => '包头',
                'citycode' => '0472',
                'x' => '109.871284',
                'y' => '40.66165',
                'spell' =>
                array (
                    0 => 'baotou','bt'
                ),
                'cityid' => '150200',
                'alias' =>
                array (
                    0 => '包头',
                ),
            ),
            '乌兰察布' =>
            array (
                'name' => '乌兰察布',
                'citycode' => '0474',
                'x' => '113.121094',
                'y' => '41.031708',
                'spell' =>
                array (
                    0 => 'wulanchabu','wlcb'
                ),
                'cityid' => '150900',
                'alias' =>
                array (
                    0 => '乌兰察布',
                ),
            ),
            '乌海' =>
            array (
                'name' => '乌海',
                'citycode' => '0473',
                'x' => '106.813996',
                'y' => '39.669164',
                'spell' =>
                array (
                    0 => 'wuhai','wh'
                ),
                'cityid' => '150300',
                'alias' =>
                array (
                    0 => '乌海',
                ),
            ),
            '兴安盟' =>
            array (
                'name' => '兴安盟',
                'citycode' => '0482',
                'x' => '122.134695',
                'y' => '46.087178',
                'spell' =>
                array (
                    0 => 'xinganmeng','xam'
                ),
                'cityid' => '152200',
                'alias' =>
                array (
                    0 => '兴安盟',
                ),
            ),
            '呼伦贝尔' =>
            array (
                'name' => '呼伦贝尔',
                'citycode' => '0470',
                'x' => '119.755811',
                'y' => '49.245792',
                'spell' =>
                array (
                    0 => 'hulunbeier','hlbe'
                ),
                'cityid' => '150700',
                'alias' =>
                array (
                    0 => '呼伦贝尔',
                ),
            ),
            '赤峰' =>
            array (
                'name' => '赤峰',
                'citycode' => '0476',
                'x' => '118.956672',
                'y' => '42.26731',
                'spell' =>
                array (
                    0 => 'chifeng','cf'
                ),
                'cityid' => '150400',
                'alias' =>
                array (
                    0 => '赤峰',
                ),
            ),
            '通辽' =>
            array (
                'name' => '通辽',
                'citycode' => '0475',
                'x' => '122.261091',
                'y' => '43.605915',
                'spell' =>
                array (
                    0 => 'tongliao','tl'
                ),
                'cityid' => '150500',
                'alias' =>
                array (
                    0 => '通辽',
                ),
            ),
            '鄂尔多斯' =>
            array (
                'name' => '鄂尔多斯',
                'citycode' => '0477',
                'x' => '110.003314',
                'y' => '39.822315',
                'spell' =>
                array (
                    0 => 'eerduosi','eeds'
                ),
                'cityid' => '150600',
                'alias' =>
                array (
                    0 => '鄂尔多斯',
                ),
            ),
            '阿拉善盟' =>
            array (
                'name' => '阿拉善盟',
                'citycode' => '0483',
                'x' => '105.677385',
                'y' => '38.835432',
                'spell' =>
                array (
                    0 => 'alashan','alsm'
                ),
                'cityid' => '152900',
                'alias' =>
                array (
                    0 => '阿拉善盟',
                ),
            ),
            '巴彦淖尔' =>
            array (
                'name' => '巴彦淖尔',
                'citycode' => '0478',
                'x' => '107.388305',
                'y' => '40.766908',
                'spell' =>
                array (
                    0 => 'bayannaoer','byne'
                ),
                'alias' =>
                array (
                    0 => '巴彦淖尔',
                ),
                'cityid' => '150800',
            ),
            '锡林郭勒盟' =>
            array (
                'name' => '锡林郭勒盟',
                'citycode' => '0479',
                'x' => '116.088165',
                'y' => '43.946146',
                'spell' =>
                array (
                    0 => 'xilinguole','xlgl'
                ),
                'cityid' => '152500',
                'alias' =>
                array (
                    0 => '锡林郭勒盟',
                ),
            ),
        ),
    ),
    '宁夏回族自治区' =>
    array (
        'name' => '宁夏回族自治区',
        'spell' =>
        array (
            0 => 'ningxiahuizuzizhiqu',
            1 => 'nx',
        ),
        'alias' =>
        array (
            0 => '宁夏',
            1 => '宁夏省',
            2 => '宁夏回族自治区',
        ),
        'capital' => '银川',
        'cities' =>
        array (
            '银川' =>
            array (
                'name' => '银川',
                'citycode' => '0951',
                'x' => '106.283211',
                'y' => '38.46279',
                'spell' =>
                array (
                    0 => 'yinchuan','yc'
                ),
                'cityid' => '640100',
                'alias' =>
                array (
                    0 => '银川',
                ),
            ),
            '中卫' =>
            array (
                'name' => '中卫',
                'citycode' => '1953',
                'x' => '105.686001',
                'y' => '37.482894',
                'spell' =>
                array (
                    0 => 'zhongwei','zw'
                ),
                'cityid' => '640500',
                'alias' =>
                array (
                    0 => '中卫',
                ),
            ),
            '吴忠' =>
            array (
                'name' => '吴忠',
                'citycode' => '0953',
                'x' => '106.194467',
                'y' => '37.985156',
                'spell' =>
                array (
                    0 => 'wuzhong','wz'
                ),
                'cityid' => '640300',
                'alias' =>
                array (
                    0 => '吴忠',
                ),
            ),
            '石嘴山' =>
            array (
                'name' => '石嘴山',
                'citycode' => '0952',
                'x' => '106.386304',
                'y' => '39.014571',
                'spell' =>
                array (
                    0 => 'shizuishan','szs'
                ),
                'cityid' => '640200',
                'alias' =>
                array (
                    0 => '石嘴山',
                ),
            ),
            '固原' =>
            array (
                'name' => '固原',
                'citycode' => '0954',
                'x' => '106.242448',
                'y' => '36.01628',
                'spell' =>
                array (
                    0 => 'guyuan','gy'
                ),
                'cityid' => '640400',
                'alias' =>
                array (
                    0 => '固原',
                ),
            ),
        ),
    ),
    '青海省' =>
    array (
        'name' => '青海省',
        'spell' =>
        array (
            0 => 'qinghaisheng',
            1 => 'qh',
        ),
        'alias' =>
        array (
            0 => '青海',
            1 => '青海省',
        ),
        'capital' => '西宁',
        'cities' =>
        array (
            '西宁' =>
            array (
                'name' => '西宁',
                'citycode' => '0971',
                'x' => '101.776629',
                'y' => '36.61723',
                'spell' =>
                array (
                    0 => 'xining','xn'
                ),
                'cityid' => '630100',
                'alias' =>
                array (
                    0 => '西宁',
                ),
            ),
            '海东地区' =>
            array (
                'name' => '海东地区',
                'citycode' => '0972',
                'x' => '102.08626',
                'y' => '36.509186',
                'spell' =>
                array (
                    0 => 'haidong','hd'
                ),
                'cityid' => '632100',
                'alias' =>
                array (
                    0 => '海东地区',
                ),
            ),
            '海北藏族自治州' =>
            array (
                'name' => '海北藏族自治州',
                'citycode' => '0970',
                'x' => '100.972912',
                'y' => '36.943314',
                'spell' =>
                array (
                    0 => 'haibei','hb'
                ),
                'cityid' => '632200',
                'alias' =>
                array (
                    0 => '海北藏族自治州',
                ),
            ),
            '海南藏族自治州' =>
            array (
                'name' => '海南藏族自治州',
                'citycode' => '0974',
                'x' => '100.637725',
                'y' => '36.324383',
                'spell' =>
                array (
                    0 => 'hainan','hn'
                ),
                'cityid' => '632500',
                'alias' =>
                array (
                    0 => '海南藏族自治州',
                ),
            ),
            '果洛藏族自治州' =>
            array (
                'name' => '果洛藏族自治州',
                'citycode' => '0975',
                'x' => '100.244922',
                'y' => '34.471735',
                'spell' =>
                array (
                    0 => 'guoluo','gl'
                ),
                'cityid' => '632600',
                'alias' =>
                array (
                    0 => '果洛藏族自治州',
                ),
            ),
            '黄南藏族自治州' =>
            array (
                'name' => '黄南藏族自治州',
                'citycode' => '0973',
                'x' => '101.81637',
                'y' => '35.464097',
                'spell' =>
                array (
                    0 => 'huangnan','hn'
                ),
                'cityid' => '632300',
                'alias' =>
                array (
                    0 => '黄南藏族自治州',
                ),
            ),
            '玉树藏族自治州' =>
            array (
                'name' => '玉树藏族自治州',
                'citycode' => '0976',
                'x' => '97.00278',
                'y' => '33.007095',
                'spell' =>
                array (
                    0 => 'yushu','ys'
                ),
                'cityid' => '632700',
                'alias' =>
                array (
                    0 => '玉树藏族自治州',
                ),
            ),
            '海西蒙古族藏族自治州' =>
            array (
                'name' => '海西蒙古族藏族自治州',
                'citycode' => '0977',
                'x' => '97.370785',
                'y' => '37.374663',
                'spell' =>
                array (
                    0 => 'haixi','hx'
                ),
                'cityid' => '632800',
                'alias' =>
                array (
                    0 => '海西蒙古族藏族自治州',
                ),
            ),
        ),
    ),
    '山西省' =>
    array (
        'name' => '山西省',
        'spell' =>
        array (
            0 => 'shanxisheng',
            1 => 'sx',
        ),
        'alias' =>
        array (
            0 => '山西',
            1 => '山西省',
        ),
        'capital' => '太原',
        'cities' =>
        array (
            '太原' =>
            array (
                'name' => '太原',
                'citycode' => '0351',
                'x' => '112.546669',
                'y' => '37.855753',
                'spell' =>
                array (
                    0 => 'taiyuan','ty'
                ),
                'cityid' => '140100',
                'alias' =>
                array (
                    0 => '太原',
                ),
            ),
            '临汾' =>
            array (
                'name' => '临汾',
                'citycode' => '0357',
                'x' => '111.52689',
                'y' => '36.102097',
                'spell' =>
                array (
                    0 => 'linfen','lf'
                ),
                'cityid' => '141000',
                'alias' =>
                array (
                    0 => '临汾',
                ),
            ),
            '吕梁' =>
            array (
                'name' => '吕梁',
                'citycode' => '0358',
                'x' => '111.130076',
                'y' => '37.520296',
                'spell' =>
                array (
                    0 => 'lvliang','ll'
                ),
                'cityid' => '141100',
                'alias' =>
                array (
                    0 => '吕梁',
                ),
            ),
            '大同' =>
            array (
                'name' => '大同',
                'citycode' => '0352',
                'x' => '113.299776',
                'y' => '40.078396',
                'spell' =>
                array (
                    0 => 'datong','dt'
                ),
                'cityid' => '140200',
                'alias' =>
                array (
                    0 => '大同',
                ),
            ),
            '忻州' =>
            array (
                'name' => '忻州',
                'citycode' => '0350',
                'x' => '112.734632',
                'y' => '38.415785',
                'spell' =>
                array (
                    0 => 'xinzhou','xz'
                ),
                'cityid' => '140900',
                'alias' =>
                array (
                    0 => '忻州',
                ),
            ),
            '晋中' =>
            array (
                'name' => '晋中',
                'citycode' => '0354',
                'x' => '112.752199',
                'y' => '37.688306',
                'spell' =>
                array (
                    0 => 'jinzhong','jz'
                ),
                'cityid' => '140700',
                'alias' =>
                array (
                    0 => '晋中',
                ),
            ),
            '晋城' =>
            array (
                'name' => '晋城',
                'citycode' => '0356',
                'x' => '112.852735',
                'y' => '35.490555',
                'spell' =>
                array (
                    0 => 'jincheng','jc'
                ),
                'cityid' => '140500',
                'alias' =>
                array (
                    0 => '晋城',
                ),
            ),
            '朔州' =>
            array (
                'name' => '朔州',
                'citycode' => '0349',
                'x' => '112.429359',
                'y' => '39.318565',
                'spell' =>
                array (
                    0 => 'shuozhou','sz'
                ),
                'cityid' => '140600',
                'alias' =>
                array (
                    0 => '朔州',
                ),
            ),
            '运城' =>
            array (
                'name' => '运城',
                'citycode' => '0359',
                'x' => '110.99764',
                'y' => '35.031487',
                'spell' =>
                array (
                    0 => 'yuncheng','yc'
                ),
                'cityid' => '140800',
                'alias' =>
                array (
                    0 => '运城',
                ),
            ),
            '长治' =>
            array (
                'name' => '长治',
                'citycode' => '0355',
                'x' => '113.11657',
                'y' => '36.192155',
                'spell' =>
                array (
                    0 => 'changzhi','cz'
                ),
                'cityid' => '140400',
                'alias' =>
                array (
                    0 => '长治',
                ),
            ),
            '阳泉' =>
            array (
                'name' => '阳泉',
                'citycode' => '0353',
                'x' => '113.580237',
                'y' => '37.856676',
                'spell' =>
                array (
                    0 => 'yangquan','yq'
                ),
                'cityid' => '140300',
                'alias' =>
                array (
                    0 => '阳泉',
                ),
            ),
        ),
    ),
    '山东省' =>
    array (
        'name' => '山东省',
        'spell' =>
        array (
            0 => 'shandongsheng',
            1 => 'sd',
        ),
        'alias' =>
        array (
            0 => '山东',
            1 => '山东省',
        ),
        'capital' => '济南',
        'cities' =>
        array (
            '济南' =>
            array (
                'name' => '济南',
                'citycode' => '0531',
                'x' => '116.998643',
                'y' => '36.675108',
                'spell' =>
                array (
                    0 => 'jinan','jn'
                ),
                'cityid' => '370100',
                'alias' =>
                array (
                    0 => '济南',
                ),
            ),
            '青岛' =>
            array (
                'name' => '青岛',
                'citycode' => '0532',
                'x' => '120.372227',
                'y' => '36.090395',
                'spell' =>
                array (
                    0 => 'qingdao','qd'
                ),
                'cityid' => '370200',
                'alias' =>
                array (
                    0 => '青岛',
                ),
            ),
            '淄博' =>
            array (
                'name' => '淄博',
                'citycode' => '0533',
                'x' => '118.05007',
                'y' => '36.806334',
                'spell' =>
                array (
                    0 => 'zibo','zb'
                ),
                'cityid' => '370300',
                'alias' =>
                array (
                    0 => '淄博',
                ),
            ),
            '德州' =>
            array (
                'name' => '德州',
                'citycode' => '0534',
                'x' => '116.301868',
                'y' => '37.454545',
                'spell' =>
                array (
                    0 => 'dezhou','dz'
                ),
                'cityid' => '371400',
                'alias' =>
                array (
                    0 => '德州',
                ),
            ),
            '烟台' =>
            array (
                'name' => '烟台',
                'citycode' => '0535',
                'x' => '121.392346',
                'y' => '37.537894',
                'spell' =>
                array (
                    0 => 'yantai','yt'
                ),
                'cityid' => '370600',
                'alias' =>
                array (
                    0 => '烟台',
                ),
            ),
            '潍坊' =>
            array (
                'name' => '潍坊',
                'citycode' => '0536',
                'x' => '119.122407',
                'y' => '36.715885',
                'spell' =>
                array (
                    0 => 'weifang','wf'
                ),
                'cityid' => '370700',
                'alias' =>
                array (
                    0 => '潍坊',
                ),
            ),
            '泰安' =>
            array (
                'name' => '泰安',
                'citycode' => '0538',
                'x' => '117.12131',
                'y' => '36.181254',
                'spell' =>
                array (
                    0 => 'taian','ta'
                ),
                'cityid' => '370900',
                'alias' =>
                array (
                    0 => '泰安',
                ),
            ),
            '东营' =>
            array (
                'name' => '东营',
                'citycode' => '0546',
                'x' => '118.674727',
                'y' => '37.432148',
                'spell' =>
                array (
                    0 => 'dongying','dy'
                ),
                'cityid' => '370500',
                'alias' =>
                array (
                    0 => '东营',
                ),
            ),
            '威海' =>
            array (
                'name' => '威海',
                'citycode' => '0631',
                'x' => '122.107674',
                'y' => '37.516379',
                'spell' =>
                array (
                    0 => 'weihai','wh'
                ),
                'cityid' => '371000',
                'alias' =>
                array (
                    0 => '威海',
                ),
            ),
            '临沂' =>
            array (
                'name' => '临沂',
                'citycode' => '0539',
                'x' => '118.346424',
                'y' => '35.053784',
                'spell' =>
                array (
                    0 => 'linyi','ly'
                ),
                'cityid' => '371300',
                'alias' =>
                array (
                    0 => '临沂',
                ),
            ),
            '日照' =>
            array (
                'name' => '日照',
                'citycode' => '0633',
                'x' => '119.526308',
                'y' => '35.418758',
                'spell' =>
                array (
                    0 => 'rizhao','rz'
                ),
                'cityid' => '371100',
                'alias' =>
                array (
                    0 => '日照',
                ),
            ),
            '枣庄' =>
            array (
                'name' => '枣庄',
                'citycode' => '0632',
                'x' => '117.308697',
                'y' => '34.812728',
                'spell' =>
                array (
                    0 => 'zaozhuang','zz'
                ),
                'cityid' => '370400',
                'alias' =>
                array (
                    0 => '枣庄',
                ),
            ),
            '济宁' =>
            array (
                'name' => '济宁',
                'citycode' => '0537',
                'x' => '116.587633',
                'y' => '35.413259',
                'spell' =>
                array (
                    0 => 'jining','jn'
                ),
                'cityid' => '370800',
                'alias' =>
                array (
                    0 => '济宁',
                ),
            ),
            '滨州' =>
            array (
                'name' => '滨州',
                'citycode' => '0543',
                'x' => '118.015949',
                'y' => '37.383209',
                'spell' =>
                array (
                    0 => 'binzhou','bz'
                ),
                'cityid' => '371600',
                'alias' =>
                array (
                    0 => '滨州',
                ),
            ),
            '聊城' =>
            array (
                'name' => '聊城',
                'citycode' => '0635',
                'x' => '115.985537',
                'y' => '36.456066',
                'spell' =>
                array (
                    0 => 'liaocheng','lc'
                ),
                'cityid' => '371500',
                'alias' =>
                array (
                    0 => '聊城',
                ),
            ),
            '莱芜' =>
            array (
                'name' => '莱芜',
                'citycode' => '0634',
                'x' => '117.678509',
                'y' => '36.213576',
                'spell' =>
                array (
                    0 => 'laiwu','lw'
                ),
                'cityid' => '371200',
                'alias' =>
                array (
                    0 => '莱芜',
                ),
            ),
            '菏泽' =>
            array (
                'name' => '菏泽',
                'citycode' => '0530',
                'x' => '115.460359',
                'y' => '35.247484',
                'spell' =>
                array (
                    0 => 'heze','hz'
                ),
                'cityid' => '371700',
                'alias' =>
                array (
                    0 => '菏泽',
                ),
            ),
        ),
    ),
    '陕西省' =>
    array (
        'name' => '陕西省',
        'spell' =>
        array (
            0 => 'shanxisheng',
            1 => 'sx',
        ),
        'alias' =>
        array (
            0 => '陕西',
            1 => '陕西省',
        ),
        'capital' => '西安',
        'cities' =>
        array (
            '西安' =>
            array (
                'name' => '西安',
                'citycode' => '029',
                'x' => '108.947273',
                'y' => '34.264460',
                'spell' =>
                array (
                    0 => 'xian','xa'
                ),
                'cityid' => '610100',
                'alias' =>
                array (
                    0 => '西安',
                ),
            ),
            '咸阳' =>
            array (
                'name' => '咸阳',
                'citycode' => '0910',
                'x' => '108.70988',
                'y' => '34.326785',
                'spell' =>
                array (
                    0 => 'xianyang','xy'
                ),
                'cityid' => '610400',
                'alias' =>
                array (
                    0 => '咸阳',
                ),
            ),
            '延安' =>
            array (
                'name' => '延安',
                'citycode' => '0911',
                'x' => '109.4965',
                'y' => '36.59332',
                'spell' =>
                array (
                    0 => 'yanan','ya'
                ),
                'cityid' => '610600',
                'alias' =>
                array (
                    0 => '延安',
                ),
            ),
            '宝鸡' =>
            array (
                'name' => '宝鸡',
                'citycode' => '0917',
                'x' => '107.138882',
                'y' => '34.369801',
                'spell' =>
                array (
                    0 => 'baoji','bj'
                ),
                'cityid' => '610300',
                'alias' =>
                array (
                    0 => '宝鸡',
                ),
            ),
            '商洛' =>
            array (
                'name' => '商洛',
                'citycode' => '0914',
                'x' => '109.943108',
                'y' => '33.882453',
                'spell' =>
                array (
                    0 => 'shangluo','sl'
                ),
                'cityid' => '611000',
                'alias' =>
                array (
                    0 => '商洛',
                ),
            ),
            '安康' =>
            array (
                'name' => '安康',
                'citycode' => '0915',
                'x' => '109.031082',
                'y' => '32.691681',
                'spell' =>
                array (
                    0 => 'ankang','ak'
                ),
                'cityid' => '610900',
                'alias' =>
                array (
                    0 => '安康',
                ),
            ),
            '榆林' =>
            array (
                'name' => '榆林',
                'citycode' => '0912',
                'x' => '109.753698',
                'y' => '38.295385',
                'spell' =>
                array (
                    0 => 'yulin','yl'
                ),
                'cityid' => '610800',
                'alias' =>
                array (
                    0 => '榆林',
                ),
            ),
            '汉中' =>
            array (
                'name' => '汉中',
                'citycode' => '0916',
                'x' => '107.031347',
                'y' => '33.079889',
                'spell' =>
                array (
                    0 => 'hanzhong','hz'
                ),
                'cityid' => '610700',
                'alias' =>
                array (
                    0 => '汉中',
                ),
            ),
            '渭南' =>
            array (
                'name' => '渭南',
                'citycode' => '0913',
                'x' => '109.510274',
                'y' => '34.507339',
                'spell' =>
                array (
                    0 => 'weinan','wn'
                ),
                'cityid' => '610500',
                'alias' =>
                array (
                    0 => '渭南',
                ),
            ),
            '铜川' =>
            array (
                'name' => '铜川',
                'citycode' => '0919',
                'x' => '108.947602',
                'y' => '34.90046',
                'spell' =>
                array (
                    0 => 'tongchuan','tc'
                ),
                'cityid' => '610200',
                'alias' =>
                array (
                    0 => '铜川',
                ),
            ),
        ),
    ),
    '四川省' =>
    array (
        'name' => '四川省',
        'spell' =>
        array (
            0 => 'sichuansheng',
            1 => 'sc',
        ),
        'alias' =>
        array (
            0 => '四川',
            1 => '四川省',
        ),
        'capital' => '成都',
        'cities' =>
        array (
            '成都' =>
            array (
                'name' => '成都',
                'citycode' => '028',
                'x' => '104.062324',
                'y' => '30.659417',
                'spell' =>
                array (
                    0 => 'chengdu','cd'
                ),
                'cityid' => '510100',
                'alias' =>
                array (
                    0 => '成都',
                ),
            ),
            '自贡' =>
            array (
                'name' => '自贡',
                'citycode' => '0813',
                'x' => '104.770243',
                'y' => '29.353381',
                'spell' =>
                array (
                    0 => 'zigong','zg'
                ),
                'cityid' => '510300',
                'alias' =>
                array (
                    0 => '自贡',
                ),
            ),
            '绵阳' =>
            array (
                'name' => '绵阳',
                'citycode' => '0816',
                'x' => '104.725553',
                'y' => '31.466993',
                'spell' =>
                array (
                    0 => 'mianyang','my'
                ),
                'cityid' => '510700',
                'alias' =>
                array (
                    0 => '绵阳',
                ),
            ),
            '泸州' =>
            array (
                'name' => '泸州',
                'citycode' => '0830',
                'x' => '105.451562',
                'y' => '28.885015',
                'spell' =>
                array (
                    0 => 'luzhou','lz'
                ),
                'cityid' => '510500',
                'alias' =>
                array (
                    0 => '泸州',
                ),
            ),
            '宜宾' =>
            array (
                'name' => '宜宾',
                'citycode' => '0831',
                'x' => '104.628696',
                'y' => '28.759226',
                'spell' =>
                array (
                    0 => 'yibin','yb'
                ),
                'cityid' => '511500',
                'alias' =>
                array (
                    0 => '宜宾',
                ),
            ),
            '内江' =>
            array (
                'name' => '内江',
                'citycode' => '1832',
                'x' => '105.062918',
                'y' => '29.5825',
                'spell' =>
                array (
                    0 => 'neijiang','nj'
                ),
                'cityid' => '511000',
                'alias' =>
                array (
                    0 => '内江',
                ),
            ),
            '资阳' =>
            array (
                'name' => '资阳',
                'citycode' => '0832',
                'x' => '104.650678',
                'y' => '30.128564',
                'spell' =>
                array (
                    0 => 'ziyang','zy'
                ),
                'cityid' => '512000',
                'alias' =>
                array (
                    0 => '资阳',
                ),
            ),
            '乐山' =>
            array (
                'name' => '乐山',
                'citycode' => '0833',
                'x' => '103.7613',
                'y' => '29.58202',
                'spell' =>
                array (
                    0 => 'leshan','ls'
                ),
                'cityid' => '511100',
                'alias' =>
                array (
                    0 => '乐山',
                ),
            ),
            '眉山' =>
            array (
                'name' => '眉山',
                'citycode' => '1833',
                'x' => '103.8318',
                'y' => '30.04832',
                'spell' =>
                array (
                    0 => 'meishan','ms'
                ),
                'cityid' => '511400',
                'alias' =>
                array (
                    0 => '眉山',
                ),
            ),
            '凉山彝族自治州' =>
            array (
                'name' => '凉山彝族自治州',
                'citycode' => '0834',
                'x' => '102.242284',
                'y' => '27.909519',
                'spell' =>
                array (
                    0 => 'liangshan','ls'
                ),
                'cityid' => '513400',
                'alias' =>
                array (
                    0 => '凉山彝族自治州',
                ),
            ),
            '南充' =>
            array (
                'name' => '南充',
                'citycode' => '0817',
                'x' => '106.094789',
                'y' => '30.784372',
                'spell' =>
                array (
                    0 => 'nanchong','nc'
                ),
                'cityid' => '511300',
                'alias' =>
                array (
                    0 => '南充',
                ),
            ),
            '巴中' =>
            array (
                'name' => '巴中',
                'citycode' => '0827',
                'x' => '106.754622',
                'y' => '31.857356',
                'spell' =>
                array (
                    0 => 'bazhong','bz'
                ),
                'cityid' => '511900',
                'alias' =>
                array (
                    0 => '巴中',
                ),
            ),
            '广元' =>
            array (
                'name' => '广元',
                'citycode' => '0839',
                'x' => '105.833673',
                'y' => '32.438449',
                'spell' =>
                array (
                    0 => 'guangyuan','gy'
                ),
                'cityid' => '510800',
                'alias' =>
                array (
                    0 => '广元',
                ),
            ),
            '广安' =>
            array (
                'name' => '广安',
                'citycode' => '0826',
                'x' => '106.641793',
                'y' => '30.47063',
                'spell' =>
                array (
                    0 => 'guangan','gg'
                ),
                'cityid' => '511600',
                'alias' =>
                array (
                    0 => '广安',
                ),
            ),
            '德阳' =>
            array (
                'name' => '德阳',
                'citycode' => '0838',
                'x' => '104.387676',
                'y' => '31.136816',
                'spell' =>
                array (
                    0 => 'deyang','dy'
                ),
                'cityid' => '510600',
                'alias' =>
                array (
                    0 => '德阳',
                ),
            ),
            '攀枝花' =>
            array (
                'name' => '攀枝花',
                'citycode' => '0812',
                'x' => '101.699123',
                'y' => '26.573304',
                'spell' =>
                array (
                    0 => 'panzhihua','pzh'
                ),
                'cityid' => '510400',
                'alias' =>
                array (
                    0 => '攀枝花',
                ),
            ),
            '甘孜藏族自治州' =>
            array (
                'name' => '甘孜藏族自治州',
                'citycode' => '0836',
                'x' => '101.86571',
                'y' => '30.141357',
                'spell' =>
                array (
                    0 => 'ganzi','gz'
                ),
                'cityid' => '513300',
                'alias' =>
                array (
                    0 => '甘孜藏族自治州',
                ),
            ),
            '达州' =>
            array (
                'name' => '达州',
                'citycode' => '0818',
                'x' => '107.48828',
                'y' => '31.212569',
                'spell' =>
                array (
                    0 => 'dazhou','dz'
                ),
                'cityid' => '511700',
                'alias' =>
                array (
                    0 => '达州',
                ),
            ),
            '遂宁' =>
            array (
                'name' => '遂宁',
                'citycode' => '0825',
                'x' => '105.583027',
                'y' => '30.513749',
                'spell' =>
                array (
                    0 => 'suining','sn'
                ),
                'cityid' => '510900',
                'alias' =>
                array (
                    0 => '遂宁',
                ),
            ),
            '阿坝藏族羌族自治州' =>
            array (
                'name' => '阿坝藏族羌族自治州',
                'citycode' => '0837',
                'x' => '102.22245',
                'y' => '31.899164',
                'spell' =>
                array (
                    0 => 'aba','ab'
                ),
                'cityid' => '513200',
                'alias' =>
                array (
                    0 => '阿坝藏族羌族自治州',
                ),
            ),
            '雅安' =>
            array (
                'name' => '雅安',
                'citycode' => '0835',
                'x' => '103.015113',
                'y' => '29.993669',
                'spell' =>
                array (
                    0 => 'yaan','ya'
                ),
                'cityid' => '511800',
                'alias' =>
                array (
                    0 => '雅安',
                ),
            ),
        ),
    ),
    '新疆维吾尔自治区' =>
    array (
        'name' => '新疆维吾尔自治区',
        'spell' =>
        array (
            0 => 'xinjiangweiwuerzizhiqu',
            1 => 'xj',
        ),
        'alias' =>
        array (
            0 => '新疆',
            1 => '新疆省',
            2 => '新疆自治区',
            3 => '新疆维吾尔自治区',
        ),
        'capital' => '乌鲁木齐',
        'cities' =>
        array (
            '乌鲁木齐' =>
            array (
                'name' => '乌鲁木齐',
                'citycode' => '0991',
                'x' => '87.6168',
                'y' => '43.823475',
                'spell' =>
                array (
                    0 => 'wulumuqi','wlmq'
                ),
                'cityid' => '650100',
                'alias' =>
                array (
                    0 => '乌鲁木齐',
                ),
            ),
            '伊犁哈萨克自治州' =>
            array (
                'name' => '伊犁哈萨克自治州',
                'citycode' => '0999',
                'x' => '81.338329',
                'y' => '43.923253',
                'spell' =>
                array (
                    0 => 'yili','yl'
                ),
                'cityid' => '654000',
                'alias' =>
                array (
                    0 => '伊犁哈萨克自治州',
                ),
            ),
            '克拉玛依' =>
            array (
                'name' => '克拉玛依',
                'citycode' => '0990',
                'x' => '84.931152',
                'y' => '45.596358',
                'spell' =>
                array (
                    0 => 'kelamayi','klmy'
                ),
                'cityid' => '650200',
                'alias' =>
                array (
                    0 => '克拉玛依',
                ),
            ),
            '博尔塔拉蒙古自治州' =>
            array (
                'name' => '博尔塔拉蒙古自治州',
                'citycode' => '0909',
                'x' => '82.078715',
                'y' => '44.912552',
                'spell' =>
                array (
                    0 => 'boertala','betl'
                ),
                'cityid' => '652700',
                'alias' =>
                array (
                    0 => '博尔塔拉蒙古自治州',
                ),
            ),
            '吐鲁番地区' =>
            array (
                'name' => '吐鲁番地区',
                'citycode' => '0995',
                'x' => '89.210691',
                'y' => '43.006963',
                'spell' =>
                array (
                    0 => 'tulufan','tlf'
                ),
                'cityid' => '652100',
                'alias' =>
                array (
                    0 => '吐鲁番地区',
                ),
            ),
            '塔城地区' =>
            array (
                'name' => '塔城地区',
                'citycode' => '0901',
                'x' => '83.014787',
                'y' => '46.752266',
                'spell' =>
                array (
                    0 => 'tacheng','tc'
                ),
                'cityid' => '654200',
                'alias' =>
                array (
                    0 => '塔城地区',
                ),
            ),
            '昌吉回族自治州' =>
            array (
                'name' => '昌吉回族自治州',
                'citycode' => '0994',
                'x' => '87.988229',
                'y' => '44.00443',
                'spell' =>
                array (
                    0 => 'changji','cj'
                ),
                'cityid' => '652300',
                'alias' =>
                array (
                    0 => '昌吉回族自治州',
                ),
            ),
            '石河子' =>
            array (
                'name' => '石河子',
                'citycode' => '0993',
                'x' => '86.05264',
                'y' => '44.305053',
                'spell' =>
                array (
                    0 => 'shihezi','shz'
                ),
                'cityid' => '659001',
                'alias' =>
                array (
                    0 => '石河子',
                ),
            ),
            '阿克苏地区' =>
            array (
                'name' => '阿克苏地区',
                'citycode' => '0997',
                'x' => '80.262315',
                'y' => '41.170296',
                'spell' =>
                array (
                    0 => 'akesu','aks'
                ),
                'cityid' => '652900',
                'alias' =>
                array (
                    0 => '阿克苏地区',
                ),
            ),
            '阿勒泰地区' =>
            array (
                'name' => '阿勒泰地区',
                'citycode' => '0906',
                'x' => '88.135539',
                'y' => '47.835025',
                'spell' =>
                array (
                    0 => 'aletai','alt'
                ),
                'cityid' => '654300',
                'alias' =>
                array (
                    0 => '阿勒泰地区',
                ),
            ),
            '巴音郭楞蒙古自治州' =>
            array (
                'name' => '巴音郭楞蒙古自治州',
                'citycode' => '0996',
                'x' => '86.145909',
                'y' => '41.76429',
                'spell' =>
                array (
                    0 => 'bayinguoleng','bygl'
                ),
                'cityid' => '652800',
                'alias' =>
                array (
                    0 => '巴音郭楞蒙古自治州',
                ),
            ),
            '哈密地区' =>
            array (
                'name' => '哈密地区',
                'citycode' => '0902',
                'x' => '93.514308',
                'y' => '42.826306',
                'spell' =>
                array (
                    0 => 'hami','hm'
                ),
                'cityid' => '652200',
                'alias' =>
                array (
                    0 => '哈密地区',
                ),
            ),
            '和田地区' =>
            array (
                'name' => '和田地区',
                'citycode' => '0903',
                'x' => '79.911194',
                'y' => '37.11133',
                'spell' =>
                array (
                    0 => 'hetian','ht'
                ),
                'cityid' => '653200',
                'alias' =>
                array (
                    0 => '和田地区',
                ),
            ),
            '喀什地区' =>
            array (
                'name' => '喀什地区',
                'citycode' => '0998',
                'x' => '75.994568',
                'y' => '39.460863',
                'spell' =>
                array (
                    0 => 'kashi','ks'
                ),
                'cityid' => '653100',
                'alias' =>
                array (
                    0 => '喀什地区',
                ),
            ),
            '克孜勒苏柯尔克孜自治州' =>
            array (
                'name' => '克孜勒苏柯尔克孜自治州',
                'citycode' => '0908',
                'x' => '76.168976',
                'y' => '39.714861',
                'spell' =>
                array (
                    0 => 'kezilesu','kzls'
                ),
                'cityid' => '653000',
                'alias' =>
                array (
                    0 => '克孜勒苏柯尔克孜自治州',
                ),
            ),
            '阿拉尔' =>
            array (
                'name' => '阿拉尔',
                'citycode' => '0997',
                'x' => '81.285884',
                'y' => '40.541914',
                'spell' =>
                array (
                    0 => 'Alaer','ale'
                ),
                'alias' =>
                array (
                    0 => '阿拉尔',
                ),
                'cityid' => '659002',
            ),
            '图木舒克' =>
            array (
                'name' => '图木舒克',
                'citycode' => '0998',
                'x' => '79.077978',
                'y' => '39.867316',
                'spell' =>
                array (
                    0 => 'tumushuke','tmsk'
                ),
                'alias' =>
                array (
                    0 => '图木舒克',
                ),
                'cityid' => '659003',
            ),
            '五家渠' =>
            array (
                'name' => '五家渠',
                'citycode' => '0994',
                'x' => '87.526884',
                'y' => '44.167401',
                'spell' =>
                array (
                    0 => 'wujiaqu','wjq'
                ),
                'alias' =>
                array (
                    0 => '五家渠',
                ),
                'cityid' => '659004',
            ),
        ),
    ),
    '西藏自治区' =>
    array (
        'name' => '西藏自治区',
        'spell' =>
        array (
            0 => 'xizangzizhiqu',
            1 => 'xz',
        ),
        'alias' =>
        array (
            0 => '西藏',
            1 => '西藏自治区',
        ),
        'capital' => '拉萨',
        'cities' =>
        array (
            '拉萨' =>
            array (
                'name' => '拉萨',
                'citycode' => '0891',
                'x' => '91.118939',
                'y' => '29.655277',
                'spell' =>
                array (
                    0 => 'lasa','ls'
                ),
                'cityid' => '540100',
                'alias' =>
                array (
                    0 => '拉萨',
                ),
            ),
            '山南地区' =>
            array (
                'name' => '山南地区',
                'citycode' => '0893',
                'x' => '91.804954',
                'y' => '29.240671',
                'spell' =>
                array (
                    0 => 'shannan','sn'
                ),
                'cityid' => '542200',
                'alias' =>
                array (
                    0 => '山南地区',
                ),
            ),
            '日喀则地区' =>
            array (
                'name' => '日喀则地区',
                'citycode' => '0892',
                'x' => '88.88838',
                'y' => '29.27172',
                'spell' =>
                array (
                    0 => 'rikaze','rkz'
                ),
                'cityid' => '542300',
                'alias' =>
                array (
                    0 => '日喀则地区',
                ),
            ),
            '阿里地区' =>
            array (
                'name' => '阿里地区',
                'citycode' => '0897',
                'x' => '80.105588',
                'y' => '32.50266',
                'spell' =>
                array (
                    0 => 'ali','al'
                ),
                'cityid' => '542500',
                'alias' =>
                array (
                    0 => '阿里地区',
                ),
            ),
            '昌都地区' =>
            array (
                'name' => '昌都地区',
                'citycode' => '0895',
                'x' => '97.150731',
                'y' => '31.153177',
                'spell' =>
                array (
                    0 => 'changdu','cd'
                ),
                'cityid' => '542100',
                'alias' =>
                array (
                    0 => '昌都地区',
                ),
            ),
            '林芝地区' =>
            array (
                'name' => '林芝地区',
                'citycode' => '0894',
                'x' => '94.481938',
                'y' => '29.574467',
                'spell' =>
                array (
                    0 => 'linzhi','lz'
                ),
                'cityid' => '542600',
                'alias' =>
                array (
                    0 => '林芝地区',
                ),
            ),
            '那曲地区' =>
            array (
                'name' => '那曲地区',
                'citycode' => '0896',
                'x' => '92.059109',
                'y' => '31.474164',
                'spell' =>
                array (
                    0 => 'naqu','nq'
                ),
                'cityid' => '542400',
                'alias' =>
                array (
                    0 => '那曲地区',
                ),
            ),
        ),
    ),
    '云南省' =>
    array (
        'name' => '云南省',
        'spell' =>
        array (
            0 => 'yunnansheng',
            1 => 'yn',
        ),
        'alias' =>
        array (
            0 => '云南',
            1 => '云南省',
        ),
        'capital' => '昆明',
        'cities' =>
        array (
            '昆明' =>
            array (
                'name' => '昆明',
                'citycode' => '0871',
                'x' => '102.7033',
                'y' => '25.049893',
                'spell' =>
                array (
                    0 => 'kunming','km'
                ),
                'cityid' => '530100',
                'alias' =>
                array (
                    0 => '昆明',
                ),
            ),
            '玉溪' =>
            array (
                'name' => '玉溪',
                'citycode' => '0877',
                'x' => '102.535926',
                'y' => '24.347156',
                'spell' =>
                array (
                    0 => 'yuxi','yx'
                ),
                'cityid' => '530400',
                'alias' =>
                array (
                    0 => '玉溪',
                ),
            ),
            '大理白族自治州' =>
            array (
                'name' => '大理白族自治州',
                'citycode' => '0872',
                'x' => '100.22212',
                'y' => '25.584232',
                'spell' =>
                array (
                    0 => 'dali','dl'
                ),
                'cityid' => '532900',
                'alias' =>
                array (
                    0 => '大理白族自治州',
                ),
            ),
            '昭通' =>
            array (
                'name' => '昭通',
                'citycode' => '0870',
                'x' => '103.703761',
                'y' => '27.365566',
                'spell' =>
                array (
                    0 => 'zhaotong','zt'
                ),
                'cityid' => '530600',
                'alias' =>
                array (
                    0 => '昭通',
                ),
            ),
            '曲靖' =>
            array (
                'name' => '曲靖',
                'citycode' => '0874',
                'x' => '103.784312',
                'y' => '25.491341',
                'spell' =>
                array (
                    0 => 'qujing','qj'
                ),
                'cityid' => '530300',
                'alias' =>
                array (
                    0 => '曲靖',
                ),
            ),
            '楚雄彝族自治州' =>
            array (
                'name' => '楚雄彝族自治州',
                'citycode' => '0878',
                'x' => '101.544722',
                'y' => '25.054926',
                'spell' =>
                array (
                    0 => 'chuxiong','cx'
                ),
                'cityid' => '532300',
                'alias' =>
                array (
                    0 => '楚雄彝族自治州',
                ),
            ),
            '红河哈尼族彝族自治州' =>
            array (
                'name' => '红河哈尼族彝族自治州',
                'citycode' => '0873',
                'x' => '103.180036',
                'y' => '23.430131',
                'spell' =>
                array (
                    0 => 'honghe','hh'
                ),
                'cityid' => '532500',
                'alias' =>
                array (
                    0 => '红河哈尼族彝族自治州',
                ),
            ),
            '西双版纳傣族自治州' =>
            array (
                'name' => '西双版纳傣族自治州',
                'citycode' => '0691',
                'x' => '100.799258',
                'y' => '22.010894',
                'spell' =>
                array (
                    0 => 'xishuangbanna','xsbn'
                ),
                'cityid' => '532800',
                'alias' =>
                array (
                    0 => '西双版纳傣族自治州',
                ),
            ),
            '保山' =>
            array (
                'name' => '保山',
                'citycode' => '0875',
                'x' => '99.16245',
                'y' => '25.115909',
                'spell' =>
                array (
                    0 => 'baoshan','bs'
                ),
                'cityid' => '530500',
                'alias' =>
                array (
                    0 => '保山',
                ),
            ),
            '德宏傣族景颇族自治州' =>
            array (
                'name' => '德宏傣族景颇族自治州',
                'citycode' => '0692',
                'x' => '98.584295',
                'y' => '24.433863',
                'spell' =>
                array (
                    0 => 'dehong','dh'
                ),
                'cityid' => '533100',
                'alias' =>
                array (
                    0 => '德宏傣族景颇族自治州',
                ),
            ),
            '迪庆藏族自治州' =>
            array (
                'name' => '迪庆藏族自治州',
                'citycode' => '0887',
                'x' => '99.70213',
                'y' => '27.819119',
                'spell' =>
                array (
                    0 => 'diqing','dq'
                ),
                'cityid' => '533400',
                'alias' =>
                array (
                    0 => '迪庆藏族自治州',
                ),
            ),
            '丽江' =>
            array (
                'name' => '丽江',
                'citycode' => '0888',
                'x' => '100.23016',
                'y' => '26.876225',
                'spell' =>
                array (
                    0 => 'lijiang','lj'
                ),
                'cityid' => '530700',
                'alias' =>
                array (
                    0 => '丽江',
                ),
            ),
            '临沧' =>
            array (
                'name' => '临沧',
                'citycode' => '0883',
                'x' => '100.092438',
                'y' => '23.880428',
                'spell' =>
                array (
                    0 => 'lincang','lc'
                ),
                'alias' =>
                array (
                    0 => '临沧',
                ),
                'cityid' => '530900',
            ),
            '怒江傈僳族自治州' =>
            array (
                'name' => '怒江傈僳族自治州',
                'citycode' => '0886',
                'x' => '98.856156',
                'y' => '25.851879',
                'spell' =>
                array (
                    0 => 'nujiang','nj'
                ),
                'cityid' => '533300',
                'alias' =>
                array (
                    0 => '怒江傈僳族自治州',
                ),
            ),
            '普洱' =>
            array (
                'name' => '普洱',
                'citycode' => '0879',
                'x' => '100.970296',
                'y' => '22.777531',
                'spell' =>
                array (
                    0 => 'puer','pe'
                ),
                'cityid' => '530800',
                'alias' =>
                array (
                    0 => '普洱',
                ),
            ),
            '文山壮族苗族自治州' =>
            array (
                'name' => '文山壮族苗族自治州',
                'citycode' => '0876',
                'x' => '104.245562',
                'y' => '23.370488',
                'spell' =>
                array (
                    0 => 'wenshan','ws'
                ),
                'cityid' => '532600',
                'alias' =>
                array (
                    0 => '文山壮族苗族自治州',
                ),
            ),
        ),
    ),
    '浙江省' =>
    array (
        'name' => '浙江省',
        'spell' =>
        array (
            0 => 'zhejiangsheng',
            1 => 'zj',
        ),
        'alias' =>
        array (
            0 => '浙江',
            1 => '浙江省',
        ),
        'capital' => '杭州',
        'cities' =>
        array (
            '杭州' =>
            array (
                'name' => '杭州',
                'citycode' => '0571',
                'x' => '120.149896',
                'y' => '30.287175',
                'spell' =>
                array (
                    0 => 'hangzhou','hz'
                ),
                'cityid' => '330100',
                'alias' =>
                array (
                    0 => '杭州',
                ),
            ),
            '嘉兴' =>
            array (
                'name' => '嘉兴',
                'citycode' => '0573',
                'x' => '120.758541',
                'y' => '30.75392',
                'spell' =>
                array (
                    0 => 'jiaxing','jx'
                ),
                'cityid' => '330400',
                'alias' =>
                array (
                    0 => '嘉兴',
                ),
            ),
            '绍兴' =>
            array (
                'name' => '绍兴',
                'citycode' => '0575',
                'x' => '120.586112',
                'y' => '29.995764',
                'spell' =>
                array (
                    0 => 'shaoxing','sx'
                ),
                'cityid' => '330600',
                'alias' =>
                array (
                    0 => '绍兴',
                ),
            ),
            '湖州' =>
            array (
                'name' => '湖州',
                'citycode' => '0572',
                'x' => '120.096927',
                'y' => '30.870597',
                'spell' =>
                array (
                    0 => 'huzhou','hz'
                ),
                'cityid' => '330500',
                'alias' =>
                array (
                    0 => '湖州',
                ),
            ),
            '宁波' =>
            array (
                'name' => '宁波',
                'citycode' => '0574',
                'x' => '121.547124',
                'y' => '29.868938',
                'spell' =>
                array (
                    0 => 'ningbo','nb'
                ),
                'cityid' => '330200',
                'alias' =>
                array (
                    0 => '宁波',
                ),
            ),
            '台州' =>
            array (
                'name' => '台州',
                'citycode' => '0576',
                'x' => '121.455904',
                'y' => '28.670797',
                'spell' =>
                array (
                    0 => 'taizhou','tz'
                ),
                'cityid' => '331000',
                'alias' =>
                array (
                    0 => '台州',
                ),
            ),
            '温州' =>
            array (
                'name' => '温州',
                'citycode' => '0577',
                'x' => '120.637517',
                'y' => '28.027019',
                'spell' =>
                array (
                    0 => 'wenzhou','wz'
                ),
                'cityid' => '330300',
                'alias' =>
                array (
                    0 => '温州',
                ),
            ),
            '金华' =>
            array (
                'name' => '金华',
                'citycode' => '0579',
                'x' => '119.649095',
                'y' => '29.086264',
                'spell' =>
                array (
                    0 => 'jinhua','jh'
                ),
                'cityid' => '330700',
                'alias' =>
                array (
                    0 => '金华',
                ),
            ),
            '舟山' =>
            array (
                'name' => '舟山',
                'citycode' => '0580',
                'x' => '122.105547',
                'y' => '30.013207',
                'spell' =>
                array (
                    0 => 'zhoushan','zs'
                ),
                'cityid' => '330900',
                'alias' =>
                array (
                    0 => '舟山',
                ),
            ),
            '丽水' =>
            array (
                'name' => '丽水',
                'citycode' => '0578',
                'x' => '119.916769',
                'y' => '28.452229',
                'spell' =>
                array (
                    0 => 'lishui','ls'
                ),
                'cityid' => '331100',
                'alias' =>
                array (
                    0 => '丽水',
                ),
            ),
            '衢州' =>
            array (
                'name' => '衢州',
                'citycode' => '0570',
                'x' => '118.874175',
                'y' => '28.935902',
                'spell' =>
                array (
                    0 => 'quzhou','qz'
                ),
                'cityid' => '330800',
                'alias' =>
                array (
                    0 => '衢州',
                ),
            ),
        ),
    ),
    '香港特别行政区' =>
    array (
        'name' => '香港特别行政区',
        'spell' =>
        array (
            0 => 'xianggangtebiexingzhengqu',
            1 => 'xg',
        ),
        'alias' =>
        array (
            0 => '香港',
            1 => '香港特别行政区',
        ),
        'capital' => '香港',
        'cities' =>
        array (
            '香港' =>
            array (
                'name' => '香港',
                'citycode' => '1852',
                'x' => '114.158663',
                'y' => '22.279408',
                'spell' =>
                array (
                    0 => 'xianggang','xg'
                ),
                'cityid' => '810000',
                'alias' =>
                array (
                    0 => '香港',
                ),
            ),
        ),
    ),
    '澳门特别行政区' =>
    array (
        'name' => '澳门特别行政区',
        'spell' =>
        array (
            0 => 'aomentebiexingzhengqu',
            1 => 'am',
        ),
        'alias' =>
        array (
            0 => '澳门',
            1 => '澳门特别行政区',
        ),
        'capital' => '澳门',
        'cities' =>
        array (
            '澳门' =>
            array (
                'name' => '澳门',
                'citycode' => '1853',
                'x' => '113.537935',
                'y' => '22.191061',
                'spell' =>
                array (
                    0 => 'aomen','am'
                ),
                'cityid' => '820000',
                'alias' =>
                array (
                    0 => '澳门',
                ),
            ),
        ),
    ),
    '台湾省' =>
    array (
        'name' => '台湾省',
        'spell' =>
        array (
            0 => 'taiwansheng',
            1 => 'tw',
        ),
        'alias' =>
        array (
            0 => '台湾',
            1 => '台湾省',
        ),
        'capital' => '台北',
        'cities' =>
        array (
            '台湾' =>
            array (
                'name' => '台湾',
                'citycode' => '1886',
                'x' => '121.509062',
                'y' => '25.044332',
                'spell' =>
                array (
                    0 => 'taiwan','tw'
                ),
                'cityid' => '710000',
                'alias' =>
                array (
                    0 => '台湾',
                ),
            ),
        ),
    ),
);