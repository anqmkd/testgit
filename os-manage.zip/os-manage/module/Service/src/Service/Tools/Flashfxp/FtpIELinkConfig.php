﻿<?php
namespace Service\Tools\Flashfxp;

/**
 * 通过ftp://link 方式连接服务器的配置类
 * 
 * @author liangweiwei
 * @since 2013-01-09
 */
class FtpIELinkConfig {
	private $username;
	private $password;
	private $ftpHost;
	private $ftpPort;
	private $localpath;
	private $remotepath;

	function __construct() {
		$this->username = "YL17539_lijie";
		$this->password = "YL17539!QAZ";
		$this->ftpHost = "172.16.2.11";
		$this->ftpPort = "21";
	}

	function setUsername($username) {
		$this->username = $username;
	}

	function getUsername() {
		return $this->username;
	}

	function setPassword($password) {
		$this->password = $password;
	}

	function getPassword() {
		return $this->password;
	}

	function setFtpHost($ftpHost) {
		$this->ftpHost = $ftpHost;
	}

	function getFtpHost() {
		return $this->ftpHost;
	}

	function setFtpPort($ftpPort) {
		$this->ftpPort = $ftpPort;
	}

	function getFtpPort() {
		return $this->ftpPort;
	}

	function setLocalpath($localpath) {
		$this->localpath = $localpath;
	}

	function getLocalpath() {
		return $this->localpath;
	}

	function setRemotepath($remotepath) {
		$this->remotepath = $remotepath;
	}

	function  getRemotepath() {
		return $this->remotepath;
	}
}
?>