﻿<?php

// TODO AutoFlashFXP::uploadWithLink(FtpIELinkConfig $config) 使用实例
$config = new FtpIELinkConfig();
$config->setLocalpath("d:\\log\\");
$config->setRemotepath("/log/");

$autoFlashFXP = new AutoFlashFXP("D:\\program_files\\FlashFXP4\\FlashFXP.exe");

if(AutoFlashFXP::uploadWithLink($flashxp, $config)) {
	echo "AutoFlashFXP::uploadWithLink upload success......";
} else {
	echo "AutoFlashFXP::uploadWithLink upload false......";
}


// TODO AutoFlashFXP::uploadWithSiteManager(SiteManagerConfig $config) 使用实例
$config = new SiteManagerConfig();
$config->setSitename("172.16.2.11");
$config->setLocalpath("d:\\log\\");
$config->setRemotepath("/log/");

$autoFlashFXP = new AutoFlashFXP("D:\\program_files\\FlashFXP4\\FlashFXP.exe");

if($autoFlashFXP->uploadWithSiteManager($config)) {
	echo "AutoFlashFXP::uploadWithSiteManager success......";
} else {
	echo "AutoFlashFXP::uploadWithSiteManager false......";
}
