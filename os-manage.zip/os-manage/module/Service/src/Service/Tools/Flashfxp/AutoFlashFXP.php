﻿<?php
namespace Service\Tools\Flashfxp;

use Service\Logs\Logs; 
/**
 * 命令行方式自动化运行FlashFXP程序
 * 
 * @author liangweiwei
 * @since 2013-01-09
 */
class AutoFlashFXP {
	const USERNAME_EMPTY_EXP = "username in the FtpIELinkConfig is empty!!!";
	const PSW_EMPTY_EXP = "password in the FtpIELinkConfig is empty!!!";
	const FTPHOST_EMPTY_EXP = "ftpHost in the FtpIELinkConfig is empty!!!";
	const FTPPORT_EMPTY_EXP = "ftpPort in the FtpIELinkConfig is empty!!!";
	const LOCALPATH_EMPTY_EXP = "localpath in the FtpIELinkConfig or SiteManagerConfig is empty!!!";
	const REMOTEPATH_EMPTY_EXP = "remotepath in the FtpIELinkConfig or SiteManagerConfig is empty!!!";
	const FLASHFXPPATH_EMPTY_EXP = "flashfxppath in the FtpIELinkConfig is empty!!!";
	const SITENAME_EMPTY_EXP = "sitename in the SiteManagerConfig is empty!!!";

	private $flashfxppath;

	public function __construct($localflashfxppath) {
		$this->flashfxppath = $localflashfxppath;
	}

	public function setFlashFXPPath($flashfxppath) {
		$this->flashfxppath = $flashfxppath;
	}

	public function getFlashFXPPath() {
		return $this->flashfxppath;
	}

	/**
	 * 上传本地文件或目录到服务器，采用ftp://links的方式建立连接
	 *
	 * @param FtpIELinkConfig $config FlashFXP的ftp连接配置
	 * @return boolean 运行成功返回true 否则返回false
	 */
	public function uploadWithLink(FtpIELinkConfig $config) {
		try{
			$this->checkFtpLinkInfo($config);
			$this->checkLocalPath4Link($config);
			$this->checkRemotePath4Link($config);
			$command = $this->createUploadCommand4Link($config);
			exec($command, $out, $status);
			if($status != 0){
				return false;
			} 
		} catch (Exception $e) {
			Logs::write('AutFlashFXP::uploadWithLink():exception error:'.$e->getMessage(), 'log'); // TODO 可更改为其他异常处理方式
			return false;
		}
		return true;
	}

	/**
	 * 上传本地文件或目录到服务器，采用站点管理器的方式建立连接
	 *
	 * @param SiteManagerConfig $config 站点管理器配置
	 * @return boolean 运行成功返回true 否则返回false
	 */
	public function uploadWithSiteManager(SiteManagerConfig $config) {
		try{
			$this->checkSitename4SiteManager($config);
			$this->checkLocalPath4SiteManager($config);
			$this->checkRemotePath4SiteManager($config);
			$command = $this->createUploadCommand4SiteManager($config);
			exec($command, $out, $status);
			if($status != 0){
				return false;
			} 
		} catch (Exception $e) {
			Logs::write('AutFlashFXP::uploadWithSiteManager():exception error:'.$e->getMessage(), 'log'); // TODO 可更改为其他异常处理方式
			return false;
		}
		return true;
	}

	/**
	 * 两个站点之间的同步<p>
	 * 必须采用站点管理器建立连接 [未测试]
	 * 
	 * @param SiteManagerConfig $srcConfig 源ftp
	 * @param SiteManagerConfig $dstConfig 目的ftp
	 * @return boolean
	 */
	public function synchroniseSites(SiteManagerConfig $srcConfig,
			SiteManagerConfig $dstConfig) {
		try{
			$this->checkSitename4SiteManager($srcConfig);
			$this->checkRemotePath4SiteManager($srcConfig);
			$this->checkSitename4SiteManager($dstConfig);
			$this->checkRemotePath4SiteManager($dstConfig);
			$command = $this->createSyncSitesCommand($srcConfig,$dstConfig);
			exec($command, $out, $status);
			if($status != 0){
				return false;
			} 
		} catch (Exception $e) {
			Logs::write('AutFlashFXP::synchroniseSites():exception error:'.$e->getMessage(), 'log'); // TODO 可更改为其他异常处理方式
			return false;
		}
		return true;
	}


	/**
	 * 创建FTP://link形式的 upload 命令<p>
	 * flashfxp.exe -upload ftp://user:psw@ip:port -remotepath="/root/" <p>
	 * -localpath="c:\path\folder\"
	 *
	 * @param FtpIELinkConfig $config
	 * @return string
	 */
	private function createUploadCommand4Link(FtpIELinkConfig $config) {
		return $this->flashfxppath." -tray -c2 -upload ftp://"
				.$config->getUsername().":".$config->getPassword()."@"
						.$config->getFtpHost().":".$config->getFtpPort()
						." -localpath=".$config->getLocalpath()
						." -remotepath=".$config->getRemotepath();
	}

	/**
	 * 创建站点管理器形式的 upload 命令<p>
	 * flashfxp.exe -upload <sitename> -remotepath="\incoming\newfolder\" <p>
	 * -localpath="c:\path\folder\"
	 *
	 * @param SiteManagerConfig $config
	 * @return string
	 */
	private function createUploadCommand4SiteManager(SiteManagerConfig $config) {
		return $this->flashfxppath." -tray -c2 -upload "
				.$config->getSitename()." "
						." -localpath=".$config->getLocalpath()
						." -remotepath=".$config->getRemotepath();
	}

	private function createSyncSitesCommand(SiteManagerConfig $srcConfig,
			SiteManagerConfig $dstConfig) {
		return $this->flashfxppath." -tray -c2 -fxp "
				.$srcConfig->getSitename().";".$dstConfig->getSitename()
				." -remotepath=".$srcConfig->getLocalpath()
				." -remotepath=".$dstConfig->getRemotepath();
		return null;
	}

	private function checkFtpLinkInfo(FtpIELinkConfig $config) {
		$username = $config->getUsername();
		$password = $config->getPassword();
		$ftphost = $config->getFtpHost();
		$ftpport = $config->getFtpPort();
		if (empty($username)) {
			throw new Exception(self::USERNAME_EMPTY_EXP);
		} elseif (empty($password)) {
			throw new Exception(self::PSW_EMPTY_EXP);
		} elseif (empty($ftphost)) {
			throw new Exception(self::FTPHOST_EMPTY_EXP);
		} elseif (empty($ftpport)) {
			throw new Exception(self::FTPPORT_EMPTY_EXP);
		}
	}

	private function checkLocalPath4Link(FtpIELinkConfig $config) {
		$localpath = $config->getLocalpath();
		if(empty($localpath)) {
			throw new Exception(self::LOCALPATH_EMPTY_EXP);
		}
	}

	private function checkRemotePath4Link(FtpIELinkConfig $config) {
		$remotepath = $config->getRemotepath();
		if(empty($remotepath)) {
			throw new Exception(self::REMOTEPATH_EMPTY_EXP);
		}
	}

	private function checkLocalPath4SiteManager(SiteManagerConfig $config) {
		$localpath = $config->getLocalpath();
		if(empty($localpath)) {
			throw new Exception(self::LOCALPATH_EMPTY_EXP);
		}
	}

	private function checkRemotePath4SiteManager(SiteManagerConfig $config) {
		$remotepath = $config->getRemotepath();
		if(empty($remotepath)) {
			throw new Exception(self::REMOTEPATH_EMPTY_EXP);
		}
	}

	private function checkSitename4SiteManager(SiteManagerConfig $config) {
		$sitename = $config->getSitename();
		if(empty($sitename)) {
			throw new Exception(self::SITENAME_EMPTY_EXP);
		}
	}
}
?>