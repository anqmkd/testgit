﻿<?php
namespace Service\Tools\Flashfxp;

/**
 * FlashFXP站点管理器配置类
 * 
 * @author liangweiwei
 * @since 2013-01-09
 */
class SiteManagerConfig {
	private $sitename;
	private $remotePath;
	private $localpath;

	function setSitename($sitename) {
		$this->sitename = $sitename;
	}

	function getSitename() {
		return $this->sitename;
	}

	function setRemotepath($remotepath) {
		$this->remotepath = $remotepath;
	}

	function  getRemotepath() {
		return $this->remotepath;
	}

	function setLocalpath($localpath) {
		$this->localpath = $localpath;
	}

	function getLocalpath() {
		return $this->localpath;
	}
}