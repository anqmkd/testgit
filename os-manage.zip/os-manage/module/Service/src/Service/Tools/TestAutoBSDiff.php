<?php
require_once 'AutoBSDiff.php';

// step1: 根据查分制作程序的地址声明
$auto = new AutoBSDiff("bsdiff4.3-win32.exe");

// step2: 创建差分包到指定路径
if($auto->createPatch("D:\\test\\iReader1.6.2.0(v35).apk",
		"D:\\test\\iReader1.8.0.1(v40).apk", "D:\\test\\iReader.patch")){
		echo "yes";
}else {
	echo "no";
}
?>