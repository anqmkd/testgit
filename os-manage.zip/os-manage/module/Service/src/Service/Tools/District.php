<?php

namespace Service\Tools;

use Data\Verify as D;
use Data\Type as DT;

class District
{
    private $districts = null;
    static $singleton = null;

    public function __construct()
    {
        $this->districts = include('district_data.php');
    }

    public static function singleton()
    {
        if (is_null(self::$singleton)) {
            self::$singleton = new self();
        }

        return self::$singleton;
    }

    /**
     * 获取城市信息
     */
    public function getCity($cityName)
    {
        foreach ($this->districts as $provinceName => $province) {
            $cityName1 = $cityName;
            $cityName2 = preg_replace('/(省|市|\||城区)$/', '', $cityName);
            $city = D::pipe($province, "cities.{$cityName1}|cities.{$cityName2}");

            if ($city) {
                unset($province['cities']);
                $city['province'] = $province;
                return $city;
            }
        }

        return [];
    }

    /**
     * 搜索城市，可能是拼音
     */
    public function searchDistrictBySpell($q)
    {
        $rows = [];
        foreach ($this->districts as $provinceName => $province) {
            // 先匹配省份内容
            if (!D::get($province, 'special')) {
                $provinceSpell = D::get($province, 'spell');
                // 根据拼音做前缀匹配
                foreach ($provinceSpell as $s) {
                    if (preg_match("/^$q/", $s)) {
                        $rows[] = $province;
                        break;
                    }
                }
            }

            $cities = D::get($province, 'cities');

            if ($cities) {
                foreach ($cities as $city) {
                    $spells = D::get($city, 'spell');

                    // 根据拼音做前缀匹配
                    foreach ($spells as $s) {
                        if (preg_match("/^$q/", $s)) {
                            $tmp = $province;
                            unset($tmp['cities']);
                            $city['province'] = $tmp;
                            $rows[] = $city;
                            break;
                        }
                    }
                }
            }
        }

        return $rows;
    }

    public function search($q)
    {
        if (preg_match("/^\w+$/", $q)) {
            return $this->searchDistrictBySpell($q);
        }

        $rows = [];
        foreach ($this->districts as $provinceName => $province) {
            // 先匹配省份内容
            $provinceAlias = D::get($province, 'alias');
            // 根据拼音做前缀匹配
            foreach ($provinceAlias as $s) {
                if (preg_match("/^$q/", $s)) {
                    $rows[] = $province;
                    break;
                }
            }

            $cities = D::get($province, 'cities');

            if ($cities) {
                foreach ($cities as $city) {
                    $alias = D::get($city, 'alias');

                    // 根据拼音做前缀匹配
                    foreach ($alias as $s) {
                        if (preg_match("/^$q/", $s)) {
                            unset($province['cities']);
                            $city['province'] = $province;
                            $rows[] = $city;
                            break;
                        }
                    }
                }
            }
        }

        return $rows;
    }

    public function searchCityBySpell($q)
    {
        $rows = [];
        foreach ($this->districts as $provinceName => $province) {
            $cities = D::get($province, 'cities');

            if ($cities) {
                foreach ($cities as $city) {
                    $spells = D::get($city, 'spell');

                    // 根据拼音做前缀匹配
                    foreach ($spells as $s) {
                        if (preg_match("/^$q/", $s)) {
                            unset($province['cities']);
                            $city['province'] = $province;
                            $rows[] = $city;
                            break;
                        }
                    }
                }
            }
        }

        return $rows;
    }

    public static function cityEqual($city1, $city2)
    {
        $city1 = preg_replace('/(省|市|\||城区)$/', '', $city1);
        $city2 = preg_replace('/(省|市|\||城区)$/', '', $city2);

        return $city1 === $city2;
    }

    public function getTree($q)
    {
        foreach ($this->districts as $provinceName => $province) {
            if (in_array($q, $province['alias'])) {
                unset($province['cities']);
                return $province;
            }

            $cityName1 = $q;
            $cityName2 = preg_replace('/(省|市|\||城区)$/', '', $q);
            $city = D::pipe($province, "cities.{$cityName1}|cities.{$cityName2}");

            if ($city) {
                unset($province['cities']);
                $province['city'] = $city;
                return $province;
            }
        }

        return [];
    }
}