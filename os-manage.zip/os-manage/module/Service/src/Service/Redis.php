<?php

namespace Service;

class Redis
{
    static private $redis;

    public static function getRedis($redisConfig)
    {
        $cfg = [
            'host' => '127.0.0.1',
            'port' => '6379',
            'db' => 0,
            'password' => '',
            'persistent' => true,
            'timeout' => 1,
            'socket' => ''
        ];
        $redisConfig = array_merge($cfg, $redisConfig);

        $redisHash = implode(':', $redisConfig);

        if (!(isset(self::$redis[$redisHash]) && self::$redis[$redisHash] instanceof \Redis)) {
            self::$redis[$redisHash] = self::applyRedis($redisConfig);
        }

        return self::$redis[$redisHash];
    }

    /**
     * 申请一个redis连接对象
     */
    public static function applyRedis($cfg)
    {
        $redis = null;

        try {
            $redis = new \Redis();
            $connectType = $cfg['persistent'] ? 'pconnect' : 'connect';

            if ($cfg['socket']) {
                $redis->$connectType($cfg['socket']);
            } else {
                $redis->$connectType($cfg['host'], $cfg['port'], $cfg['timeout']);
            }

            if ($cfg['password']) {
                $redis->auth($cfg['password']);
            }
        } catch (\Exception $e) {
            throw $e;
        }

        return $redis;
    }
}