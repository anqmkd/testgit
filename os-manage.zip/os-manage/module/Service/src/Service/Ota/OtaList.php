<?php
namespace Service\Ota;
class OtaList
{
    public $deviceModel;              //型号
    public $publishTime;			//发布时间
    public $dstVersion;            //目标版本
    public $srcVersion;             //原版本
    public $hwVersion;              //硬件版本
    public $downloadUrle;           //下载地址
    public $resourceSize;            //包大小

    const URL_OTA_DATA = "http://101.198.152.154/otalogs/";         //正式
    const URL_OTA_DATA_TEST = "http://101.198.153.217/otalogs/";   //测试
	public function __construct()
    {

    }
    
}