<?php
namespace Service\Error;

class Error
{
    const YL_ERROR_EXCEPOTION           = 1000;				//异常
    const YL_ERROR_NO_POWER             = 1001;

    const YL_ERROR_TASK_SAVE			= 2000;				//业务存储错误
    const YL_ERROR_TASK_INFO_ERROR		= 2001;			//业务信息错误
    const YL_ERROR_SETTING_EXIST_FAILED = 2002;		//配置信息已存在
    const YL_ERROR_SETTING_POST_FAILED  = 2003;		//配置信息传输错误
    const YL_ERROR_SETTING_CHECK_FAILED = 2004;		//配置信息检查错误
    const YL_ERROR_MOBILE_EXIST_FAILED  = 2011;		//终端信息已存在
    const YL_ERROR_MOBILE_POST_FAILED   = 2012;		//终端信息传输错误
    const YL_ERROR_MOBILE_CHANGE_FAILED = 2016;		//终端信息修改错误
    const YL_ERROR_MOBILE_CHECK_FAILED  = 2013;		//终端信息检查错误
    const YL_ERROR_MOBILE_DELETE_FAILED = 2014;		//终端信息删除错误
    const YL_ERROR_MOBILE_COUNT_FAILED  = 2015;		//终端信息删除错误
    const YL_ERROR_APP_EXIST_FAILED     = 2021;		//应用信息传输错误
    const YL_ERROR_APP_POST_FAILED      = 2022;			//应用信息传输错误
    const YL_ERROR_APP_CHECK_FAILED     = 2023;			//应用信息检查错误
    const YL_ERROR_APP_DELETE_FAILED    = 2224;		//应用信息删除错误
    const YL_ERROR_PRODUCT_EXIST_FAILED = 2031;		//产品信息已存在
    const YL_ERROR_PRODUCT_POST_FAILED  = 2032;		//产品信息传输错误
    const YL_ERROR_PRODUCT_CHECK_FAILED = 2043;		//产品信息检查错误
    const YL_ERROR_PRODUCT_DELETE_FAILED= 2044;	//产品信息删除错误
    const YL_ERROR_TASK_PRODUCT_VERSION_CHANGE_FAILED = 2045;  //更新产品版本出错
    const YL_ERROR_MOBILE_SET_POST_FAILED   = 2051;	//终端配置信息传输错误
    const YL_ERROR_MOBILE_SET_CHANGE_FAILED = 2052;	//终端配置信息修改错误
    const YL_ERROR_MOBILE_SET_SAVE_FAILED   = 2053;	//终端配置信息保存错误
    const YL_ERROR_PRODUCT_SET_POST_FAILED  = 2061;	//产品配置信息传输错误
    const YL_ERROR_PRODUCT_SET_CHANGE_FAILED= 2062;//产品配置信息修改错误
    const YL_ERROR_PRODUCT_SET_SAVE_FAILED  = 2063;	//产品配置信息保存错误
    const YL_ERROR_MANAGE_CHECK_FAILED      = 2064;		//终端管理信息检查错误

    const YL_ERROR_RECORD_PRODUCT_VERSION_FAILED = 3001; //获取产品版本错误
    const YL_ERROR_REDIS_COUNT_FAILED		= 2051;		//获取在线终端数量异常
    const YL_ERROR_CREATE_ID				= 4000;			//ID创建错误
    const YL_ERROR_PARAM					= 4001;			// 检查参数置空错误
    const YL_ERROR_LOGIN_CHECK_FAILED = 4002;           //登录校验失败

    const YL_ERROR_USER_CHECK_FAILED = 30001; # 用户信息检测失败
    const YL_ERROR_USER_GET_FAILED = 30002; # 用户信息获取失败
    const YL_ERROR_USER_CHANGE_FAILED = 30003; # 用户信息修改失败
}