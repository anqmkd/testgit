<?php
namespace Service\Package;

use Service\Mongo;
use Data\Verify as D;
use Data\Type as DT;

class Package extends Mongo
{
    protected $dbName = 'package';
    protected $collection = 'package';

    public function del($id, $op)
    {
        $bool = $this->remove(['_id' => new \MongoId($id)]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function search($q, $limit = 5)
    {
        $rows = $this->find([
                '$or' => [
                    ['ename' => new \MongoRegex("/.*$q/")],
                    ['name' => new \MongoRegex("/.*$q/")]
                ]
            ]
        )->limit($limit);
        $rows = iterator_to_array($rows);

        return $rows;
    }

    public function validMachine($q)
    {
        return $this->count(['ename' => $q]) ? true : false;
    }
}
