<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:06
 */
namespace Service\Policy;
class APPMarket
{
    public $strId;              //table id
    public $nMarketId;			//应用市场中ID号
    public $strName;            //APP名称
    public $strPackageName;     //APP包名
    public $strCompany;         //APP开发公司
    public $strDownloadURL;     //APP下载地址
    public $strVersion;            //
    public $nVersionCode;            //
    public $strPoll;            //APP评分
    public $strSize;            //APP大小
    public $strLogoUrl;         //APP Logo地址
    public $strSoftBrief;       //APP介绍
    public $nWeekDownload;      //周下载
    public $nTotalDownload;     //总下载
    public $tInsertTime;        //插入时间
    public $tUpdateTime;        //更新时间

    public $nFlag;              //旧版本是否下发标识位
    public $nValid;             //是否有效

    public function __construct()
    {
        $this->strId			= '';
        $this->nMarketId        = '';
        $this->strName          = '';
        $this->strPackageName       = '';
        $this->strCompany            = '';
        $this->strDownloadURL     = '';
        $this->strVersion       = '';
        $this->nVersionCode          = '';
        $this->strPoll         = '';
        $this->strSize          = '';
        $this->strLogoUrl          = '';
        $this->strSoftBrief       = "";
        $this->nWeekDownload          = 0;
        $this->nTotalDownload         = 0;
        $this->tInsertTime      = '';
        $this->tUpdateTime      = '';
        $this->nFlag            = 1;
        $this->nValid           = 1;
    }

    public function exchangeArray($row)
    {
        $this->strId		    = isset($row['id'])?$row['id']:'';
        $this->nMarketId		= isset($row['market_id'])?$row['market_id']:'';
        $this->strName	        = isset($row['name'])?$row['name']:'';
        $this->strPackageName	= isset($row['package_name'])?$row['package_name']:'';
        $this->strCompany	    = isset($row['company'])?$row['company']:'';
        $this->strDownloadURL	= isset($row['download_url'])?$row['download_url']:'';
        $this->strVersion	    = isset($row['version'])?$row['version']:'';
        $this->nVersionCode	    = isset($row['version_code'])?$row['version_code']:'';
        $this->strPoll		    = isset($row['poll'])?$row['poll']:'';
        $this->strSize	        = isset($row['size'])?$row['size']:'';
        $this->strLogoUrl	    = isset($row['logo'])?$row['logo']:'';
        $this->strSoftBrief     = isset($row['soft_brief'])?$row['soft_brief']:'';
        $this->nWeekDownload    = isset($row['week_download'])?$row['week_download']:'';
        $this->nTotalDownload   = isset($row['total_download'])?$row['total_download']:'';
        $this->tInsertTime		= isset($row['insert_time'])?$row['insert_time']:'';
        $this->tUpdateTime		= isset($row['update_time'])?$row['update_time']:'';
        $this->nFlag		    = isset($row['flag'])?$row['flag']:'';
        $this->nValid		    = isset($row['valid'])?$row['valid']:'';

        $this->tUpdateTime      = date("Y-m-d H:i:s", $this->tUpdateTime);
    }

    public function setId($strId){
        $this->strId = $strId;
    }
    public function setAppName($strName){
        $this->strName = $strName;
    }

    public function setAppFlag($nFlag){
        $this->nFlag = $nFlag;
    }

    public function setAppValid($nValid){
        $this->nValid = $nValid;
    }

    public function getCondition(){
        $strCondition = '';
        if (!empty($this->strName)){
            $strLike = "%".$this->strName."%";
            $strCondition .= sprintf(" AND name like '%s'", $strLike);
        }

        return $strCondition;
    }

}