<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:06
 */
namespace Service\Policy;
class TFPolicyUser
{
    public $strId;              //table id
    public $strQiKuId;			//奇酷ID
    public $strUserAccount;       //奇酷账户
    public $strUserName;        //用户名称
    public $strUserCard;        //用户身份证
    public $strUserPhone;       //用户手机号
    public $strDeviceId;            //用户标示
    public $strPhonePrice;            //手机价格
    public $strProduct;         //型号
    public $tUpdateTime;           //更新时间
    public $tInsertTime;        //生成日期
    public $nCount;             //返回记录数

    public function __construct()
    {
        $this->strId			= '';
        $this->strQiKuId        = '';
        $this->strUserAccount   = '';
        $this->strUserName      = '';
        $this->strUserCard      = '';
        $this->strUserPhone     = '';
        $this->strDeviceId          = '';
        $this->strPhonePrice          = '';
        $this->strProduct       = '';
        $this->tUpdateTime      = date("Y-m-d H:i:s", time());
        $this->tInsertTime      = '';
        $this->nCount           = 0;
    }

    public function exchangeArray($row)
    {
        $this->strId		    = isset($row['id'])?$row['id']:'';
        $this->strQiKuId		= isset($row['qiku_id'])?$row['qiku_id']:'';
        $this->strUserAccount	= isset($row['account'])?$row['account']:'';
        $this->strUserName		= isset($row['name'])?$row['name']:'';
        $this->strUserCard	    = isset($row['id_card'])?$row['id_card']:'';
        $this->strUserPhone		= isset($row['phone'])?$row['phone']:'';
        $this->strDeviceId	        = isset($row['deviceid'])?$row['deviceid']:'';
        $this->strPhonePrice       = isset($row['price'])?$row['price']:'';
        $this->strProduct		= isset($row['product'])?$row['product']:'';
        $this->tUpdateTime		= isset($row['update_time'])?$row['update_time']:'';
        $this->tInsertTime		    = isset($row['insert_time'])?$row['insert_time']:'';
        $this->nCount		    = isset($row['count'])?$row['count']:'';
    }

    public function setId($strId){
        $this->strId = $strId;
    }
    public function setPhonePrice($strPrice){
        $this->strPhonePrice = $strPrice;
    }

    public function setDeviceId($strDeviceId)
    {
        $this->strDeviceId = $strDeviceId;
    }

    public function setUserName($strName){
        $this->strUserName = $strName;
    }

    public function setUserPhone($strPhone){
        $this->strUserPhone = $strPhone;
    }

    public function setUserAccount($strAccount){
        $this->strUserAccount = $strAccount;
    }

    public function getCondition($startTime, $endTime){
        $strCondition = '';
        if (!empty($this->strUserAccount)){
            $strCondition .= sprintf(" AND account = '%s' ", $this->strUserAccount);
        }

        if (!empty($this->strUserName)){
            $strCondition .= sprintf(" AND name = '%s'", $this->strUserName);
        }

        if (!empty($this->strUserPhone)){
            $strCondition .= sprintf(" AND phone = '%s'", $this->strUserPhone);
        }

        $strCondition .= sprintf(" AND insert_time >= '%s' AND insert_time <= '%s' ", $startTime, $endTime);

        return $strCondition;
    }

}