<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:24
 */
namespace Service\Policy;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Logs\Logs;

class ClaimInfoTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_claim_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new ClaimInfo());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getClaimInfo($strCondition = '')
    {
        try {
            $select = $this->getSql()->select();
            $select->join(array("policy"=>"tb_qiku_policy_user_info"), "tb_qiku_claim_info.deviceid = policy.deviceid", array("account"), $select::JOIN_LEFT);
            $select->where('1=1 '.$strCondition);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('ClaimInfoTable::getClaimInfo() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function getClaimDetail($strId)
    {
        try {
            $strCondition = sprintf(" and tb_qiku_claim_info.id=%d ", $strId);
            $select = $this->getSql()->select();
            $select->join(array("policy"=>"tb_qiku_policy_user_info"), "tb_qiku_claim_info.deviceid = policy.deviceid", array("account", "name"), $select::JOIN_LEFT);
            $select->join(array("pf"=>"tb_qiku_policy_user_file"), "tb_qiku_claim_info.report_num = pf.report_num", array("type", "file_path"), $select::JOIN_LEFT);
            $select->where('1=1 '.$strCondition);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('ClaimInfoTable::getClaimDetail() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function updateStatus(ClaimInfo $info){
        try{
            $data = array(
                'status'       => $info->nStatus,
                'update_time'   => $info->tUpdateTime
            );
            if(!$this->update($data, array('report_num' => $info->strReportNum))){
                Logs::write('ClaimInfoTable::updateStatus():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('ClaimInfoTable::updateStatus() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }

}