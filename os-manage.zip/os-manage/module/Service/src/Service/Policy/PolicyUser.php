<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:06
 */
namespace Service\Policy;
class PolicyUser
{
    public $strId;              //table id
    public $strQiKuId;			//奇酷ID
    public $strUserAccount;       //奇酷账户
    public $strUserName;        //用户名称
    public $strUserCard;        //用户身份证
    public $strUserPhone;       //用户手机号
    public $strDeviceId;            //用户标示
    public $strMeid;            //用户MEID
    public $strOsVersion;         //系统版本号
    public $strAppVersion;      //应用版本号
    public $strSdkVersion;      //SDK版本号
    public $strProduct;         //型号
    public $strRoot;             //是否root
    public $tUpdateTime;           //更新时间

    public $strPolicyId;        //保险单号
    public $tStartTime;         //保单开始日期
    public $tEndTime;           //保单结束日期
    public $tInsertTime;        //保单生成日期

    public $nCount;             //返回记录数

    public function __construct()
    {
        $this->strId			= '';
        $this->strQiKuId        = '';
        $this->strUserAccount   = '';
        $this->strUserName      = '';
        $this->strUserCard      = '';
        $this->strUserPhone     = '';
        $this->strDeviceId          = '';
        $this->strMeid          = '';
        $this->strOsVersion     = '';
        $this->strAppVersion    = '';
        $this->strSdkVersion    = '';
        $this->strProduct       = '';
        $this->strRoot          = '';
        $this->tUpdateTime      = date("Y-m-d H:i:s", time());

        $this->strPolicyId      = '';
        $this->tStartTime       = '';
        $this->tEndTime         = '';
        $this->tInsertTime      = '';

        $this->nCount           = 0;
    }

    public function exchangeArray($row)
    {
        $this->strId		    = isset($row['id'])?$row['id']:'';
        $this->strQiKuId		= isset($row['qiku_id'])?$row['qiku_id']:'';
        $this->strUserAccount	= isset($row['account'])?$row['account']:'';
        $this->strUserName		= isset($row['name'])?$row['name']:'';
        $this->strUserCard	    = isset($row['id_card'])?$row['id_card']:'';
        $this->strUserPhone		= isset($row['phone'])?$row['phone']:'';
        $this->strDeviceId	    = isset($row['deviceid'])?$row['deviceid']:'';
        $this->strMeid	        = isset($row['meid'])?$row['meid']:'';
        $this->strOsVersion		= isset($row['os_version'])?$row['os_version']:'';
        $this->strAppVersion	= isset($row['app_version'])?$row['app_version']:'';
        $this->strSdkVersion	= isset($row['sdk_version'])?$row['sdk_version']:'';
        $this->strProduct		= isset($row['product'])?$row['product']:'';
        $this->strRoot		    = isset($row['rooted'])?$row['rooted']:'';
        $this->tUpdateTime		= isset($row['update_time'])?$row['update_time']:'';

        $this->strPolicyId		= isset($row['policy_id'])?$row['policy_id']:'';
        $this->tStartTime		= isset($row['start_time'])?$row['start_time']:'';
        $this->tEndTime		    = isset($row['end_time'])?$row['end_time']:'';
        $this->tInsertTime		    = isset($row['insert_time'])?$row['insert_time']:'';

        $this->nCount		    = isset($row['count'])?$row['count']:'';
    }

    public function setDeviceId($strDeviceId)
    {
        $this->strDeviceId = $strDeviceId;
    }

    public function setUserName($strName){
        $this->strUserName = $strName;
    }

    public function setUserPhone($strPhone){
        $this->strUserPhone = $strPhone;
    }

    public function setUserAccount($strAccount){
        $this->strUserAccount = $strAccount;
    }

    public function getCondition($startTime, $endTime){
        $strCondition = '';
        if (!empty($this->strUserAccount)){
            $strCondition .= sprintf(" AND tb_qiku_policy_user_info.account = '%s' ", $this->strUserAccount);
        }

        if (!empty($this->strUserName)){
            $strCondition .= sprintf(" AND name = '%s'", $this->strUserName);
        }

        if (!empty($this->strUserPhone)){
            $strCondition .= sprintf(" AND phone = '%s'", $this->strUserPhone);
        }

        $strCondition .= sprintf(" AND tb_qiku_policy_user_info.insert_time >= '%s' AND tb_qiku_policy_user_info.insert_time <= '%s' ", $startTime, $endTime);

        return $strCondition;
    }

}