<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:06
 */
namespace Service\Policy;
class ClaimInfo
{
    public $strId;              //table id
    public $strReportNum;			//报案号
    public $nPolicyType;       //1 财产隔离系统理赔 2 默认系统理赔
    public $nClaimType;        //1 仿冒/木马应用 2 诈骗短信/网址
    public $strQQ;              //用户QQ
    public $strClaimMoney;       //诈骗金额
    public $strDeviceId;            //用户标示
    public $strDesc;            //诈骗描述
    public $strPhone;         //用户电话
    public $strClaimDate;      //诈骗日期
    public $nStatus;            //理赔状态 0 待处理 1处理中 2 已赔付 3 已审核 4 已拒绝
    public $tInsertTime;        //插入时间
    public $tUpdateTime;        //更新时间

    public $strAccount;         //用户账户
    public $strName;            //用户姓名
    public $nType;              //文件类型
    public $strFilePath;        //文件路径

    public function __construct()
    {
        $this->strId			= '';
        $this->strReportNum     = '';
        $this->nPolicyType      = '';
        $this->nClaimType       = '';
        $this->strQQ            = '';
        $this->strClaimMoney     = '';
        $this->strDeviceId      = '';
        $this->strDesc          = '';
        $this->strPhone         = '';
        $this->strClaimDate     = '';
        $this->nStatus          = 0;
        $this->tInsertTime      = '';
        $this->tUpdateTime      = date("Y-m-d H:i:s", time());

        $this->strAccount       = "";
        $this->strName          = "";
        $this->nType            = "";
        $this->strFilePath      = "";
    }

    public function exchangeArray($row)
    {
        $this->strId		    = isset($row['id'])?$row['id']:'';
        $this->strReportNum		= isset($row['report_num'])?$row['report_num']:'';
        $this->nPolicyType	    = isset($row['policy_type'])?$row['policy_type']:'';
        $this->nClaimType		= isset($row['claim_type'])?$row['claim_type']:'';
        $this->strQQ	        = isset($row['qq'])?$row['qq']:'';
        $this->strClaimMoney	= isset($row['claim_money'])?$row['claim_money']:'';
        $this->strDeviceId	    = isset($row['deviceid'])?$row['deviceid']:'';
        $this->strDesc	        = isset($row['description'])?$row['description']:'';
        $this->strPhone		    = isset($row['phone'])?$row['phone']:'';
        $this->strClaimDate	    = isset($row['claim_time'])?$row['claim_time']:'';
        $this->nStatus	        = isset($row['status'])?$row['status']:'';
        $this->tInsertTime		= isset($row['insert_time'])?$row['insert_time']:'';
        $this->tUpdateTime		= isset($row['update_time'])?$row['update_time']:'';

        $this->strAccount       = isset($row['account'])?$row['account']:'';
        $this->strName       = isset($row['name'])?$row['name']:'';
        $this->nType       = isset($row['type'])?$row['type']:'';
        $this->strFilePath       = isset($row['file_path'])?$row['file_path']:'';
    }

    public function setDeviceId($strDeviceId)
    {
        $this->strDeviceId = $strDeviceId;
    }

    public function setReportNum($strReportNum){
        $this->strReportNum = $strReportNum;
    }

    public function setStatus($nStatus){
        $this->nStatus = $nStatus;
    }

    public function setAccount($strAccount){
        $this->strAccount = $strAccount;
    }

    public function setPhone($strPhone){
        $this->strPhone = $strPhone;
    }

    public function getCondition(){
        $strCondition = '';
        if (!empty($this->strAccount)){
            $strCondition .= sprintf(" AND policy.account = '%s' ", $this->strAccount);
        }

        if (!empty($this->strPhone)){
            $strCondition .= sprintf(" AND tb_qiku_claim_info.phone = '%s'", $this->strPhone);
        }

        return $strCondition;
    }

}