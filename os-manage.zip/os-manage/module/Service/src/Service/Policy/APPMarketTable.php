<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:24
 */
namespace Service\Policy;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Logs\Logs;

class APPMarketTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_apk_market';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new APPMarket());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getAppList($strCondition = '')
    {
        try {
            $select = $this->getSql()->select();
            $select->where('1=1 '.$strCondition);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('APPMarketTable::getAppList() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function updateFlag(APPMarket $info, $nType){
        try{
            $data = array();
            if($nType == 1){
                $data['flag'] = $info->nFlag;
            }
            if($nType == 2){
                $data['valid'] = $info->nValid;
            }

            if(!$this->update($data, array('id' => $info->strId))){
                Logs::write('APPMarketTable::updateFlag():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('APPMarketTable::updateFlag() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }

}