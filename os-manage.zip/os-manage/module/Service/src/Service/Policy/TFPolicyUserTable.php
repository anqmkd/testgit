<?php
/**
 * Created by PhpStorm.
 * User: wangweilin
 * Date: 2015/7/14
 * Time: 11:24
 */
namespace Service\Policy;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class TFPolicyUserTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_tf_policy_user_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new TFPolicyUser());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getUserInfo($strCondition = '', $nPageNum, $nPageCount)
    {
        try {
            $offset = ($nPageNum -1)*$nPageCount;
            $select = $this->getSql()->select();
            $select->where('1=1 '.$strCondition);
            $select->order('insert_time desc');
            $select->offset($offset);
            $select->limit($nPageCount);
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(\Exception $e){
            Logs::write('TFPolicyUserTable::getUserInfo() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function updateUser(TFPolicyUser $info){
        try{
            $data = array(
                'price'       => $info->strPhonePrice,
                'update_time'   => $info->tUpdateTime
            );
            if(!$this->update($data, array('id' => $info->strId))){
                Logs::write('TFPolicyUserTable::updateUser():update() failed', 'log');
                return false;
            }
        }catch(\Exception $e){
            Logs::write('TFPolicyUserTable::updateUser() exception, '
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }

    public function getCountList($strCondition = '')
    {
        try {
            $select = $this->getSql()->select();
            $select->columns(array('count'=>new Expression('COUNT(*)')), false);
            $select->where('1=1 '.$strCondition);
            $rowset = $this->selectWith($select);
            $row = $rowset->current();
            $nCount = $row->nCount;
        }catch(\Exception $e){
            Logs::write('PolicyUserTable::getCountList() error:'
                .' message:'.$e->getMessage(), 'log');
            return false;
        }
        return $nCount;
    }

}