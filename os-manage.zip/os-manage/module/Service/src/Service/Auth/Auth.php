<?php
namespace Service\Auth;

use Service\Logs\Logs;
use Service\AclRole\AclRole;

use Zend\Db\Adapter\Adapter as DbAdapter;
use Zend\Authentication,
    Zend\Authentication\Adapter,
    Zend\Authentication\Result,
    Zend\Authentication\AuthenticationService;

class Auth
{
    const YL_AUTH_NOT_LOGIN = 101;	//未登录
    const YL_AUTH_NO_POWER  = 102;	//没有权限

    public $auth;
    public $acl;
    public function __construct()
    {
        $this->auth = new AuthenticationService();
        $this->acl = new AclRole();
    }

    public function roleAuth($resource = null, $privilege = null, $id=null)
    {
        if (!$this->isLogin()) {
            $arrResource = preg_split("/[\s.]+/", $resource);
            if ($id) {
                $arrRemember =  array('controller'=>$arrResource[1],
                        'action'=>$arrResource[2],
                        'id'=>$id);
            } else {
                $arrRemember =  array('controller'=>$arrResource[1],
                        'action'=>$arrResource[2]);
            }

            $this->authStore($arrRemember);
            Logs::write('Auth::roleAuth() is not login', 'log');
            return self::YL_AUTH_NOT_LOGIN;
        }

        $user = $this->authRead();
        $strRole = isset($user->role) ? $user->role : 'any';


        if (!$this->acl->isAllowed($strRole, $resource, $privilege)) {
            Logs::write('Auth::roleAuth() is no power,'
                        .' nrole:'.$user->nrole
                        .' role:'.$strRole
                        .' resource:'.$resource
                        .' privilege'.$privilege, 'log');
            return self::YL_AUTH_NO_POWER;
        }

        return $user;
    }

    public function isLogin()
    {
        $stdUser = '';
        if (!$this->auth->hasIdentity()) {
            return false;
        }
        $strUser = $this->auth->getIdentity();
        if (!isset($strUser->name)) {
            return false;
        }
        return $strUser;
    }

    public function authRead()
    {
        $arrStore = $this->auth->getStorage()->read();
        return $arrStore;
    }

    public function authRemember($controller = null, $action = null, $id = null)
    {
        $authRemember = $this->auth->getStorage()->read();
        if(isset($authRemember->id)){
            $arrRemember = array('controller' => isset($authRemember->controller)?$authRemember->controller:$controller,
                    'action' => isset($authRemember->action)?$authRemember->action:$action,
                    'id' => isset($authRemember->id)?$authRemember->id:$id);
        }else{
            $arrRemember = array('controller' => isset($authRemember->controller)?$authRemember->controller:$controller,
                    'action' => isset($authRemember->action)?$authRemember->action:$action);
        }
        return $arrRemember;
    }

    public function authStore($arrStore)
    {
        $this->auth->getStorage()->write((object)$arrStore);
    }

    public function logout()
    {
        $this->auth->getStorage()->clear();
    }

    public function loginAuth(DbAdapter $zendDb,$strIdentity, $strCredential,
                              $tableName = null, $identityColumn = null,
                              $credentialColumn = null, $credentialTreatment = null)
    {
        try{
            $authAdapter = new \Zend\Authentication\Adapter\DbTable($zendDb,
                    $tableName,
                    $identityColumn,
                    $credentialColumn,
                    $credentialTreatment);

            $authAdapter->setIdentity($strIdentity)->setCredential($strCredential);
            $result = $this->auth->authenticate($authAdapter);
            if(!$result->isValid()){
                switch($result->getCode()){
                    case Result::FAILURE_IDENTITY_NOT_FOUND:
                        $errorMessage = "Admin name isn't exist!";
                        break;
                    case Result::FAILURE_CREDENTIAL_INVALID:
                        $errorMessage = "Your password is wrong!";
                        break;
                    default:
                        $errorMessage = "There are some mistakes when login!";
                }
                return $errorMessage;
            }
        }catch (\Exception $e){
            Logs::write('Auth::longinAuth() Exception, error:'.$e->getMessage(), 'log');
            return false;
        }
        return true;
    }
}
