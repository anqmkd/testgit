<?php
namespace Service\User;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Predicate\PredicateSet;

use Service\Role\Role;
use Service\Logs\Logs;

class UserTable extends AbstractTableGateway
{
    protected $table = 'tb_qiku_admin_user';

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new User());

        $this->initialize();
    }

    public function fetchAll()
    {
        $resultSet = $this->select();
        return $resultSet;
    }

    public function getAllRoleUser(Role $role)
    {
        try {
            $select = $this->getSql()->select();
            $select->where("name ='".$role->strTest
                        ."' OR name = '".$role->strTestPrincipal."'");//, PredicateSet::OP_OR);
            Logs::write('UserTable::getAllRoleUser() SQL:'.$select->getSqlString($this->getAdapter()->getPlatform()), 'log');
            $rowset = $this->selectWith($select);
            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(Exception $e){
            Logs::write('UserTable::getAllRoleUser() exception, err:'.$e->getMessage(), 'log');
            return false;
        }

        return $rows;
    }

    public function getTestUserByCpab($strId)
    {
        try {
            $select = $this->getSql()->select();
            $select->join(array('cpab' => 'tb_yl_cpab' ),
                        'tb_yl_user.name = cpab.insert_user',
                        array(),
                        $select::JOIN_INNER);
            $select->where(array('cpab.identity' => $strId));
            Logs::write('UserTable::getUserByCpab()SQL:'.$select->getSqlString($this->getAdapter()->getPlatform()).' failed', 'log');
            $rowset = $this->selectWith($select);
            $rows	= $rowset->current();
            if (!$rows) {
                Logs::write('UserTable::getUserByCpab()SQL:'.$select->getSqlString($this->getAdapter()->getPlatform()).' failed', 'log');
                return false;
            }
        }catch(Exception $e){
            Logs::write('UserTable::getUser() exception, err:'.$e->getMessage(), 'log');
            return false;
        }
        return rows;
    }
    /**
     * 根据角色编码获取角色信息
     * @param unknown_type $nRole
     * @return boolean|string
     */
    public function getUserByRole($nRole)
    {
        try {
            $select = $this->getSql()->select();
            $select->where(array('role' => $nRole));
            $rowset = $this->selectWith($select);

            $rows = array();
            while($rowset->valid()){
                $row = $rowset->current();
                if(!$row){
                    continue;
                }
                array_push($rows, $row);
                $rowset->next();
            }
        }catch(Exception $e){
            Logs::write('UserTable::getUser() exception, err:'.$e->getMessage(), 'log');
            return false;
        }
        return $rows;
    }

    public function getUser($strName)
    {
        try {
            if (empty($strName)) {
                Logs::write('UserTable:GetUser() username is empty', 'log');
                return false;
            }
            $select = $this->getSql()->select();
            $select->where(['name' => $strName]);
            $rowset = $this->selectWith($select);
            $rows	= $rowset->current();
            if (!$rows) {
                Logs::write('UserTable:GetUser()SQL:' . $select->getSqlString($this->getAdapter()->getPlatform()).' failed', 'log');
            }
        } catch(Exception $e) {
            Logs::write('UserTable::getUser() exception,  err:'
                .' file:'.$e->getFile()
                .' line:'.$e->getLine()
                .' message:'.$e->getMessage()
                .' trace:'.$e->getTraceAsString(), 'log');
            return false;
        }

        return $rows;
    }

    public function getUserById($id)
    {
        try {
            if (empty($id)) {
                Logs::write('UserTable:GetUserById() id is empty', 'log');
                return false;
            }

            $select = $this->getSql()->select();
            $select->where(array('id' => $id));
            $rowset = $this->selectWith($select);
            $rows	= $rowset->current();

            if (!$rows) {
                Logs::write('UserTable:GetUser()SQL:'.$select->getSqlString($this->getAdapter()->getPlatform()).' failed', 'log');
            }
        } catch(\Exception $e) {
            Logs::write('UserTable::getUser() exception,  err:'
                    .' file:'.$e->getFile()
                    .' line:'.$e->getLine()
                    .' message:'.$e->getMessage()
                    .' trace:'.$e->getTraceAsString(), 'log');
            return false;
        }

        return $rows;
    }

    public function checkPasswd($id, $strPsw)
    {
        try {
            if(empty($id) || empty($strPsw)){
                Logs::write('UserTable::checkPasswd() $id or strpsw is empty', 'log');
                return false;
            }

            $select = $this->getSql()->select();
            $select->where(array(
                    'id' => $id,
                    'password' => $strPsw
                )
            );
            $rowset = $this->selectWith($select);
            $rows	= $rowset->current();
            if (!$rows || !is_object($rows)) {
                Logs::write('UserTable:GetUser()SQL:'.$select->getSqlString($this->getAdapter()->getPlatform()).' failed', 'log');
                return false;
            }
        } catch(Exception $e) {
            Logs::write('UserTable::getUser() exception,  err:'
                    .' file:'.$e->getFile()
                    .' line:'.$e->getLine()
                    .' message:'.$e->getMessage()
                    .' trace:'.$e->getTraceAsString(), 'log');
                    return false;
        }

        return $rows;
    }

    public function updatePasswd($id, $strPsw)
    {
        try {
            if(empty($id) || empty($strPsw)){
                Logs::write('UserTable::updatePasswd() username or strpsw is empty', 'log');
                return false;
            }

            $data = array(
                'password'  => $strPsw,
                'update_time' => date("Y-m-d H:i:s"),
            );

            if (!$this->update($data, array('id' => $id))) {
                Logs::write('UserTable::updatePasswd():update() failed', 'log');
                return false;
            }
        } catch (Exception $e) {
            Logs::write('UserTable::updatePasswd() exception,  err:'
                .' file:'.$e->getFile()
                .' line:'.$e->getLine()
                .' message:'.$e->getMessage()
                .' trace:'.$e->getTraceAsString(), 'log');
            return false;
        }

        return true;
    }

    public function updateUser(User $user)
    {
        try {
            $data = array(
                'name'  => $user->strName,
                'password'  => $user->strPassword,
                'role'  => $user->nRole,
                'email' => $user->strEmail,
                'update_time' => date("Y-m-d H:i:s"),
            );

            if (!$this->update($data, array('name' => $user->strName))) {
                Logs::write('UserTable::updateUser():update() failed', 'log');
                return false;
            }
        } catch(Exception $e) {
            Logs::write('UserTable::updateUser() exception,  err:'
                .' file:'.$e->getFile()
                .' line:'.$e->getLine()
                .' message:'.$e->getMessage()
                .' trace:'.$e->getTraceAsString(), 'log');
            return false;
        }

        return true;
    }

    public function saveUser(User $user)
    {
        try {
            $data = array(
                    'name'  => $user->strName,
                    'password'  => $user->strPassword,
                    'role'  => $user->nRole,
                    'email' => $user->strEmail,
                    'insert_time' => date("Y-m-d H:i:s"),
            );

            $result = $this->insert($data);
            if (!$result) {
                Logs::write('UserTable::saveUser():insert() failed', 'log');
                return false;
            }
        } catch(Exception $e) {
            Logs::write('UserTable::saveUser() exception,  err:'
                .' file:'.$e->getFile()
                .' line:'.$e->getLine()
                .' message:'.$e->getMessage()
                .' trace:'.$e->getTraceAsString(), 'log');
            return false;
        }

        return true;
    }

    public function deleteUser($strName)
    {
        $this->delete(array('name' => $strName));
    }
}