<?php
namespace Service\User;

class User
{
    const ENCRYPT_SALT = 'secure_pay_';
    const YL_AUTO_UPDATE_ROLE_STAFF = 0; // 员工
    const YL_AUTO_UPDATE_ROLE_TEST          = 1;	//测试人员，申请提交人员
    const YL_AUTO_UPDATE_ROLE_TEST_PRINC    = 2;	//测试负责人，1审批提交正式服务器人员
    const YL_AUTO_UPDATE_ROLE_DEV           = 3;	//开发人员，2审批提交正式服务器人员
    const YL_AUTO_UPDATE_ROLE_DEV_PRINC     = 4;	//开发负责人，同步测试服务器，3审批同步正式服务器人员
    const YL_AUTO_UPDATE_ROLE_QUALITY_PRINC = 5;	//质量负责人
    const YL_AUTO_UPDATE_ROLE_ALL           = 10;	//所有人员

    const YL_AUTO_UPDATE_ROLE_SUPER_ADMIN = 9;		//超级管理人员

    const YL_AUTO_UPDATE_ROLE_OPERATOR           = 11;	// 运营人员
    const YL_AUTO_UPDATE_ROLE_OPERATOR_PRINC     = 12;	// 运营负责人

    public $id;
    public $strName;
    public $strPassword;
    public $nRole;
    public $strRole;
    public $strEmail;
    public $strLastLoginIp;

    public function __construct()
    {
        $this->id      = null;
        $this->strName      = '';
        $this->strPassword  = '';
        $this->nRole		= 0;
        $this->strRole		= '';
        $this->strEmail     = '';
        $this->strLastLoginIp   = '';
    }

    public function exchangeArray($data)
    {
        $this->id     = (isset($data['id'])) ? $data['id'] : null;
        $this->strName     = (isset($data['name'])) ? $data['name'] : null;
        $this->strPassword = (isset($data['password'])) ? $data['password'] : null;
        $this->nRole       = (isset($data['role'])) ? $data['role'] : 0;
        $this->strEmail    = (isset($data['email'])) ? $data['email'] : '';
        $this->strLastLoginIp    = (isset($data['last_login_ip'])) ? $data['last_login_ip'] : '';
        $this->_setRole();
    }

    static public function getNextRole($nPublish)
    {
        $nNextRole= null;
        switch ($nPublish){
            case Cpab::YL_AUTO_UPDATE_PUBLISH_UPDATE:
            case Cpab::YL_AUTO_UPDATE_PUBLISH_TEST_REPORT:
                $nNextRole = self::YL_AUTO_UPDATE_ROLE_TEST_PRINC;
                break;
            case Cpab::YL_AUTO_UPDATE_PUBLISH_VERIFY:
            case Cpab::YL_AUTO_UPDATE_PUBLISH_VERIFY_FAILED:
            case Cpab::YL_AUTO_UPDATE_PUBLISH_TEST_FAILED:
            case Cpab::YL_AUTO_UPDATE_PUBLISH_SYNC:
            case Cpab::YL_AUTO_UPDATE_PUBLISH_SYNC_FAILED:
                $nNextRole = self::YL_AUTO_UPDATE_ROLE_TEST;
                break;
            default:
                $nNextRole = self::YL_AUTO_UPDATE_ROLE_ALL;
                break;
        }
        return $nNextRole;
    }

    static function getRoleFiled($nRole)
    {
        $strFiled = '';
        switch ($nRole){
        case self::YL_AUTO_UPDATE_ROLE_TEST:
            $strFiled = 'test';
            break;
        case self::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
            $strFiled = 'test_principal';
            break;
        case self::YL_AUTO_UPDATE_ROLE_DEV:
            $strFiled = 'dev';
            break;
        case self::YL_AUTO_UPDATE_ROLE_DEV_PRINC:
            $strFiled = 'dev_principal';
            break;
        case self::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC:
            $strFiled = 'quality_principal';
            break;
        case self::YL_AUTO_UPDATE_ROLE_OPERATOR:
            $strFiled = 'operator';
            break;
        case self::YL_AUTO_UPDATE_ROLE_OPERATOR_PRINC:
            $strFiled = 'operator_principal';
            break;
        default:
            $strFiled = '';
            break;
        }
        return $strFiled;
    }

    private function _setRole()
    {
        switch ($this->nRole){
        case self::YL_AUTO_UPDATE_ROLE_TEST:
            $this->strRole = 'test';
            break;
        case self::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
            $this->strRole = 'test_princ';
            break;
        case self::YL_AUTO_UPDATE_ROLE_OPERATOR:
            $this->strRole = 'operator';
            break;
        case self::YL_AUTO_UPDATE_ROLE_DEV:
            $this->strRole = 'dev';
            break;
        case self::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN:
            $this->strRole = 'superadmin';
            break;
        default:
            $this->strRole = 'staff';
            break;
        }
    }

    public function setUser($strName, $strPassword, $nRole, $strEmail)
    {
        $this->strName      = $strName;
        $this->strPassword  = $strPassword;
        $this->nRole        = $nRole;
        $this->strEmail     = $strEmail;
    }

    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

    public static function encryptPassword($password)
    {
        $encPassword = md5(self::ENCRYPT_SALT . $password);

        return $encPassword;
    }
}