<?php
namespace Service\Conf;

use Service\Mongo;
use Data\Verify as D;
use Data\Type as DT;

class App extends Mongo
{
    protected $dbName = 'appConf';
    protected $collection = 'app';

    /**
     * 获取版本信息
     * @param {MongoId} $appid 项目ID
     * @param {string} $version 版本号
     * @param {boolean} $isFull 是否完整信息
     */
    public function getVersion($appId, $version, $isFull = false)
    {
        $version = $this->findOne(['_id' => new \MongoId($appId), 'versions.version' => $version], ['versions.$' => 1, 'ename' => 1]);

        if ($version && $version['versions'] && !$isFull) {
            return D::get($version, 'versions.0');
        } else {
            return $version;
        }

        return [];
    }

    /**
     * 在某个app下面增加版本
     * @todo 考虑去重的问题
     */
    public function addVersion($appId, $version)
    {
        $this->update(['_id' => new \MongoId($appId)], ['$push' => ['versions' => $version]]);

        return true;
    }

    /**
     * 复制某个版本
     */
    public function cloneVersion($appId, $version, $clonedVersion, $desc)
    {
        // 取出clonedVersion的所有信息
        $versionInfo = $this->getVersion($appId, $clonedVersion, $isFull = true);
        $ename = D::get($versionInfo, 'ename');
        $versionInfo = D::get($versionInfo, 'versions.0');

        // 复制所有的接口
        $time = time();

        $versionInfo['version'] = $version;
        $versionInfo['desc'] = $desc;
        $versionInfo['ctime'] = $time;

        if ($versionInfo['apis']) {
            foreach ($versionInfo['apis'] as &$api) {
                $api['ctime'] = $api['utime'] = $time;
                $clonedApiId = $api['id'];
                $api['id'] = \Service\Conf\Api::getApiId($appId, $ename, $version, $api['api']);

                // select from api
                $apiTable = new Api();

                $clonedApi = $apiTable->getApi($clonedApiId, $isFull = false);
                $clonedApi = $clonedApi ? $clonedApi : [];
                unset($clonedApi['_id']);
                $init = [
                    'id' => $api['id'],
                    // 覆盖使用新的version
                    'version' => $version,
                    'snapshot' => [],
                    'logs' => [],
                    'rowIndex' => 0,
                    'ctime' => $time,
                    'utime' => $time
                ];

                $clonedApi = array_merge($clonedApi, $init);
                $apiTable->setDocument($clonedApi)->save();
            }
        }

        // 重新生成api id
        $this->addVersion($appId, $versionInfo);
        // add apis

        return true;
    }

    public function delVersion($appId, $version)
    {
        // 删除app中的version信息
        $bool = $this->update(['_id' => new \MongoId($appId)], ['$pull' => ['versions' => ['version' => $version]]]);
        // 删除该version下的api
        $apiTable = new Api();
        $bool = $apiTable->remove(['appId' => $appId, 'version' => $version]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function setApp($id, $row, $op)
    {
        $bool = $this->update(['_id' => new \MongoId($id)], ['$set' => $row]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function delApp($id, $op)
    {
        $bool = $this->remove(['_id' => new \MongoId($id)]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function addApi($appId, $ename, $version, $apiId, $api, $desc, $model)
    {
        $cond = [
            '_id' => new \MongoId($appId),
            'versions.version' => $version
        ];

        $time = time();

        $api = [
            'id' => $apiId,
            'api' => $api,
            'desc' => $desc,
            'model' => $model,
            'ctime' => $time,
            'utime' => $time
        ];
        $bool = $this->update($cond, ['$push' => ['versions.$.apis' => $api]]);

        return $bool;
    }

    public function delApi($id, $ename, $version, $api)
    {
        $apiId = md5($ename . $version . $api);
        $bool = $this->update(['_id' => new \MongoId($id), 'versions.version' => $version, 'versions.apis.id' => $apiId], ['$pull' => ['versions.$.apis' => ['id' => $apiId]]]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function apiInfo($ApiId)
    {
        $api = $this->aggregate(
            ['$match' => ['versions.apis.id' => $ApiId]],
            ['$unwind' => '$versions'],
            ['$unwind' => '$versions.apis'],
            ['$match' => ['versions.apis.id' => $ApiId]],
            ['$project' => ["name" => 1, "ename" => 1, "versions.version" => 1, "versions.apis" => 1]]
        );

        if (empty($api) || !$api['ok'] || empty($api['result'])) {
            return false;
        }

        $api = D::get($api, 'result.0');
        $apiInfo = [
            'appId' => (string)$api['_id'],
            'version' => $api['versions']['version'],
            'api' => $api['versions']['apis']['api'],
            'app' => $api['ename'],
            'appName' => $api['name']
        ];

        return $apiInfo;
    }
}
