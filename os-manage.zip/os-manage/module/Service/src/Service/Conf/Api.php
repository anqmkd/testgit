<?php
namespace Service\Conf;
use Service\Mongo;
use Data\Verify as D;
use Data\Type as DT;
use Service\Log\Log;

class Api extends Mongo
{
    protected $dbName = 'appConf';
    protected $collection = 'api';

    // 指令-新增
    const INSTRUCT_ADD = 0;
    // 指令-修改
    const INSTRUCT_UPDATE = 1;
    // 指令-删除
    const INSTRUCT_DEL = 2;

    const MODEL_INSTRUCT = 'instruct';
    const MODEL_NEW = 'new';
    const MODEL_NEWEST = 'newest';

    public static function getApiId($appId, $ename, $version, $api)
    {
        return md5($ename . $version . $api);
    }

    public function getApi($id, $isFull = true)
    {
        $appTable = new App();
        $apiInfo = $this->findOne(['id' => $id]);

        if (empty($apiInfo)) {
            return false;
        }

        if (!$isFull) {
            return $apiInfo;
        }

        // get api description info
        $api = $appTable->aggregate(
            ['$match' => ['versions.apis.id' => $id]],
            ['$unwind' => '$versions'],
            ['$unwind' => '$versions.apis'],
            ['$match' => ['versions.apis.id' => $id]],
            ['$project' => ["ename" => 1, "versions.version" => 1, "versions.apis" => 1]]
        );

        if (empty($api) || !$api['ok'] || empty($api['result'])) {
            return false;
        }

        $api = D::get($api, 'result.0');
        $appInfo = [
            'appId' => (string)$api['_id'],
            'version' => $api['versions']['version'],
            'ename' => $api['ename']
        ];
        $api = $api['versions']['apis'];

        $demo = [
            'attributes' => [],
            'snapshot' => [],
            'isQuick' => 0,
            'logs' => []
        ];

        $api = array_merge($demo, $api, $apiInfo);
        $api['appInfo'] = $appInfo;

        return $api;
    }

    /**
     * 新增api
     * param {string} $appId 项目id
     * param {string} $version 版本
     * param {string} $api 接口 eg. whilte_list
     * param {string} $desc 描述
     */
    public function addApi($appId, $ename, $version, $api, $desc, $model = self::MODEL_INSTRUCT)
    {
        $appTable = new App();
        $apiId = $this->getApiId($appId, $ename, $version, $api);
        $appTable->addApi($appId, $ename, $version, $apiId, $api, $desc, $model);

        $time = time();
        $api = [
            'id' => $apiId,
            'appId' => $appId,
            'version' => $version,
            'attributes' => [],
            'snapshot' => [],
            'isQuick' => false,
            'logs' => [],
            'ops' => [],
            'rowIndex' => 0,
            'ctime' => $time,
            'utime' => $time
        ];

        return $this->setDocument($api)->save();
    }

    public function delApi($appId, $ename, $version, $api)
    {
        $appTable = new App();
        $appTable->delApi($appId, $ename, $version, $api);

        $apiId = md5($ename . $version . $api);
        $bool = $this->remove(['id' => $apiId]);

        return $bool && $bool['ok'] ? true : false;
    }

    /**
     * 克隆复制接口格式
     */
    public function cloneApi($appId, $ename, $version, $api, $clonedApi, $desc, $model = self::MODEL_INSTRUCT)
    {
        $apiId = $this->getApiId($appId, $ename, $version, $clonedApi);
        $apiInfo = $this->getApi($apiId);
        $appInfo = $apiInfo['appInfo'];

        // change name to api_clone
        $apiId = $this->getApiId($appId, $ename, $version, $api);
        $apiInfo['api'] = $api;
        $apiInfo['id'] = $apiId;
        $apiInfo['logs'] = [];
        $apiInfo['snapshot'] = [];
        $apiInfo['rowIndex'] = 0;
        $apiInfo['ctime'] = $apiInfo['utime'] = time();
        unset($apiInfo['appInfo']);
        unset($apiInfo['_id']);

        // save app table
        $appTable = new App();
        $appTable->addApi($appId, $ename, $version, $apiId, $api, $desc, $model);

        // save api table
        $bool = $this->setDocument($apiInfo)->save();

        return $bool ? true : false;
    }

    public function addAttribute($apiId, $attribute)
    {
        $attribute['time'] = time();
        $this->update(['id' => $apiId], ['$push' => ['attributes' => $attribute]]);

        return true;
    }

    /**
     * 增加数据集
     */
    public function addRow($apiId, $row, $op, $instruct = self::INSTRUCT_ADD)
    {
        $time = time();
        // 用来diff的log，每条_log只有一个
        $log = [
            'del' => 0,
            'time' => $time,
            'utime' => $time,
            'row' => $row,
        ];

        // 完整的操作记录
        $ops = [
            'api' => $apiId,
            'row' => $row,
            'oriRow' => []
        ];
        $opLog = new Log();
        $opLog->add($op, $time, 'Conf', $instruct, $ops);
        // end

        return $this->update(['id' => $apiId], ['$push' => ['logs' => $log, 'snapshot' => $row], '$set' => ['utime' => $time]]);
    }

    public function setRow($apiId, $row, $op, $oriRow, $instruct = self::INSTRUCT_UPDATE)
    {
        $rowId = $row['_id'];
        $time = time();

        $ops = [
            'api' => $apiId,
            'row' => $row,
            'oriRow' => $oriRow
        ];
        $opLog = new Log();
        $opLog->add($op, $time, 'Conf', $instruct, $ops);

        $bool =  $this->update(
            ['id' => $apiId, 'snapshot._id' => $rowId],
            [
                '$set' => [
                    'utime' => $time,
                    'snapshot.$' => $row,
                ]
            ]
        );

        $boolLog =  $this->update(
            ['id' => $apiId, 'logs.row._id' => $rowId],
            [
                '$set' => [
                    'logs.$.utime' => $time, # update time
                    'logs.$.row' => $row
                ]
            ]
        );

        return $bool['ok'] && $boolLog['ok'];
    }

    /**
     * 增加数据集
     */
    public function delRow($apiId, $rowId, $op)
    {
        $instruct = self::INSTRUCT_DEL;
        $time = time();
        $row = $this->getSnapshotRow($apiId, $rowId);

        // 完整的操作记录
        $ops = [
            'api' => $apiId,
            'row' => $row,
            'oriRow' => $row
        ];
        $opLog = new Log();
        $opLog->add($op, $time, 'Conf', $instruct, $ops);
        // end

        return $this->update(
            ['id' => $apiId, 'logs.row._id' => $rowId],
            [
                '$set' => [
                    'utime' => $time,
                    'logs.$.del' => 1,
                    'logs.$.utime' => $time,
                    'logs.$.row' => $row
                ],
                '$pull' => ['snapshot' => ['_id' => $rowId]]
            ]
        );
    }

    /**
     * 获取snapshot里的row
     */
    public function getSnapshotRow($apiId, $rowId)
    {
        $row = $this->findOne(['id' => $apiId, 'snapshot._id' => $rowId], ['snapshot.$' => 1, '_id' => 0]);

        return $row && $row['snapshot'] ? $row['snapshot'][0] : [];
    }

    /**
     * 增加快照，即直接快速上传配置
     * param {string} $apiId
     * param {mix} $snapshot 快照
     * param {string} $op 操作员
     * param {const} $instruct 指令:set or del
     */
    public function addSnapshot($apiId, $snapshot, $op, $instruct = self::INSTRUCT_ADD)
    {
        $time = time();
        $log = [
            'instruct' => $instruct,
            'op' => $op,
            'isQuick' => 1,
            'time' => $time,
            'row' => $snapshot
        ];

        return $this->update(['id' => $apiId], ['$push' => ['logs' => $log], '$set' => ['utime' => $time, 'isQuick' => 1, 'snapshot' => $snapshot]]);
    }

    /**
     * 删除字段
     */
    public function delAttribute($apiId, $key)
    {
        return $this->update(['id' => $apiId], ['$pull' => ['attributes' => ['key' => $key]]]);
    }

    /**
     * 设置修改属性
     */
    public function setAttribute($apiId, $key, $attribute)
    {
        $attribute['time'] = time();
        return $this->update(['id' => $apiId, 'attributes.key' => $key], ['$set' => ['attributes.$' => $attribute]]);
    }

    /**
     * 自增rowIndex
     * rowIndex来记录记录自增id
     */
    public function incRowIndex($apiId)
    {
        $api = $this->findAndModify(['id' => $apiId], ['$inc' => ['rowIndex' => 1]], null, ['new' => true]);
        return $api;
    }

    /**
     * 检查类型
     * param {mix} $data 数据源
     * param {string} $type 类型
     * param {array} $typeOpt 类型参数
     */
    public function checkType($data, $type, $typeOpt = [])
    {
        if ($type == 'strings') {
            $type = 'string';
        }

        // 如果是包名，目前并不需要验证
        if ($type == 'package') {
            $type = 'string';
        }

        // 如果是枚举型，统一处理成字符型
        if ($type === 'enums') {
            return D::vv($data, DT::STRING);
        } elseif ($type === 'machine') {
            // check
            $machine = new \Service\Machine\Machine();
            // 未通过，设为空
            if (!$machine->validMachine($data)) {
                $data = '';
            }

            return $data;
        } elseif ($type === 'district') {
            // 验证地区

            return $data;
        } else {
            return D::vv($data, $type);
        }
    }

    /**
     * key排序
     */
    public function sortKeys($id, $keys)
    {
        $apiInfo = $this->findOne(['id' => $id], ['attributes' => 1]);
        if (empty($apiInfo)) {
            return false;
        }

        $attributes = $apiInfo['attributes'];

        foreach ($attributes as &$attr) {
            $key = $attr['key'];
            $sort = array_keys($keys, $key);
            $sort = $sort[0];
            $attr['sort'] = $sort;
        }

        $bool = $this->update(['id' => $id], ['$set' => ['attributes' => $attributes]]);

        return $bool && $bool['ok'] ? true : false;
    }
}
