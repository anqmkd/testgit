<?php
namespace Service\Log;

use Service\Mongo;
use Data\Verify as D;
use Data\Type as DT;

class Log extends Mongo
{
    protected $dbName = 'log';
    protected $collection = 'log';

    /**
     * 新增记录
     * @param {string} $op 操作人
     * @param {int} $time 时间
     * @param {string} $project 项目
     * @param {string} $instruct 指令
     * @param {mix} $ops 其他操作
     */
    public function add($op, $time, $project, $instruct, $ops = [])
    {
        $ops['op'] = $op;
        $ops['time'] = $time;
        $ops['project'] = $project;
        $ops['instruct'] = $instruct;

        return $this->setDocument($ops)->save();
    }

    public function del($id, $op)
    {
        $bool = $this->remove(['_id' => new \MongoId($id)]);

        return $bool && $bool['ok'] ? true : false;
    }

    public function search($q, $limit = 5)
    {
        $rows = $this->find([
                'project' => new \MongoRegex("/.*$q/"),
            ]
        )->limit($limit);
        $rows = iterator_to_array($rows);

        return $rows;
    }
}
