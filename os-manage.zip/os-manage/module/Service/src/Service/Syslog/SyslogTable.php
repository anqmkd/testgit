<?php
namespace Service\Syslog;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class SyslogTable extends AbstractTableGateway
{
	protected $table = 'tb_qiku_syslog';
	
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new Syslog());
		
		$this->initialize();
	}
	
	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function saveSyslog(Syslog $log)
	{
		try{
			if(!$log){
				Logs::write('SyslogTable::saveSyslog():$$log is null', 'log');
				return false;
			}
			
			$data = array(
					'type' 	  		=> $log->strType,
					'username' 	  	=> $log->strUserName,
					'logtitle'    	=> $log->strTitle,
					'logtext'		=> $log->strText,
					'logtime'		=> $log->strTime,
			);
	
			$result = $this->insert($data);
			if(!$result){
				Logs::write('SyslogTable::saveSyslog():insert() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('SyslogTable::saveSyslog() exception,  err:'
												.' file:'.$e->getFile()
												.' line:'.$e->getLine()
												.' message:'.$e->getMessage()
												.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
		return true;
	}
}