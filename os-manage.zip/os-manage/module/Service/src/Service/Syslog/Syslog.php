<?php
namespace Service\Syslog;

class Syslog
{	
	public $strType;
	public $strUserName;
	public $strTitle;
	public $strText;
	public $strTime;
	
	const SYSLOG_LOGIN	= 1;
	const SYSLOG_PUSH	= 2;
	const SYSLOG_COUNT	= 3;
	
	public function __construct()
	{
		$this->strType    	= ''; 
		$this->strUserName 	= '';
		$this->strText 		= '';
		$this->strTitle 	= '';
		$this->strTime		= date("Y-m-d H:i:s");
	}
	
	public function exchangeArray($row)
	{
		$this->strType    	= isset($row['type'])?$row['type']:'';
		$this->strUserName 	= isset($row['username'])?$row['username']:'';
		$this->strText 		= isset($row['logtitle'])?$row['logtitle']:'';
		$this->strTitle 	= isset($row['logtext'])?$row['logtext']:'';
		$this->strTime 		= isset($row['logtime'])?$row['logtime']:'';
	}

	public function setParam($type, $username, $title, $text){
		$this->strType    	= $type;
		$this->strUserName 	= $username;
		$this->strText 		= $text;
		$this->strTitle 	= $title;
	}
	
	/**
	 * 获得客户端真实的IP地址
	 */
	public function getip()
	{
		if (getenv("HTTP_CLIENT_IP") && strcasecmp(getenv("HTTP_CLIENT_IP"), "unknown"))
		{
			$ip = getenv("HTTP_CLIENT_IP");
		}
		elseif (getenv("HTTP_X_FORWARDED_FOR") && strcasecmp(getenv("HTTP_X_FORWARDED_FOR"), "unknown"))
		{
			$ip = getenv("HTTP_X_FORWARDED_FOR");
		}
		elseif (getenv("REMOTE_ADDR") && strcasecmp(getenv("REMOTE_ADDR"), "unknown"))
		{
			$ip = getenv("REMOTE_ADDR");
		}
		elseif (isset ($_SERVER['REMOTE_ADDR']) && $_SERVER['REMOTE_ADDR'] && strcasecmp($_SERVER['REMOTE_ADDR'], "unknown"))
		{
			$ip = $_SERVER['REMOTE_ADDR'];
		}
		else
		{
			$ip = "unknown";
		}
		return ($ip);
	}
}