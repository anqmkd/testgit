<?php

namespace Service;
use AppConf;

class Mongo
{
    private static $db = null;

    /**
     * 数据驱动配置
     * servers, username, password
     */
    protected $driveCfg = [];
    protected $readPreference = \MongoClient::RP_NEAREST;

    protected $fields = [];

    protected $document = [];

    protected $qconfKey = '';

    // 最大执行时间
    protected static $maxTimeMS = 250;

    public function __construct()
    {
        // server port username password readPreference
        $this->driveCfg = $this->initCfg();
    }

    public function initCfg()
    {
        $key = '/dba/mdb/os_manage_mongo';
        $spec = AppConf::getSpec($key);

        $username = '';
        $password = '';
        $replicaSet = '';

        if ($spec && is_array($spec)) {
            $servers = $spec['servers'];
            $username = $spec['username'];
            $password = $spec['password'];
            $replicaSet = $spec['replicaSet'];
        } else {
            $servers = AppConf::getHosts($key);
        }

        return [
            'servers' => $servers,
            'options' => [
                'username' => $username,
                'password' => $password,
                'replicaSet' => $replicaSet
            ]
        ];
    }

    public function getServers()
    {
        return $this->driveCfg['servers'];
    }

    public function getOptions()
    {
        return $this->driveCfg['options'];
    }

    public function getFields()
    {
        return $this->fields;
    }

    public function getLink($options = null)
    {
        $options = $options ? $options : $this->getOptions();
        $link = self::applyMongo($this->getServers(), $options);

        return $link;
    }

    /**
     * 获得$db
     * @return {Collection}
     */
    public function getDb($link = null, $dbName = '')
    {
        if (is_null($link)) {
            $link = $this->getLink();
        }

        $dbName = $dbName ? $dbName : $this->dbName;

        return $link->$dbName;
    }

    /**
     * 获得collection
     * @return {Collection}
     */
    public function getCollection($db = null, $collection = '')
    {
        if (is_null($db)) {
            $db = $this->getDb();
        }

        $collection = $collection ? $collection : $this->collection;

        return $db->$collection;
    }

    public function getDocument()
    {
        $document = $this->document;

        if (!isset($document['ctime'])) {
            $document['ctime'] = time();
        }

        if (!isset($document['utime'])) {
            $document['utime'] = time();
        }

        return $this->document;
    }

    public function getSaveCollection()
    {
        $options = $this->getOptions();
        $link = self::applyMongo($this->getServers(), $options);

        $db = $this->getDb($link);
        $collection = $this->getCollection($db);

        return $collection;
    }

    public function save()
    {
        $collection = $this->getSaveCollection();
        $aDocument = $this->getDocument();

        $bool = $collection->save($aDocument);

        if ($bool['ok']) {
            return true;
        }

        return false;
    }

    public function find()
    {
        $cursor = $this->getCollection();

        return call_user_func_array([$cursor, 'find'], func_get_args());        
    }

    public function findOne()
    {
        $cursor = $this->getCollection();

        return call_user_func_array([$cursor, 'findOne'], func_get_args());
    }

    public function getList($cond = [], $sort = [], $page = 1, $pagesize = 10)
    {
        $row = $this->find($cond);
        $offset = ($page - 1) * $pagesize;

        if ($offset) {
            $row->skip($offset);
        }

        if (!is_null($pagesize)) {
            $row->limit($pagesize);
        }

        if ($sort) {
            $row->sort($sort);
        }

        $rows = iterator_to_array($row);

        foreach ($rows as &$row) {
            if (!isset($row['id']) && isset($row['_id'])) {
                $row['id'] = (string)$row['_id'];
            }
        }
        return $rows ? $rows : [];
    }

    /**
     * 该函数直接调用drive提供的collection方法
     */
    public function __call($name, $arguments)
    {
        $cursor = $this->getCollection();

        return call_user_func_array([$cursor, $name], $arguments);
    }

    /**
     * 获得数据
     */
    public function getRes($cursor)
    {
        $cursor->maxTimeMS(self::$maxTimeMS);

        $res = iterator_to_array($cursor);

        return $res;
    }

    
    /**
     * 申请一个mongo连接对象
     */
    public static function applyMongo($servers, $options = [])
    {
        $mongo = null;

        if (!isset($options['connectTimeoutMS'])) {
            $options['connectTimeoutMS'] = self::$maxTimeMS;
        }

        if (is_array($servers)) {
            $servers = "mongodb://" . implode(',', $servers);
        }

        foreach ($options as $k => $op) {
            if (empty($op)) {
                unset($options[$k]);
            }
        }

        try {
            $mongo = new \MongoClient($servers, $options);
        } catch (\Exception $e) {
            throw $e;
        }

        return $mongo;
    }

    public function __get($property_name)
    {
        if (in_array($property_name, $this->fields)) {
            return $this->document[$property_name];
        } else {
            return NULL;
        }
    }

    public function __set($property_name, $value)
    {
        $this->document[$property_name] = $value;
    }

    public function setDocument($data)
    {
        foreach ($data as $property_name => $value) {
            $this->document[$property_name] = $value;
        }

        return $this;
    }
}