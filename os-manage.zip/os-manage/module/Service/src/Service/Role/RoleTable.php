<?php
namespace Service\Role;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class RoleTable extends AbstractTableGateway
{
	protected $table = 'tb_yl_cpab_roles';
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new Role());

		$this->initialize();
	}

	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function fetchAllApps()
	{
		try {
// 			$select = $this->getSql()->select();
// 			$select->columns(array('test',
// 									'test_principal',
// 									'dev',
// 									'dev_principal',
// 									'quality_principal',
// 									'app', 
// 								   'identity'=>new Expression('app.identity'),  
// 								   'ver_code'=>new Expression('MAX(ver_code)'),
// 								   'ver_name'=>new Expression('MAX(ver_name)'),
// 								   'publish'=>new Expression('app.publish'),
// 									), false);
// 			$select->join(array('app' => 'tb_yl_app' ),// table name,
// 					'app.name = tb_yl_app_roles.app', 				// expression to join on (will be quoted by platform object before insertion),
// 					array('identity', 'ver_code', 'ver_name', 'publish'), // (optional) list of columns, same requiremetns as columns() above
// 					$select::JOIN_LEFT);
	
// 			$select->where('tb_yl_app_roles.valid = 1 AND ver_name IN (SELECT MAX(ver_name) FROM tb_yl_app GROUP BY name)');
// 			$select->group('app.name');
// 			//Logs::write('AppTable::fetchAllApps() SQL'.$select->getSqlString(), 'log');
// 			$rowset = $this->selectWith($select);
// 			$sql = 'SELECT roles.app, roles.test, roles.test_principal, roles.dev, roles.dev_principal, roles.quality_principal, '
// 					.' app.identity, app.ver_code, app.ver_name, app.publish '
// 					.' FROM tb_yl_app_roles AS roles'
// 					.' LEFT JOIN (SELECT identity, name , ver_code, ver_name, publish' 
// 	   				.' 			  FROM tb_yl_app'  
// 					.' 			  			WHERE ver_name IN (SELECT MAX(ver_name) FROM tb_yl_app GROUP BY name)'
// 	   				.' 			  ) app'
// 	   				.' ON roles.app = app.name'
// 					.' WHERE roles.valid=1';

			$sql = 'SELECT app.app, app.test, app.test_principal, app.dev, app.dev_principal, app.quality_principal,'
					.' app.identity, app.version, app.publish, app.update_time, report.reportname, report.report'
					.' FROM (SELECT roles.app, roles.test, roles.test_principal, roles.dev, roles.dev_principal, roles.quality_principal,'
					.'				app.identity, app.version, app.publish, app.update_time' 
					.'		FROM tb_yl_cpab_roles AS roles'
					.'		LEFT JOIN (SELECT identity, name , version, publish, update_time'
					.' 					FROM tb_yl_cpab'
					.' 					WHERE publish !=-1  AND version IN (SELECT MAX(version)' 
					.'					FROM tb_yl_cpab)'
					.'		 ) app'
					.' 		ON roles.app = app.name' 
					.'		WHERE roles.valid=1 '
					.'	) app'
					.' LEFT JOIN tb_yl_cpab_test_report report ON app.identity = report.identity';
			
			$rowset = $this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
			
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('AppTable::fetchAllApps() error:'.$e->getMessage(), 'log');
			return false;
		}
		return $rows;
	}
	
	public function getRoleByCpab($strCpab){
		try {
			$select = $this->getSql()->select();
			$select->where(array('app'=>$strCpab));
			$rowset = $this->selectWith($select);		
			$rows	= $rowset->current();
		}catch(Exception $e){
			Logs::write('AppTable::getRoleByApp() error:'.$e->getMessage(), 'log');
			return false;
		}
		return $rows;
	}
	

	public function saveRole(Role $role){
		try{
			if(!$role){
				Logs::write('RoleTable::saveRole():role is null', 'log');
				return false;
			}
			 
			$data = array(
					'app' 			=> $role->app,
					'test' 			=> $role->test,
					'dev'			=> $role->test_principal,
					'sys_ver'  		=> $role->dev,
					'dev_principal' => $role->dev_principal,
					'quality_principal'=> $role->quality_principal,
			);
			 
			$result = $this->insert($data);
			if(!$result){
				Logs::write('RoleTable::saveRole():insert() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('RoleTable::saveRole exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}

	public function updateRole(Role $role){
		try{
			if(!$role){
				Logs::write('RoleTable::updateRole():role is null', 'log');
				return false;
			}
	
			 
			$data = array(
					'app' 			=> $role->app,
					'test' 			=> $role->test,
					'dev'			=> $role->test_principal,
					'sys_ver'  		=> $role->dev,
					'dev_principal' => $role->dev_principal,
					'quality_principal'=> $role->quality_principal,
			);
	
			if(!$this->update($data, array('app' => $role->app))){
				Logs::write('RoleTable::updateRole():update() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('RoleTable::updateRole() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
}