<?php
namespace Service\Role;

use Service\User\User;
use Service\App\App;

class Role
{
	public $bValid;				//APP的ID
	public $strTest;			//APP的名称
	public $strTestPrincipal;	//版本
	public $strDev;				//开发人员
	public $strDevPrincipal;		//开发负责人
	public $strQualityPrincipal;	//质量负责人
	
    public function __construct()
    {
    	$this->bValid				= false;
		$this->strTest				= '';
		$this->strTestPrincipal		= '';
		$this->strDev				= '';
		$this->strDevPrincipal		= '';
		$this->strQualityPrincipal	= '';	
	} 
	
    public function exchangeArray($row)
    {
    	$this->bValid				= false;
    	$this->strTest				= isset($row['test'])?$row['test']:'';
    	$this->strTestPrincipal		= isset($row['testprincipal'])?$row['testprincipal']:'';
    	$this->strDev				= isset($row['dev'])?$row['dev']:'';
    	$this->strDevPrincipal		= isset($row['devprincipal'])?$row['devprincipal']:'';
    	$this->strQualityPrincipal	= isset($row['qualityprincipal'])?$row['qualityprincipal']:'';
    }
    
    public function getCurrentUserName($nRole)
    {
    	switch ($nRole){
    		case User::YL_AUTO_UPDATE_ROLE_TEST:
    			$strName = $this->strTest;
    			break;
    		case User::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
    			$strName = $this->strTestPrincipal;
    			break;
    		case User::YL_AUTO_UPDATE_ROLE_DEV:
    			$strName = $this->strDev;
    			break;
    		case User::YL_AUTO_UPDATE_ROLE_DEV_PRINC:
    			$strName = $this->strDevPrincipal;
    			break;
    		case User::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC:
    			$strName = $this->strQualityPrincipal;
    			break;
    	}
    	return $strName;
    }

    public function getNextUserName($nPublish)
    {
    	switch ($nPublish){
    		case App::YL_AUTO_UPDATE_PUBLISH_UPDATE:
    			$strName = $this->strDevPrincipal;
    			break;
    		case App::YL_AUTO_UPDATE_PUBLISH_VERIFY:
    			$strName = $this->strTest;
    			break;
    		case App::YL_AUTO_UPDATE_PUBLISH_SUCCESS:
    			$strName = $this->strTestPrincipal;
    			break;
    		case App::YL_AUTO_UPDATE_PUBLISH_SYNC_1:
    			$strName = $this->strDev;
    			break;
    		case App::YL_AUTO_UPDATE_PUBLISH_SYNC_2:
    			$strName = $this->strDevPrincipal;
    			break;
    		case App::YL_AUTO_UPDATE_PUBLISH_SYNC_3:
    			$strName = $this->strQualityPrincipal;
    			break;
   			case App::YL_AUTO_UPDATE_PUBLISH_SYNC_4:
   				$strName = $this->strQualityPrincipal;
   				break;
    	}
    	return $strName;
    }
}