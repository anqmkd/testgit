<?php
namespace Service\Record;

class PathRecord
{	
	public $strLevel1;
	public $strLevel2;
	public $strLevel3;
	public $strLevel4;
	public $strLevel5;
	
	public function __construct()
	{
		$this->strLevel1    = ''; 
		$this->strLevel2 	= '';
		$this->strLevel3 	= '';
		$this->strLevel4 	= '';
		$this->strLevel5	= '';
	}
	
	public function exchangeArray($row)
	{
		$this->strLevel1    = isset($row['level1'])?$row['level1']:'';
		$this->strLevel2 	= isset($row['level2'])?$row['level2']:'';
		$this->strLevel3 	= isset($row['level3'])?$row['level3']:'';
		$this->strLevel4 	= isset($row['level4'])?$row['level4']:'';
		$this->strLevel5 	= isset($row['level5'])?$row['level5']:'';
	}

	public function getCondition($strLevel1, $strLevel2){
		$strCondition = '';
		$strField = 'level1';
		if (!empty($strLevel1)){
			$strCondition .= sprintf(" AND level1='%s' ", $strLevel1);
			$strField = 'level2';
		}
		if (!empty($strLevel2)){
			$strCondition .= sprintf(" AND level2='%s' ", $strLevel2);
			$strField = 'level3';
		}
		
		return array('condition'=>$strCondition, 'field'=>$strField);
	}
}