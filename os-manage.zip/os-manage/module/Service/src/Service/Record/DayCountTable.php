<?php
namespace Service\Record;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class DayCountTable extends AbstractTableGateway
{
	protected $table = 'tb_yl_action_count_day';
	
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new DayCount());
		
		$this->initialize();
	}
	
	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getDayCount($strCondition)
	{
		try{
			$select = $this->getSql()->select();
			$select->columns(array('total_user'=>new Expression('SUM(total_user)'), 'total_click'=>new Expression('SUM(total_click)'), 'date'), false);
			$select->where('1=1'.$strCondition);
			$select->group('date');
			$select->order('date');
			$rowset = $this->selectWith($select);
	
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('DayCountTable::getDayCount() exception,  err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
		return $rows;
	}	
	
}