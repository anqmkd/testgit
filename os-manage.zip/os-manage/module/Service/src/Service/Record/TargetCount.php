<?php
namespace Service\Record;

class TargetCount
{	
	public $strPath;
	public $strTarget;
	public $strDate;
	public $nCount;
	
	public function __construct()
	{
		$this->strPath		= '';
		$this->strTarget	= '';
		$this->strDate		= '';
		$this->nCount		= 0;
	}
	
	public function exchangeArray($row)
	{
		$this->strPath 		= isset($row['path'])?$row['path']:'';
		$this->strTarget	= isset($row['target'])?$row['target']:'';
		$this->strDate 		= isset($row['date'])?$row['date']:'';
		$this->nCount		= (int)isset($row['count'])?$row['count']:'';
	}

	public function getCondition($strLevel1, $strLevel2, $strLevel3, $tStartTime, $tEndTime){
		$strCondition = '';
		$strLike = '';
		if (!empty($strLevel1)){
			$strLike = $strLevel1;
		}
		if (!empty($strLevel2)){
			$strLike = $strLevel1.'-'.$strLevel2;
		}
		if (!empty($strLevel3)){
			$strLike = $strLevel1.'-'.$strLevel2.'-'.$strLevel3;
		}
		
		$strCondition = " AND path like CONCAT('%', '$strLike', '%') ";
		$strCondition .= sprintf(" AND date BETWEEN '%s' AND '%s'", $tStartTime, $tEndTime);
		
		return $strCondition;
	}
	
	public function getCommCondition($tStartTime, $tEndTime){	
		$strCondition = sprintf(" AND date BETWEEN '%s' AND '%s'", $tStartTime, $tEndTime);
	
		return $strCondition;
	}
}