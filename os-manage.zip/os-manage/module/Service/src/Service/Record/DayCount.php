<?php
namespace Service\Record;

class DayCount
{	
	public $strProduct;
	public $nTotalUser;
	public $nTotalClick;
	public $strDate;
	public $nCount;
	
	public function __construct()
	{
		$this->strProduct	= '';
		$this->nTotalUser	= 0;
		$this->nTotalClick	= 0;
		$this->strDate		= '';
		$this->nCount		= 0;
	}
	
	public function exchangeArray($row)
	{
		$this->strProduct 		= isset($row['product'])?$row['product']:'';
		$this->nTotalUser		= isset($row['total_user'])?$row['total_user']:'';
		$this->nTotalClick		= isset($row['total_click'])?$row['total_click']:'';
		$this->strDate 			= isset($row['date'])?$row['date']:'';
		$this->nCount			= (int)isset($row['count'])?$row['count']:'';
	}

	public function getCondition($tStartTime, $tEndTime){
		$strCondition = '';
		if (!empty($tStartTime) && !empty($tEndTime)){
			$strCondition .= sprintf(" AND date BETWEEN '%s' AND '%s'", $tStartTime, $tEndTime);
		}
		
		return $strCondition;
	}
}