<?php
namespace Service\Record;

class FileRecord
{	
	public $strActionId;
	public $strProduct;
	public $strSn;
	public $strUid;
	public $strImsi;
	public $strCyAccount;
	public $strPackage;
	public $strVersion;
	public $strSoftware;
	public $strAppVersion;
	public $strXmlVersion;
	public $strFilePath;
	public $strFileSzie;
	public $strFileMd5;
	public $insert_time;
	public $nCount;
	
	public function __construct()
	{
		$this->strActionId 	= '';
		$this->strProduct	= '';
		$this->strSn		= '';
		$this->strUid		= '';
		$this->strImsi		= '';
		$this->strCyAccount	= '';
		$this->strPackage	= '';
		$this->strVersion	= '';
		$this->strSoftware	= '';
		$this->strAppVersion= '';
		$this->strXmlVersion= '';
		$this->strFilePath	= '';
		$this->strFileSzie	= '';
		$this->strFileMd5	= '';
		$this->insert_time	= date("Y-m-d H:i:s");
		$this->nCount		= 0;
	}
	
	public function exchangeArray($row)
	{
		$this->strActionId    	= isset($row['action_id'])?$row['action_id']:'';
		$this->strProduct 		= isset($row['product'])?$row['product']:'';
		$this->strSn 			= isset($row['sn'])?$row['sn']:'';
		$this->strUid 			= isset($row['uid'])?$row['uid']:'';
		$this->strImsi 			= isset($row['imsi'])?$row['imsi']:'';
		$this->strCyAccount    	= isset($row['cyaccount'])?$row['cyaccount']:'';
		$this->strPackage 		= isset($row['package'])?$row['package']:'';
		$this->strVersion 		= isset($row['version'])?$row['version']:'';
		$this->strSoftware 		= isset($row['software'])?$row['software']:'';
		$this->strAppVersion 	= isset($row['app_version'])?$row['app_version']:'';
		$this->strXmlVersion    = isset($row['xml_version'])?$row['xml_version']:'';
		$this->strFilePath 		= isset($row['file_path'])?$row['file_path']:'';
		$this->strFileSzie 		= isset($row['file_size'])?$row['file_size']:'';
		$this->strFileMd5 		= isset($row['file_md5'])?$row['file_md5']:'';
		$this->insert_time		= isset($row['insert_time'])?$row['insert_time']:'';
		$this->nCount			= (int)isset($row['count'])?$row['count']:'';
	}

	public function getCondition($tStartTime, $tEndTime){
		$strCondition = '';
		if (!empty($tStartTime) && !empty($tEndTime)){
			$strCondition .= sprintf(" AND insert_time BETWEEN '%s' AND '%s'", $tStartTime, $tEndTime);
		}
		
		return $strCondition;
	}
}