<?php
namespace Service\Record;

class CollectRecord
{	
	public $strActionId;
	public $strAction;
	public $strTarget;
	public $strActionPath;
	public $strProvider;
	public $strActionTime;
	public $insert_time;
	public $nCount;
	
	public function __construct()
	{
		$this->strActionId    	= ''; 
		$this->strAction 		= '';
		$this->strTarget 		= '';
		$this->strActionPath 	= '';
		$this->strProvider		= '';
		$this->strActionTime	= '';
		$this->insert_time		= date("Y-m-d H:i:s");
		$this->nCount			= 0;
	}
	
	public function exchangeArray($row)
	{
		$this->strActionId    	= isset($row['action_id'])?$row['action_id']:'';
		$this->strAction 		= isset($row['action'])?$row['action']:'';
		$this->strTarget 		= isset($row['target'])?$row['target']:'';
		$this->strActionPath 	= isset($row['action_path'])?$row['action_path']:'';
		$this->strProvider		= isset($row['provider'])?$row['provider']:'';
		$this->strActionTime 	= isset($row['action_time'])?$row['action_time']:'';
		$this->insert_time		= isset($row['insert_time'])?$row['insert_time']:'';
		$this->nCount			= (int)isset($row['count'])?$row['count']:'';
	}

	public function getCondition($strLevel1, $strLevel2){
		$strCondition = '';
		$strLike = '';
		if (!empty($strLevel1)){
			$strLike = $strLevel1;
		}
		if (!empty($strLevel2)){
			$strLike = $strLevel1.'-'.$strLevel2;
		}
		
		$strCondition = " AND action_path like CONCAT('%', '$strLike', '%') ";
		
		return $strCondition;
	}
}