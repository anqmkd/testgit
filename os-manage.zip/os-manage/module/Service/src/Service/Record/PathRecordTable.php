<?php
namespace Service\Record;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql;
use Zend\Db\Sql\Select;
use Zend\Db\Sql\Expression;
use Service\Logs\Logs;

class PathRecordTable extends AbstractTableGateway
{
	protected $table = 'tb_yl_path_data';
	
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new PathRecord());
		
		$this->initialize();
	}
	
	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getPathDir()
	{
		try{
			$select = $this->getSql()->select();
			$rowset = $this->selectWith($select);
										
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('CollectRecordTable::getTargetCount() exception,  err:'
												.' file:'.$e->getFile()
												.' line:'.$e->getLine()
												.' message:'.$e->getMessage()
												.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
		return $rows;
	}
	
	public function getPathCount()
	{
		try{
			$select = $this->getSql()->select();
			$select->columns(array('count'=>new Expression('COUNT(1)'), 'action_path'), false);
			$select->group('action_path');
			$select->order('count DESC');
			$rowset = $this->selectWith($select);
	
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('CollectRecordTable::getTargetCount() exception,  err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
		return $rows;
	}
	
	public function getLevels($arrCondition)
	{
		try{
			$select = $this->getSql()->select();
			$select->where("1=1".$arrCondition['condition']);
			$select->group($arrCondition['field']);
			//$select->order('count DESC');
			$rowset = $this->selectWith($select);
	
			$rows = array();
			while($rowset->valid()){
				$row = $rowset->current();
				if(!$row){
					continue;
				}
				array_push($rows, $row);
				$rowset->next();
			}
		}catch(Exception $e){
			Logs::write('CollectRecordTable::getTargetCount() exception,  err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
		return $rows;
	}
}