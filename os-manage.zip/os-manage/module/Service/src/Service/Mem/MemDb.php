<?php
namespace Service\Mem;
use Service\Logs\Logs;

class MemDb{
	private $memcached;
	function __construct($arr_memcache){
		$this->memcached = new Memcached();	
		$this->connectMemcached($arr_memcache);
	}
	
	function setConnect($arr_memcache)
	{
		$this->memcached = new Memcached();
		$this->connectMemcached($arr_memcache);
	}
	
	function connectMemcached($servers){
		$result = $this->memcached->addServers($servers);
		if(!$result){
			Logs::write("MemDb::connectMemcached():addServers() failed", "log");
			return false;
		}
		return true;
	}
	
	function setSearchResult($sql, $ret, $expiration = 0, $flag = MEMCACHE_COMPRESSED){
		if(empty($sql)){
			return false;
		}
		$key = md5($sql);
		
		$result = $this->memcached->get($key);
		if(!$result){
			$result = $this->memcached->set($key, $ret, $flag, $expiration);
		}else{
			$result = $this->memcached->replace($key, $ret, $flag, $expiration);
		}
		if(!$result){
			Logs::write("Memecached::setSearchResult():set()/replace() key:".$key."  ret:".json_encode($ret)." failed", "log");
			return false;
		}
		return true;
	}
	
	function getSearchResult($sql){
		if(empty($sql)){
			return false;
		}
		$key = md5($sql);
		$result = $this->memcached->get($key);
		if(!$result){
// 			Logs::write("MemDb::getSearchResult():get() key:".$key." failed", "log");
			return false;
		}
		return $result;
	}
	
	public function clearMemcache(){
		$result = $this->memcached->flush();
		if(!$result){
			Logs::write("MemDb::clearMemcach() failed", "log");
			return false;
		}
		return true;
	}
}

function  unit_coolxiu_memcached_test(){
	$memcached = new MemDb();
	global $g_arr_memcache;
	$memcached->connectMemcached($g_arr_memcache['memcache']);
	$memcached->setSearchResult("AAAA", "BBBB");
	$result = $memcached->getSearchResult("AAAA");
	echo $result;
}

//unit_coolxiu_memcached_test();
?>
