<?php
namespace Service;
use Zend\Db\Adapter\Adapter;
use \Pdo;

use Service\IdCreater\IdCreaterTable;
use Service\Whlist\SecureLevelTable;
use Service\Whlist\WhiteListTable;
use Service\Whlist\WidgetListTable;
use Service\Policy\PolicyUserTable;
use Service\Policy\TFPolicyUserTable;
use Service\Whlist\ApkListTable;
use Service\Whlist\ParamsTable;
use Service\Policy\ClaimInfoTable;
use Service\Policy\APPMarketTable;
use Service\Syslog\SyslogTable;
use Service\ManagerFactory;
use Service\User\UserTable;

class Module
{
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }

    public function getServiceConfig()
    {

        return array(
            'factories' => array(
                'Service\Whlist\SecureLevelTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new SecureLevelTable($dbAdapter);
                    return $table;
                },
                'Service\Whlist\WhiteListTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new WhiteListTable($dbAdapter);
                    return $table;
                },
                'Service\Policy\PolicyUserTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new PolicyUserTable($dbAdapter);
                    return $table;
                },
                'Service\Policy\TFPolicyUserTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new TFPolicyUserTable($dbAdapter);
                    return $table;
                },
                'Service\Policy\ClaimInfoTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new ClaimInfoTable($dbAdapter);
                    return $table;
                },
                'Service\Whlist\ApkListTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new ApkListTable($dbAdapter);
                    return $table;
                },
                'Service\Policy\APPMarketTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new APPMarketTable($dbAdapter);
                    return $table;
                },
                'Service\Whlist\ParamsTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new ParamsTable($dbAdapter);
                    return $table;
                },
                'Service\Whlist\WidgetListTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new WidgetListTable($dbAdapter);
                    return $table;
                },
                'Service\Syslog\SyslogTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new SyslogTable($dbAdapter);
                    return $table;
                },
                'Service\IdCreater\IdCreaterTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new IdCreaterTable($dbAdapter);
                    return $table;
                },
                'Service\Role\RoleTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new RoleTable($dbAdapter);
                    return $table;
                },
                'Service\User\UserTable' =>  function($sm) {
                    $dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $table = new UserTable($dbAdapter);
                    return $table;
                },
                'Service\Conf\App' =>  function($sm) {
                    $table = new Conf\App();
                    return $table;
                },
                'Service\Conf\Api' => function($sm) {
                    $table = new Conf\Api();
                    return $table;
                },
                'Service\Machine\Machine' => function($sm) {
                    $table = new Machine\Machine();
                    return $table;
                },
                'Service\Package\Package' => function($sm) {
                    $table = new Package\Package();
                    return $table;
                },
                'Service\Log\Log' => function($sm) {
                    $table = new Log\Log();
                    return $table;
                },
            ),
        );
    }

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
}