<?php
/**
 * 基础服务配置
 */
return array(
	'browser' => array(
		'email' => array('instance' => array(
                'Zend\Mail\Transport\FileOptions' => array(
                    'parameters' => array(
                        'path' => __DIR__,
                    )
                ),
                'Zend\Mail\Transport\File' => array(
                    'injections' => array(
                        'Zend\Mail\Transport\FileOptions'
                    )
                ),
                'Zend\Mail\Transport\SmtpOptions' => array(
                    'parameters' => array(
                        'name'              => 'os-center',
                        'host'              => 'smtp.163.com',
                        'port' => 25,
                        'connectionClass'  => 'login',
                        'connectionConfig' => array(
                         //   'username' => 'oqskcen@163.com',
                         //   'password' => '0p9o8i7u6y!QAZ',
                            'username' => 'wangweilin51888@163.com',
                            'password' => '1q2w3e4r5t',
                        ),
                    )
                ),
                'Zend\Mail\Message' => array(
                    'parameters' => array(
                        'headers' => 'Zend\Mail\Headers',
                        'Zend\Mail\Message::setFrom:emailOrAddressList' => 'wangweilin51888@163.com',
                        'Zend\Mail\Message::setFrom:name' => 'os-center',
                    )
                ),
                'Zend\Mail\Transport\Smtp' => array(
                    'injections' => array(
                        'Zend\Mail\Transport\SmtpOptions'
                    )
                ),
			)
        ),
	),
	'service_manager' => array(
		'factories' => array(
			'AppManager' => 'Service\ManagerFactory',
		),
	),
);