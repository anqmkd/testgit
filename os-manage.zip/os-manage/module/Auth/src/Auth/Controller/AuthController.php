<?php
namespace Auth\Controller;

use Service\Error\Error;
use Error\Model\ErrorInfo;
use Service\Syslog\Syslog;

use Service\Logs\Logs;

use Service\User\User;
use Service\User\UserTable;
use Service\Syslog\SyslogTable;

use Service\Auth\Auth;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Mvc\Controller\Plugin\Params;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;


class AuthController extends AbstractActionController
{
    public $dbAdapter;
    public $syslog;
    public $userTable;

    public function indexAction()
    {
        $user = '';
        $view =  new ViewModel(array('user'=>$user));
        return $view;
    }

    public function homeAction(){
        $auth = new Auth();
        $strUserName = $auth->isLogin();
        if(empty($strUserName)){
            return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                'action' => 'login'));
        }

        $user = $auth->authRead();
        $view = new ViewModel(array(
            'user'=>$user
        ));
        return $view;
    }

    public function logoutAction()
    {
        $auth = new Auth();
        $user = $auth->authRead();
        $syslog = new Syslog();
        $syslog->setParam(Syslog::SYSLOG_LOGIN, $user->name, '用户注销', $user->name.'用户注销，时间：'.date("Y-m-d H:i:s"));
        $auth->logout();
        //用户注销日志
        $this->_getSyslog()->saveSyslog($syslog);

        $update = [
            'last_login_ip' => $syslog->getip(),
            'update_time' => date("Y-m-d H:i:s"),
        ];
        $this->getUserTable()->update($update, ['name' => $user->name]);
        return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                'action' => 'login'));
    }

    public function loginAction()
    {
        try{
            $auth = new Auth();

            $arrRemember = $auth->authRemember('auth', 'home');
            $request = $this->getRequest();
            if (!$request->isPost()) {
                $id = $this->params('id');
                if(empty($id)){
                    $msg = "请先登录！";
                }else{
                    $msg = ErrorInfo::getError($id);
                }

                $strUserName = $auth->isLogin();
                if(empty($strUserName)){
                    $view = new ViewModel(array('msg'=>$msg));
                    return $view;
                }
                return $this->redirect()->toRoute($arrRemember['controller'], $arrRemember);
            }

            $strName     = $request->getPost()->get('username');
            $strPassword = $request->getPost()->get('password');

            if(empty($strName) || empty($strPassword)){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }

            $strPassword = \Service\User\User::encryptPassword($strPassword);
            $dbAdapter = $this->getAdapter();
            $bResult = $auth->loginAuth($dbAdapter,
                                $strName,
                                $strPassword,
                                'tb_qiku_admin_user',
                                'name',
                                'password');
            if($bResult !== true){
                //用户登录失败
                $syslog = new Syslog();
                $ip = $syslog->getip();
                $syslog->setParam(Syslog::SYSLOG_LOGIN, $strName, '用户登录失败', '用户名或密码不正确，用户：'.$strName.',IP:'.$ip);
                $this->_getSyslog()->saveSyslog($syslog);
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                                                'action' => 'login',
                                                'id' => Error::YL_ERROR_LOGIN_CHECK_FAILED));
            }

            $user = new User();
            $user = $this->getUserTable()->getUser($strName);

            $auth->authStore(array('name' => $strName,
                            'password' => $strPassword,
                            'role' => $user->strRole,
                            'nrole' => $user->nRole,
                            'email' => $user->strEmail,
                            'last_login_ip'=>$user->strLastLoginIp
                ));
        }catch (\Exception $e){
            Logs::write('AuthController::longinAction() Exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
        }
        //用户登录成功
        $syslog = new Syslog();
        $ip = $syslog->getip();
        $syslog->setParam(Syslog::SYSLOG_LOGIN, $strName, '用户登录成功', '用户：'.$strName.'登录成功,IP:'.$ip);
        $this->_getSyslog()->saveSyslog($syslog);
        return $this->redirect()->toRoute($arrRemember['controller'], $arrRemember);
    }

    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Auth\Model\UserTable');
        }
        return $this->userTable;
    }

    private function _getSyslog()
    {
        if (!$this->syslog) {
            $sm = $this->getServiceLocator();
            $this->syslog = $sm->get('Service\Syslog\SyslogTable');
        }
        return $this->syslog;
    }

    public function getAdapter()
    {
        if (!$this->dbAdapter) {
            $sm = $this->getServiceLocator();
            $this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
        }
        return $this->dbAdapter;
    }
}
