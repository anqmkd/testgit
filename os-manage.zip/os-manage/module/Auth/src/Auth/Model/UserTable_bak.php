<?php
namespace Auth\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

use Service\Logs\logs;

use Auth\Model\User;

class UserTable extends AbstractTableGateway
{
	protected $table = 'tb_yl_user';
	
	public function __construct(Adapter $adapter)
	{
		$this->adapter = $adapter;
		$this->resultSetPrototype = new ResultSet();
		$this->resultSetPrototype->setArrayObjectPrototype(new User());
	
		$this->initialize();
	}
	
	public function fetchAll()
	{
		$resultSet = $this->select();
		return $resultSet;
	}
	
	public function getUser($strName)
	{
		$rowset = $this->select(array('name' => $strName));
		$row = $rowset->current();
		if (!$row) {
			Logs::write('UserTable:GetUser() failed', 'log');
		}
		return $row;
	}

	public function updateUser(User $user)
	{
		try{
			$data = array(
					'name' 	=> $user->strName,
					'password'  => $user->strPassword,
					'role'  => $user->nRole,
					'email' => $user->strEmail,
					'update_time' => date("Y-m-d H:i:s"),
			);
	
			if(!$this->update($data, array('name' => $app->name))){
				Logs::write('UserTable::updateUser():update() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('UserTable::updateUser() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}	
	
	public function saveUser(User $user)
	{
		try{
			$data = array(
					'name' 	=> $user->strName,
					'password'  => $user->strPassword,
					'role'  => $user->nRole,
					'email' => $user->strEmail,
					'insert_time' => date("Y-m-d H:i:s"),
			);

			$this->insert($data);
			if(!$result){
				Logs::write('UserTable::saveUser():insert() failed', 'log');
				return false;
			}
		}catch(Exception $e){
			Logs::write('UserTable::saveUser() exception, err:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
	
	public function deleteUser($strName)
	{
		$this->delete(array('name' => $strName));
	}
}