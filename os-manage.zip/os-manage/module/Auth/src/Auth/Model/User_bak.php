<?php
namespace Auth\Model;

use Service\Logs\logs;
use Apps\Model\MailNotify;

class User
{
	const YL_AUTO_UPDATE_ROLE_TEST = 1;			//测试人员，申请提交人员
	const YL_AUTO_UPDATE_ROLE_TEST_PRINC = 1;	//测试负责人，1审批提交正式服务器人员
	const YL_AUTO_UPDATE_ROLE_DEV  = 2;			//开发人员，2审批提交正式服务器人员
	const YL_AUTO_UPDATE_ROLE_DEV_PRINC = 3;	//开发负责人，同步测试服务器，3审批同步正式服务器人员
	const YL_AUTO_UPDATE_ROLE_QUALITY_PRINC = 4;//质量负责人
	const YL_AUTO_UPDATE_ROLE_ALL = 5;			//所有然员
	
	const YL_AUTO_UPDATE_ROLE_SUPER_ADMIN = 9;	//超级管理人员
	
	public $strName;
	public $strPassword;
	public $nRole;
	public $strRole;
	public $strEmail;
	
	public function __construct()
	{
		$this->strName 		= '';
		$this->strPassword 	= '';
		$this->nRole		= 0;
		$this->strRole		= '';
		$this->strEmail 	= '';
	}
	
	public function exchangeArray($data)
	{
		$this->strName     = (isset($data['name'])) ? $data['name'] : null;
		$this->strPassword = (isset($data['password'])) ? $data['password'] : null;
		$this->nRole  	   = (isset($data['role'])) ? $data['role'] : 0;
		$this->strEmail    = (isset($data['email'])) ? $data['email'] : '';
		$this->_setRole();
	}
	

	static public function getNextRole($nType, $nRole)
	{
		switch($nRole){
			case self::YL_AUTO_UPDATE_ROLE_TEST:{
				if($nType == MailNotify::YL_MAIL_NOTIFY_TEST){
					$nNextRole = self::YL_AUTO_UPDATE_ROLE_DEV_PRINC;	
				}
				if($nType == MailNotify::YL_MAIL_NOTIFY_TEST_SUCCESS){
					$nNextRole = self::YL_AUTO_UPDATE_ROLE_TEST_PRINC;
				}	
			}break;
			case self::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
				$nNextRole = self::YL_AUTO_UPDATE_ROLE_DEV;
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV:
				$nNextRole = self::YL_AUTO_UPDATE_ROLE_DEV_PRINC;
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV_PRINC:{
				if($nType == MailNotify::YL_MAIL_NOTIFY_SYNCH){
					$nNextRole = self::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC;
				}
				if($nType == MailNotify::YL_MAIL_NOTIFY_TEST){
					$nNextRole = self::YL_AUTO_UPDATE_ROLE_TEST;
				}	
			}break;
			case self::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC:
				$nNextRole = self::YL_AUTO_UPDATE_ROLE_ALL;
				break;
			default:
				$nNextRole = self::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN;
				break;
		}
		return $nNextType;
	}
	
	static function getRoleFiled($nRole)
	{
		$strFiled = '';
		switch ($nRole){
			case self::YL_AUTO_UPDATE_ROLE_TEST:
				$strFiled = 'test';
				break;
			case self::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
				$strFiled = 'test_principal';
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV:
				$strFiled = 'dev';
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV_PRINC:
				$strFiled = 'dev_principal';
				break;
			case self::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC:
				$strFiled = 'quality_principal';
				break;
			default:
				$strFiled = '';
				break;
		}	
		return $strFiled;
	}
	
	private function _setRole()
	{
		switch ($this->nRole){
			case self::YL_AUTO_UPDATE_ROLE_TEST:
				$this->strRole = 'test';
				break;
			case self::YL_AUTO_UPDATE_ROLE_TEST_PRINC:
				$this->strRole = 'test_princ';
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV:
				$this->strRole = 'dev';
				break;
			case self::YL_AUTO_UPDATE_ROLE_DEV_PRINC:
				$this->strRole = 'dev_princ';
				break;
			case self::YL_AUTO_UPDATE_ROLE_QUALITY_PRINC:
				$this->strRole = 'quality_princ';
				break;
			case self::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN:
				$this->strRole = 'superadmin';
				break;
			default:
				$this->strRole = 'any';
				break;
		}
	}
	
	public function setUser($strName, $strPassword, $nRole, $strEmail)
	{
		$this->strName 		= $strName;
		$this->strPassword 	= $strPassword;
		$this->nRole  	   	= $nRole;
		$this->strEmail   	= $strEmail;
	}
	
	public function getArrayCopy()
	{
		return get_object_vars($this);
	}
	
}