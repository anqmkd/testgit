<?php
namespace Error\Model;
use Service\Error\Error;

class ErrorInfo
{
    public function __construct()
    {

    }

    static function getError($type)
    {
        $msg = '未知错误';
        switch ($type) {
            case Error::YL_ERROR_EXCEPOTION:
                $msg = '抛出异常';
                break;
            case Error::YL_ERROR_NO_POWER:
                $msg = '没有权限';
                break;
            case Error::YL_ERROR_TASK_SAVE:
                $msg = '业务信息存储错误';
                break;
            case Error::YL_ERROR_TASK_INFO_ERROR:
                $msg = '业务信息错误';
                break;
            case Error::YL_ERROR_SETTING_EXIST_FAILED:
                $msg = '配置信息已存在';
                break;
            case Error::YL_ERROR_SETTING_POST_FAILED:
                $msg = '配置信息传输错误';
                break;
            case Error::YL_ERROR_SETTING_CHECK_FAILED:
                $msg = '配置信息检查错误';
                break;
            case Error::YL_ERROR_MOBILE_EXIST_FAILED:
                $msg = '终端信息已存在';
                break;
            case Error::YL_ERROR_MOBILE_POST_FAILED:
                $msg = '终端信息传输错误';
                break;
            case Error::YL_ERROR_MOBILE_CHECK_FAILED:
                $msg = '终端信息检查错误';
                break;
            case Error::YL_ERROR_MOBILE_DELETE_FAILED:
                $msg = '终端信息删除错误';
                break;
            case Error::YL_ERROR_MOBILE_COUNT_FAILED:
                $msg = '获取终端数量错误';
                break;
            case Error::YL_ERROR_APP_EXIST_FAILED:
                $msg = '应用信息已存在';
                break;
            case Error::YL_ERROR_APP_POST_FAILED:
                $msg = '应用信息传输错误';
                break;
            case Error::YL_ERROR_APP_CHECK_FAILED:
                $msg = '应用信息检查错误';
                break;
            case Error::YL_ERROR_APP_DELETE_FAILED:
                $msg = '应用信息删除错误';
                break;
            case Error::YL_ERROR_PRODUCT_EXIST_FAILED:
                $msg = '产品信息已存在';
                break;
            case Error::YL_ERROR_PRODUCT_POST_FAILED:
                $msg = '产品信息传输错误';
                break;
            case Error::YL_ERROR_PRODUCT_CHECK_FAILED:
                $msg = '产品信息检查错误';
                break;
            case Error::YL_ERROR_PRODUCT_DELETE_FAILED:
                $msg = '产品信息删除错误';
                break;
            case Error::YL_ERROR_REDIS_COUNT_FAILED;
                $msg = '获取在线终端数量异常';
                break;
            case Error::YL_ERROR_MOBILE_SET_POST_FAILED:
                $msg = '终端配置信息传输错误';
                break;
            case Error::YL_ERROR_MOBILE_SET_CHANGE_FAILED:
                $msg = '终端配置信息修改错误';
                break;
            case Error::YL_ERROR_MOBILE_SET_SAVE_FAILED:
                $msg = '终端配置信息保存错误';
                break;
            case Error::YL_ERROR_PRODUCT_SET_POST_FAILED:
                $msg = '产品配置信息传输错误';
                break;
            case Error::YL_ERROR_PRODUCT_SET_CHANGE_FAILED:
                $msg = '产品配置信息修改错误';
                break;
            case Error::YL_ERROR_PRODUCT_SET_SAVE_FAILED:
                $msg = '产品配置信息保存错误';
                break;
            case Error::YL_ERROR_PARAM:
                $msg = '检查参数置空错误';
                break;
            case Error::YL_ERROR_LOGIN_CHECK_FAILED:
                $msg = '登录校验失败!';
                break;
            default:
                $maps = [
                    Error::YL_ERROR_USER_CHECK_FAILED => '用户信息检测失败',
                    Error::YL_ERROR_USER_GET_FAILED => '用户信息获取失败',
                    Error::YL_ERROR_USER_CHANGE_FAILED => '用户信息修改失败'
                ];

                $msg = isset($maps[$type]) ? $maps[$type] : '未知错误';
                break;
        }

        return $msg;
    }
}