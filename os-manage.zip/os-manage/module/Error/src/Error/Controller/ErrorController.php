<?php
namespace Error\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;

use Error\Model\ErrorInfo;

class ErrorController extends AbstractActionController
{
    public function indexAction()
    {
        $id = $this->params('id');
        $msg = ErrorInfo::getError($id);

        $view =  new ViewModel(array('msg'=>$msg));
        return $view;
    }

    public function successAction()
    {
        $msg = $this->params('msg');

        $view =  new ViewModel(['msg' => $msg]);
        return $view;
    }
}
