<?php
namespace User\Controller;

use Exception;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Mvc\Controller\Plugin\Params;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;

use Service\AclRole\AclRole;
use Service\Auth\Auth;
use Service\Logs\Logs;
use Service\Error\Error;
use Service\User\User;

class UserController extends \Application\Controller\BaseController
{
    private $userTable;

    public function getRoles()
    {
        $rolesMap = [
            User::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN => '超级管理员',
            User::YL_AUTO_UPDATE_ROLE_OPERATOR => '运营',
            User::YL_AUTO_UPDATE_ROLE_TEST => '测试',
            User::YL_AUTO_UPDATE_ROLE_TEST_PRINC => '测试负责人',
            User::YL_AUTO_UPDATE_ROLE_DEV => '开发',
            User::YL_AUTO_UPDATE_ROLE_DEV_PRINC => '开发负责人',
            User::YL_AUTO_UPDATE_ROLE_STAFF => '员工'
        ];

        return $rolesMap;
    }

    public function indexAction()
    {
        $user = $this->getUserTable()->getUser($this->authUser->name);

        if (!$user) {
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_USER_GET_FAILED,
            ));
        }

        $view =  new ViewModel(array(
                'user' => (array)$user,
                'rolesMap' => $this->getRoles(),
            )
        );
        return $view;
    }

    public function setAction()
    {
        $requet = $this->getRequest();
        if ($requet->isPost()) {
            $post = $requet->getPost();

            $id        = $post->get('id');
            $email = $post->get('email');
            $password = $post->get('password');
            $newPassword = $post->get('new-password');
            $rePassword = $post->get('re-password');

            $user = [
                'email' => $email,
            ];

            if ($newPassword) {
                $bResult = $this->_checkPasswd($id, $password, $newPassword, $rePassword);

                if ($bResult !== true) {
                    return $bResult;
                }

                $user['password'] = User::encryptPassword($newPassword);
            }


            $bResult = $this->getUserTable()->update($user, ['id' => $id]);
            if (!$bResult) {
                return $this->errorParam(Error::YL_ERROR_PARAM, '用户信息修改失败，请重试');
            }
        }

        return $this->success(
            '修改用户信息成功',
            '/user'
        );
    }

    private function _checkPasswd($id, $strOldPsw, $strNewPsw, $strVerifyPsw)
    {
        if (strlen($strNewPsw) < 5) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '新密码长度必须大于4');
        }

        if (strcmp($strNewPsw, $strVerifyPsw) != 0) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '新密码和确认密码输入不一致');
        }

        $bResult = $this->getUserTable()->checkPasswd($id, User::encryptPassword($strOldPsw));
        if (!$bResult) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '旧密码校验失败');
        }

        return true;
    }

    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Service\User\UserTable');
        }
        return $this->userTable;
    }
}
