<?php
namespace Ota\Controller;

use Service\Ota\OtaList;
use Service\Tools\Funcs;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\Mvc\Controller\Plugin\Params;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;

use Zend\Mail\Transport;

class OtaController extends AbstractActionController
{
    private $_funcs;
	public  $dbAdapter;
	private $authUser;

	public function indexAction()
	{
		exit();
	}
	
	public function listAction()
	{
		try{
			$auth = new Auth();
			$result = $auth->roleAuth('Ota.ota.index', 'index');
			if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
				return $this->redirect()->toRoute('auth', array('controller'=>'auth',
						'action' => 'login'));
			}
			if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
				return $this->redirect()->toRoute('error', array('controller'=>'error',
						'action' => 'index',
						'id'	=> Error::YL_ERROR_NO_POWER,
				));
			}
			$this->authUser = $result;
			
			$request 	    = $this->getRequest();
            if($request->isPost()){
                $strServerAddr  = $request->getPost()->get('server_addr');
                $strOrderBy 	= $request->getPost()->get('order_by');
                $nPage	        = $request->getPost()->get('page');
                $nPageLimit	    = $request->getPost()->get('limit');
                $strServerAddr  = isset($strServerAddr)?$strServerAddr:"2";
                $strOrderBy = isset($strOrderBy)?$strOrderBy:"desc";
                $nPage      = isset($nPage)?$nPage:1;
                $nPageLimit = isset($nPageLimit)?$nPageLimit:20;
                $offset = ($nPage - 1) * $nPageLimit;

                if($strServerAddr == '1'){
                    $strUrl = OtaList::URL_OTA_DATA;
                }elseif($strServerAddr == '2'){
                    $strUrl = OtaList::URL_OTA_DATA_TEST;
                }

                $strParam = "orderBy=".$strOrderBy."&offset=".$offset."&limit=".$nPageLimit;
                $curlResult = $this->getFuncs()->curl_data($strUrl, $strParam);
                if($curlResult === false){
                    return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_EXCEPOTION,
                    ));
                }

                echo $curlResult;
                exit();
            }else{
                $view =  new ViewModel(array(
                    'lists' 		=> array(),
                    'server_addr'   => 2,
                    'menu'			=> 'ota',
                    'left'			=> 'list'));

                return $view;
            }
		}catch(\Exception $e){
			Logs::write('OtaController::listAction() exception, err:'
					.' message:'.$e->getMessage(), 'log');
		}
	}

    public function getFuncs()
    {
        if (!$this->_funcs) {
            $this->_funcs = new Funcs($this->getServiceLocator());
        }
        return $this->_funcs;
    }
	
	public function getAdapter()
	{
		if (!$this->dbAdapter) {
			$sm = $this->getServiceLocator();
			$this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
		}
		return $this->dbAdapter;
	}
	
}
