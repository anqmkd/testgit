<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Ota\Controller\Ota' => 'Ota\Controller\OtaController',
        ),
    ),
    
    'router' => array(
        'routes' => array(
            'ota' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/ota[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Ota\Controller\ota',
                        'action'     => 'list',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Ota' => __DIR__ . '/../view/',
        ),
    ),
);