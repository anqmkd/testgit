<?php

// 判断是否生产
// 约定一个特殊的key application_idc 在php.ini
// corp: 开发
// infra_test: 测试/回归机
// server: 生产机
$idc = get_cfg_var('application_idc');
$GLOBALS['idc'] = $idc ? $idc : 'corp';

class AppConf
{
    // 兜底的配置，推荐所有配置都有
    // 如果value是数组，则分机房配置
    // 例如：
    // 'mapso/tile/traffic' => arary('corp' => '10.138.240.240:10000', 'bjdt' => 'xxx')
    static $defaultCfgs = [
    ];

    // 强制指定的配置
    // 该项在配置开发环境等比较适用
    // value为非数组，则全环境指定
    // value为数组，必须以idc为index，全机房为 ['all' => value]
    // 例如:
    // 'mapso/map/version' => 11
    // 'mapso/map/version' => ['corp' => 12, 'bjdt' => 13]
    // 'mapso/map/version' => ['all' => [1,2]]
    // 不支持 'mapso/map/version' => [1,2]
    static $specCfgs = [
        '/dba/mdb/os_manage_mongo' => [
            'all' => [
                'servers' => '10.0.70.8:7013,10.0.70.9:7013',
                'username' => 'mongo',
                'password' => '4e67b53975a919ba',
                'replicaSet' => '7013'
            ]
        ],
        # mysql conf
        '/dba/mdb/os_manage_mysql' => [
            'all' => [
                'driver' => 'Pdo',
                'dsn'            => 'mysql:dbname=db_qiku_secure_pay;host=10.120.253.211;port=3514',
                'username'       => 'qiku',
                'password'       => 'Il1_8Nl9s__',
                'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                ),
            ]
        ],
        '/dba/mdb/os_api_redis' => [
            'all' => [
                "host"    => "10.0.70.6",
                "port"    => "6001",
                "password" => "76be998c347cb674",
                "expire" => 7200,
            ]
        ]
    ];

    /**
     * 获得qconf配置项
     * @params {String} $key qconf配置的key
     * @params {String} $specIdc 强制指定的idc，默认为空 @default ''
     * @params {Mix} $default 如值为空，则返回default值 @default null
     */
    public static function getCfg($key, $specIdc = '', $default = null)
    {
        global $idc;

        $defaultCfgs = self::$defaultCfgs;

        if (empty($specIdc)) {
            $specIdc = $idc;
        }

        $spec = self::getSpec($key, $specIdc);
        if (!is_null($spec)) {
            return $spec;
        }

        $value = null;
        $value = Qconf::getConf($key, $specIdc);

        if (is_null($value)) {
            $value = Qconf::getConf($key, 'bjdt');
        }

        if (is_null($value)) {
            if (!is_null($default)) {
                $value = $default;
            } elseif (isset($defaultCfgs[$key])) {
                $v = $defaultCfgs[$key];

                if (is_array($v) && isset($v[$specIdc])) {
                    $value = $v[$specIdc];
                } else {
                    $value = $v;
                }
            }
        }

        return $value;
    }

    /**
     * 获得服务配置
     * 服务和配置的概念不同，配置一般是值，服务是一组资源，一般为ip/vip
     * @params {String} $key qconf配置的key
     * @params {String} $specIdc 强制指定的idc，默认为空 @default ''
     * @params {Mix} $default 如值为空，则返回default值 @default null
     */
    public static function getHosts($key, $specIdc = '', $default = null)
    {
        global $idc;

        $defaultCfgs = self::$defaultCfgs;
        if (empty($specIdc)) {
            $specIdc = $idc;
        }

        $spec = self::getSpec($key, $specIdc);
        if (!is_null($spec)) {
            return $spec;
        }

        $hosts = [];
        $hosts = Qconf::getAllHost($key, $specIdc);

        if (is_null($hosts)) {
            $hosts = Qconf::getAllHost($key, 'bjdt');
        }

        if (is_null($hosts)) {
            if (!is_null($default)) {
                $hosts = $default;
            } elseif (isset($defaultCfgs[$key])) {
                $v = $defaultCfgs[$key];

                if (is_array($v) && isset($v[$specIdc])) {
                    $hosts = $v[$specIdc];
                } else {
                    $hosts = $v;
                }
            }
        }

        return $hosts;
    }

    /**
     * 获得指定配置
     * 如果没有指定配置，则返回null
     */
    public static function getSpec($key, $specIdc = '')
    {
        global $idc;

        $specCfgs = self::$specCfgs;
        if (empty($specIdc)) {
            $specIdc = $idc;
        }

        if (isset($specCfgs[$key])) {
            if (is_array($specCfgs[$key])) {
                if (!isset($specCfgs[$key][$specIdc])) {
                    $specIdc = 'all';
                }

                return isset($specCfgs[$key][$specIdc]) ? $specCfgs[$key][$specIdc] : null;
            } else {
                return $specCfgs[$key];
            }
        }

        return null;
    }
}

// 如果存在本地配置，则追加local.config.php
// 该文件不进入版本管理
$devConfigFile = __DIR__ . '/local.config.php';

if (file_exists($devConfigFile)) {
    $devSpec = include($devConfigFile);
    AppConf::$specCfgs = array_merge(AppConf::$specCfgs, $devSpec);
}

return array(
    'idc' => $idc,
    'router' => array(
        'routes' => array(
            'home' => array(
                'type' => 'Zend\Mvc\Router\Http\Literal',
                'options' => array(
                    'route'    => '/',
                    'defaults' => array(
                        'controller' => 'Auth\Controller\Auth',
                        'action'     => 'login',
                    ),
                ),
            ),
            // The following is a route to simplify getting started creating
            // new controllers and actions without needing to create a new
            // module. Simply drop new controllers in, and you can access them
            // using the path /application/:controller/:action
            'application' => array(
                'type'    => 'Literal',
                'options' => array(
                    'route'    => '/application',
                    'defaults' => array(
                        '__NAMESPACE__' => 'Application\Controller',
                        'controller'    => 'Index',
                        'action'        => 'index',
                    ),
                ),
                'may_terminate' => true,
                'child_routes' => array(
                    'default' => array(
                        'type'    => 'Segment',
                        'options' => array(
                            'route'    => '/[:controller[/:action][/:id]]',
                            'constraints' => array(
                                'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
                                'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
                            ),
                            'defaults' => array(
                            ),
                        ),
                    ),
                ),
            ),
        ),
    ),
    'service_manager' => array(
        'factories' => array(
            'translator' => 'Zend\I18n\Translator\TranslatorServiceFactory',
        ),
    ),
    'translator' => array(
        'locale' => 'en_US',
        'translation_patterns' => array(
            array(
                'type'     => 'gettext',
                'base_dir' => __DIR__ . '/../language',
                'pattern'  => '%s.mo',
            ),
        ),
    ),
    'controllers' => array(
        'invokables' => array(
            'Application\Controller\Index' => 'Application\Controller\IndexController'
        ),
    ),
    'view_manager' => array(
        'display_not_found_reason' => true,
        'display_exceptions'       => true,
        'doctype'                  => 'HTML5',
        'not_found_template'       => 'error/404',
        'exception_template'       => 'error/index',
        'template_map' => array(
            'layout/layout'           => __DIR__ . '/../view/layout/layout.phtml',
            'application/index/index' => __DIR__ . '/../view/application/index/index.phtml',
            'error/404'               => __DIR__ . '/../view/error/404.phtml',
            'error/index'             => __DIR__ . '/../view/error/index.phtml',
        ),
        'template_path_stack' => array(
            __DIR__ . '/../view',
        ),
    ),
);
