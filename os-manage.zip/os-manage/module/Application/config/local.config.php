<?php
return array(
'/dba/mdb/os_manage_mysql' => [
            'all' => [
                'driver' => 'Pdo',
                'dsn'            => 'mysql:dbname=db_qiku_secure_pay;host=localhost;port=3306',
                'username'       => 'root',
                'password'       => '',
                'driver_options' => array(
                    PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                ),
            ]
        ],
);
?>