<?php

namespace Application\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Data\Verify as D;
use Data\Type as DT;
use Service\Tools\Debug;

use Zend\Mvc\MvcEvent;
use Service\Auth\Auth;
use Service\Error\Error;

class BaseController extends AbstractActionController
{

    protected $authUser;
    protected $auth;

    /**
     * 回调函数
     * @var string
     */
    protected $cb = 'cb';

    public function __construct()
    {
        $events = $this->getEventManager();
        $events->attach(MvcEvent::EVENT_DISPATCH, [$this, 'init'], 200);
        //$events->attach(MvcEvent::EVENT_DISPATCH_ERROR, [$this, 'xxx'], 500);
    }

    /**
     * 进行权限验证
     * 统一的模块验证，如果某个action单独权限，需要自行处理
     */
    public function init()
    {
        $event = $this->getEvent();
        $controller = ucfirst($event->getRouteMatch()->getMatchedRouteName());

        $this->auth = new Auth();

        if (!$this->auth->isLogin()) {
            return $this->redirect()->toRoute('auth', [
                    'controller' => 'auth',
                    'action' => 'login'
                ]
            );
        }

        $this->roleAuth($controller, '');

        $view = $event->getViewModel();
        $view->setVariable('auth', $this->auth);
    }

    public function roleAuth($resource, $privileges = null, $id = null)
    {
        try {
            $result = $this->auth->roleAuth($resource, $privileges, $id);
        } catch (\Exception $e) {
            $result = Auth::YL_AUTH_NO_POWER;
        }

        if (!is_object($result) && $result == Auth::YL_AUTH_NO_POWER) {
            $request = $this->getRequest();

            if ($request->isXmlHttpRequest()) {
                $this->jsonOutput(['status' => 0, 'error' => '没有权限']);
            } else {
                return $this->redirect()->toRoute('error', [
                        'controller' => 'error',
                        'action' => 'index',
                        'id' => Error::YL_ERROR_NO_POWER,
                    ]
                );
            }
        }

        $this->authUser = $result;
    }

    /**
     * 格式化的输出
     */
    public function jsonOutput($result, $cb = '', $encode = true)
    {
        $request = $this->getRequest();
        if (empty($cb)) {
            $cb = D::vv($request->getQuery($this->cb), 'jsonp');
        }

        Debug::result($result);

        if ($encode) {
            $result = json_encode($result);
        }

        // _dbg输出
        if (D::vv($request->getQuery('_dbg'), \Data\Type::INT)) {
            Debug::time('end');
            Debug::export($request->getQuery('_dbg'));
            die();
        }

        if ($cb) {
            if ($result === 'NULL') {
                $result = 'null';
            }

            header('Content-Type: application/x-javascript');
            echo ' ' . $cb . '(' . $result . ')';
        } else {
            header('Content-Type: application/json; charset=utf-8');
            echo $result;
        }

        exit(0);
    }

    /**
     * 参数错误后的跳转
     */
    public function errorParam($errorId = Error::YL_ERROR_PARAM, $error = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 0, 'errcode' => $errorId, 'error' => $error];

            header('Content-Type: application/json');
            echo json_encode($result);
            exit();
        } else {
            $view = new ViewModel([
                    'msg' => $error,
                    'link' => $link
                ]
            );

            $view->setTemplate('error/error.phtml');
            return $view;
        }
    }

    /**
     * 参数错误后的跳转
     */
    public function success($msg = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 1, 'success' => $msg];

            $this->jsonOutput($result);
        } else {
            $view = new ViewModel([
                    'msg' => $msg,
                    'link' => $link
                ]
            );
            $view->setTemplate('error/success.phtml');
            return $view;
        }
    }
}
