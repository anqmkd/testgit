<?php
namespace Admin\Controller;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Service\ManagerFactory;

use Data\Verify as D;
use Data\Type as DT;

class IndexController extends \Application\Controller\BaseController
{
    private $userTable;

    public function indexAction()
    {
        $userTable = $this->getUserTable();
        $userCount = $userTable->fetchAll()->count();

        return new ViewModel([
                'userCount' => $userCount
            ]
        );
    }


    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Service\User\UserTable');
        }

        return $this->userTable;
    }
}
