<?php
namespace Admin\Controller;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Service\ManagerFactory;
use Service\User\User;

use Data\Verify as D;
use Data\Type as DT;

use Zend\Mail\Message;
use Zend\Mail\Transport;
use Zend\Di\Di;
use Zend\Di\Config as DiConfig;

class UserController extends \Application\Controller\BaseController
{
    private $userTable;

    public function getRoles()
    {
        $rolesMap = [
            User::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN => '超级管理员',
            User::YL_AUTO_UPDATE_ROLE_OPERATOR => '运营',
            User::YL_AUTO_UPDATE_ROLE_TEST => '测试',
            User::YL_AUTO_UPDATE_ROLE_TEST_PRINC => '测试负责人',
            User::YL_AUTO_UPDATE_ROLE_DEV => '开发',
            User::YL_AUTO_UPDATE_ROLE_DEV_PRINC => '开发负责人',
            User::YL_AUTO_UPDATE_ROLE_STAFF => '员工'
        ];

        return $rolesMap;
    }

    public function indexAction()
    {
        $id = $this->params()->fromRoute('id', '');

        if (empty($id)) {
            return $this->listAction();
        }

        $user = $this->getUserTable()->getUserById($id);

        $view =  new ViewModel([
                'user' => (array)$user,
                'rolesMap' => $this->getRoles()
            ]
        );

        $view->setTemplate('admin/user/new.phtml');
        return $view;
    }

    // 控制器
    public function listAction()
    {
        $request = $this->getRequest();
        $q = $request->getQuery('name');

        if ($q) {
            $list = $this->getUserTable()->select("name like '$q%'");
        } else {
            $list = $this->getUserTable()->fetchAll();
        }

        $view =  new ViewModel([
                'name' => $q,
                'lists' => $list,
                'rolesMap' => $this->getRoles()
            ]
        );

        return $view;
    }

    public function newAction()
    {
        $view =  new ViewModel([
                'user' => [],
                'rolesMap' => $this->getRoles()
            ]
        );

        return $view;
    }

    public function addAction()
    {
        $post = $this->getRequest()->getPost();
        $table = $this->getUserTable();

        $name = $post->get('name');
        $email = $post->get('email');
        $role = $post->get('role');
        $model = (int)($post->get('pwdmodel'));
        if($model == 1){
            $password = trim($post->get('password'));
            $rePassword = $post->get('re-password');
        }elseif($model == 2){
            $password = $rePassword = $this->_generatePassword();
        }else{
            $password = $rePassword = "";
        }

        if (empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '用户名不能为空');
        }
        if (empty($role)) {
            $role = 0;
        }
        if (strlen($password) < 5) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '密码长度必须大于4');
        }
        if ($password !== $rePassword) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '两次密码不一致');
        }

        # check whether name exists
        $existUser = $table->getUser($name);
        if (!empty($existUser)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, "$name 用户已存在");
        }

        $user = new User();
        $user->exchangeArray([
                'name' => $name,
                'email' => $email,
                'role' => $role,
                'password' => User::encryptPassword($password)
            ]);
        $bool = $table->saveUser($user);
        if ($bool) {
            $this->emailNotify($name, $password, $email);
            return $this->success(
                '增加用户成功',
                '/admin/user/' . $table->lastInsertValue
            );
        } else {
            return $this->errorParam(Error::YL_ERROR_PARAM, '添加失败，请重试');
        }
    }

    public function setAction()
    {
        $post = $this->getRequest()->getPost();

        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $table = $this->getUserTable();

        $role = $post->get('role');

        $user = $table->getUserById($id);
        if (empty($user)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '不存在该用户');
        }
        if ($user->strRole == 'superadmin') {
            return $this->errorParam(Error::YL_ERROR_PARAM, '不可修改超级管理员信息');
        }

        $name = $user->strName;
        $email = $post->get('email');
        $role = $post->get('role');

        $user = [
            'email' => $email,
            'role' => $role,
            'update_time' => date("Y-m-d H:i:s"),
        ];

        $bool = $table->update($user, ['id' => $id]);

        return $this->success(
            '修改用户信息成功',
            '/admin/user/' . $id
        );
    }

    public function pwdAction()
    {
        $request = $this->getRequest();
        if($request->isPost()){
            $id = $request->getPost()->get('id');
            if (empty($id)) {
                return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
            }

            $table = $this->getUserTable();
            $role = $request->getPost()->get('role');
            $user = $table->getUserById($id);
            if (empty($user)) {
                return $this->errorParam(Error::YL_ERROR_PARAM, '不存在该用户');
            }

            $name = $user->strName;
            $email = $user->strEmail;
            $model = (int)($request->getPost()->get('pwdmodel'));
            if($model == 1){
                $password = trim($request->getPost()->get('password'));
                $rePassword = $request->getPost()->get('re-password');
            }elseif($model == 2){
                $password = $rePassword = $this->_generatePassword();
            }else{
                $password = $rePassword = "";
            }

            if ($password) {
                if (strlen($password) < 5) {
                    return $this->errorParam(Error::YL_ERROR_PARAM, '密码长度必须大于4');
                }
                if ($password !== $rePassword) {
                    return $this->errorParam(Error::YL_ERROR_PARAM, '两次密码不一致');
                }
            }else{
                return $this->errorParam(Error::YL_ERROR_PARAM, '密码不可以为空');
            }

            $user = [
                'password' => User::encryptPassword($password),
                'update_time' => date("Y-m-d H:i:s"),
            ];

            $bool = $table->update($user, ['id' => $id]);
            if($bool){
                $this->emailNotify($name, $password, $email, 2);
            }

            return $this->success(
                '重置密码成功，新密码已邮件通知',
                '/admin/user/list'
            );
        }

        $id = $this->params()->fromRoute('id', '');
        if (empty($id)) {
            return $this->listAction();
        }

        $user = $this->getUserTable()->getUserById($id);
        $view =  new ViewModel([
                'user' => (array)$user,
                'rolesMap' => $this->getRoles()
            ]
        );

        return $view;
    }

    public function delAction()
    {
        $post = $this->getRequest()->getPost();
        $id = $post->get('id');

        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $userTable = $this->getUserTable();
        $user = $userTable->getUserById($id);

        if ($user->nRole == User::YL_AUTO_UPDATE_ROLE_SUPER_ADMIN) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '超级管理员账户不能随意删除，请联系开发处理');
        }

        $bool = $userTable->delete(['id' => $id]);

        if ($bool) {
            $this->jsonOutput(['status' => 1]);
        } else {
            $this->jsonOutput(['status' => 0, 'error' => '删除出错，请重试']);
        }
    }

    public function emailNotify($strUserName, $strUsePwd, $strEmail, $nType=1)
    {
        $subject 	= 'OS配置中心账户密码通知';
        if($nType == 1){
            $body = "您好,  \r\n \r\n您的OS配置中心的账户 ".$strUserName." 已创建成功！密码是:".$strUsePwd.",请妥善保管！";
        }elseif($nType == 2){
            $body = "您好,  \r\n \r\n您的OS配置中心的账户 ".$strUserName." 密码已重置！密码是:".$strUsePwd.",请妥善保管！";
        }

        $arrToUser = array();
        array_push($arrToUser, $strEmail);
        $result = $this->sendEmail($subject, $body, $arrToUser);
    }

    function sendEmail($subject, $msg_body, $arrTo, $arr_attachment=null){
        try{
            $di = new Di();
            $diConfig = $this->_getEmailConfig();
            $di->configure(new DiConfig($diConfig));

            $transport = $di->get('Zend\Mail\Transport\Smtp');
            $message = $di->get('Zend\Mail\Message');
            $message->setEncoding("UTF-8");
            $message->setTo($arrTo);
            $message->setSubject($subject)->setBody($msg_body);
            $transport->send($message);

        }catch (\Exception $e){
            Logs::write("UserController::sendEmail() zend_exception : ".$e->getMessage(), "log");
            return false;
        }
        return true;
    }

    private function _generatePassword($length = 8 ) {
        $chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()-_[]{}<>~+=,.;:/?|';
        $password = '';
        for ( $i = 0; $i < $length; $i++ )
        {
            // 这里提供两种字符获取方式
            // 第一种是使用 substr 截取$chars中的任意一位字符；
            // 第二种是取字符数组 $chars 的任意元素
            // $password .= substr($chars, mt_rand(0, strlen($chars) – 1), 1);
            $password .= $chars[ mt_rand(0, strlen($chars) - 1) ];
        }
        return $password;
    }

    private function _getEmailConfig()
    {
        $manageFact = new ManagerFactory();
        $manageFact->createService($this->getServiceLocator());
        $arrEmailConfig = ManagerFactory::$params['email'];

        return $arrEmailConfig;
    }

    public function getUserTable()
    {
        if (!$this->userTable) {
            $sm = $this->getServiceLocator();
            $this->userTable = $sm->get('Service\User\UserTable');
        }

        return $this->userTable;
    }
}
