<?php
namespace Machine\Controller;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Service\ManagerFactory;
use Zend\EventManager\EventManagerInterface;

use Data\Verify as D;
use Data\Type as DT;
use Service\Tools\District;

class MachineController extends \Application\Controller\BaseController
{
    public  $dbAdapter;
    private $machineTable;

    public function indexAction()
    {
        $id = $this->params()->fromRoute('id', '');

        if (empty($id)) {
            return $this->listAction();
        }

        $machineTable = $this->getMachineTable();
        $machine = $machineTable->findOne(['_id' => new \MongoId($id)]);

        $view = new ViewModel([
                'machine' => $machine
            ]
        );

        $view->setTemplate('machine/machine/new.phtml');
        return $view;
    }

    // 控制器
    public function listAction()
    {
        $request = $this->getRequest();
        $ename = $request->getQuery('ename');

        $cond = [];
        if ($ename) {
            $cond['ename'] = $ename;
        }

        $lists = $this->getMachineTable()->getList($cond, ['time' => -1], $page = 1, $pagesize = 100);

        $view =  new ViewModel([
                'ename' => $ename,
                'lists' => $lists,
            ]
        );

        return $view;
    }

    public function newAction()
    {
    }

    public function appAction()
    {
        $request = $this->getRequest();
        $id = $this->params()->fromRoute('id', '');

        $app = $this->getAppTable()->findOne(['_id' => new \MongoId($id)]);

        if (empty($app)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        // 倒序versions
        // @todo 考虑插入的时候能保持时间倒叙
        if (!isset($app['versions'])) {
            $app['versions'] = [];
        } else {
            $app['versions'] = array_reverse($app['versions']);
        }


        $view = new ViewModel([
                'app' => $app,
            ]
        );

        return $view;
    }

    /**
     * 项目增加
     */
    public function addAction()
    {
        $request = $this->getRequest();
        $name = $request->getPost()->get('name');
        $ename = $request->getPost()->get('ename');
        $desc = $request->getPost()->get('desc');

        if (empty($ename) || empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型标记或者名称为空, 请填写');
        }

        $machineTable = $this->getMachineTable();
        $appExist = $machineTable->findOne(['ename' => $ename], ['_id' => 0]);

        if ($appExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型标记已经存在, 请更换');
        }

        $machineTable->name = $name;
        $machineTable->ename = $ename;
        $machineTable->desc = $desc;
        $machineTable->time = time();
        $stauts = $machineTable->save();

        $document = $machineTable->getDocument();

        return $this->success(
            '增加机型成功',
            '/machine/' . (string)$document['_id']
        );
    }

    public function setAction()
    {
        $post = $this->getRequest()->getPost();

        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $machineTable = $this->getMachineTable();

        $name = $post->get('name');
        //$ename = $post->get('ename');
        $desc = $post->get('desc');

        if (empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型名称为空, 请填写');
        }

        $machine = $machineTable->findOne(['_id' => new \MongoId($id)]);

        // ename 不可修改
        // $machine['ename'] = $ename;
        $machine['name'] = $name;
        $machine['desc'] = $desc;

        $machineTable->setDocument($machine);
        $stauts = $machineTable->save();

        $document = $machineTable->getDocument();

        return $this->success(
            '修改机型信息成功',
            '/machine/' . D::get($document, '_id')
        );
    }

    public function delAction()
    {
        $this->roleAuth('Machine', 'delete');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $machineTable = $this->getMachineTable();
        $bool = $machineTable->del($id, $this->authUser->name);

        $this->jsonOutput(['status' => $bool]);
    }

    public function getMachineTable()
    {
        if (!$this->machineTable) {
            $sm = $this->getServiceLocator();
            $this->machineTable = $sm->get('Service\Machine\Machine');
        }

        return $this->machineTable;
    }

    public function getAdapter()
    {
        if (!$this->dbAdapter) {
            $sm = $this->getServiceLocator();
            $this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
        }

        return $this->dbAdapter;
    }

    /**
     * 参数错误后的跳转
     */
    public function errorParam($errorId = Error::YL_ERROR_PARAM, $error = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 0, 'errcode' => $errorId, 'error' => $error];

            $this->jsonOutput($result);
        } else {
            $view = new ViewModel([
                    'msg' => $error,
                    'link' => $link
                ]
            );

            $view->setTemplate('error/error.phtml');
            return $view;
        }
    }

    /**
     * 参数错误后的跳转
     */
    public function success($msg = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 1, 'success' => $msg];

            $this->jsonOutput($result);
        } else {
            $view = new ViewModel([
                    'msg' => $msg,
                    'link' => $link
                ]
            );
            $view->setTemplate('error/success.phtml');
            return $view;
        }
    }

    public function searchAction()
    {
        $request = $this->getRequest();
        $q = $request->getQuery('q');

        if (empty($q)) {
            die('[]');
        }

        $machineTable = $this->getMachineTable();
        $rows = $machineTable->search($q);
        $res = [];

        foreach ($rows as $row) {
            $res[] = [
                'label' => $row['name'] . ' => ' . $row['ename'],
                'value' => $row['ename'],
            ];
        }

        $this->jsonOutput($res);
    }
}
