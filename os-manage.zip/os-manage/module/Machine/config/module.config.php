<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Machine\Controller\Machine' => 'Machine\Controller\MachineController',
        ),
    ),

    'router' => array(
        'routes' => array(
            'machine' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/machine[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[a-zA-Z0-9][a-zA-Z0-9]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Machine\Controller\machine',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Machine' => __DIR__ . '/../view/',
        ),
    ),
);