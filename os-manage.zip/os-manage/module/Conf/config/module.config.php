<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Conf\Controller\Conf' => 'Conf\Controller\ConfController',
        ),
    ),
    
    'router' => array(
        'routes' => array(
            'conf' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/conf[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[a-zA-Z0-9][a-zA-Z0-9]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Conf\Controller\conf',
                        'action'     => 'list',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Conf' => __DIR__ . '/../view/',
        ),
    ),
);