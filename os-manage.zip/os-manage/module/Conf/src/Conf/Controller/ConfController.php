<?php
namespace Conf\Controller;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Service\Syslog\Syslog;
use Service\Syslog\SyslogTable;
use Service\ManagerFactory;

use Data\Verify as D;
use Data\Type as DT;
use Service\Tools\District;

class ConfController extends \Application\Controller\BaseController
{
    private $syslog;
    public  $dbAdapter;
    private $appTable;
    private $apiTable;
    private $machineTable;

    public function indexAction()
    {
        exit();
    }

    // list控制器
    public function listAction()
    {
        $request = $this->getRequest();
        $ename = $request->getQuery('ename');

        $cond = [];
        if ($ename) {
            $cond['ename'] = $ename;
        }

        $lists = $this->getAppTable()->getList($cond, ['time' => -1]);

        $view =  new ViewModel([
                'ename' => $ename,
                'lists' => $lists,
            ]
        );

        return $view;
    }

    public function appAction()
    {
        $request = $this->getRequest();
        $id = $this->params()->fromRoute('id', '');

        $app = $this->getAppTable()->findOne(['_id' => new \MongoId($id)]);

        if (empty($app)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        // 倒序versions
        // @todo 考虑插入的时候能保持时间倒叙
        if (!isset($app['versions'])) {
            $app['versions'] = [];
        } else {
            $app['versions'] = array_reverse($app['versions']);
        }


        $view = new ViewModel([
                'app' => $app,
            ]
        );

        return $view;
    }

    /**
     * 项目增加
     */
    public function addAction()
    {
        $this->roleAuth('Conf', 'set');

        $status = 1;
        $request = $this->getRequest();
        $name = $request->getPost()->get('name');
        $ename = $request->getPost()->get('ename');
        $desc = $request->getPost()->get('desc');

        if (empty($ename) || empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '项目标记或者名称为空, 请填写');
        }

        $appTable = $this->getAppTable();
        $appExist = $appTable->findOne(['ename' => $ename], ['_id' => 0]);

        if ($appExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '项目标记已经存在, 请更换');
        }

        $appTable->name = $name;
        $appTable->ename = $ename;
        $appTable->desc = $desc;
        $appTable->time = time();
        $stauts = $appTable->save();

        echo json_encode(['status' => 1]);
        exit();
    }

    public function setAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $appTable = $this->getAppTable();

        $rowPost = $post->get('row');
        $row = [
            'name' => $rowPost['name'],
            'desc' => $rowPost['desc'],
        ];

        $appTable->setApp($id, $row, $this->authUser->name);

        $this->jsonOutput(['status' => 1]);
    }

    public function delAction()
    {
        $this->roleAuth('Conf', 'delete');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }
        $appTable = $this->getAppTable();
        $bool = $appTable->delApp($id, $this->authUser->name);

        $this->jsonOutput(['status' => $bool]);
    }

    /**
     * 新增版本
     */
    public function versionAddAction()
    {
        $this->roleAuth('Conf', 'set');

        $request = $this->getRequest();
        $id = $request->getPost()->get('id');
        $version = $request->getPost()->get('version');
        $desc = $request->getPost()->get('desc');

        if (empty($id) || empty($version)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '项目ID或者版本号为空');
        }

        $appTable = $this->getAppTable();
        $versionExist = $appTable->getVersion($id, $version);

        if ($versionExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '版本号已存在');
        }

        $version = [
            // 版本
            'version' => $version,
            // 描述
            'desc' => $desc,
            // 创建时间
            'ctime' => time(),
            // apis
            'apis' => []
        ];

        $bool = $appTable->addVersion($id, $version);

        $this->jsonOutput(['status' => $bool]);
    }

    /**
     * 复制版本
     */
    public function versionCloneAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $version = $post->get('version');
        $clonedVersion = $post->get('clonedVersion');
        $desc = $post->get('desc');

        if (empty($id) || empty($version) || empty($clonedVersion)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '项目ID或者版本号为空');
        }

        $appTable = $this->getAppTable();
        $versionExist = $appTable->getVersion($id, $version);

        if ($versionExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '版本号已存在');
        }

        $bool = $appTable->cloneVersion($id, $version, $clonedVersion, $desc);

        $this->jsonOutput(['status' => $bool]);
    }

    /**
     * 版本删除
     */
    public function versionDelAction()
    {
        $this->roleAuth('Conf', 'delete');

        $request = $this->getRequest();
        $id = $request->getPost()->get('id');
        $version = $request->getPost()->get('version');

        if (empty($id) || empty($version)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '项目ID或者版本号为空');
        }

        $appTable = $this->getAppTable();
        $bool = $appTable->delVersion($id, $version);

        $this->jsonOutput(['status' => $bool]);
    }

    /**
     * 属性增加
     */
    public function attributeAddAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $key = $post->get('key');
        $type = $post->get('type');
        $label = $post->get('label');
        $desc = $post->get('desc');
        $download = intval($post->get('download'));
        $require = intval($post->get('require'));
        $primary = intval($post->get('primary')); # 是否主键
        // if primary key, then require is needed
        if ($primary) {
            $require = 1;
        }
        $filter = intval($post->get('filter')); # Api查询键
        $filterContDef = 0;
        if ($filter) {
            $filterContDef = intval($post->get('filterContDef')); # Api查询是否包含默认配置;
        }
        $enums = $post->get('enums');
        if ($type !== 'enums') {
            $enums = [];
        }

        if (empty($id) || empty($key)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '接口ID为空或者key为空');
        }

        // 查询该key是否存在
        $apiTable = $this->getApiTable();
        $keyExist = $apiTable->findOne(['id' => $id, 'attributes.key' => $key], ['id' => 1, '_id' => 0]);
        if ($keyExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, 'key重复，请更换key');
        }

        $attribute = [
            'key' => $key,
            'label' => $label,
            'type' => $type,
            'desc' => $desc,
            'download' => $download,
            'require' => $require,
            'primary' => $primary,
            'filter' => $filter,
            'filterContDef' => $filterContDef,
            'enums' => $enums
        ];
        $apiTable->addAttribute($id, $attribute);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => 1]);
    }

    public function attributeSetAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $key = $post->get('key');
        $type = $post->get('type');
        $label = $post->get('label');
        $desc = $post->get('desc');
        $download = intval($post->get('download'));
        $require = intval($post->get('require'));
        $primary = intval($post->get('primary'));
        if ($primary) {
            $require = 1;
        }
        $filter = intval($post->get('filter')); # Api查询键
        $filterContDef = 0;
        if ($filter) {
            $filterContDef = intval($post->get('filterContDef')); # Api查询是否包含默认配置;
        }
        $enums = $post->get('enums');
        if ($type !== 'enums') {
            $enums = [];
        }

        if (empty($id) || empty($key)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '接口ID为空或者key为空');
        }

        // 查询该key是否存在
        $apiTable = $this->getApiTable();

        $attribute = [
            'key' => $key,
            'label' => $label,
            'type' => $type,
            'desc' => $desc,
            'download' => $download,
            'require' => $require,
            'primary' => $primary,
            'filter' => $filter,
            'filterContDef' => $filterContDef,
            'enums' => $enums
        ];
        $apiTable->setAttribute($id, $key, $attribute);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => 1]);
    }

    public function attributeKeysAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $keys = $post->get('keys');

        if (empty($id) || empty($keys)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数不能为空');
        }

        // 查询该key是否存在
        $apiTable = $this->getApiTable();
        $bool = $apiTable->sortKeys($id, $keys);

        if (!$bool) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '发生错误，请重试');
        }

        $this->jsonOutput(['status' => $bool]);
    }

    public function rowAddAction()
    {
        $this->roleAuth('Conf.data', 'set');

        $request = $this->getRequest();
        $id = $request->getPost()->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();
        $api = $apiTable->findOne(['id' => $id]);

        if (empty($api) || empty($api['attributes'])) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '不存在该接口或者该接口字段为空');
        }

        $api = $apiTable->incRowIndex($id);
        $rowIndex = (isset($api['rowIndex']) ? $api['rowIndex'] : 0);
        $row = ['_id' => $rowIndex];
        $post = $request->getPost();
        $isAllEmpty = true;

        foreach ($api['attributes'] as $attr) {
            $key = $attr['key'];
            $row[$key] = $apiTable->checkType($post->get($key), $attr['type']);

            if (($row[$key] === null || $row[$key] === '') && D::get($attr, 'require')) {
                return $this->errorParam(Error::YL_ERROR_PARAM, "{$key} 为必填字段，请输入");
            }

            // 判断是否为空
            if (
                ($attr['type'] == 'boolean' && $row[$key] === false) ||
                ($attr['type'] == 'int' && $row[$key] === 0) ||
                ($attr['type'] == 'float' && $row[$key] === 0) ||
                $row[$key]
            ) {
                $isAllEmpty = false;
            }
        }

        if ($isAllEmpty) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '所有内容项都为空，请输入数据内容');
        }

        $apiTable->addRow($id, $row, $this->authUser->name);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => 1, 'rowId' => $row['_id']]);
    }

    public function rowSetAction()
    {
        $this->roleAuth('Conf.data', 'set');

        $request = $this->getRequest();
        $post = $request->getPost();
        $id = $post->get('id');
        $rowId = intval($post->get('rowId'));
        if (empty($id) || empty($rowId)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();
        $api = $apiTable->findOne(['id' => $id]);

        # get origin row data
        $snapshot = D::hashMap(D::get($api, 'snapshot'), '_id');
        $oriRow = D::get($snapshot, $rowId);

        $rowPost = $post->get('row');
        $row = ['_id' => $rowId];
        foreach ($api['attributes'] as $attr) {
            $key = $attr['key'];

            # 主键不允许修改
            if (D::get($attr, 'primary')) {
                $row[$key] = $oriRow[$key];
                continue;
            }

            $row[$key] = $apiTable->checkType(D::get($rowPost, $key), $attr['type']);

            if (($row[$key] === null || $row[$key] === '') && D::get($attr, 'require')) {
                return $this->errorParam(Error::YL_ERROR_PARAM, "{$key} 为必填字段，请输入");
            }
        }

        $apiTable->setRow($id, $row, $this->authUser->name, $oriRow);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => 1]);
    }

    public function rowDelAction()
    {
        $this->roleAuth('Conf.data', 'delete');

        $request = $this->getRequest();
        $id = $request->getPost()->get('id');
        $rowId = intval($request->getPost()->get('rowId'));
        if (empty($id) || empty($rowId)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();
        $apiTable->delRow($id, $rowId, $this->authUser->name);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => 1]);
    }

    /**
     * 快照功能
     */
    public function snapshotAddAction()
    {
        $this->roleAuth('Conf.data', 'set');

        $request = $this->getRequest();
        $post = $request->getPost();
        $id = $post->get('id');

        $files = $request->getFiles()->toArray();
        $snapshot = $post->get('snapshot');

        $tmp_name = D::get($files, 'file.tmp_name');
        if (empty($id) || (empty($snapshot) && empty($tmp_name))) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '请输入快照内容');
        }

        // 文件优先
        if ($tmp_name) {
            $snapshot = file_get_contents($tmp_name);
        }

        $apiTable = $this->getApiTable();
        $apiTable->addSnapshot($id, $snapshot, $this->authUser->name);

        $this->redirect()->toRoute('conf', [
                'controller' => 'conf',
                'action' => 'api',
                'id' => $id
            ]
        );
    }

    public function apiAddAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $ename = $post->get('ename');
        $version = $post->get('version');
        $api = $post->get('api');
        $model = $post->get('model');
        $desc = $post->get('desc');

        if (empty($id) || empty($version) || empty($api)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '请输入相关参数');
        }

        $apiTable = $this->getApiTable();
        if (!in_array($model, [\Service\Conf\Api::MODEL_INSTRUCT, \Service\Conf\Api::MODEL_NEW, \Service\Conf\Api::MODEL_NEWEST])) {
            $model = \Service\Conf\Api::MODEL_INSTRUCT;
        }

        $apiId = \Service\Conf\Api::getApiId($id, $ename, $version, $api);
        $apiExist = $apiTable->findOne(['id' => $apiId], ['id' => 1, '_id' => 0]);
        if ($apiExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '该接口已经存在，请更换接口名');
        }
        $bool = $apiTable->addApi($id, $ename, $version, $api, $desc, $model);

        $this->jsonOutput(['status' => $bool ? 1 : 0]);
    }

    public function apiDelAction()
    {
        $this->roleAuth('Conf', 'delete');

        $request = $this->getRequest();
        $id = $request->getPost()->get('id');
        $ename = $request->getPost('ename');
        $version = $request->getPost()->get('version');
        $api = $request->getPost()->get('api');

        if (empty($id) || empty($version) || empty($api)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();
        $bool = $apiTable->delApi($id, $ename, $version, $api);
        if ($bool) {
            $this->resetApiCacheByKey($ename, $version, $api);
        }

        $this->jsonOutput(['status' => $bool ? 1 : 0]);
    }

    public function apiCloneAction()
    {
        $this->roleAuth('Conf', 'set');

        $request = $this->getRequest();
        $post = $request->getPost();
        $id = $post->get('id');
        $ename = $post->get('ename');
        $version = $post->get('version');
        // @todo length validator
        $api = $post->get('api');
        $clonedApi = $post->get('clonedApi');
        $model = $post->get('model');
        $desc = $post->get('desc');

        if (empty($id) || empty($version) || empty($api) || empty($clonedApi)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();

        if (!in_array($model, [\Service\Conf\Api::MODEL_INSTRUCT, \Service\Conf\Api::MODEL_NEW, \Service\Conf\Api::MODEL_NEWEST])) {
            $model = \Service\Conf\Api::MODEL_INSTRUCT;
        }

        $apiId = \Service\Conf\Api::getApiId($id, $ename, $version, $api);
        $apiExist = $apiTable->findOne(['id' => $apiId], ['id' => 1, '_id' => 0]);

        if ($apiExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '该接口已经存在，请更换接口名');
        }

        $bool = $apiTable->cloneApi($id, $ename, $version, $api, $clonedApi, $desc, $model);

        $this->jsonOutput(['status' => $bool ? 1 : 0]);
    }

    /**
     * 属性字段删除
     */
    public function attributeDelAction()
    {
        $this->roleAuth('Conf', 'delete');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        $key = $post->get('key');

        if (empty($id) || empty($key)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $apiTable = $this->getApiTable();
        $bool = $apiTable->delAttribute($id, $key);
        $this->resetApiCache($id);

        $this->jsonOutput(['status' => $bool ? 1 : 0]);
    }

    public function apiAction()
    {
        $request = $this->getRequest();
        $id = $this->params()->fromRoute('id', '');

        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $api = $this->getApiTable()->getApi($id);

        if (empty($api)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $machineTable = $this->getMachineTable();
        $machines = $machineTable->getList();
        $cleanMachines = [];
        foreach ($machines as $machine) {
            $cleanMachines[] = [
                'label' => $machine['name'],
                'value' => $machine['ename']
            ];
        }
        $machines = $cleanMachines;

        // sort snapshot
        if (is_array($api['snapshot'])) {
            $api['snapshot'] = array_reverse($api['snapshot']);
        }

        $view =  new ViewModel([
                'api' => $api,
                'machines' => $machines
            ]
        );

        return $view;
    }

    public function getAppTable()
    {
        if (!$this->appTable) {
            $sm = $this->getServiceLocator();
            $this->appTable = $sm->get('Service\Conf\App');
        }

        return $this->appTable;
    }

    public function getApiTable()
    {
        if (!$this->apiTable) {
            $sm = $this->getServiceLocator();
            $this->apiTable = $sm->get('Service\Conf\Api');
        }

        return $this->apiTable;
    }

    public function getMachineTable()
    {
        if (!$this->machineTable) {
            $sm = $this->getServiceLocator();
            $this->machineTable = $sm->get('Service\Machine\Machine');
        }

        return $this->machineTable;
    }

    public function getAdapter()
    {
        if (!$this->dbAdapter) {
            $sm = $this->getServiceLocator();
            $this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
        }

        return $this->dbAdapter;
    }

    private function _getSyslog()
    {
        if (!$this->syslog) {
            $sm = $this->getServiceLocator();
            $this->syslog = $sm->get('Service\Syslog\SyslogTable');
        }
        return $this->syslog;
    }

    /**
     * 参数错误后的跳转
     */
    public function errorParam($errorId = Error::YL_ERROR_PARAM, $error = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 0, 'errcode' => $errorId, 'error' => $error];

            header('Content-Type: application/json');
            echo json_encode($result);
            exit();
        } else {
            return $this->redirect()->toRoute('error', [
                    'controller' => 'error',
                    'action' => 'index',
                    'id'	=> $errorId
                ]
            );
        }
    }

    public function searchDistrictAction()
    {
        $request = $this->getRequest();
        $q = $request->getQuery('q');

        if (empty($q)) {
            die('[]');
        }

        $t1 = microtime(true);
        $rows = (new District())->search($q);
        $t2 = microtime(true) - $t1;

        // 如果只有一个省份的结果
        if (count($rows) === 1 && D::get($rows, '0.capital')) {
            $cities = D::get($rows, '0.cities');
            unset($rows[0]['cities']);
            $rows = array_merge($rows, $cities);
        }

        $res = [];
        foreach ($rows as $row) {
            $res[] = [
                'label' => $row['name'],
                'value' => $row['name'],
            ];
        }

        $this->jsonOutput($res);
    }

    /**
     * 检查点设置
     */
    public function checkSetAction()
    {
        $this->roleAuth('Conf', 'set');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $check = $post->get('check');
        $time = strtotime($post->get('time'));

        if (!$check) {
            // 删除检查点
            $time = 0;
        } else {
            // 设置检查点
            $time = $time ? $time : time();
        }

        $apiTable = $this->getApiTable();
        $set = ['checkPoint' => $time];
        $bool = $apiTable->update(['id' => $id], ['$set' => $set]);
        if (D::get($bool, 'ok')) {
            $this->resetApiCache($id);
        }

        $this->jsonOutput(['status' => D::get($bool, 'ok') ? 1 : 0]);
    }

    /**
     * 重置api cache
     */
    public function resetApiCache($id)
    {
        $appTable = $this->getAppTable();
        $apiInfo = $appTable->apiInfo($id);

        if (empty($apiInfo)) {
            return false;
        }

        return $this->resetApiCacheByKey($apiInfo['app'], $apiInfo['version'], $apiInfo['api']);
    }

    public function resetApiCacheByKey($app, $version, $api)
    {
        $key = implode(':', [$app, $version, $api]);

        try {
            $config = $this->getServiceLocator()->get('config');
            $redisCfg = $config['redis'];
            $redis = \Service\Redis::getRedis($redisCfg);

            return $redis->del($key) ? true : false;
        } catch (\Exception $e) {
            Logs::write('api cache reset failed, message:' . $e->getMessage(), 'log');
            return false;
        }
    }
}
