<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Whlist\Controller\Whlist' => 'Whlist\Controller\WhlistController',
        ),
    ),
    
    'router' => array(
        'routes' => array(
            'whlist' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/whlist[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',
                    ),
                    'defaults' => array(
                        'controller' => 'Whlist\Controller\whlist',
                        'action'     => 'list',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Whlist' => __DIR__ . '/../view/',
        ),
    ),
);