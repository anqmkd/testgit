<?php
namespace Whlist\Controller;

use Service\Whlist\GParams;

use Service\Whlist\ApkList;

use Service\Whlist\WhiteList;

use Service\Logs\Logs;
use Service\User\User;
use Service\User\UserTable;
use Service\Auth\Auth;
use Service\Error\Error;

use Service\Whlist\WidgetList;
use Zend\Mvc\Controller\AbstractActionController;
use Zend\Mvc\Controller\Plugin\Params;
use Zend\Db\ResultSet\ResultSet;
use Zend\View\Model\ViewModel;
use Service\Syslog\Syslog;
use Service\Syslog\SyslogTable;
use Service\ManagerFactory;

use Zend\Mail\Transport;

class WhlistController extends \Application\Controller\BaseController
{
    private $_securelevel;
    private $_whitelist;
    private $_apklist;
    private $_gparam;
    private $_widget;
    private $syslog;
    public  $dbAdapter;

    public function indexAction()
    {
        exit();
    }

    public function listAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.list', 'list');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $arrIds = $this->getSecureLevelTable()->getAllLevelInfo();
            if($arrIds === false){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_EXCEPOTION,
                ));
            }

            $request        = $this->getRequest();
            if($request->isPost()){
                $strAppLevel    = $request->getPost()->get('level_id');
                $strAppName     = $request->getPost()->get('app_name');
                $strAppLevel	= (int)(isset($strAppLevel)?$strAppLevel:-1);
                $strAppName     = isset($strAppName)?$strAppName:'';
                $nPageNum = $request->getPost()->get('page');
                $nPageCount = $request->getPost()->get('page_count');

                $white = new WhiteList();
                $white->setLevelId($strAppLevel);
                $white->setApkName($strAppName);
                $strCondition = $white->getCondition();
                $arrWhlist = $this->getWhiteListTable()->getWhiteList($strCondition, $nPageNum, $nPageCount);
                $nCount = $this->getWhiteListTable()->getCountList($strCondition);

            }else{
                $arrWhlist = array();
                $strAppLevel = '';
                $strAppName = '';
                $view =  new ViewModel(array(
                    'rids'			=> $arrIds,
                    'lists'         => $arrWhlist,
                    'reqLevelId'	=> $strAppLevel,
                    'appname'		=> $strAppName,
                    'menu'			=> 'secpay',
                    'left'			=> 'whitelist'));

                return $view;
            }

            echo json_encode(array('result'=>true,'list'=>$arrWhlist,'count'=>$nCount));
            exit();

        }catch(\Exception $e){
            Logs::write('WhlistController::rulehintAction() exception, err:'
                    .' message:'.$e->getMessage(), 'log');
        }
    }

    public function updateflagAction(){
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.list', 'list');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request 	    = $this->getRequest();
            $nType 	    = $request->getQuery('type');
            $nValue	    = $request->getQuery('value');
            $strId      = $request->getQuery('id');

            if(empty($nType)){
                echo false;
                exit();
            }
            $whilte = new WhiteList();
            $whilte->setFlag($nValue);
            $whilte->setType($nType);
            $whilte->setId($strId);

            $bRet = $this->getWhiteListTable()->updateFlag($whilte);
            if($bRet === false){
                echo false;
                exit();
            }

            echo true;
            exit();
        }catch (\Exception $e){
            Logs::write('PolicyController::updateflagAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
            echo false;
            exit();
        }
    }

    public function reportAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.list', 'list');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request    = $this->getRequest();
            $nStatus    = $request->getQuery('status');
            $strApkName	= $request->getQuery('apk_name');
            $nStatus	= (int)(isset($nStatus)?$nStatus:0);
            $strApkName	= isset($strApkName)?$strApkName:'';

            $apk = new ApkList();
            $apk->setApkName($strApkName);
            $apk->setApkStatus($nStatus);
            $strCondition = $apk->getCondition();
            $arrApk = $this->getApkListTable()->getApkList($strCondition);
            $view =  new ViewModel(array(
                    'lists'         => $arrApk,
                    'name'			=> $strApkName,
                    'nStatus'		=> $nStatus,
                    'menu'			=> 'secpay',
                    'left'			=> 'report'));

            return $view;

        }catch(\Exception $e){
            Logs::write('WhlistController::rulehintAction() exception, err:'
                    .' message:'.$e->getMessage(), 'log');
        }
    }

    public function addWhiteAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.add', 'add');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request = $this->getRequest();
            $strApkName = $request->getPost()->get('apk_name');
            $strPackage = $request->getPost()->get('package_name');
            $strMd5 = $request->getPost()->get("apk_md5");
            $strActivity = $request->getPost()->get("apk_activity");
            $strVersion = $request->getPost()->get('version');
            $nLevelId = $request->getPost()->get('level_id');

            if (empty($strPackage)){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_PARAM,
                ));
            }

            $white = new WhiteList();
            $white->setPackage($strPackage);
            $white->setLevelId($nLevelId);
            $white->setApkName($strApkName);
            $white->setVersion($strVersion);
            $white->setApkMd5($strMd5);
            $white->setApkActivity($strActivity);

            $arrResult = $this->getWhiteListTable()->isHaveSameRecord($white);
            if(count($arrResult) != 0){
                Logs::write("this white had exist", "log");
                exit("-1");    //有重复的白名单记录（有可能是无效的记录）
            }

            $bResult = $this->getWhiteListTable()->saveApkWhite($white);
            if(!$bResult){
                Logs::write('WhlistController::addWhiteAction():saveApkWhite() failed', 'log');
                return false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName();
            $strValue = date("YmdHis", time());
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();

        }catch (\Exception $e){
            Logs::write('WhlistController::addWhiteAction() exception, err:'
                    .' message:'.$e->getMessage(), 'log');
        }

        $view =  new ViewModel();
        return $view;
    }

    public function delWhiteAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.update', 'update');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request    = $this->getRequest();
            $strId = $request->getPost()->get('id');
            $strId = isset($strId)?$strId:'';
            if (empty($strId)){
                Logs::write("WhlistController::delWhiteAction: id is empty", "log");
                echo false;
                exit();
            }

            $white = new WhiteList();
            $white->setId($strId);
            $white->setLevelId(WhiteList::SECURE_LEVEL_0);
            $bResult = $this->getWhiteListTable()->setApkLevel($white);
            if(!$bResult) {
                Logs::write('WhlistController::delWhiteAction():setApkLevel() failed', 'log');
                echo false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName();
            $strValue = date("YmdHis", time());
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();
        }catch(\Exception $e){
            Logs::write('WhlistController::delWhiteAction() exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index'
            ));
        }
    }

    public function editWhiteAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.update', 'update');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request    = $this->getRequest();
            $strId = $request->getPost()->get('id');
            $strApkName = $request->getPost()->get('apk_name');
            $strMd5 = $request->getPost()->get("apk_md5");
            $strActivity = $request->getPost()->get("apk_activity");
            $strPackage = $request->getPost()->get('package_name');
            $strVersion = $request->getPost()->get('version');
            $nLevelId = $request->getPost()->get('level_id');

            if(empty($strId)){
                Logs::write('WhlistController::editWhiteAction() id is null', 'log');
                echo false;
                exit();
            }

            if(empty($strPackage)){
                Logs::write('WhlistController::editWhiteAction() package is null', 'log');
                echo false;
                exit();
            }

            $white = new WhiteList();
            $white->setId($strId);
            $white->setPackage($strPackage);
            $white->setLevelId($nLevelId);
            $white->setApkName($strApkName);
            $white->setVersion($strVersion);
            $white->setApkMd5($strMd5);
            $white->setApkActivity($strActivity);

            $bResult = $this->getWhiteListTable()->updateWhite($white);
            if(!$bResult) {
                Logs::write('WhlistController::editWhiteAction():updateWhite() failed', 'log');
                echo false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName();
            $strValue = date("YmdHis", time());
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();
        }catch(\Exception $e){
            Logs::write('WhlistController::editWhiteAction() exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index'
            ));
        }
    }

    public function apkWhiteAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.apk', 'apk');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                        'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                        'action' => 'index',
                        'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request        = $this->getRequest();
            $strIds         = $request->getPost()->get('ids');
            $strStatus      = $request->getPost()->get('status');
            $nLevelId       = $request->getPost()->get('level_id');
            $strIds			= isset($strIds)?$strIds:"";
            $strStatus		= isset($strStatus)?$strStatus:"";
            $nLevelId		= isset($nLevelId)?$nLevelId:"";

            if(empty($strIds) || empty($strStatus)){
                Logs::write('WhlistController::apkWhiteAction() ids is null', 'log');
                echo false;
                exit();
            }

            $strIds = trim($strIds, ", ");
            $arrIds = explode(",", $strIds);

            if($strStatus == ApkList::APK_STATUS_2){
                foreach ($arrIds as $id){
                    $this->_setApkStatus($id, $strStatus);
                }
            }

            if ($strStatus == ApkList::APK_STATUS_1){
                if (empty($nLevelId)){
                    Logs::write('WhlistController::apkWhiteAction() level_id is null', 'log');
                    echo false;
                    exit();
                }

                foreach ($arrIds as $id){
                    $this->_setApkWhite($id, $strStatus, $nLevelId);
                }

                //更新白名单下发时间参数
                $gParam = new GParams();
                $gParam->setParamName();
                $strValue = date("YmdHis", time());
                $gParam->setParamValue($strValue);
                $this->getGParamTable()->updateParamValue($gParam);
            }

            echo true;
            exit();

        }catch(\Exception $e){
            Logs::write('WhlistController::apkWhiteAction() exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index'
            ));
        }
    }

    private function _setApkStatus($id, $strStatus){
        $apk = new ApkList();
        $apk->setId($id);
        $apk->setApkStatus($strStatus);
        $bResult = $this->getApkListTable()->setStatus($apk);
        if(!$bResult) {
            Logs::write('WhlistController::_setApkStatus():setStatus() failed', 'log');
            return false;
        }

        return true;
    }

    private function _setApkWhite($id, $strStatus, $nLevelId){
        $apk = new ApkList();
        $apk->setId($id);
        $condition = $apk->getCondition();
        $arrApk = $this->getApkListTable()->getApkList($condition);
        if($arrApk === false) {
            Logs::write('WhlistController::_setApkWhite():getApkList() failed', 'log');
            return false;
        }

        $nStatus = $arrApk[0]->nStatus;
        if ($nStatus != ApkList::APK_STATUS_0){
            return true;
        }


        $bRet = $this->_setApkStatus($id, $strStatus);
        if(!$bRet){
            return false;
        }

        $white = new WhiteList();
        $white->setApkName($arrApk[0]->strName);
        $white->setPackage($arrApk[0]->strPackage);
        $white->setVersion($arrApk[0]->strVersion);
        $white->setLevelId($nLevelId);
        $white->setApkMd5($arrApk[0]->strMd5);
        $arrRet = $this->getWhiteListTable()->isHaveSameRecord($white);
        if($arrRet === false) {
            Logs::write('WhlistController::_setApkWhite():isHaveSameRecord() failed', 'log');
            return false;
        }

        if (count($arrRet) != 0){
            Logs::write('WhlistController::_setApkWhite():isHaveSameRecord() white list had this apk', 'log');
            return false;
        }

        $bResult = $this->getWhiteListTable()->saveApkWhite($white);
        if(!$bResult) {
            Logs::write('WhlistController::_setApkWhite():saveApkWhite() failed', 'log');
            return false;
        }

        return true;
    }

    public function widgetAction(){
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.widget', 'widget');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $arrlist = $this->getWidgetListTable()->getWidgetList();
            $view =  new ViewModel(array(
                'lists'         => $arrlist,
                'menu'			=> 'secpay',
                'left'			=> 'widget'));

            return $view;

        }catch(\Exception $e){
            Logs::write('WhlistController::rulehintAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }
    }

    public function addWidgetAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.widget', 'widget');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request = $this->getRequest();
            $strStatus = $request->getPost()->get('status');
            $strContent = $request->getPost()->get('content');

            if (empty($strContent)){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_PARAM,
                ));
            }

            $widget = new WidgetList();
            $widget->setContent($strContent);
            $widget->setStatus($strStatus);

            $bResult = $this->getWidgetListTable()->saveWidget($widget);
            if(!$bResult){
                Logs::write('WhlistController::addWidgetAction():saveWidget() failed', 'log');
                return false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName("widget");
            $strValue = time();
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();

        }catch (\Exception $e){
            Logs::write('WhlistController::addWidgetAction() exception, err:'
                .' message:'.$e->getMessage(), 'log');
        }

        $view =  new ViewModel();
        return $view;
    }

    public function delWidgetAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.widget', 'widget');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request    = $this->getRequest();
            $strId = $request->getPost()->get('id');
            $nStatus = $request->getPost()->get('status');
            $strId = isset($strId)?$strId:'';
            if (empty($strId)){
                Logs::write("WhlistController::delWidgetAction: id is empty", "log");
                echo false;
                exit();
            }

            $widget = new WidgetList();
            $widget->setId($strId);
            $widget->setStatus($nStatus);
            $bResult = $this->getWidgetListTable()->setWidgetStatus($widget);
            if(!$bResult) {
                Logs::write('WhlistController::delWidgetAction():setWidgetStatus() failed', 'log');
                echo false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName("widget");
            $strValue = time();
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();
        }catch(\Exception $e){
            Logs::write('WhlistController::delWidgetAction() exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                'action' => 'index'
            ));
        }
    }

    public function editWidgetAction()
    {
        try{
            $auth = new Auth();
            $result = $auth->roleAuth('Whlist.whlist.widget', 'widget');
            if(!is_object($result) && $result == Auth::YL_AUTH_NOT_LOGIN){
                return $this->redirect()->toRoute('auth', array('controller'=>'auth',
                    'action' => 'login'));
            }
            if(!is_object($result) && $result == Auth::YL_AUTH_NO_POWER){
                return $this->redirect()->toRoute('error', array('controller'=>'error',
                    'action' => 'index',
                    'id'	=> Error::YL_ERROR_NO_POWER,
                ));
            }
            $this->authUser = $result;

            $request    = $this->getRequest();
            $strId = $request->getPost()->get('id');
            $strContent = $request->getPost()->get('content');
            $strStatus = $request->getPost()->get("status");

            if(empty($strId)){
                Logs::write('WhlistController::editWidgetAction() id is null', 'log');
                echo false;
                exit();
            }

            if(empty($strContent)){
                Logs::write('WhlistController::editWidgetAction() content is null', 'log');
                echo false;
                exit();
            }

            $widget = new WidgetList();
            $widget->setId($strId);
            $widget->setStatus($strStatus);
            $widget->setContent($strContent);
            $bResult = $this->getWidgetListTable()->updateWidget($widget);
            if(!$bResult) {
                Logs::write('WhlistController::editWidgetAction():updateWidget() failed', 'log');
                echo false;
                exit();
            }

            //更新白名单下发时间参数
            $gParam = new GParams();
            $gParam->setParamName("widget");
            $strValue = time();
            $gParam->setParamValue($strValue);
            $this->getGParamTable()->updateParamValue($gParam);

            echo true;
            exit();
        }catch(\Exception $e){
            Logs::write('WhlistController::editWidgetAction() exception, error:'.$e->getMessage(), 'log');
            return $this->redirect()->toRoute('error', array('controller'=>'error',
                'action' => 'index'
            ));
        }
    }

    public function getSecureLevelTable()
    {
        if (!$this->_securelevel) {
            $sm = $this->getServiceLocator();
            $this->_securelevel = $sm->get('Service\Whlist\SecureLevelTable');
        }
        return $this->_securelevel;
    }

    public function getWhiteListTable()
    {
        if (!$this->_whitelist) {
            $sm = $this->getServiceLocator();
            $this->_whitelist = $sm->get('Service\Whlist\WhiteListTable');
        }
        return $this->_whitelist;
    }

    public function getWidgetListTable()
    {
        if (!$this->_widget) {
            $sm = $this->getServiceLocator();
            $this->_widget = $sm->get('Service\Whlist\WidgetListTable');
        }
        return $this->_widget;
    }

    public function getApkListTable()
    {
        if (!$this->_apklist) {
            $sm = $this->getServiceLocator();
            $this->_apklist = $sm->get('Service\Whlist\ApkListTable');
        }
        return $this->_apklist;
    }

    public function getGParamTable()
    {
        if (!$this->_gparam) {
            $sm = $this->getServiceLocator();
            $this->_gparam = $sm->get('Service\Whlist\ParamsTable');
        }
        return $this->_gparam;
    }

    public function getAdapter()
    {
        if (!$this->dbAdapter) {
            $sm = $this->getServiceLocator();
            $this->dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
        }
        return $this->dbAdapter;
    }

    private function _getSyslog()
    {
        if (!$this->syslog) {
            $sm = $this->getServiceLocator();
            $this->syslog = $sm->get('Service\Syslog\SyslogTable');
        }
        return $this->syslog;
    }

    private function _getEmailConfig()
    {
        $manageFact = new ManagerFactory();
        $manageFact->createService($this->getServiceLocator());
        $arrEmailConfig = ManagerFactory::$params['email'];

        return $arrEmailConfig;
    }

}
