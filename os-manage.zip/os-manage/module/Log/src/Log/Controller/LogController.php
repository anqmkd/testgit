<?php

namespace Log\Controller;

use Service\Error\Error;
use Zend\View\Model\ViewModel;
use Data\Verify as D;
use Data\Type as DT;

class LogController extends \Application\Controller\BaseController
{
    private $logTable;
    private $appTable;

    private $projects = [
        'Conf' => '配置中心',
    ];

    private $instructs = [
        '0' => '增加',
        '1' => '修改',
        '2' => '删除'
    ];

    public function indexAction()
    {
        exit();
    }

    // list控制器
    public function listAction()
    {
        $request = $this->getRequest();
        $project = $request->getQuery('project');
        $page = $request->getQuery('page');
        $op = D::verify($_GET, 'op', DT::STRING);

        $cond = [];
        if ($project) {
            $cond['project'] = $project;
        }
        if ($op) {
            $cond['op'] = new \MongoRegex("/.*$op.*/");
        }

        $lists = $this->getLogTable()->getList($cond, ['time' => -1], 1, 100);

        $view =  new ViewModel([
                'project' => $project,
                'op' => $op,
                'projects' => $this->projects,
                'instructs' => $this->instructs,
                'lists' => $lists,
            ]
        );

        return $view;
    }

    // list控制器
    public function apiAction()
    {
        $request = $this->getRequest();
        $page = $request->getQuery('page');
        $id = D::verify($_GET, 'id', DT::STRING);
        $op = D::verify($_GET, 'op', DT::STRING);

        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '缺少Api ID');
        }

        $cond = [];
        $cond['api'] = $id;
        if ($op) {
            $cond['op'] = new \MongoRegex("/.*$op.*/");
        }

        $api = $this->getAppTable()->apiInfo($id);
        $lists = $this->getLogTable()->getList($cond, ['time' => -1], 1, 100);

        $view =  new ViewModel([
                'id' => $id,
                'op' => $op,
                'api' => $api,
                'projects' => $this->projects,
                'instructs' => $this->instructs,
                'lists' => $lists,
            ]
        );

        return $view;
    }

    public function getLogTable()
    {
        if (!$this->logTable) {
            $sm = $this->getServiceLocator();
            $this->logTable = $sm->get('Service\Log\Log');
        }

        return $this->logTable;
    }

    public function getAppTable()
    {
        if (!$this->appTable) {
            $sm = $this->getServiceLocator();
            $this->appTable = $sm->get('Service\Conf\App');
        }

        return $this->appTable;
    }
}