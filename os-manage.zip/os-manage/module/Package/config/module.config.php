<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Package\Controller\Package' => 'Package\Controller\PackageController',
        ),
    ),

    'router' => array(
        'routes' => array(
            'package' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/package[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[a-zA-Z0-9][a-zA-Z0-9]*',
                    ),
                    'defaults' => array(
                        'controller' => 'Package\Controller\package',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Package' => __DIR__ . '/../view/',
        ),
    ),
);