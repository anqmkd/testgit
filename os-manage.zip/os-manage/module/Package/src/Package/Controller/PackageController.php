<?php
namespace Package\Controller;

use Service\Logs\Logs;
use Service\Auth\Auth;
use Service\Error\Error;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Service\ManagerFactory;

use Data\Verify as D;
use Data\Type as DT;

class PackageController extends \Application\Controller\BaseController
{
    private $packageTable;

    public function indexAction()
    {
        $id = $this->params()->fromRoute('id', '');

        if (empty($id)) {
            return $this->listAction();
        }

        $packageTable = $this->getPackageTable();
        $package = $packageTable->findOne(['_id' => new \MongoId($id)]);

        $view = new ViewModel([
                'package' => $package
            ]
        );

        $view->setTemplate('package/package/new.phtml');
        return $view;
    }

    // 控制器
    public function listAction()
    {
        $request = $this->getRequest();
        $q = $request->getQuery('ename');

        $cond = [];
        if ($q) {
            $cond = [
                '$or' => [
                    ['ename' => new \MongoRegex("/.*$q/")],
                    ['name' => new \MongoRegex("/.*$q/")]
                ]
            ];
        }

        $lists = $this->getPackageTable()->getList($cond, ['time' => -1], $page = 1, $pagesize = 100);

        $view =  new ViewModel([
                'ename' => $q,
                'lists' => $lists,
            ]
        );

        return $view;
    }

    public function newAction()
    {
    }

    /**
     * 项目增加
     */
    public function addAction()
    {
        $request = $this->getRequest();
        $name = $request->getPost()->get('name');
        $ename = $request->getPost()->get('ename');
        $desc = $request->getPost()->get('desc');

        if (empty($ename) || empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型标记或者名称为空, 请填写');
        }

        $packageTable = $this->getPackageTable();
        $appExist = $packageTable->findOne(['ename' => $ename], ['_id' => 0]);

        if ($appExist) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型标记已经存在, 请更换');
        }

        $packageTable->name = $name;
        $packageTable->ename = $ename;
        $packageTable->desc = $desc;
        $packageTable->time = time();
        $stauts = $packageTable->save();

        $document = $packageTable->getDocument();

        return $this->success(
            '增加机型成功',
            '/package/' . (string)$document['_id']
        );
    }

    public function setAction()
    {
        $post = $this->getRequest()->getPost();

        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $packageTable = $this->getPackageTable();

        $name = $post->get('name');
        //$ename = $post->get('ename');
        $desc = $post->get('desc');

        if (empty($name)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '机型名称为空, 请填写');
        }

        $package = $packageTable->findOne(['_id' => new \MongoId($id)]);

        // ename 不可修改
        // $package['ename'] = $ename;
        $package['name'] = $name;
        $package['desc'] = $desc;

        $packageTable->setDocument($package);
        $stauts = $packageTable->save();

        $document = $packageTable->getDocument();

        return $this->success(
            '修改机型信息成功',
            '/package/' . D::get($document, '_id')
        );
    }

    public function delAction()
    {
        $this->roleAuth('Package', 'delete');

        $post = $this->getRequest()->getPost();
        $id = $post->get('id');
        if (empty($id)) {
            return $this->errorParam(Error::YL_ERROR_PARAM, '参数错误');
        }

        $packageTable = $this->getPackageTable();
        $bool = $packageTable->del($id, $this->authUser->name);

        echo json_encode(['status' => $bool]);
        exit();
    }

    public function getPackageTable()
    {
        if (!$this->packageTable) {
            $sm = $this->getServiceLocator();
            $this->packageTable = $sm->get('Service\Package\Package');
        }

        return $this->packageTable;
    }

    /**
     * 参数错误后的跳转
     */
    public function errorParam($errorId = Error::YL_ERROR_PARAM, $error = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 0, 'errcode' => $errorId, 'error' => $error];

            header('Content-Type: application/json');
            echo json_encode($result);
            exit();
        } else {
            $view = new ViewModel([
                    'msg' => $error,
                    'link' => $link
                ]
            );

            $view->setTemplate('error/error.phtml');
            return $view;
        }
    }

    /**
     * 参数错误后的跳转
     */
    public function success($msg = '', $link = '')
    {
        if ($this->getRequest()->isXmlHttpRequest()) {
            $result = ['status' => 1, 'success' => $msg];

            header('Content-Type: application/json');
            echo json_encode($result);
            exit();
        } else {
            $view = new ViewModel([
                    'msg' => $msg,
                    'link' => $link
                ]
            );
            $view->setTemplate('error/success.phtml');
            return $view;
        }
    }

    public function searchAction()
    {
        $request = $this->getRequest();
        $q = $request->getQuery('q');

        if (empty($q)) {
            die('[]');
        }

        $packageTable = $this->getPackageTable();
        $rows = $packageTable->search($q);
        $res = [];

        foreach ($rows as $row) {
            $res[] = [
                'label' => $row['name'] . ' => ' . $row['ename'],
                'value' => $row['ename'],
            ];
        }

        //echo "1111";
        echo json_encode($res);
        exit();
    }
}
