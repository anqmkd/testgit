<?php
return array(
    'modules' => array(
        'Application',
        'Service',
        'Whlist',
        'Policy',
        'Conf',
        'Machine',
        'Ota',
        'Package',
        'Auth',
        'User',
        'Error',
        'Tools',
        'Admin',
        'Log'
    ),
    'module_listener_options' => array(
        'config_glob_paths'    => array(
            'config/autoload/{,*.}{global,local}.php',
        ),
        'module_paths' => array(
            './module',
            './vendor',
        ),
    ),
);
