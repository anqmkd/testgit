<?php
return array(
    'db' => AppConf::getCfg('/dba/mdb/os_manage_mysql'),
    'redis' => AppConf::getCfg('/dba/mdb/os_api_redis'),
    'service_manager' => array(
        'factories' => array(
            'Zend\Db\Adapter\Adapter' => 'Zend\Db\Adapter\AdapterServiceFactory',
        ),
    ),
);

function dump()
{
    $args = func_get_args();

    echo '<pre>';

    foreach ($args as $a) {
        var_dump($a);
    }

    echo '</pre>';
}

function dd()
{
    call_user_func_array('dump', func_get_args());
    die();
}