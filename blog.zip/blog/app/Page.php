<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    public function hasManyComments(){
     return $this->hasMany('App\Comment','page_id','id');
    }
    public function tags(){
    	return $this->belongsToMany('App\Tag');
    }

    //一个评论文章的用户可能有多条回复
    public  function hasManyReplay(){
        return $this->hasMany('App\Replay','user_id','comment_id');
    }

    //文章属于哪个分类
    public function cate(){
       return $this->belongsTo('App\Categoies','cate_id','id');
    }
}
