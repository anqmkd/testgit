<?php
namespace App\Http\Controllers\Admin;
header("content-type:text/html;charset=utf-8");
use Input,Redirect;
use Illuminate\Http\Request;
use App\Comment;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class CommentsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
     //获取所有评论的列表
     return view('admin.comments.index')->withComments(Comment::all());
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
    return view('admin.comments.edit')->withComment(Comment::find($id));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
     //需要先验证
     $this->validate($request,
        [
        'nickname'    =>'required',
        'content'    =>'required',
        ]);
    if(Comment::where('id',$id)->update(Input::except(['_method', '_token']))){
        return Redirect::to('admin/comments');
    }else{
        return Redirect::back()->withInput()->withErrors('更新失败');
    }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
    echo"<script> alert('确定要删除吗');</script>";
     $comment=Comment::find($id);
     $comment->delete();
     return Redirect::to('admin/comments');
    }
}
