<?php

namespace App\Http\Controllers;
header("content-type:text/html;charset=utf-8");
use App\Comment;
use Illuminate\Http\Request;
use App\Page;
use App\Reply;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Parsedown;
class PagesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //展示某一篇博文的详情
        return view('pages.show')->withPage(Page::find($id));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
     
    }

    public function read($id)
    {
        $parsedown=new Parsedown();
        $obj =Page::find($id);
        $obj->title=($parsedown->text($obj->title));
        $obj->body=($parsedown->text($obj->body));
        $lists=DB::select("SELECT `comments`.`nickname`,`comments`.`content`,`comments`.`created_at`,
                         comments.user_id,reply.pic,`reply`.`rpl_content`,`reply`.`user_name`,`reply`.`updated_at`,`reply`.`reply_name`
                         FROM `comments` LEFT JOIN `reply` ON `comments`.`user_id`=`reply`.`user_id`WHERE `comments`.`page_id`={$id}");
         $arrRet = array();
    foreach($lists as $list){
            if(array_key_exists($list->user_id, $arrRet)){
                array_push($arrRet[$list->user_id]['reply'], ['rpl_content'=>$list->rpl_content,
                    'user_name'=>$list->user_name,'updated_at'=>$list->updated_at,'pic' =>$list->pic,'user_id'=>$list->user_id,'reply_name' =>$list->reply_name]);
            }else{
                //echo "1"."<br/>";
                $arrRet[$list->user_id]['comment'] = ['nickname' =>$list->nickname,'content'=>$list->content,'created_at'=>$list->created_at,'user_id'=>$list->user_id];
                if($list->rpl_content!=null){
                $arrRet[$list->user_id]['reply'][]=  ['rpl_content'=>$list->rpl_content,
                    'user_name'=>$list->user_name,'updated_at'=>$list->updated_at ,'pic' =>$list->pic,'user_id'=>$list->user_id,'reply_name' =>$list->reply_name];
            }
            }
        }
        //var_dump($arrRet[1]['reply']);exit;
        return View('read/page')->withPage($obj)->with('lists' ,$arrRet)->with('id',$id);
    }
    
    public function register(){
        return view('register');
    }
}
