<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Reply extends Model
{
    //
    protected $table="reply";
    protected  $fillable=['content','user_name','comment_id','user_id','rpl_content'];

    public function rpl(){
        return $this->belongsTo('App\Comment','user_id','user_id');
    }
}
