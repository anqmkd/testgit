<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Tag;
class TagTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Tag::create(
        [
        'id'             =>1,
        'name'           =>'Github'
         ]

    );
        Tag::create(
        [
        'id'             =>2,
        'name'           =>'Git'
         ]

    );
        Tag::create(
        [
        'id'             =>3,
        'name'           =>'Laravel'
         ]

    );
    }
}
