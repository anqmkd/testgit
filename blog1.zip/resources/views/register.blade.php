<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title></title>
    <link href="{{asset('css/bootstrap.min.css')}}" rel="stylesheet">
    <link href="http://concat.lietou-static.com/core/pc/revs/css/common/header_c8045ce8.css" rel="stylesheet" type="text/css">
    <link href="http://concat.lietou-static.com/pics/pc/revs/p/beta2/css/event/landingpage/get_new_user_lz_public_10e39635.css" rel="stylesheet" type="text/css">
    <script src="http://concat.lietou-static.com/core/pc/revs/js/common/header_94ad27a1.js"></script>
</head>
<body>
<div class="login">
    <h3>10秒快速注册</h3>
    <div data-selector="loginTp1">
        <style>#NTGUID__1 form{  padding: 0 30px;  position: relative;}
        #NTGUID__1 input{  padding: 2px 0;  height: 46px;}#NTGUID__1 .accept{  height: 20px;  color: #666;  font-size: 12px;
      padding-top: 19px;  _padding: 0 0 4px 0;  _margin: 0;  font-family: "Microsoft YaHei";}
        #NTGUID__1 .accept label{  vertical-align: top;  _vertical-align: middle;  margin: -2px -5px 0 0;  _margin: 2px 2px 0 0;}
        #NTGUID__1 .accept span a{  color: #666;}#NTGUID__1 .go-login{  height: 57px;}
        #NTGUID__1 .go-login p{  background: #f8f8f8;  height: 56px;  line-height: 56px;  position: absolute;  left: 0;  bottom: 0;  width: 370px;  font-size: 18px;  color:
        #333333;  text-align: center;}#NTGUID__1 .go-login p a{  margin-right: 20px;  color: #0088bb;  text-decoration: none}
        #NTGUID__1 .button .btn{  background: #ff9500;  color: #FFF;  font-size: 24px;  height: 58px;  line-height: 58px;  width: 310px;  padding: 0;  border: 0;}
        #NTGUID__1 .button .btn:hover{  opacity: .8;  filter: alpha(opacity: 80);}#NTGUID__1 .login-form{  margin-bottom: 20px;  height: 46px;}
        #NTGUID__1 input.text{  height: 18px;  border: 1px solid #ccc;  background: #fff;  padding: 14px 7px;  font-size: 16px;  font-family: "Microsoft YaHei";}
        #NTGUID__1 input.info{  width: 294px;}#NTGUID__1 .validation_def_pass{  font-size: 16px;  font-family: "Microsoft YaHei";}
        #NTGUID__1 input.input-verycode{  width: 114px;}#NTGUID__1 .image-verycode{  vertical-align: middle;  margin: 0 5px;}
        #NTGUID__1 .btn-phone-code{  font-size: 14px;  height: 36px;  line-height: 36px;  margin-left: 10px;  width: 143px;}
        </style>
        <div id="NTGUID__1">
            <form class="register-box" method="post" action="/user/regc/reguserc/?validrandflag=1" lt-plugins-valid="0.7347353538498282">
                <input type="hidden" value="4" name="web_user.user_status">
                <input type="hidden" value="" name="inviteHId">
                <input type="hidden" value="" name="userID">
                <input type="hidden" value="" name="taskID">
                <input type="hidden" value="" name="params">
                <div class="login-form">
                    <input validate-rules="[['required','请输入$'],['dynrule','checkPhoneEmail']]" validate-title="邮箱/手机号" data-selector="checkEmail" placeholder="请输入常用邮箱/手机号" value="" name="web_user.user_login" class="text info user_email" autocomplete="off">
                </div>
                <div class="login-form">
                    <input type="password" validate-rules="[['required','请输入$'],['length',{min:6,max:16},'$1长度不能$2$3个字符'],['pattern',/^[a-zA-Z0-9]+$/ig,'$只能数字或字母']]" validate-title="密码" placeholder="请输入密码" value="" name="web_user.user_pwd" class="text info" autocomplete="off">
                </div>
                <div data-selector="email-code-wrap" class="login-form">
                    <input type="text" validate-rules="[['required','请输入$']]" validate-title="验证码" placeholder="" value="" name="rand" class="text input-verycode" autocomplete="off">
                    <img class="image-verycode" src="http://www.liepin.com/image/randomcode/"><a href="javascript:;" class="changecode">换一张</a>
                </div>
                <div data-selector="phone-code-wrap" class="login-form hide">
                    <input type="text" validate-rules="[['required','请输入$']]" validate-title="验证码" placeholder="" value="" name="rand" class="text input-verycode" disabled="disabled" autocomplete="off"><a class="btn btn-light btn-phone-code" href="javascript:;" data-selector="phone-code-btn">获取验证码</a>
                </div>
                <div class="button login-form">
                    <input type="submit" class="btn btn-warning" style="background-color:#ff9500;" value="免费注册">
                </div>
                <div validate-rules="[['required','您必须接受$才能注册']]" validate-title="《用户服务协议》" validate-group="checkbox" class="accept login-form">
                    <label>
                        <input type="checkbox" autocomplete="off" checked="checked" class="checkbox" style="display: none;"><i data-name="" class="checkboxui checkboxui-checked" style="margin: 0px 5px 0px 0px;"></i>
                    </label>
                    <span>我已阅读并同意<a target="_blank" href="http://www.liepin.com/user/agreement.shtml">《用户服务协议》</a></span>
                </div>
                <div class="go-login login-form">
                    <p class="muted text-right">已有账号？直接 <a class="goLogin" href="javascript:;">登录&gt;&gt;</a></p>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>