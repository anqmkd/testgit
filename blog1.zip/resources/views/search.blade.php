<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ghost</title>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/app2.css" rel="stylesheet">
    <link rel="stylesheet" href="css/iconfont.css">
    <!--<link href="css/howzhi.css" rel="stylesheet">-->
    <!--<link href="bootstrap.css" rel="stylesheet">-->
    <script src="jquery-1.11.3.min.js"></script>
    <script src="js/bootstrap.js"></script>
</head>
<body class="home-template">
<header class="main-header" style="background-image: url(http://static.ghostchina.com/image/6/d1/fcb3879e14429d75833a461572e64.jpg)">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <a class="branding" href="http://jikexueyuan.com" title="Ghost开源博客">
                    <img src="http://static.ghostchina.com/image/b/46/4f5566c1f7bc28b3f7ac1fada8abe.png">
                    <h2 class="text-hide">
                        Ghost是一个简洁、强大的写作平台。你只专注用文字表达你的你的想法就好,
                        其余的事情就交给Ghost帮你处理就好了
                    </h2>
                    <img src="http://static.ghostchina.com/image/6/d1/fcb3879e14429d75833a461572e64.jpg " class="hide">
                </a>
            </div>
        </div>
    </div>
</header>
<nav class="main-navigation">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-header">
                  <span class="nav-toggle-button collapse" data-target="#main-menu">
                      <span class="sr-only">Toogle navigaton</span>
                      <i class="fa fa-bars"></i>
                  </span>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <ul class="menu">
                        <li class="nav-current" role="presentation">
                            <div class="home-page">
                                <a href="#" ><span class=" glyphicon glyphicon-home"></span>&nbsp;首页</a></div>
                        </li>
                        <li  role="presentation">
                            <div class="about">
                                <a href="#">关于</a></div>
                        </li>
                        <!--<li>-->
                        <!--&lt;!&ndash;<aside class="col-md-4">&ndash;&gt;-->
                        <!-- -->
                        <!--&lt;!&ndash;</aside>&ndash;&gt;-->
                        <!--</li>-->
                        <!--<div class="search">-->
                        <!--<form id="formsearch" action="#" role="search">-->
                        <!--<input type="text" placeholder="搜索文章" class="form-control"/>-->
                        <!--<button class="btn btn-search btn-large" type="submit">-->
                        <!--<span class="glyphicon glyphicon-search"></span>-->
                        <!--</button>-->
                        <!--</form>-->
                        <!--</div>-->
                        <form id="search"   method="post" role="search" onkeydown="if(event.keyCode==13) return setParam();" >
                            <input type="text" name="keyword" class="text" id="keyword" placeholder="输入关键字搜索"required="required" >
                            <input type="hidden" name="_token" value="{{ csrf_token() }}">
                            <span class="glyphicon glyphicon-search" aria-hidden="true"> </span><i class="fa fa-search"></i>
                        </form>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
<section class="content-wrap">
    <div class="wrap">
        <div class="container">
            <div class="row">
                <main class="col-md-9   main-content">
                    @foreach($pages as $page)
                        <article class="post tag-about-ghost tag-ghost-in depth tag-zhu-shou-han-shu">

                            <div class="post-head">
                                <div class="post-category">
                                    <span class="glyphicon glyphicon-bookmark" aria-hidden="true"></span>
                                    <a>编程技法</a>
                                </div>
                                <h5 class="post-title">
                                    <a href="#" style="color: #303030"> {!! nl2br($page->title) !!}</a>
                                </h5>
                                <div class="post-content">
                                    <div class="post-content-show">
                                        &nbsp;<span class="glyphicon glyphicon-user" aria-hidden="true"></span>&nbsp;<a href="#" style="color: #999">king</a>&nbsp;&nbsp;&nbsp;
                                        <span class="glyphicon glyphicon-time" aria-hidden="true"></span><i style="color: #999">&nbsp;{{$page->created_at}}</i>
                                        &nbsp;&nbsp;&nbsp; <span class="glyphicon glyphicon-tag" aria-hidden="true"></span><i style="color: #999">&nbsp;Ghost版本</i>
                                        &nbsp;&nbsp;&nbsp; <span class="glyphicon glyphicon-pencil" aria-hidden="true"></span><i style="color: #999">&nbsp;2</i>
                                    </div>
                                    <p>
                                        {!! $page->content!!} </p>
                                </div>
                                <div class="post-permalink">
                                    <a class="btn btn-default" href="read/{{$page->id}}">阅读全文</a>
                                </div>
                                <div class="post-footer clearfix">
                                    <hr>
                                    <div class="pull-left tag-list">
                                        <i class="fa fa-folder-open-o"></i>
                                        <a href="#">Ghost</a>
                                        <a href="#">新版本发布</a>
                                        <a href="#">Ghost 0.7 版本</a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    @endforeach
                    {{--<div style="text-align: center"> {!!$pages->render()!!}</div>--}}
                </main>
                <aside class="col-md-3 sidebar">
                    <div class="widget1">
                        <h4 class="widget-title widget-title-one">最新发布</h4>
                        <ul>
                            @foreach($publishes as $publish)
                                <li><a href="#">{!!$publish!!}</a></li>
                            @endforeach
                        </ul>
                        <h4 class="widget-title">最近回复</h4>
                        <ul>
                            @foreach($comments as $comment)
                                <li><a href="#">{!!$comment!!}</a></li>
                            @endforeach
                        </ul>
                        <h4 class="widget-title">分类</h4>
                        <ul>
                            @foreach($categoies as $category)
                                <li><a href="#">{!!$category!!}</a></li>
                            @endforeach
                        </ul>
                        <h4 class="widget-title">归档</h4>
                        <ul>
                            @foreach($pages as $page)
                                <li><a href="#">{!!$page->title!!}</a></li>
                            @endforeach
                        </ul>
                        <h4 class="widget-title">友情链接</h4>
                    </div>
                </aside>
            </div>
        </div>
    </div>
</section>
<footer class="main-footer">
    <div class="container ">
        <div class="row ">
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">最新文章</h4>
                    <div class="content recent-post">
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                            <hr class="hr1">
                        </div>
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                            <hr class="hr2">
                        </div>
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">标签云</h4>
                    <div class="content tag-cloud">
                        <a href="#">Ghost</a>
                        <a href="#">新版本发布</a>
                        <a href="#">JavaScript</a>
                        <a href="#">Promise</a>
                        <a href="#">主题</a>
                        <a href="#">MySQL</a>
                        <a href="#">Node.js</a>
                        <a href="#">深度玩转Ghost</a>
                        <a href="#">Ubuntu</a>
                        <a href="#">阿里云服务器</a>
                        <a href="#">Ghost0.7版本</a>
                        <a href="#">Nginx</a>
                        <a href="#">助手函数</a>
                        <a href="#">自定义界面</a>
                        <a href="#">Ghost</a>
                        <a href="#">静态页面</a>
                        <a href="#" style="height: 1.5em">....</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">合作伙伴</h4>
                    <div class="content tag-cloud friend-links">
                        <a href="#">Bootstrap中文网</a>
                        <a href="#">开放CDN服务</a>
                        <a href="#">Grunt中文网</a>
                        <hr>
                        <a href="#">阿里云</a>
                        <hr>
                        <a href="#">又拍云</a>
                        <a href="#">Ucloud</a>
                        <a href="#">七牛云存储</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <span>Copyright &copy:<a href="#">Ghost中文网</a></span>
                <span><a href="#">京ICP备11008151号</a></span> |
                <span>京公网安备11010802014853</span>
            </div>
        </div>
    </div>
</div>
<script>
    function setParam(){
        var val=$('#keyword').val();
        if(val !=' '){
            location.href="/blog?keyword=" + val;
        }
    }
</script>
</body>
</html>