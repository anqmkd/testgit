<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ghost</title>
    <link href="{{asset('css/bootstrap.min2.css')}}" rel="stylesheet">
    <link href="{{asset('css/app3.css')}}" rel="stylesheet">
    <link rel="stylesheet" href="{{asset('css/iconfont.css')}}">
    <!--<link href="css/howzhi.css" rel="stylesheet">-->
    <!--<link href="bootstrap.css" rel="stylesheet">-->
    <script src="{{asset('jquery-1.11.3.min.js')}}"></script>
    <script src="{{asset('js/bootstrap.js')}}"></script>
</head>
<body class="home-template">
<header class="main-header" style="background: #ffffff">
    <div class="container">
        <div class="row">
            <div class="col-md-12 ">
                <a class="branding" href="http://jikexueyuan.com" title="Ghost开源博客">
                    <h2 class="text-hide">
                        Ghost是一个简洁、强大的写作平台。你只专注用文字表达你的你的想法就好,
                        其余的事情就交给Ghost帮你处理就好了
                    </h2>
                    <img src="http://static.ghostchina.com/image/6/d1/fcb3879e14429d75833a461572e64.jpg " class="hide">
                </a>
            </div>
        </div>
    </div>
</header>
<nav class="main-navigation">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="navbar-header">
                  <span class="nav-toggle-button collapse" data-target="#main-menu">
                      <span class="sr-only">Toogle navigaton</span>
                      <i class="fa fa-bars"></i>
                  </span>
                </div>
                <div class="collapse navbar-collapse" id="main-menu">
                    <ul class="menu">
                        <li class="nav-current" role="presentation">
                            <a href="#" class=""><span class=" glyphicon glyphicon-home"></span>&nbsp;首页</a>
                        </li>
                        <li  role="presentation">
                            <a href="#">论坛</a>
                        </li>
                        <li  role="presentation">
                            <a href="#">快捷手册</a>
                        </li>
                        <li role="presentation">
                            <a href="#">中文文档</a>
                        </li>
                        <li role="presentation">
                            <a href="#">下载</a>
                        </li>
                        <li role="presentation">
                            <a href="#">关于</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</nav>
<section class="content-wrap">
    <div class="container">
        <div class="row">
            <main class="col-md-8 main-content">
                <article class="post tag-about-ghost tag-ghost-in depth tag-zhu-shou-han-shu">
                    <div >
                        <div style="text-align: center">
                        <h2>
                            <a href="#" style="color: #303030"> {!! nl2br($page->title) !!}</a>
                        </h2>
                        <div style="margin-top: -40px">
                         <span >
                             作者
                             <a href="#">周宇红</a>
                         </span>
                            <time class="date" datetime="2015年9月26日">2015年9月26日</time>
                        </div></div>
              <p> {!! nl2br($page->body) !!}</p>
               <div class="post-footer clearfix">
                        <hr>
                         <div class="pull-left tag-list">
                            <i class="fa fa-folder-open-o"></i>
                            <a href="#">Ghost</a>
                            <a href="#">新版本发布</a>
                            <a href="#">Ghost 0.7 版本</a>
                        </div>
              <div class="pull-right share">
                            <div class="bdsharebuttonbox share-icons">
                                <a href="#" class="bds_more" data-cmd="more"></a>
                                <a href="#" class="bds_qzone" data-cmd="qzone" title="分享到QQ空间"></a>
                                <a href="#" class="bds_tsina" data-cmd="tsina" title="分享到新浪微博"></a>
                                <a href="#" class="bds_tqq" data-cmd="tqq" title="分享到腾讯微博"></a>
                                <a href="#" class="bds_renren" data-cmd="renren" title="分享到人人网"></a>
                                <a href="#" class="bds_weixin" data-cmd="weixin" title="分享到微信"></a>
                            </div></div>
                        <script>
                            window._bd_share_config={"common":{"bdSnsKey":{},"bdText":"","bdMini":"2","bdMiniList":false,"bdPic":"","bdStyle":"0","bdSize":"24"},"share":{}};with(document)0[(getElementsByTagName('head')[0]||body).appendChild(createElement('script')).src='http://bdimg.share.baidu.com/static/api/js/share.js?v=89860593.js?cdnversion='+~(-new Date()/36e5)];
                        </script>
                   <script type="text/javascript">
                            var _bdhmProtocol = (("https:" == document.location.protocol) ? " https://" : " http://");
                            document.write(unescape("%3Cscript src='" + _bdhmProtocol + "hm.baidu.com/h.js%3F6338835ad35c6d950a554fdedb598e48' type='text/javascript'%3E%3C/script%3E"));
                        </script>
                        </div>
                    <div class="st-query-present" style="display: none;"></div>
                        </div>
                    <div class="comment-sign">已有 <?php echo count($lists);?>条评论</div>
                    <div id="comments" >
                        @foreach($lists as $list)
                            <ol class="comment-list">
                                <li>
                                    <div class="comment-author">
                                <span itemprop="image">
                                <img class="avatar" src="http://gravatar.duoshuo.com/avatar/89312e036fb8a745525846968000c0ee?s=32&amp;r=G&amp;d=" alt="Ldeepin" width="32" height="32">
                               </span>
                                        <cite class="fn" itemprop="name"><a href="https://blog.justforfun.top" rel="external nofollow"></a>{{ $list['comment']['nickname'] }}</cite>
                                    </div>
                                    <div class="comment-meta">
                                        <a href="http://blog.lucode.net/linux/archlinux-install-tutorial.html#comment-20"><time itemprop="commentTime" datetime="2015-04-03T15:55:44+08:00">{{$list['comment']['created_at']}}</time></a>
                                    </div>
                                    <div class="comment-content" itemprop="commentText">
                                        <p>{{ $list['comment']['content']}}</p>
                                    </div>
                                    <div class="comment-reply">
                                        <a href="#text-reply" rel="nofollow" class="replyComment" onclick="sendUid({{$list['comment']['user_id']}})">回复</a></div>
                                    <div class="comment-children" itemprop="discuss">
                                        @foreach($list['reply'] as $arr)
                                            <ol class="comment-list">
                                                <li itemscope="" itemtype="http://schema.org/UserComments" id="comment-25" class="comment-body comment-child comment-level-odd comment-odd comment-by-author">
                                                    <div class="comment-author" itemprop="creator" itemscope="" itemtype="http://schema.org/Person">
                                                        <span itemprop="image"><img class="avatar" src="{{ $arr['pic'] }}?s=32&amp;r=G&amp;d=" alt="codesun" width="32" height="32"></span>
                                                        <cite class="fn" itemprop="name"><a href="http://www.lucode.net" rel="external nofollow">{{$arr['user_name']}}<a href="#">回复</a><i>{{$arr['reply_name']}}</i></a></cite>
                                                    </div>
                                                    <div class="comment-meta">
                                                        <a href="http://blog.lucode.net/linux/archlinux-install-tutorial.html#comment-25"><time itemprop="commentTime" datetime="2015-06-04T14:39:50+08:00">{{$arr['updated_at']}}</time></a>
                                                    </div>
                                                    <div class="comment-content" itemprop="commentText">
                                                        <p >{{ $arr['rpl_content']}}</p> <div class="comment-reply">
                                                            <a href="#text-reply"
                                                               rel="nofollow"  class="replyComment" onclick="sendUid({{$arr['user_id']}})">回复</a>
                                                        </div>
                                                    </div>
                                                </li>
                                            </ol>
                                            @endforeach
                                    </div>
                                </li>
                            </ol>
                        @endforeach
                    </div>
                    <hr>
                    <p style="text-align: center">快来评论吧</p>
                    <a  class="ds-avatar">
                        <img src="http://ds.cdncache.org/avatar-50/41/195566.jpg">
                    </a>
                    <div class=" ds-replybox">
                        <form method="post" action=" {{url('comments/create')}}" role="form">
                            <input type="hidden" name="page_id" value="{{$id}}">
                            <input type="hidden" name="type_id"  id="type">
                            <input type="hidden" name="uid" id="u_id">
                            <input type="hidden" name="_token" value="{{ csrf_token() }}" />
                            <div class="ds-textarea-wrapper ds-rounded-top">
                                <textarea  class="form-control" rows="4" placeholder="文章写起来挺不容易的，对您有帮助，就请留个赞"  name="content" id="text-reply" ></textarea>
                            </div>
                            <div class="post-options">
                                <div class="cfq">&nbsp;&nbsp;&nbsp;&nbsp;<i><span class="glyphicon glyphicon-user" aria-hidden="true" style="color: #e67e22"></span>&nbsp;</i>
                                    <input type="text" name="author" id="author" class="text" placeholder="昵称" required="required" style="width: 180px"  >
                                    &nbsp;&nbsp;&nbsp;&nbsp;<i><span class="glyphicon glyphicon-envelope" aria-hidden="true" style="color: #e67e22"></span></i>
                                    <input type="text" name="email" id="author" class="text" placeholder="邮箱" required="required" style="width: 180px">
                                    <i><span class="glyphicon glyphicon-home" aria-hidden="true" style="color: #e67e22"></span></i>
                                    <input type="text" name="social" id="author" class="text" placeholder="新浪微博"  style="width: 120px">
                                    <button class="ds-post-button" type="submit" id="send" style="background: #72c9e4">发布</button><div class="ds-toolbar-buttons">
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </article>
            </main>
            <aside class="col-md-4 sidebar">
                <div class="widget">
                    <h4 class="title">社区</h4>
                    <div class="content community">
                        <p>QQ群:123456789</p>
                        <p> <a href="#"> <i class="hz-icon icon-weibo"></i></a>
                            <a href="#">问答社区</a>
                        </p>
                        <p>
                            <a href="#"> <i class="hz-icon icon-weibo"></i></a>
                            <a href="#">官方微博</a>
                        </p>
                    </div>
                </div>
                <div class="widget">
                    <h4 class="title">下载Ghost</h4>
                    <div class="content-download">
                        <a href="#" class="btn btn-default btn-block">Ghost中文版(0.6.3)</a>
                    </div>
                </div>
                <div class="widget">
                    <h4 class="title">标签云</h4>
                    <div class="content tag-cloud">
                        <a href="#">Ghost</a>
                        <a href="#">新版本发布</a>
                        <a href="#">JavaScript</a>
                        <a href="#">Promise</a>
                        <a href="#">主题</a>
                        <a href="#">MySQL</a>
                        <a href="#">Node.js</a>
                        <a href="#">深度玩转Ghost</a>
                        <a href="#">Ubuntu</a>
                        <a href="#">阿里云服务器</a>
                        <a href="#">Ghost0.7版本</a>
                        <a href="#">Nginx</a>
                        <a href="#">自定义界面</a>
                        <a href="#">助手函数</a>
                        <a href="#">静态页面</a>
                        <a href="#">Ghost</a>
                    </div>
                </div>
            </aside>
        </div>
    </div>
</section>
<footer class="main-footer">
    <div class="container ">
        <div class="row ">
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">最新文章</h4>
                    <div class="content recent-post">
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                            <hr class="hr1">
                        </div>
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                            <hr class="hr2">
                        </div>
                        <div class="recent-single-post">
                            <a href="#">Ghost 0.7.0 正式发布</a>
                            <div class="date">Mar 4 2015</div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">标签云</h4>
                    <div class="content tag-cloud">
                        <a href="#">Ghost</a>
                        <a href="#">新版本发布</a>
                        <a href="#">JavaScript</a>
                        <a href="#">Promise</a>
                        <a href="#">主题</a>
                        <a href="#">MySQL</a>
                        <a href="#">Node.js</a>
                        <a href="#">深度玩转Ghost</a>
                        <a href="#">Ubuntu</a>
                        <a href="#">阿里云服务器</a>
                        <a href="#">Ghost0.7版本</a>
                        <a href="#">Nginx</a>
                        <a href="#">助手函数</a>
                        <a href="#">自定义界面</a>
                        <a href="#">Ghost</a>
                        <a href="#">静态页面</a>
                        <a href="#" style="height: 1.5em">....</a>
                    </div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="widget">
                    <h4 class="title">合作伙伴</h4>
                    <div class="content tag-cloud friend-links">
                        <a href="#">Bootstrap中文网</a>
                        <a href="#">开放CDN服务</a>
                        <a href="#">Grunt中文网</a>
                        <hr>
                        <a href="#">阿里云</a>
                        <hr>
                        <a href="#">又拍云</a>
                        <a href="#">Ucloud</a>
                        <a href="#">七牛云存储</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<div class="copyright">
    <div class="container">
        <div class="row">
            <div class="col-sm-12">
                <span>Copyright &copy:<a href="#">Ghost中文网</a></span>
                <span><a href="#">京ICP备11008151号</a></span> |
                <span>京公网安备11010802014853</span>
            </div>
        </div>
    </div>
</div>
<script>
 $(".replyComment").click(function(){
    $("#type").val("1");
 });
function sendUid($uid){
$("#u_id").val($uid);
}
</script>
</body>
</html>