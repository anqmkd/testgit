你已经是{{$service['name']}}<br>
@if ($service['type'] == 1)
<a href="/upgrade">升级为金牌会员</a>
@endif
