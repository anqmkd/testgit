<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
//用户个人主页
Route::get('profile','UserController@profile');
//用户会员级别
Route::get('service','UserController@service');
//付费会员页面
Route::get('subscription','UserController@subscription');
//处理收费逻辑
Route::post('subscribe','UserController@subscribe');
//升级到更高级别
Route::get('upgrade','UserController@upgrade');
//支付宝处理
Route::get('alipay/pay','AlipayController@pay');
//支付后跳转页面
Route::post('alipay/return','AlipayController@result');
Route::resource('/register','PagesController@register');
Route::resource('/comments/create','CommentsController');
Route::get('/read/{id}','PagesController@read');
Route::resource('/blog','HomeController@index');
Route::post('/blog/search','HomeController@search');
Route::get('/blog/search/{id}','HomeController@publish');
Route::get('pages/{id}','PagesController@show');              //获取每篇博文的详细信息
Route::post('comment/store','CommentsController@store');
//路由组,用于后台管理
Route::group(['prefix'  => 'admin', 'namespace' => 'Admin', 'middleware' =>'auth'],function()
{
Route::get('/','AdminHomeController@index');
Route::resource('pages','PagesController');
Route::resource('comments','CommentsController');
});
Route::get('auth/login', 'Auth\AuthController@getLogin');
Route::post('auth/login', 'Auth\AuthController@postLogin');
Route::get('auth/logout', 'Auth\AuthController@getLogout');
Route::get('pages/{id}','PagesController@show');
Route::resource('/password/email','Auth\PasswordController@index');
Route::get('auth/register','Auth\AuthController@getRegister');
Route::post('auth/register','Auth\AuthController@postCreate');
//引导用户到新浪微博的登录授权页面
Route::get('auth/weibo','Auth\AuthController@weibo');
//用户授权后新浪微博的回调页面
Route::get('auth/callback','Auth\AuthController@callback');
Route::any('foo',function()
{
  return "hello world";

});