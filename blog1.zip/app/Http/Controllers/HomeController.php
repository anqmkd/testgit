<?php

namespace App\Http\Controllers;
header("content-type:text/html;charset=utf-8");
use Illuminate\Http\Request;
use App\Parsedown;
use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Page;
use Illuminate\Support\Facades\DB;
class HomeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return Response
     */

    public function index()
    {
        $keyword= isset($_POST['keyword'])?$_POST['keyword']:null;
        $keyword= trim($keyword);
        $parsedown=new Parsedown();
        $cnt=DB::select("SELECT  COUNT(1) cnt FROM comments  GROUP BY page_id");
        if($keyword!= null){
            $obj=DB::select("select * from pages where body like'%{$keyword}%' ");
        }else{
        $obj =Page::all();
        }
        foreach($obj as $arr)
       {
           $arr->title= ($parsedown->text($arr->title));
           $arr->body= ($parsedown->text($arr->body));
        }
        //$obj=$parsedown->parse($obj);
    $publish= DB::select("SELECT  title,id from pages order by created_at limit 5");
    $comment= DB::select("select content,page_id from comments order by created_at limit 5");
    //$cate=DB::select("SELECT `categoies`.`cate_name`  FROM `categoies` LEFT JOIN  `pages`  ON  `categoies`.`id`=`pages`.`cate_id` WHERE `categoies`.`id`=`pages`.`cate_id`");
    $categoies= DB::table('categoies')->orderBy('created_at','desc')->take(10)->lists('cate_name');
     return view('home')->with('pages',$obj)
        ->with('publishes',$publish)
        ->with('comments',$comment)
        ->with('categoies',$categoies)->with('cate',$categoies);
    }

    public function search($id)
    {

        $keyword= isset($_POST['keyword'])?$_POST['keyword']:null;
        $keyword= trim($keyword);
        $parsedown=new Parsedown();
        if($keyword!= null){
            $res=DB::select("select * from pages where body like'%{$keyword}%' ");
        }
        foreach($res as $arr){
            $arr->title=$parsedown->text($arr->title);
            $arr->body=$parsedown->text($arr->body);
        }
        return view('search')->with('pages',$res);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  Request  $request
     * @return Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  Request  $request
     * @param  int  $id
     * @return Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return Response
     */
    public function destroy($id)
    {
        //
    }
}
