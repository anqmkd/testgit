<?php

namespace App\Http\Controllers;
use Laravel\Cashier\Billable;
use Illuminate\Http\Request;
use App\User;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class UserController extends Controller
{
    public function profile(Request $request)
    {
        $user = $request->user();
        return redirect('service');
    }

    public function service(Request $request){
        $user = $request->user();
        //$invoices = $user->invoices();

            if (!$user->subscribed()) {
            return redirect('subscription');
        }
        if($user->onPlan('silver')){
            $service = ['type'=>1,'name'=>'银牌会员'];
        }else{
            $service = ['type'=>2,'name'=>'金牌会员'];
        }
        return view('user.service',['service'=>$service]);
    }

    public function subscription(Request $request)
    {
        $user = $request->user();
        if($user->subscribed()){
            return redirect('service');
        }
        return view('user.subscription');
    }

    public function subscribe(Request $request)
    {
        $plan = $request->input('plan');
        $creditCardToken = $request->input('stripeToken');

        $user = $request->user();
        $user->subscription($plan)->create($creditCardToken);
        if($user->save()){
            return redirect('service');
        }else{
            return back()->withInput();
        }
    }

    public function upgrade(Request $request){
        $user = $request->user();
        if (!$user->subscribed()) {
            return redirect('subscription');
        }
        if($user->onPlan('gold')){
            exit('您已经是金牌会员了');
        }
        try{
            $user->subscription('gold')->swap();
        }catch(Exception $ex){
            exit('升级失败！');
        }
        return redirect('service');

    }
}
