<?php

namespace App\Http\Controllers\Auth;
use Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;
use Input;
use App\User;
use Validator;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */
   protected $redirectPath='/admin';
    use AuthenticatesAndRegistersUsers, ThrottlesLogins;
    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {   
        $this->middleware('guest', ['except' => 'getLogout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'name' => 'required|max:255',
            'email' => 'required|email|max:255|unique:users',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        return User::create([
            'name' => $data['name'],
            'email' => $data['email'],
            'password' => bcrypt($data['password']),
        ]);
    }

    public function getRegister(){
        return view('auth.register');
    }
    // public function authenticate(){
    //     $email=Input::get('eamil');
    //     $password=Input::get('password');
    // }

    public function postCreate(Request $request){

    $this->validate($request,
        [
            'name'                             =>'required|unique:users,name|max:255',
            'email'                            =>'required',
            'password'                         =>'required|min:6',
            'password_confirmation'            =>'required',
        ]);
    $user=new User();
    $user->name=Input::get('name');
    $user->email=Input::get('email');
    $user->password=(Input::get('password'));
    if($user->save()){
        return Redirect::to('auth/login')->with('message','注册成功!');
    }else{
        return Redirect::back()->with('message','注册失败');
    }
    }
}
