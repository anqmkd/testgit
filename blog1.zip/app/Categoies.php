<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Categoies extends Model
{
    //
    protected  $table="categoies";
    public function hasManyPage(){
        return $this->hasMany('App\Page','id','cate_id');
    }
}

