<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Page;
class PageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Page::create(
        [
        'title'              =>'MVC的基本流程', 
        'body'               =>'MVC在laravel中，最常见的流程就是这个样子的，
                                  我们在实现某个功能的时候，
                                    通常就是走上面的这个流程。比如我们这个blog项目中，
                                      我们需要实现下面的功能：'
        ]

    );
    }
}
