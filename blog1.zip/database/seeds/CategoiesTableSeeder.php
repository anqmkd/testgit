<?php
/**
 * Created by PhpStorm.
 * User: zhouyuhong
 * Date: 2015/10/21
 * Time: 20:07
 */
use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Categoies;
class CategoiesTableSeeder extends Seeder
{
    public function run()
    {



        Categoies::create(
            [
                'cate_id' => 3,
                'cate_name' => '编译原理',
            ]);
        Categoies::create(
            [
                'cate_id' => 4,
                'cate_name' => '设计模式',
            ]);
        Categoies::create(
            [
                'cate_id' => 5,
                'cate_name' => '通讯协议',
            ]);
        Categoies::create(
            [
                'cate_id' => 6,
                'cate_name' => '杂谈',
            ]);
        Categoies::create(
            [
                'cate_id' => 7,
                'cate_name' => 'D语言',
            ]);
        Categoies::create(
            [
                'cate_id' => 8,
                'cate_name' => '程序库',
            ]);
        Categoies::create(
            [
                'cate_id' => 9,
                'cate_name' => 'web服务器',
            ]);
        Categoies::create(
            [
                'cate_id' => 10,
                'cate_name' => '编程技法',
            ]);
    }
}

