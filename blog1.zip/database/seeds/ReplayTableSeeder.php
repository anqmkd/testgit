<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Replay;
class ReplayTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Replay::create(
        [
        'content'                          =>'哎呀，字打错了，谢谢指正^_^',
        'user_name'                    =>'codezhou',
        'comment_id'                  =>1,
        ]);
    }
}
