<?php
namespace Designer\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Designer\Model\TemplateTable;
use Designer\Model\MainTable;
use Designer\Model\UserTable;
use Designer\Model\UserinfoTable;
use Designer\Model\PreviewTable;
use Designer\Model\PayTable;

use Designer\Lib\Fileupload;
use \ZipArchive;
use \DOMDocument;

//session_start();
class ApiController extends AbstractActionController
{
	public $showurl = 'http://csm.coolyun.com/designer/';
	
	public $designerxml = '/home/wwwroot/app/public/designerxml/';
        public $templatezip = '/home/wwwroot/app/public/designerxml/themetool.zip';
	public $designerfold = '/home/wwwroot/app/public/designer/';
	
	public $datadescription = "datadescription.xml";
	public $property = "com.yulong.android/properties.xml";
	public $description = "description.xml";
        public $addurl = 'theme/';
        	
	protected $templateTable;
        protected $mainTable;
        protected $userTable;
        protected $userinfoTable;
        protected $previewTable;
        protected $payTable;

	public $callback = "";
        public $zipfile = "zipfile/";
        public $tdesign = "/designer/";
    public function indexAction()
    {        
	$this->callback = isset($_REQUEST['callback'])?$_REQUEST['callback']:'';
    	$act = isset($_REQUEST['act'])?$_REQUEST['act']:'';
         
        if(empty($_COOKIE['templateuser'])){
              $_REQUEST['uid'] = '';
        }else{
           $loginuser = file_get_contents("http://developer.coolyun.com/actionapi.php?sid=".$_COOKIE['templateuser']);          
           $loginarr = json_decode($loginuser,true);
           $_REQUEST['uid'] = isset($loginarr['userid'])?$loginarr['userid']:'';
           
        }

    	if($act == "create_template"){
    		$this->createtemplate();
    	}
        else if($act == "get_userinfo"){
                $this->getuser();
        }
        else if($act == "finish_template"){
                $this->finishtemplate();
        }
        else if($act == "get_type_list"){
                $this->gettypelist();
        }
    	else if($act == "get_template_list"){
    		$this->getlist();
    	}else if($act == "upload_resource"){
			$this->uploadpng();
		}else if($act == "download_resource"){
			$this->downloadrar();
		}else if($act == "set_description_value"){
			$this->editproperty();
		}else if($act == "delete_template"){
			$this->deltemplate();
		}else{
			die($this->callback."(".json_encode(array("result" => -1,"message" => "非法的act=".$act)).")");
		}
    }

    public function gettypelist(){
        $typeList = array(
              array("typeid" => 2,"typename" => "简约"),
              array("typeid" => 3,"typename" => "卡通"),
              array("typeid" => 4,"typename" => "爱情"),
              array("typeid" => 5,"typename" => "酷炫"),
              array("typeid" => 6,"typename" => "创意"),
              array("typeid" => 7,"typename" => "其他"), 
        );

        die($this->callback."(".json_encode(array("result" => 0,"message" => "成功获取分类列表","data" => array("list" => $typeList))).")");
    }

    public function getPayTable()
    {
        if (!$this->payTable) {
                $sm = $this->getServiceLocator();
                $this->payTable = $sm->get('Designer\Model\PayTable');
        }
        return $this->payTable;
    }

    public function getMainTable()
    {
        if (!$this->mainTable) {
                $sm = $this->getServiceLocator();
                $this->mainTable = $sm->get('Designer\Model\MainTable');
        }
        return $this->mainTable;
    }

    public function getUserTable()
    {
        if (!$this->userTable) {
                $sm = $this->getServiceLocator();
                $this->userTable = $sm->get('Designer\Model\UserTable');
        }
        return $this->userTable;
    }

    public function getUserinfoTable()
    {
        if (!$this->userinfoTable) {
                $sm = $this->getServiceLocator();
                $this->userinfoTable = $sm->get('Designer\Model\UserinfoTable');
        }
        return $this->userinfoTable;
    }

    public function getPreviewTable()
    {
        if (!$this->previewTable) {
                $sm = $this->getServiceLocator();
                $this->previewTable = $sm->get('Designer\Model\PreviewTable');
        }
        return $this->previewTable;
    }


    public function readxmlfile($xmlfile,$key){
                $doc = new DOMDocument();
                $doc->load($xmlfile);

                $root = $doc->getElementsByTagName('root');
                $root = $root->item(0);
                $itemlist = $root->getElementsByTagName('item');

                foreach ($itemlist as $rootdata)
                {
                        $attribValue = $rootdata->getAttribute("key");
                        if($attribValue==$key){
                            return $rootdata->getAttribute("value");    
                        }else{
                            continue;
                        }
                }                
        
    }

    public function savexmlfile($xmlfile,$arrdata){
                $doc = new DOMDocument();
                $doc->load($xmlfile);

                $root = $doc->getElementsByTagName('root');
                $root = $root->item(0);
                $itemlist = $root->getElementsByTagName('item');

                foreach ($itemlist as $rootdata)
                {
                        $attribValue = $rootdata->getAttribute("key");
                        foreach($arrdata as $k=>$val){
                            if($attribValue == $k){
                                $rootdata->setAttribute('value',$val); 
                            }else{
                                continue;
                            }
                        }
                       
                }
                $doc->save($xmlfile);
                return true;
    }

        public function finishtemplate(){

                $uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
                if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
                $tid = isset($_REQUEST['tid'])?$_REQUEST['tid']:'';
                if($tid == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板ID为空")).")"); }
                $dataobj = $this->getTemplateTable()->getAppData(array("uid" => $uid,"valid" => 1,"tid" => $tid));
                if($dataobj->count()==0){
                        die($this->callback."(".json_encode(array("result" => -1,"message" => "模板不存在")).")");
                }

                $tfolder = $dataobj->url;
				
                $typeListArr = array('','','简约','卡通','爱情','酷炫','创意','其他');
                $typeid = $dataobj->typeid;
                $typename = $typeListArr[$typeid];

                $myxmlfile = $this->designerfold.$tfolder.$this->addurl.$this->description;
 
                        $authordata = $this->getUserinfoTable()->getAppData(array("userid" => $uid));
                        $author = "";
                        $cyname = "";
                        if($authordata->count()>0){
                             $author = $authordata->devname;
                        }

                        $userdata = $this->getUserTable()->getAppData(array("userid" => $uid));
                        if($userdata->count()>0){
                             $cyname = $userdata->username;
                        }

                        $cpid = $tid;
                        

                $ischarge = 0;
                $appid = '';
                $waresid = '0';
                $price = $this->readxmlfile($myxmlfile,"price");
                $price = intval($price);
                if($price > 0){
                    $pricedata = $this->getPayTable()->getAppData(array("warename" => "主题","price" => "".$price*100));
                    if($pricedata->count()>0){
                         $ischarge = 1;
                         $appid = $pricedata->appid;
                         $waresid = $pricedata->waresid;

                         
                    }
                  
                }
                $myarrdata = array("cyname" => $cyname,"ischarge" => $ischarge,"appid" => $appid,
                		"waresid" => $waresid,"cpid" => $cpid,"insertname" => $uid,"author" => $author,"classify"=>$typename);
                $this->savexmlfile($myxmlfile,$myarrdata);
 
                $tname = $this->readxmlfile($myxmlfile,"label-zh-rCN");
                $note = $this->readxmlfile($myxmlfile,"label");

                $keyword = $this->readxmlfile($myxmlfile,"keyword");
                
                $slen = strlen($tfolder) - 1;
                $tstr = substr($tfolder,0,$slen);
                $tpath = $this->designerfold.$tstr;
                $filezipname = $uid."_".$tid.".zip";
                $creatfiledir  = $this->designerfold.$this->zipfile.date('Ymd').'/';
                if(!is_dir($creatfiledir)) mkdir($creatfiledir);
                $filename = $creatfiledir.$filezipname;
                @unlink($filename);
                
                $zip = new ZipArchive();
                if ($zip->open($filename, ZIPARCHIVE::CREATE)!==TRUE) {
                        die($this->callback."(".json_encode(array("result" => -1,"message" => "创建打包文件失败")).")");
                }              
                $files = $this->listdir($tpath);
                foreach($files as $path)
                {
                        $fileinfoarr = pathinfo($path);
                        $fpath = str_replace($this->designerfold.$tfolder,"",$path);
                        $zip->addFile($path,$fpath);
                }
                $zip->close();
//                 Logs::write($filename, 'debug');
                if(file_exists($filename)){
                        
                        $urlzip = $this->tdesign.$this->zipfile.date('Ymd').'/'.$filezipname;             
                        
                        $filesize = filesize($filename);
                        $md5 = md5_file($filename);
                        $identity = sprintf("%u", crc32($filename));
                        $cpid = $tid;

                        $ziptabledata = $this->getMainTable()->getAppData(array("identity" => $identity));                                              

                        $tempadddata = array(
                             "identity" => $identity,
                             "cpid" => $cpid,
                             "type" => $typeid,
                             "name" => $tname,
                             "note" => $note,
                             "keystr" => $keyword,
                             "url" => $urlzip,
                             "size" => $filesize,
                             "md5" => $md5,
                             "author" => $author,
                             "folder" => $tfolder,
                             "ischarge" => $ischarge,
                             "appid" => $appid,
                             "waresid" => $waresid,
                             "insert_user" => $uid,
                             "cyname" => $cyname,
                        	 "update_time" => date('Y-m-d H:i:s'),
                        );

                        if($ziptabledata && $ziptabledata->count()>0){
                             unset($tempadddata['insert_user']);
                             $zipid = $ziptabledata->id;
                             $tempadddata['id'] = $zipid;
                             $this->getMainTable()->updateData($tempadddata);                            
                             die($this->callback."(".json_encode(array("result" => 0,"message" => "模板制作完成","data" => "")).")");

                        }

                        $this->getMainTable()->saveArr($tempadddata);

                        die($this->callback."(".json_encode(array("result" => 0,"message" => "模板制作完成","data" => "")).")");
    
                }else{
                        die($this->callback."(".json_encode(array( "result" => -1,"message" => "打包脚本失败" )).")");
                }


        }


	public function getuser(){
                $uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
                if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
                die($this->callback."(".json_encode(array("result" => 0,"message" => "用户已登录","data" => "")).")");
        }
	public function deltemplate(){
	
		$uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
		if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }

		$tid = isset($_REQUEST['tid'])?$_REQUEST['tid']:'';
		if($tid == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板ID为空")).")"); }
		
		$dataobj = $this->getTemplateTable()->getAppData(array("uid" => $uid,"valid" => 1,"tid" => $tid));
		if($dataobj->count()==0){
			die($this->callback."(".json_encode(array("result" => -1,"message" => "模板不存在")).")");
		}
		$id = $dataobj->id;
		$this->getTemplateTable()->updateData(array("id" => $id,"valid" => 0));
		die($this->callback."(".json_encode(array("result" => 0,"message" => "删除模板成功","data" => "")).")");
		/*
		$tfolder = $dataobj->url;
		$tempfolder = $this->designerfold.$tfolder;
		$id = $dataobj->id;
		$this->getTemplateTable()->deldata( array('id' => $id) );
		$this->deldir($tempfolder);
		*/
	}
		
	public function deldir($dir) {
		$dh=opendir($dir);
		while ($file=readdir($dh)) {
			if($file!="." && $file!="..") {
				$fullpath=$dir."/".$file;
				if(!is_dir($fullpath)) {
					unlink($fullpath);
				} else {
					$this->deldir($fullpath);
				}
			}
		}	 
		closedir($dh);
		if(rmdir($dir)) {
			return true;
		} else {
			return false;
		}
	}	
	
	public function editproperty(){		
		$uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
                $tuid = isset($_REQUEST['tuid'])?(int)$_REQUEST['tuid']:0;
                if($tuid){
                    $uid = $tuid;
                }

		if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }

		$tid = isset($_REQUEST['tid'])?$_REQUEST['tid']:'';
		if($tid == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板ID为空")).")"); }

		$filepath = isset($_REQUEST['filepath'])?$_REQUEST['filepath']:'';
		if($filepath == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "filepath为空")).")"); }

		$key = isset($_REQUEST['key'])?$_REQUEST['key']:'';
		if($key == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "key为空")).")"); }

		$value = isset($_REQUEST['value'])?$_REQUEST['value']:'';
		if($value == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "value为空")).")"); }
		
		$dataobj = $this->getTemplateTable()->getAppData(array("uid" => $uid,"valid" => 1,"tid" => $tid));
		if($dataobj->count()==0){
			die($this->callback."(".json_encode(array("result" => -1,"message" => "模板不存在")).")");
		}
		
		$setflag = false;
		$otherflag = false;
		
		$tfolder = $dataobj->url;
		$tempfolder = $this->designerfold.$tfolder;
		$xmlfile = $tempfolder.$filepath;
		
		$doc = new DOMDocument();
		$doc->load($xmlfile);
		
		$root = $doc->getElementsByTagName('root');
		$root = $root->item(0);
		$itemlist = $root->getElementsByTagName('item');
		$setflag = $this->setxmldata($itemlist,$key,$value,$xmlfile,$doc,"");
		
		$dataxml = $tempfolder.$this->addurl.$this->datadescription;
		$docnew = new DOMDocument();
		$docnew->load($dataxml);
		$rootnew = $docnew->getElementsByTagName('root');
		$rootnew = $rootnew->item(0);
		$itemlistnew = $rootnew->getElementsByTagName('item');	
		$otherflag = $this->setxmldata($itemlistnew,$key,$value,$dataxml,$docnew,$filepath);
		
		/*
		if($filepath == $this->property){			
			$itemlistnew = $diritem->getElementsByTagName('item');					
		}
		*/
		if($setflag && $otherflag){
			die($this->callback."(".json_encode(array("result" => 0,"message" => "设置属性成功","data" => "")).")");
		}else{
			die($this->callback."(".json_encode(array("result" => -1,"message" => "设置属性失败","data" => "")).")");
		}
		
	}
	
	public function setxmldata($itemlist,$key,$value,$xmlfile,$docobj,$fileurl){
		foreach ($itemlist as $rootdata)
		{
			$attribValue = $rootdata->getAttribute("key");			
			if($fileurl != ''){
				$attr_id = $rootdata->getAttribute("id");
				if($attr_id == $fileurl && $attribValue == $key){
					$rootdata->setAttribute('value',$value);
					$docobj->save($xmlfile);
					return true;
				}else{
					continue;
				}
			}else if($fileurl == ''){
                                if( $attribValue == $key){
				    $rootdata->setAttribute('value',$value);
				    $docobj->save($xmlfile);
				    return true;
                                }else{
                                        continue;
                                }					
			}			
			continue;
			/*
			foreach ($rootdata->attributes as $attrib)
			{			
				$attribValue = $attrib->nodeValue; 
				if ($attribValue == $key)
				{
					if($fileurl != '' && $attribValue == $fileurl){
						$rootdata->setAttribute('value',$value);
						$docobj->save($xmlfile);
						return true;
					}else if($fileurl == ''){
						$rootdata->setAttribute('value',$value);
						$docobj->save($xmlfile);
						return true;					
					}
				}
				continue;
			}
			*/
		}
	}	
	
	public function downloadrar(){
		$uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
		if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
		$tid = isset($_REQUEST['tid'])?$_REQUEST['tid']:'';
		if($tid == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板ID为空")).")"); }
		$dataobj = $this->getTemplateTable()->getAppData(array("uid" => $uid,"valid" => 1,"tid" => $tid));
		if($dataobj->count()==0){
			die($this->callback."(".json_encode(array("result" => -1,"message" => "模板不存在")).")");
		}
		
		$tfolder = $dataobj->url;
		$slen = strlen($tfolder) - 1;
		$tstr = substr($tfolder,0,$slen);
		$tpath = $this->designerfold.$tstr;
		//$filezipname = date("Ymd")."_".$tid.".zip";	
                $filezipname = $uid."_".$tid.".zip";
		$filename = $this->designerfold.$this->zipfile.$filezipname; 

		$zip = new ZipArchive();
		if ($zip->open($filename, ZIPARCHIVE::CREATE)!==TRUE) {     
			die($this->callback."(".json_encode(array("result" => -1,"message" => "创建打包文件失败")).")");
		}     
		@unlink($filename);
		$files = $this->listdir($tpath);     
		foreach($files as $path)     
		{
			$fileinfoarr = pathinfo($path);
			$fpath = str_replace($this->designerfold.$tfolder,"",$path);
			$zip->addFile($path,$fpath);    
		}    
		$zip->close();
		if(file_exists($filename)){					
			$zipurl = $this->showurl.$this->zipfile.$filezipname;
			die($this->callback."(".json_encode(array( "result" => 0,"message" => "成功获取模板下载地址","data" => array("url" => $zipurl) )).")");			
		}else{
			die($this->callback."(".json_encode(array( "result" => -1,"message" => "打包脚本失败" )).")");
		}
	}
	
	public function listdir($start_dir) {    
		$files = array();    
		if (is_dir($start_dir)) {    
		$fh = opendir($start_dir);    
		while (($file = readdir($fh)) !== false) {    
			if (strcmp($file, '.')==0 || strcmp($file, '..')==0) continue;    
			$filepath = $start_dir . '/' . $file;
			if ( is_dir($filepath) )    
				$files = array_merge($files, $this->listdir($filepath));    
			else    
				array_push($files, $filepath);    
		}    
		closedir($fh);    
		} else {    
			$files = false;    
		}    
		return $files;    
	}    	

    public function uploadpng()
    {
		$uid = isset($_REQUEST['uid'])?(int)$_REQUEST['uid']:0;
		if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
		$tid = isset($_REQUEST['tid'])?$_REQUEST['tid']:'';
		if($tid == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板ID为空")).")"); }
		$key = isset($_REQUEST['key'])?$_REQUEST['key']:'';
		if($key == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "键值key为空")).")"); }		
		$upname = isset($_REQUEST['up_name'])?$_REQUEST['up_name']:'';
		if($upname == ''){ die($this->callback."(".json_encode(array("result" => -1,"message" => "up_name为空")).")"); }		
		
		//$key = substr($key,1);
		$keyarr = explode("/",$key);
		$newfile = end($keyarr);
		$keystr = str_replace($newfile,"",$key);
		$dataobj = $this->getTemplateTable()->getAppData(array("uid" => $uid,"valid" => 1,"tid" => $tid));
		if($dataobj->count()==0){
			die($this->callback."(".json_encode(array("result" => -1,"message" => "模板不存在")).")");
		}
		
		$tfolder = $dataobj->url;
		$uploaddir = $this->designerfold.$tfolder.$keystr;  
		$upfos = new Fileupload($upname);
		$fileext = $upfos->getExt();
		//if( $fileext != "png" || $fileext != "jpg" || $fileext != "jpeg" )
                if(!in_array($fileext, array("png","jpg","jpeg")))
		{
			die($this->callback."(".json_encode(array("result" => -1,"message" => "上传失败，上传png图片")).")");
		}
		$result = $upfos->upload($uploaddir,$newfile);
		if(!$result){
			$fileurl = $this->showurl.$tfolder.$key;
			die($this->callback."(".json_encode(array("result" => 0,"message" => "上传成功","data" => array("url" => $fileurl))).")");	
		}else{
			die($this->callback."(".json_encode(array("result" => -1,"message" => $result)).")");
		}
		
		
	}
    
    public function getlist()
    {
    	$uid = isset($_REQUEST['uid'])?(int)$_REQUEST["uid"]:0;
    	if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
    	$tempdata = $this->getTemplateTable()->getAppDataList(array("uid" => $uid,"valid" => 1));
    	$num = $tempdata->count();
    	if($num == 0){
    		die($this->callback."(".json_encode(array("result" => 0,"message" => "该用户无模板","data" => array("list" => array() ))).")");
    	}
    	$infoData = array();
    	foreach ($tempdata as $tdata){
    		$row = (array)$tdata;
    		$url = $this->showurl.$row['url'];
    		$infoData[] = array(
                        "templateurl" => $url,
    			"tid" => $row['tid'],
    			"tname" => $row['tname'],
    			"menu" => $url.$this->addurl."menu.xml",
    			"scene" => $url.$this->addurl."scene.xml",
    			"datadescription" => $url.$this->addurl."datadescription.xml",						
    		);    		
    	} 
    	die($this->callback."(".json_encode(array("result" => 0,"message" => "成功获取模板列表列表","data" => array("list" => $infoData))).")");
    }
    
    public function createtemplate()
    {
    	$uid = isset($_REQUEST['uid'])?(int)$_REQUEST["uid"]:0;
    	if($uid == 0){ die($this->callback."(".json_encode(array("result" => -1,"message" => "用户ID为0")).")"); }
 
		$tname = isset($_REQUEST['tname'])?$_REQUEST['tname']:'';
        if(empty($tname)){ die($this->callback."(".json_encode(array("result" => -1,"message" => "主题名为空")).")");  }

                $typeid = isset($_REQUEST['typeid'])?$_REQUEST['typeid']:'6';
        if(empty($typeid)){ die($this->callback."(".json_encode(array("result" => -1,"message" => "模板分类为空")).")");  }

      if($tname!='' && $uid!=''){
        
        $templatedata = $this->getTemplateTable()->getAppData(array("uid" => $uid,"tname" => $tname));
        if($templatedata && $templatedata->id){
             die($this->callback."(".json_encode(array("result" => -1,"message" => "主题名重复")).")");
        } 		
    	$addtime  = time();
    	$tid      = sprintf("%u", crc32( $uid."_".$addtime."_".uniqid() ));
    	$url      = $uid."/".date("Ymd")."/".$tid."/";
    	$temp_file_path = $this->designerfold.$url;    	
    	@mkdir($temp_file_path,0755,true);
    	if( file_exists($temp_file_path) ){
    		
//    		$this->copyxml($temp_file_path);
			$zip = new ZipArchive();
//			$filezip = $temp_file_path."themetool.zip";
                        $filezip = $this->templatezip;
			if($zip->open($filezip) === TRUE){
				$zipresult= $zip->extractTo($temp_file_path);
				$zip->close();
			}
			
			if(empty($tname)){
				$tname    = $tid."主题模板";
			}
    		$saveData = array(
                                'typeid' => $typeid,
    				'tid' => $tid,
    				'uid' => $uid,
    				'tname' => $tname,
    				'url' => $url,
    		
    		);
    		$this->getTemplateTable()->saveArr($saveData);
			$myurl = $this->showurl.$url;
			
//			unlink($filezip);

                $editxmlurl = "http://csm.coolyun.com/designer/index?tid=".$tid."&tuid=".$uid."&filepath=theme/description.xml&key=label-zh-rCN&value=".$tname."&act=set_description_value&callback=345343534353";
                $ee = $this->geturldata($editxmlurl);       

                //echo $ee;exit;                         
			
    		die($this->callback."(".json_encode(array("result" => 0,"message" => "创建成功","data" => array("tid" => $tid,"menu" => $myurl.$this->addurl."menu.xml","scene" => $myurl.$this->addurl."scene.xml","datadescription" => $myurl.$this->addurl."datadescription.xml",'templateurl'=>$myurl))).")");
    		
    	}
    	
    	die($this->callback."(".json_encode(array("result" => -1,"message" => "创建失败")).")");
      }
    }

    public function geturldata( $url )
    {
    	$ch     = curl_init($url) ;
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ;
    	$output = curl_exec($ch);
    	curl_close($ch);
    	return $output;
    }


    
    public function copyxml($dstfold)
    {
    	$wholeHandle  = opendir($this->designerxml);    	
    	while(false !== ($myfile = readdir($wholeHandle))){
    		if($myfile!='Thumbs.db' && $myfile!='.' && $myfile!='..' && $myfile!=''){
    			$fileextarr   = explode(".", $myfile);
    			$fileext      = strtolower(end($fileextarr));
    			if($fileext == "zip"){
    				copy($this->designerxml . '/' . $myfile, $dstfold . '/' . $myfile);
    			}    			
    		}
    	}
    	return 0;	 
    	
    }
    
    public function getTemplateTable()
    {
    	if (!$this->templateTable) {
    		$sm = $this->getServiceLocator();
    		$this->templateTable = $sm->get('Designer\Model\TemplateTable');
    	}
    	return $this->templateTable;
    }
    
    
}
