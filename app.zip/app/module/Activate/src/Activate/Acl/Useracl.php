<?php
namespace Activate\Acl;

use Zend\Permissions\Acl\Acl;
use Zend\Permissions\Acl\Role\GenericRole as Role;
use Zend\Permissions\Acl\Resource\GenericResource as Resource;
class Useracl
{
	public $useracl;
	public function __construct()
	{
		$this->useracl = new Acl();			
	}
	public function init()
	{
		$this->useracl->addRole(new Role('user'))
			          ->addRole(new Role('admin'));
		$this->useracl->addResource(new Resource('activate'));
		$userArr = array(
				'addphone','phone','addresolution',
				'resolution','addapp','childapp',
				'addchildapp','index','top',
				'edit','left','right','down',
				'subject','addsubject',
				'pic','addpic',
				'link','addlink',
				'addapppic','insertapppic',
				'apppiclist','editapppic',
		);
		
		$this->useracl->allow('user','activate',$userArr);
		//$this->useracl->allow('manager');
		$adminArr = array(
				'addphone','phone','addresolution',
				'resolution','addapp','childapp',
				'addchildapp','index','center',
				'edit','top','left',
				'right','down','add',
				'subject','addsubject',
				'pic','addpic',
				'link','addlink',
				'addapppic','insertapppic',
				'apppiclist','editapppic',
		);
		$this->useracl->allow('admin','activate',$adminArr);
	}
	public function checkAction($role,$action)
	{
		$this->init();
		return $this->useracl->isAllowed($role,'activate',$action);
	}
}
