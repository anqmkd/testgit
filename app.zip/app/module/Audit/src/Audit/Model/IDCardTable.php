<?php

namespace Audit\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Launcher\Logs\Logs;


class IDCardTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_coolyun_userinfo';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getData($page=1,$pagesize=2,$typeid=1)
    {
    	if($typeid == 0) $and = array('user.selecttype'=>1);
    	else $and = $and = array('user.selecttype'=>1,'user.authentype'=>$typeid);;
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('user'=>'tb_yl_coolyun_user'), 
    						  'tb_yl_coolyun_userinfo.userid = user.userid',
    						  array('authentype','reason'),$myselect::JOIN_LEFT)
    			->where($and)
    	        ->order('tb_yl_coolyun_userinfo.update_time DESC')
    			->limit($pagesize)
    			->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function updateData(array $data){
    	try{
    		$sql = "UPDATE tb_yl_coolyun_user SET authentype = ".$data['authentype'].", reason='".$data['reason']
    				."' WHERE userid =". $data['userid'];
    		$result =$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		
    		return $result;
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function getCountnum($typeid)
    {
    	if($typeid == 0){
    		$and = '';
    	}else{
    		$and = ' AND authentype ='.$typeid;
    	}  	
    	$sql = "SELECT COUNT(*) AS num FROM tb_yl_coolyun_user WHERE selecttype = 1 ".$and;
    	$result = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);

    	return $result->current()->num;
    }
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function startXml($id)
    {
    	$sqlStr   = "UPDATE tb_yl_icon SET valid = 0";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	$sqlStr   = "UPDATE tb_yl_icon SET valid = 1 WHERE id =".$id;
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function getFilePath(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('url'))
    			->where($data);
    	$myData = $this->selectWith($myselect);
    	return $myData->current();
    }
    
    public function saveArr(array $data)
    {
    	try{
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    

       
}
