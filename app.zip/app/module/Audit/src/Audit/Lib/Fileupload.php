<?php
namespace Designer\Lib;
class Fileupload
{
	public $myname = '';	
    function Fileupload($myname) 
    {
		$this->myname = $myname;			
    }
    function getExt()
    {
        $ext = $_FILES[$_REQUEST['up_name']]['name'];
        $extStr = explode('.', $ext);
        return strtolower(end($extStr));	
    }
    function upload($dir,$fileName)
    {
		if(!file_exists($dir)){
			mkdir($dir,0777,true);	
		}
		
		if($_FILES[$_REQUEST['up_name']]["error"] == 0){
			if( move_uploaded_file($_FILES[$_REQUEST['up_name']]["tmp_name"],$dir.$fileName)){
				return "";
			}else{return "上传失败";}
		}else{			
			return "失败:".$_FILES[$_REQUEST['up_name']]["error"];
		}		
    }

}

?>
