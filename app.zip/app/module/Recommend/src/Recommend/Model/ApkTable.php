<?php

namespace Recommend\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class ApkTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_apk';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getApkData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    public function saveApk(array $apk)
    {
	    $data = array(
	    	'identity' => $apk['identity'],
	        'name' => $apk['name'],
	        'apk_url' => $apk['apk_url'],
	    	'icon_url' => $apk['icon_url'],
	    	'folder' => $apk['folder'],
	    	'size' => $apk['size'],
	    	'version' => $apk['version'],
	    	'md5' => $apk['apkmd5'],
	    	'insert_time' => $apk['insert_time'],
	    	'insert_user' => $apk['author'],
	    	'update_time' => $apk['update_time'],
	    	'update_user' => $apk['author'],
	    );
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    public function updateApk(array $apk)
    {
    	$data = array(
    			'name' => $apk['name'],
    			'apk_url' => $apk['apk_url'],
    			'icon_url' => $apk['icon_url'],
    			'size' => $apk['size'],
    			'version' => $apk['version'],
    			'md5' => $apk['apkmd5'],
    			'update_time' => $apk['update_time'],
    			'update_user' => $apk['author'],
    	);
    	
    	$this->update($data, array('identity' => $apk['identity']));
    }
    public function updateApp(array $widgetData)
    {
    	$this->update($widgetData, array('identity' => $widgetData['identity']));
    }
    
}
