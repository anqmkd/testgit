<?php

namespace Recommend\Model;

use Zend\Console\Prompt\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;


class WidgetTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_widget';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

    public function getDataInfo($resid)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('icon_url','apk_url','version','size'),'left')
    	->where(array('tb_yl_widget.identity'=>$resid))
    	->order(array('tb_yl_widget.id DESC'));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getData($page=1,$pagesize=2,$type="",$cpid="")
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('icon_url','apk_url','version','size'),'left')
				 ->join(array('b'=>'tb_yl_widget_extend'), 'b.identity = tb_yl_widget.identity',array('cha'=>'channel'),'left')					
				 ->where(array('tb_yl_widget.type'=>$type,'tb_yl_widget.cpid'=>$cpid))
    	         ->limit($pagesize)
    	         ->offset($offset)
    			 ->order(array('tb_yl_widget.id DESC'));

		//$w = $myselect->getSqlString();
		//var_dump($w);exit;

    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum($type="",$cpid="")
    {
    	$result = $this->select(array('type'=>$type,'cpid'=>$cpid));
    	return $result->count();
    }
    public function getCpidCountnum($data)
    {
        $result = $this->select($data);
        return $result->count();
    }

    public function getWidgetList($page=1,$pagesize=2,$type="")
    {
    	$mysql = $this->getSql();
		$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('icon_url','newversion','version','size'))
    	         ->where(array('tb_yl_widget.is_using'=>1,'tb_yl_widget.type'=>$type))
    	         ->limit($pagesize)
    	         ->offset($offset)
    	         ->order(array('tb_yl_widget.sequence ASC','tb_yl_widget.insert_time DESC'));
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }

    public function getCountListnum($type="")
    {
    	$result = $this->select(array('type'=>$type,'is_using'=>1));
    	return $result->count();
    }

    public function getGroup($page=1,$pagesize=2,$type="",$apkname,$using)
    {
    	$offset   = ((int)$page-1)*$pagesize;    	      
        
    	if($apkname == "")
    	{
                $mytemp  = (intval($using)==1)?"info.sumnum>=".$using:"info.sumnum=".$using;
    		$sql     = "SELECT info.label,info.cpid FROM "
    				  ."(SELECT label, cpid, SUM(is_using) AS sumnum FROM tb_yl_widget WHERE TYPE = '".$type."' GROUP BY cpid ORDER BY insert_time DESC) AS info "
    				  ."WHERE ".$mytemp."   LIMIT ".$pagesize." OFFSET ".$offset." ";
    		$results = $this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
    		return $results;
    	}    	 

        
    	$mysql    = $this->getSql();
//    	$offset   = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();

        $wherearr = array('type'=>$type,"label LIKE '%".$apkname."%'"); 
    	$myselect->where($wherearr)
    	         ->columns(array('label','cpid'))
    	         ->order(array('insert_time DESC'))
    	         ->group('cpid')
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getGroupCount($type,$apkname,$using)
    {
    	if($apkname == "")
    	{
/*                $mytemp  = (intval($using)==1)?"info.sumnum>=".$using:"info.sumnum=".$using; 

    		$sql     = "SELECT info.label,info.cpid FROM "
    				."(SELECT label, cpid, SUM(is_using) AS sumnum FROM tb_yl_widget WHERE TYPE = '".$type."' GROUP BY cpid) AS info "
    						."WHERE ".$mytemp; 
*/
		$mytemp  = (intval($using)==1)?"info.sumnum>=%d":"info.sumnum=%d";
	        $mytemp = sprintf($mytemp,$using); 

    		$sql     = "SELECT info.label,info.cpid FROM "
    					."(SELECT label, cpid, SUM(is_using) AS sumnum FROM tb_yl_widget WHERE TYPE = %d GROUP BY cpid) AS info "
    					."WHERE %s ";
    		
    		$sql = sprintf($sql,$type, $mytemp);
    		
  		$results = $this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
    		return $results->count();    		
    	}	

    	$mysql    = $this->getSql();
    	$myselect = $mysql->select();
        $wherearr = array('type'=>$type,"label LIKE '%".$apkname."%'");
    	$myselect->where($wherearr)
    	         ->columns(array('label','cpid'))
    	         ->group('cpid');
        //echo $myselect->getSqlString();exit;

    	$myData = $this->selectWith($myselect);
    	return $myData->count();    	 
    }
    
    public function getWidgetData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    public function saveWidget(array $widget)
    {
	    $data = array(
	    	'label'    => $widget['label'],
	    	'cpid'     => sprintf("%u", crc32( $widget['label'] ) ), 	
	    	'identity' => $widget['identity'],	
	        'business' => $widget['business'],
	        'type'     => $widget['type'],
			'note'     => $widget['note'],
	    	'package'  => $widget['packagename'],
	    	'class'    => $widget['classname'],
	    	'folder'   => $widget['folder'],
	    	'insert_time' => $widget['insert_time'],
	    	'insert_user' => $widget['author'],
	    	'update_time' => $widget['update_time'],
	    	'update_user' => $widget['author'],
                'channel'     => $widget['channel'],
	    	'commend' => (int)$widget['tj'],
                'source' => (int)$widget['source'],
	    	'sequence' => (int)$widget['sequence'],		
	    );
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateWidgetData(array $widgetData)
    {
    	$this->update($widgetData, array('id' => $widgetData['id']));
    }


    public function updateWidgetDataSequence(array $widgetData)
    {
        $this->update(array('sequence'=>$widgetData['sequence']), array( 'is_using'=>1, 'sequence'=>$widgetData['my'],'type' => $widgetData['type']));
    }

    
    public function updateWidget(array $widgetData)
    {
    	$this->update($widgetData, array('identity' => $widgetData['identity']));
    }

    public function getAppAll(array $select)
    {
    	$result = $this->select($select);
    	return $result;
    }
    public function getBusinessWidget(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	if( (int)$data['business']==7 )
    	{
    		$whereArr = array("tb_yl_widget.is_using"=>1,);
    	}    	
    	if( (int)$data['business']==1 )
    	{
    		$whereArr = array("tb_yl_widget.is_using"=>1,"tb_yl_widget.business IN(1,7,3,5) ");
    	}    	
    	if( (int)$data['business']==2 )
    	{
    		$whereArr = array("tb_yl_widget.is_using"=>1,"tb_yl_widget.business IN(2,7,3,6) ");
    	}    	
    	if( (int)$data['business']==4 )
    	{
    		$whereArr = array("tb_yl_widget.is_using"=>1,"tb_yl_widget.business IN(4,7,5,6) ");
    	}    	
    	if( $data['business']==0 )
    	{
    		return null;
    	}    	    	
    	$myselect->where( $whereArr );
//    	echo $myselect->getSqlString();exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getMaxWidget($type="")
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
        $myselect->columns(array('maxorder'=>new Expression('MAX(sequence)'),))
        ->where(array('tb_yl_widget.is_using'=>1,'tb_yl_widget.type'=>$type));
         
        $myData = $this->selectWith($myselect);
        return $myData;
    }


    public function getMaxID($package)
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
        $myselect->columns(array('maxid'=>new Expression('MAX(id)'),))
        ->where(array('tb_yl_widget.is_using'=>1,'tb_yl_widget.package'=>$package));

        $myData = $this->selectWith($myselect);
        return $myData;
    }

    
    public function getVerMax($data)
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('version','size'),'left')				
		 ->where(array('tb_yl_widget.cpid'=>$data['cpid']))
    	         ->order(array('tb_yl_widget.insert_time DESC'));
        $myData = $this->selectWith($myselect);
        //var_dump($myData);exit;
        $tdata  = $myData->current();
        return $tdata->version;
    }



    
    
}
