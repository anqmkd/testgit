<?php

namespace Recommend\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class ExtendTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_widget_extend';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData( array $data )
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateAppData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    
    public function getExtendData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    
}
