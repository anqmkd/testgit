<?php
namespace Recommend\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Recommend\Acl\Useracl;
use Recommend\Module;
use Recommend\Tools\ApkTools;
use Recommend\Model\WidgetTable;
use Recommend\Model\ApkTable;
use Recommend\Model\ImgTable;
use Recommend\Model\IconTable;
use Recommend\Model\ProductTable;
use Recommend\Logs\Logs;
use Recommend\Model\ExtendTable;
use Recommend\Model\DownloadTable;
use Recommend\Model\WidgetProductTable;
use Recommend\Model\XmltoolTable;
use Zend\Db\Adapter\Adapter;
use \PDO;

class SiteController extends AbstractActionController
{
	public $filepath = '/home/wwwroot/rsync';
	public $tempfolder = '/home/wwwroot/app/public/apk/';
	public $toolpath = '/home/wwwroot/app/tool/apktool.jar';
	public $tempaddfile = '/home/wwwroot/app/public/tempfile/appAdd.txt';
	public $dataxmlfile = '/home/wwwroot/app/public/tempfile/data.xml';
	public $showurl = 'http://download.coolyun.com/';
	public $replacestr = '/home/wwwroot/rsync/';
	public $mystr = '/NetWidget/app/';
	public $widgeturl = "http://widget.yulong.com/widgetdl.php";
	public $dataxmlfileflash = '/home/wwwroot/app/public/FusionChartsFree/Data.xml';
	
	public $taskmobile = 'http://192.168.30.54:8088/getmsg.php';

	protected $widgetTable;
	protected $apkTable;
	protected $imgTable;
	protected $iconTable;
	protected $extendTable;
	protected $productTable;
	protected $downloadTable;
        protected $xmltoolTable;
	
	protected $widgetproductTable;
	protected $productOperation = array(0,1,2,4,7);
	protected $businessArr = array(3,5,6);
	
	protected $businessNumArray = array(
		1=>'电信',
		2=>'移动',
		4=>'联通',
		3=>'电信,移动',
		5=>'电信,联通',
		6=>'移动,联通',
		7=>'全部',	
	);
	
	
	protected $productStr = array(
			1=>'1,7',
			2=>'2,7',
			4=>'4,7',
			3=>'1,2,7',
			5=>'1,4,7',
			6=>'2,4,7',
			7=>'1,2,4,7',
	);

        public function neworderAction(){
                $uData = $this->checkLogin('right');
		$request = $this->getRequest();
                $postArr = $request->getPost();
                $type = $postArr['mytype'];
                $tval = (int)$postArr['tval'];

                $myid = $postArr['myid'];
                $currentval = (int)$postArr['currentval'];
                if($tval < $currentval){
                    $w = $currentval -1;
                    for($i = $w;$i>=$tval;$i--){
                        $k = $i + 1;
                        $arrdata = array(
                            "type" => $type,
                            "my" => $i,
                            "sequence" => $k,
                        );
                        $this->getWidgetTable()->updateWidgetDataSequence($arrdata);
                    }
                    $tarr = array(
                            "id" => $myid,        
                            "sequence" => $tval,
                    );
                    $this->getWidgetTable()->updateWidgetData($tarr);
                    die('success'); 
                }                 

                else if($tval > $currentval){

                    for($i = $currentval+1;$i<=$tval;$i++){
                        $k = $i - 1;
                        $arrdata = array(
                            "type" => $type,
                            "my" => $i,
                            "sequence" => $k,
                        );
                        $this->getWidgetTable()->updateWidgetDataSequence($arrdata);
                    }
                    $tarr = array(
                            "id" => $myid,
                            "sequence" => $tval,
                    );
                    $this->getWidgetTable()->updateWidgetData($tarr);
                    die('success');
                }
                die('success');

        }

        public function xmltoolAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$result = $this->getXmltoolTable()->getXmlType();
		$xmlTypeList = array();
		foreach($result as $row){
			$xmlTypeList[] = (array)$row;
		}

		$result = $this->getXmltoolTable()->getAppDataAll(array());
		$addApkList = array();
		foreach($result as $row){
			$addApkList[] = (array)$row;
		}
		return new ViewModel(array('xmlTypeList'=>$xmlTypeList,'addApkList'=>$addApkList));
	}
	
	public function getXmltoolTable()
	{
		if (!$this->xmltoolTable) {
			$sm = $this->getServiceLocator();
			$this->xmltoolTable = $sm->get('Recommend\Model\XmltoolTable');
		}
		return $this->xmltoolTable;
	}
	
	public function addxmlapkAction()
	{
		$uData = $this->checkLogin('right');
		$request = $this->getRequest();
		$postArr = $request->getPost();
		$id      = isset($postArr['id'])?$postArr['id']:'';
		
		if($id){
			$this->getXmltoolTable()->updateData(array(
					'id'           => $id,
					'name'         => $postArr['apkname'],
					'packageName'  => $postArr['packagename'],
					'type'         => $postArr['type'],
					'typeid'       => $postArr['typeid'],  
			));
		}else{
			$this->getXmltoolTable()->saveArr(array(
					'name'         => $postArr['apkname'],
					'packageName'  => $postArr['packagename'],
					'type'         => $postArr['type'],
					'typeid'       => $postArr['typeid'],
					'insert_time'  => date("Y-m-d H:i:s"),
			));
		}
		die('success');		
	}
	
	public function delcontentAction()
	{
		try{
			$uData = $this->checkLogin('right');
			$request     = $this->getRequest();
			$postArr     = $request->getPost();
			$id          = $postArr['id'];
			$this->getXmltoolTable()->delete($id);
	
			die('success');
		}catch(Exception $e){
			Logs::write('delcontentAction() error:'.$e->getMessage(),'log');
			die('error');
		}
	
	}



    public function tjorderAction()
    {
        $uData        = $this->checkLogin('right');
        $username     = $uData->username;
        $mycontent    = $username . "在" .date('Y-m-d H:i:s').'操作了排序';
	Logs::write(''.$mycontent, 'debug');		
    }

    public function apkmsgAction()
    {
	$uData = $this->checkLogin('right');
        $resid = $_GET['id'];
        if($resid == "") 
        {   die(""); }
        $data = $this->getWidgetTable()->getWidgetData(array('identity'=>$resid));
        $tdata = $data->current();
        die($tdata->note);
    }
	
    public function getapkAction()
    {
	$uData = $this->checkLogin('right');
        $request = $this->getRequest();
        if ($request->isPost())
        {
                 $postArr  = $request->getPost();
                 if( empty($postArr['keyword']))
                 {
                        die(json_encode(array()));
                 }
                 
                 $keywd    = $postArr['keyword'];
                 $tdata    = $this->getWidgetTable()->getWidgetData(array('is_using'=>1,"label LIKE '%".$keywd."%'"));
                 $infoarr  = array();
                 foreach($tdata as $myobj)
                 {
                       $infoarr[] = array('id'=>$myobj->identity,'name'=>$myobj->label);
                 }
                 die(json_encode($infoarr));
        }
        
    }



    public function showimgbannerAction()
    {
	$uData = $this->checkLogin('right');
    	$id = $this->params('id');
    	if($id=='')
    	{
    		die('error');
    	}
    	$imgData = $this->getImgTable()->getImgData(array('identity'=>$id));
		//$iconData = $this->getIconTable()->getImgData(array('identity'=>$id));
		//$extendData = $this->getExtendTable()->getData(array('identity'=>$id));
    	//$module_temp = new Module();
    	//$params = $module_temp->getParams();
    	return new ViewModel(array('imgData'=>$imgData,'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'myid'=>$id));
    }



	public function bannerAction()
	{
		$pageSize = 10;
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$page = isset($_GET['page'])?(int)$_GET['page']:0;
		$countWidget = $this->getImgTable()->getgroup();
		$totalPage=ceil($countWidget/$pageSize);
		if($page>$totalPage) $page = $totalPage;
		if($page==0) $page = 1;
		$tempData = $this->getImgTable()->getgroupdata($page,$pageSize);
		$infoData = array();
		foreach($tempData as $mydata)
		{
			$tarr     = (array)$mydata;
			$identity = $tarr['identity'];
			if($identity == '1538898806' || $identity == '1833692738' || $identity == '1411489385' || $identity == '2198330986' ){
				continue;
			}

			$tdata    = $this->getWidgetTable()->getDataInfo($identity);
			$datainfo = $tdata->current();
			$tarr['version']  = $datainfo->version;
			$tarr['is_using'] = $datainfo->is_using;
			$tarr['commend']  = $datainfo->commend; 
			$tarr['name']     = $datainfo->label;
			$tarr['id']       = $datainfo->id;
			$tarr['package']  = $datainfo->package;
			$infoData[]       = $tarr;
		}
			
		return new ViewModel(array('uData'=>$uData,'page'=>$page,'replacestr'=>$this->replacestr,'countWidget'=>$countWidget,'totalPage'=>$totalPage,'infoData'=>$infoData));
	}	

	
    public function indexAction()
    {
    	/*
    	$aaa = 'D:\webserver\easyphp\www\MyApplication\public\upload\Files\tool\20130503174315\duomiyinle.apk';
    	$crc = sprintf("%u", crc32(file_get_contents($aaa)));
    	var_dump($crc);exit;
    	*/
    	$uData = $this->checkLogin('index');
    	if(!$uData)
    	{
    		die('没有权限');
    	}		 
        return new ViewModel();
    }
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();


    	return new ViewModel( array('params'=>$params['params']) );
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }

    
    public function appeditAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['label']) || empty($postArr['version']) || empty($postArr['id']))
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$label = $postArr['label'];
    		$version = $postArr['version'];
    		$note = $postArr['note'];
    		$businessStr = $postArr['strbusiness'];
                $source      = $postArr['source'];		    		
    		if( stristr($businessStr,"0") || stristr($businessStr,"7") )
    		{
    			$opeartion = 1;
    		}else
    		{
    			$opeartion = 2;
    		}    		
    		if($id)
    		{
    			$this->getWidgetTable()->updateWidget(array('identity'=>$id,'type'=>$postArr['mytype'],'sequence'=>$postArr['sequence'],'cpid'=>sprintf("%u", crc32($label)),'business'=>$businessStr,'label'=>$label,'note'=>$note,'source'=>$source));
                        $this->tjorderAction();
				$this->getApkTable()->updateApp(array('identity'=>$id,'version'=>$version));
    			die('success');
    		}
    	}
    }



    public function appeditnewAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['label']) || empty($postArr['version']) || empty($postArr['id']))
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$label = $postArr['label'];
    		$version = $postArr['version'];
    		$note = $postArr['note'];
    		$businessStr = $postArr['strbusiness'];   
                //var_dump($businessStr);exit; 		  
                var_dump($postArr);exit;  		
    		if( stristr($businessStr,"0") || stristr($businessStr,"7") )
    		{
    			$opeartion = 1;
    		}else
    		{
    			$opeartion = 2;
    		}    		
    		if($id)
    		{
    			$this->getWidgetTable()->updateWidget(array('identity'=>$id,'type'=>$postArr['mytype'],'cpid'=>sprintf("%u", crc32($label)),'business'=>$businessStr,'label'=>$label,'note'=>$note));
				$this->getApkTable()->updateApp(array('identity'=>$id,'icon_url'=>$postArr['iconurl'],'version'=>$version));
    			die('success');
    		}
    	}
    }

    public function rightAction()
    {
    	$pageSize     = 10;
		$listpageSize = 20;
		$listsize     = 10;
    	$uData        = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
		$type        = isset($_GET['type'])?(int)$_GET['type']:0;
    	$page        = isset($_GET['page'])?(int)$_GET['page']:0;
    	$cpid        = isset($_GET['cpid'])?$_GET['cpid']:'';
		$listpage    = isset($_GET['listpage'])?(int)$_GET['listpage']:0;
    	$countWidget = $this->getWidgetTable()->getCountnum($type,$cpid);
    	$totalPage   = ceil($countWidget/$pageSize);
    	if($page>$totalPage) $page = $totalPage; 
    	if($page==0) $page = 1;
    	$tempData    = $this->getWidgetTable()->getData($page,$pageSize,$type,$cpid);    	
    	$infoData    = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    	$module_temp = new Module();
    	$params      = $module_temp->getParams();
    	return new ViewModel(array('uData'=>$uData,'businessArr'=>$this->businessArr,'businessNumArray'=>$this->businessNumArray,'type'=>$type,'cpid'=>$cpid,'widgeturl'=>$this->widgeturl,'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'page'=>$page,'params'=>$params['params'],'listsize'=>$listsize,'countWidget'=>$countWidget,'totalPage'=>$totalPage,'infoData'=>$infoData));
    } 
	
    public function groupAction()
    {
    	$pageSize     = 10;
		$listpageSize = 20;
		$listsize     = 6;
    	$uData        = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
	$type            = isset($_GET['type'])?(int)$_GET['type']:0;
    	$page            = isset($_GET['page'])?(int)$_GET['page']:0;
	$listpage        = isset($_GET['listpage'])?(int)$_GET['listpage']:0;

        $apkname         = isset($_GET['apkname'])?$_GET['apkname']:'';
	$using           = isset($_GET['using'])?$_GET['using']:'1';

    	$countWidget     = $this->getWidgetTable()->getGroupCount($type,$apkname,$using);   
 	
	$countListWidget = $this->getWidgetTable()->getCountListnum($type);
    	$totalListPage   = ceil($countListWidget/$listpageSize);
    	if($listpage>$totalListPage) $listpage = $totalListPage; 
    	if($listpage==0) $listpage = 1;		    	
    	$totalPage       = ceil($countWidget/$pageSize);
    	if($page>$totalPage) $page = $totalPage; 
    	if($page==0) $page = 1;
    	$tempData        = $this->getWidgetTable()->getGroup($page,$pageSize,$type,$apkname,$using);    	
    	$infoData        = array();
        
    	foreach($tempData as $mydata)
    	{
                $getarr     = (array)$mydata;
                $cpid       = $getarr['cpid'];
                $getarr['num'] = $this->getWidgetTable()->getCpidCountnum(array('cpid'=>$cpid));
                $getarr['newversion'] = $this->getWidgetTable()->getVerMax(array('cpid'=>$cpid));
    		$infoData[] = $getarr;
                
    	}
        $maxresult   = $this->getWidgetTable()->getMaxWidget($type);
        $maxobj      = $maxresult->current();
        $maxorder    = $maxobj->maxorder;            	
    	$listData    = $this->getWidgetTable()->getWidgetList($listpage,$countListWidget,$type);
    	$listDataArr = array();
    	foreach($listData as $list)
    	{
    		$listDataArr[] = (array)$list;
    	}
    	$module_temp = new Module();
    	$params      = $module_temp->getParams();
    	return new ViewModel(array('maxorder'=>$maxorder,'uData'=>$uData,'using'=>$using,'apkname'=>$apkname,'businessArr'=>$this->businessArr,'businessNumArray'=>$this->businessNumArray,'type'=>$type,'widgeturl'=>$this->widgeturl,'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'page'=>$page,'params'=>$params['params'],'listsize'=>$listsize,'listArr'=>$listDataArr,'countWidget'=>$countWidget,'totalPage'=>$totalPage,'totalListPage'=>$totalListPage,'listpage'=>$listpage,'countListWidget'=>$countListWidget,'infoData'=>$infoData));
    }
	
    public function showimgAction()
    {
	$uData = $this->checkLogin('right');
    	$id = $this->params('id');
    	if($id=='')
    	{
    		die('error');
    	}
    	$imgData = $this->getImgTable()->getImgData(array('identity'=>$id));
		$iconData = $this->getIconTable()->getImgData(array('identity'=>$id));
		$extendData = $this->getExtendTable()->getData(array('identity'=>$id));
    	$module_temp = new Module();
    	$params = $module_temp->getParams();
    	return new ViewModel(array('imgData'=>$imgData,'extendData'=>$extendData,'params'=>$params,'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'iconData'=>$iconData,'fenbian'=>$params['params']['fenbianlv'],'myid'=>$id));
    }

    public function setfolderAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost()) 
    	{
    		$postArr = $request->getPost();
    		$id = $postArr['id'];
    		$data = $this->getWidgetTable()->getWidgetData(array('identity'=>$id));
    		$mydata = $data->current();
    		$folder = $mydata->folder;
    		$fArr = explode("/", $folder);
    		$count = count($fArr);
    		$start = $count-2;
    		$end = $count-1;
    		$mycontent = $fArr[$start].'/'.$fArr[$end];
			Logs::write('SiteController::setfolderAction(): '.$mycontent, 'log');
                $mycontent = date("Ym")."/".date("YmdHis");
    		@file_put_contents($this->tempaddfile, $mycontent);
    		die("");
    	}
    }


    public function img_resize( $new_width, $new_height, $src_file, $des_file){
    	try{
    
    		list($src_width, $src_height) = getimagesize($src_file);
    		//$new_width = $src_width * $resize_percent;
    		//$new_height = $src_height * $resize_percent;
    
    		$new_image = imagecreatetruecolor($new_width, $new_height);
    		$suff = strrchr($src_file, '.');
    		switch ($suff){
    			case ".jpg":
    			case ".jpeg":
    				{
    					$src_image = imagecreatefromjpeg($src_file);
    					imagecopyresized($new_image, $src_image, 0, 0, 0, 0, $new_width, $new_height, $src_width, $src_height);
    					imagejpeg($new_image, $des_file, 75);
    				}break;
    			case ".png":
    				{
    					$src_image = imagecreatefrompng($src_file);
    					imagecopyresized($new_image, $src_image, 0, 0, 0, 0, $new_width, $new_height, $src_width, $src_height);
    					imagepng($new_image,$des_file);
    				}break;
    			case ".gif":
    				{
    					$src_image = imagecreatefromgif($src_file);
    					imagecopyresized($new_image, $src_image, 0, 0, 0, 0, $new_width, $new_height, $src_width, $src_height);
    					imagegif($new_image,$src_file);
    				}break;
    			default:
    				{
    					return false;
    				}break;
    		}
    	}catch (Exception $e){
    		//Log::write("ImgResize::resize() exception: ".$e->getMessage(), "log");
    		return false;
    	}
    	return true;
    }    



    public function addimgAction()
    {
	$uData = $this->checkLogin('right');
    	$wharr   = array(
    		'big'	=> array('ratio'=>array(720,1280),'imgwh'=>array(704,246)),
    		'mid'   => array('ratio'=>array(540,960),'imgwh'=>array(528,185)),
    		'small' => array('ratio'=>array(480,800),'imgwh'=>array(468,164)),
                'other' => array('ratio'=>array(480,854),'imgwh'=>array(480,185)),
    	);
   
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = $postArr['id'];
    		$uData = $this->checkLogin('add');
    		$author = $uData->username;
    		$addtime = date('Y-m-d H:i:s');

    		if(empty($postArr['myid']) || empty($postArr['apkload']))
    		{
    			die('error');
    		}


			$tmpimg  = $this->replacestr.$postArr['apkload'];
			foreach ($wharr as $k => $row)
			{
				$suff    = strrchr($tmpimg, '.');
				$midfile = str_replace($suff, "_".$k.$suff, $tmpimg);
				$this->img_resize($row['imgwh'][0], $row['imgwh'][1], $tmpimg, $midfile);
				
				$tdata   = $this->getImgTable()->getImgData(array('identity'=>$postArr['myid'],'height'=>$row['ratio'][1],'width'=>$row['ratio'][0]));
				if($tdata->count()>0)
				{
					$mydata= $tdata->current();
					$uparr = array(
							'img_url' => str_replace($this->replacestr, "", $midfile),
							'id'      => $mydata->id,
					);
					$this->getImgTable()->updateImgData($uparr);						
				}
				else
				{
					$imgdata = array(
							'identity'    => $postArr['myid'],
							'height'      => $row['ratio'][1],
							'width'       => $row['ratio'][0],
							'img_url'     => str_replace($this->replacestr, "", $midfile),
							'insert_time' => $addtime,
							'author'      => $author,
							'update_time' => $addtime,
							'author'      => $author,
					);
					$this->getImgTable()->saveImgArr($imgdata);						
				}
			
			}


                        /*
			$ttArr = explode('-',$postArr['imgwidth']);
			$tempWidth = $ttArr[0];
			$tempHeight = $ttArr[1];
    		if($id=="")
    		{
    			$imgdata = array(
    				'identity'=>$postArr['myid'],
    				'height'=>$tempHeight,
    				'width'=>$tempWidth,
    				'img_url'=>$postArr['apkload'],
    				'insert_time'=>$addtime,
    				'author'=>$author,
    				'update_time'=>$addtime,
    				'author'=>$author,									
    			);
    			$this->getImgTable()->saveImgArr($imgdata);
    		}else{
    			$uparr = array(
    				'height'=>$tempHeight,
    				'width'=>$tempWidth,
    				'img_url'=>$postArr['apkload'],
    				'id'=>$postArr['id'],			
    			);
    			$this->getImgTable()->updateImgData($uparr);
    		}    	

                */	
    		die("success");
    	}
    	die('');
    }    

    public function addiconAction()
    {   
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = $postArr['id'];
    		$uData = $this->checkLogin('add');
    		$author = $uData->username;
    		$addtime = date('Y-m-d H:i:s');
    		if(empty($postArr['myid']) || empty($postArr['imgwidth']) || empty($postArr['apkload']))
    		{
    			die('error');
    		}
			$ttArr = explode('-',$postArr['imgwidth']);
			$tempWidth = $ttArr[0];
			$tempHeight = $ttArr[1];
    		if($id=="")
    		{
    			$imgdata = array(
    				'identity'=>$postArr['myid'],
    				'height'=>$tempHeight,
    				'width'=>$tempWidth,
    				'img_url'=>$postArr['apkload'],
    				'insert_time'=>$addtime,
    				'author'=>$author,
    				'update_time'=>$addtime,
    				'author'=>$author,									
    			);
    			$this->getIconTable()->saveImgArr($imgdata);
    		}else{
    			$uparr = array(
    				'height'=>$tempHeight,
    				'width'=>$tempWidth,
    				'img_url'=>$postArr['apkload'],
    				'id'=>$postArr['id'],			
    			);
    			$this->getIconTable()->updateImgData($uparr);
    		}    		
    		die("success");
    	}
    	die('');
    }    
    
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    
    public function editAction()
    {
    	$uData = $this->checkLogin('edit');
    	if(!$uData)
    	{
    		die('没有权限');
    	} 
		
    	$id = (int)$this->params('id');
    	if(!$id)
    	{
    		die('error');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost()) {
    		$postArr = $request->getPost();
    		if($postArr['label']=="" || $postArr['business']=="" || $postArr['type']==""
    				|| $postArr['packagename']=="" || $postArr['classname']==""
    				|| $postArr['version']=="" || $postArr['apkfile']==""){
    			die('empty');
    		}
    		if(!file_exists($this->filepath.'/'.$postArr['apkfile']))
    		{
    			die('noexist');
    		}
    		$folder = $this->filepath.$this->mystr.file_get_contents($this->tempaddfile);
    		$folder = $this->mystr.file_get_contents($this->tempaddfile);
    		$postArr['folder'] = $folder;
    		$addtime = date('Y-m-d H:i:s');
    		$postArr['insert_time'] = $addtime;
    		$postArr['update_time'] = $addtime;    		
    		$crc = sprintf("%u", crc32(file_get_contents($this->filepath.'/'.$postArr['apkfile'])));    		
    		$reData = $this->getWidgetTable()->getWidgetData(array('identity'=>$crc));
			$resultArr = array();
			foreach($reData as $tempResult)
			{
				$resultArr[] = (array)$tempResult;
			}
    		if(count($resultArr)>0)
    		{
    			die('exist');
    		}
    		
    		$postArr['identity'] = $crc;
    		$postArr['cpid']     = sprintf("%u", crc32($postArr['label']));
    		$widgetid = $this->getWidgetTable()->saveWidget((array)$postArr);
    		$upmyData = array(
    				'id' => $postArr['wid'],
    				'is_using' => 0,
    		);
    		$this->getWidgetTable()->updateWidgetData($upmyData);     		
    		$widgetResult = $this->getWidgetTable()->getWidgetData(array(
    				'id' => $postArr['wid'],		
    		));
    		$widgetData = $widgetResult->current();    		
    		$this->getWidgetProductTable()->updateWidgetProductData(array(
    				'widget'=>$widgetData->identity,
    				'valid'=>0,		
    		));    		
    		$mybusiness = $postArr['business'];
    		$productbusiness = $this->productStr[$mybusiness];
    		$tempproduct = $this->getProductTable()->getDataProduct(array('business'=>$productbusiness));
    		foreach ($tempproduct as $myproduct)
    		{
    			$this->getWidgetProductTable()->saveProductArr(array(
    						'product'=>$myproduct->name,
    						'widget' =>$crc,
    						'insert_user'=>$postArr['author'],
    			));
    		}    		
    		$apkarray = array(
    				'identity' => $crc,
    				'name' => '',
    				'apk_url' => $postArr['apkfile'],
    				'icon_url' => $postArr['apkicon'],
    				'folder' => $folder,
    				'size' => filesize($this->filepath.'/'.$postArr['apkfile']),
    				'version' => $postArr['version'],
    				'apkmd5' => md5_file($this->filepath.'/'.$postArr['apkfile']),
    				'insert_time' => $addtime,
    				'update_time' => $addtime,
    				'author' => $postArr['author'],
    		);
    		$this->getApkTable()->saveApk($apkarray);
    		die('success');
    	}
    	$module_temp = new Module();
    	$params = $module_temp->getParams();
    	return new ViewModel(array('params'=>$params['params'],'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'widgetid'=>$id,'uData'=>$uData));
    }
    
    public function addapkAction()
    {
        $uData = $this->checkLogin('add');
        if(!$uData)
        {
                die('没有权限');
        }
        $request = $this->getRequest();
        if ($request->isPost()) {
                $postArr = $request->getPost();
                if($postArr['label']=="" || $postArr['business']=="" || $postArr['type']==""
                                 || $postArr['packagename']=="" || $postArr['version']=="" || $postArr['apkfile']==""){
                        die('empty');
                }
                $folder                 = '';
                $postArr['folder']      = $folder;
                $addtime                = date('Y-m-d H:i:s');
                $postArr['insert_time'] = $addtime;
                $postArr['update_time'] = $addtime;
                if(strpos($postArr['apkfile'],"http") === false)
                {
                }else{
                      $tfilearr = explode("?",$postArr['apkfile']);
                      $postArr['apkfile'] = $tfilearr[0];
                }
                $crc                    = sprintf("%u", crc32($postArr['apkfile']));
                $reData                 = $this->getWidgetTable()->getWidgetData(array('identity'=>$crc));
                $resultArr              = array();
                foreach($reData as $tempResult)
                {
                                $resultArr[] = (array)$tempResult;
                }
                if(count($resultArr)>0)
                {
                        die('exist');
                }
                
                $postArr['channel']  = (strpos($postArr['apkfile'],"http") === false)?'0':'1';

                $postArr['identity'] = $crc;
	        $maxresult           = $this->getWidgetTable()->getMaxWidget( $postArr['type']  );
	        $maxobj              = $maxresult->current();
	        $maxorder            = $maxobj->maxorder;
	        $mycommend           = $maxorder+1;
                if( !isset($postArr['sequence']) || empty($postArr['sequence']) ){
	             $postArr['sequence'] = $mycommend;
                }
	        $postArr['cpid']     = sprintf("%u", crc32($postArr['label']));

                //var_dump($postArr);exit;
                $widgetid            = $this->getWidgetTable()->saveWidget((array)$postArr);
                $mybusiness          = $postArr['business'];
		if($mybusiness != 0){
                $productbusiness     = $this->productStr[$mybusiness];
                $tempproduct         = $this->getProductTable()->getDataProduct(array('business'=>$productbusiness));
                foreach ($tempproduct as $myproduct)
                {
                        $this->getWidgetProductTable()->saveProductArr(array(
                                                'product'     => $myproduct->name,
                                                'widget'      => $crc,
                                                'insert_user' => $postArr['author'],
                        ));
                }
		}
                $apkarray = array(
                        'identity'    => $crc,
                        'name'        => '',
                        'apk_url'     => $postArr['apkfile'],
                        'icon_url'    => $postArr['apkicon'],
                        'folder'      => $folder,
                        'size'        => $postArr['size'],
                        'version'     => $postArr['version'],
                        'apkmd5'      => $postArr['md5'],
                        'insert_time' => $addtime,
                        'update_time' => $addtime,
                        'author'      => $postArr['author'],                                                        
                );
                $this->getApkTable()->saveApk($apkarray);
                die('success');

        }
    }
    public function addAction()
    {   
        $uData = $this->checkLogin('center');     
    	$module_temp = new Module();
    	$params      = $module_temp->getParams();
    	return new ViewModel(array('params'=>$params['params'],'showurl'=>$this->showurl,'replacestr'=>$this->replacestr,'uData'=>$uData));    
    }
    public function changeAction()
    {
	$uData = $this->checkLogin('right');
    	$temp_time = date('YmdHis');
    	$apptype   = isset($_GET['apptype'])?$_GET['apptype']:"tools";
    	$temp_str  = 'app/'.$apptype.'/'.$temp_time;
		Logs::write('SiteController::changeAction(): '.$temp_str, 'log');
    	file_put_contents($this->tempaddfile, $temp_str);
    	die($temp_str);
    } 
    
    public function checkLogin($action)
    {
    	$myAuth  = new Auth();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr  = json_decode($objUser->roleStr,true);
    		$roleData = isset($roleArr['recommend'])?$roleArr['recommend']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl   = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }
    
    public function getapkinfoAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr    = $request->getPost();
    		$package    = $postArr['packagename'];
    		$post_data  = array(
    				'action=getapkinfo',
    				'packagename='.$package
    		);
    		$post_data  = implode('&',$post_data);   
    		$result     = $this->geturldatapost($this->taskmobile, $post_data);
    		$resultarr  = json_decode($result,true);

    		$urlstr     = isset($resultarr['content'][0]['apkURL'])?$resultarr['content'][0]['apkURL']:'';
                $urlarr     = explode("?",$urlstr);
                $url        = isset($urlarr[1])?str_replace('?'.$urlarr[1],'',$urlstr):$urlstr;  
                $resultarr['content'][0]['apkURL'] = $url; 
                $tarr['content'] = $resultarr['content'][0];   
    		$result     = json_encode($tarr);
    		die($result);
    	}	
    }

    public function apkinfo($package)
    {      
                $post_data  = array(
                                'action=getapkinfo',
                                'packagename='.$package
                );
                $post_data  = implode('&',$post_data);
                $result     = $this->geturldatapost($this->taskmobile, $post_data);
                $resultarr  = json_decode($result,true);

                $tarr['body'] = $resultarr['content'][0];
 
                return $tarr;               
                //$vercode    = (isset($resultarr['body']['veresionCode']))?(int)$resultarr['body']['veresionCode']:1;
                //return $vercode;
    }

    private function _addApk($postArr, $tdata)
    {
    	$folder                 = '';
    	$postArr['folder']      = $folder;
    	$addtime                = date('Y-m-d H:i:s');
    	$postArr['insert_time'] = $addtime;
    	$postArr['update_time'] = $addtime;
  	if($postArr['label']=="" || $postArr['business']=="" || $postArr['type']==""
    			|| $postArr['packagename']=="" || $postArr['version']=="" || $postArr['apkfile']==""){
	     Logs::write('updateappAction() _addApk anyparm is empty:'.json_encode($postArr), 'debug');
   	     return false;
    	}
    	if(strpos($postArr['apkfile'],"http") === false)
    	{
    	}else{
    		$tfilearr = explode("?",$postArr['apkfile']);
    		$postArr['apkfile'] = $tfilearr[0];
    	}
    	$crc                    = sprintf("%u", crc32($postArr['apkfile']));
    	$reData                 = $this->getWidgetTable()->getWidgetData(array('identity'=>$crc));
    	$resultArr              = array();
    	foreach($reData as $tempResult)
    	{
    		$resultArr[] = (array)$tempResult;
    	}
    	if(count($resultArr)>0)
    	{
    		$apkarray = array(
   				'identity'    => $crc,
    				'name'        => '',
    				'apk_url'     => $postArr['apkfile'],
    				'icon_url'    => $postArr['apkicon'],
    				'folder'      => $folder,
    				'size'        => $postArr['size'],
    				'version'     => $postArr['version'],
    				'apkmd5'      => $postArr['md5'],
    				'insert_time' => $addtime,
    				'update_time' => $addtime,
    				'author'      => $postArr['author'],
    		);
    		$this->getApkTable()->updateApk($apkarray);
    		$this->getWidgetTable()->updateWidgetData(array(
					    			'id' 	=> intval($tdata['id']),
					    			'label' => $postArr['label'],
					    		));
		Logs::write('updateappAction() _addApk resultArr the apk is last', 'debug');
		return false;
    	}
    
    	$postArr['channel']  = (strpos($postArr['apkfile'],"http") === false)?'0':'1';
    
    	$postArr['identity'] = $crc;
    	$maxresult           = $this->getWidgetTable()->getMaxWidget( $postArr['type']  );
    	$maxobj              = $maxresult->current();
    	$maxorder            = $maxobj->maxorder;
    	$mycommend           = $maxorder+1;
    	if( !isset($postArr['sequence']) || empty($postArr['sequence']) ){
    		$postArr['sequence'] = $mycommend;
    	}
    	$postArr['cpid']     = sprintf("%u", crc32($postArr['label']));
    
    	//var_dump($postArr);exit;
    	$widgetid            = $this->getWidgetTable()->saveWidget((array)$postArr);
    	$mybusiness          = $postArr['business'];
    	$productbusiness     = $this->productStr[$mybusiness];
    	$tempproduct         = $this->getProductTable()->getDataProduct(array('business'=>$productbusiness));
    	foreach ($tempproduct as $myproduct)
    	{
    		$this->getWidgetProductTable()->saveProductArr(array(
    				'product'     => $myproduct->name,
    				'widget'      => $crc,
    				'insert_user' => $postArr['author'],
    		));
    	}
    	$apkarray = array(
    			'identity'    => $crc,
    			'name'        => '',
    			'apk_url'     => $postArr['apkfile'],
    			'icon_url'    => $postArr['apkicon'],
    			'folder'      => $folder,
    			'size'        => $postArr['size'],
    			'version'     => $postArr['version'],
    			'apkmd5'      => $postArr['md5'],
    			'insert_time' => $addtime,
    			'update_time' => $addtime,
    			'author'      => $postArr['author'],
    	);
    	$this->getApkTable()->saveApk($apkarray);
	return true;
    }

    public function updateappAction()
    {
	$uData           = $this->checkLogin('down');
        $type            = $_REQUEST['type'];
        $countListWidget = $this->getWidgetTable()->getCountListnum($type);
	$listData    = $this->getWidgetTable()->getWidgetList(1,$countListWidget,$type);
    	$listDataArr = array();
    	foreach($listData as $list)
    	{
    		$tdata     = (array)$list;
                $id        = $tdata['identity'];
                $pack      = $tdata['package'];
                $version   = (int)$tdata['version'];

                $resultarr = $this->apkinfo($pack);   
 
                $newver    = (isset($resultarr['body']['versionCode']))?(int)$resultarr['body']['versionCode']:1;
                $sequence  = (int)$tdata['sequence'];
                                
                if( $newver >= $version )
                {
                      if( intval($type) == 2 && ($sequence == 7 || $sequence == 32 || $sequence == 5 || $sequence == 31) ){ $df="5"; }
                      else
                      {
                           $label     = (isset($resultarr['body']['appName']))?$resultarr['body']['appName']:"";                                                      
                           $author    = $uData->username;
                           $note      = (isset($resultarr['body']['description']))?$resultarr['body']['description']:"";
                           $apkfile   = (isset($resultarr['body']['apkURL']))?$resultarr['body']['apkURL']:"";
                           $apkicon   = (isset($resultarr['body']['iconURL']))?$resultarr['body']['iconURL']:"";
                           $apksize   = (isset($resultarr['body']['fileSize']))?$resultarr['body']['fileSize']:"";
                           $apkmd5    = (isset($resultarr['body']['apkMD5']))?$resultarr['body']['apkMD5']:"";
                           $turl      = "http://csm.coolyun.com/recommend/addapk"; 
                           $post_data = array(
                                      'label' => $label,
                                      'business' => 7,
                                      'type' => $type,
                                      'packagename' => $pack,
                                      'classname' => "",
                                      'version' => $newver,
                                      'author' => $author,
                                      'note' => $note,
                                      'tj' => 0,
                                      'md5' => $apkmd5,
                                      'size' => $apksize,
                                      'apkfile' => $apkfile,                                 
                                      'sequence' => $sequence,
                                      'apkicon' => $apkicon,
                           );
			  
                 //          echo $pack."<br>";   
                           //if(!$this->_addApk($post_data)){
                	   //	echo 'add one';           
			   //	continue;
                           //}i
			  if(!$this->_addApk($post_data, $tdata)){
                         	Logs::write('updateappAction() _addApk failed:'.json_encode($post_data), 'debug');
                           	continue;
                           }
			 //  $this->_addApk($post_data);
			   //$result =  $this->geturldatapost($turl,$post_data);
//			   die($result);
                           //$wurl   = "http://csm.coolyun.com/recommend/use";
                           $usedata = array(
                                 //'t' => "use",
                                 'id'=> (int)$tdata['id'],
                                 'v' => 0,
                                 //'package' => $pack,
                           );
                           $this->getWidgetTable()->updateWidgetData(array( 
                                      "id" => intval($tdata['id']),
                                      "is_using" => 0,
                           ));
		           
                           //$this->geturldatapost($wurl,$usedata);

                      }
                
                $this->getApkTable()->updateApp(array('identity'=>$id,'newversion'=>$newver)); 
                }
        
    	}
        echo 'success'; exit;
    }

    public function geturldatapost( $url,$post_data )
    {
    	$ch     = curl_init();
    	curl_setopt($ch, CURLOPT_POST, 1);
    	curl_setopt($ch, CURLOPT_URL,$url);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    	ob_start();
    	$result = curl_exec($ch);
    	$result = ob_get_contents() ;
    	ob_end_clean();    	
    	return $result;
    }
   

    public function newinfoAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	//if ($request->isPost()) 
        if (1)
    	{
                $apkurl = $_REQUEST['apkurl'];
    		Logs::write('SiteController::newinfoAction() apkurl:'.$apkurl, 'log');
		$crc = sprintf("%u", crc32(file_get_contents($this->filepath.'/'.$apkurl)));
                $mysize = filesize($this->filepath.'/'.$apkurl);                
                $mymd5  = md5_file($this->filepath.'/'.$apkurl);
		
    		$reData = $this->getWidgetTable()->getWidgetData(array('identity'=>$crc));
			$resultArr = array();
			foreach($reData as $tempResult)
			{
				$resultArr[] = (array)$tempResult;
			}
    		if(count($resultArr)>0)
    		{
    			die('exist');
    		}
	    	
    		$apktool = new ApkTools();
    		$tempfile = $this->mystr.file_get_contents($this->tempaddfile).'/';
		
    		$folder = $this->filepath.$tempfile;
    		$foldertemp = $this->tempfolder;
    		//$this->deldir($this->tempfolder); 

    		$arrApkParam = $apktool::getApkParam($foldertemp, $this->toolpath,$this->filepath.'/'.$apkurl);
                //var_dump($arrApkParam);exit;
		if(!$arrApkParam)
		{
		        die('error');
		}
    		$icon = $arrApkParam['icon'];
    		$iconfile = $apktool::getAkpIcon($arrApkParam['apkfold'], $icon);
		$fileArr = explode("/",$iconfile);
                //var_dump($iconfile,$folder.end($fileArr));exit;
		$t_file_name = end($fileArr);
		$extArr = explode(".",$t_file_name);
                $crc = sprintf("%u", crc32(file_get_contents( $iconfile )));
		$newicon = $folder.$crc.'_default.'.end($extArr);
		//echo $newicon;
    		@copy($iconfile, $newicon);
    		$arrApkParam['icon'] = $newicon;
    		//$classname = $apktool::getClassData($foldertemp.'package/AndroidManifest.xml');   
		$classname = $apktool::getClassData($arrApkParam['apkfold'].'/AndroidManifest.xml');             
		$classnameNew = $classname;
    		if($classname[0]==".")
    		{
    			$classnameNew = $arrApkParam['packagename'].$classname;
    		}    		
    		
		$arrApkParam['classname'] = $classnameNew;
    		//$arrApkParam['imgicon'] = $tempfile.end($fileArr);
			$len = strlen( $tempfile.$crc.'_default.'.end($extArr) );
			$mytempicon = substr( $tempfile.$crc.'_default.'.end($extArr), 1, $len);
    		$arrApkParam['imgicon'] = $mytempicon;

                $arrApkParam['mysize']  = $mysize;
                $arrApkParam['mymd5']   = $mymd5;
			die(json_encode($arrApkParam));    		
    	}
    	die("");
    }
 
    public function infoAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost()) 
    	{
    		$postArr   = $request->getPost();
    		$apkurlnew = $postArr['apkurl'];
    		$apkurl    = file_get_contents($this->tempaddfile)."/".$apkurlnew;
    		$crc = sprintf("%u", crc32(file_get_contents($this->filepath.'/'.$apkurl)));
    		$reData = $this->getWidgetTable()->getWidgetData(array('identity'=>$crc));
			$resultArr = array();
			foreach($reData as $tempResult)
			{
				$resultArr[] = (array)$tempResult;
			}
    		if(count($resultArr)>0)
    		{
    			die('exist');
    		}    		
    		$apktool = new ApkTools();
    		$tempfile = $this->mystr.file_get_contents($this->tempaddfile).'/';
		    Logs::write('SiteController::infoAction(): '.$tempfile, 'log');
    		$folder = $this->filepath.$tempfile;
    		$foldertemp = $this->tempfolder;
    		$this->deldir($this->tempfolder);                
    		$arrApkParam = $apktool::getApkParam($foldertemp, $this->toolpath,$this->filepath.'/'.$apkurl);
            //var_dump($arrApkParam);exit;
			if(!$arrApkParam)
			{
			    die('error');
			}
    		$icon = $arrApkParam['icon'];
    		$iconfile = $apktool::getAkpIcon($arrApkParam['apkfold'], $icon);
    		$fileArr = explode("/",$iconfile);
            //var_dump($iconfile,$folder.end($fileArr));exit;
		    $t_file_name = end($fileArr);
		    $extArr = explode(".",$t_file_name);
            $crc = sprintf("%u", crc32(file_get_contents( $iconfile )));
		    $newicon = $folder.$crc.'_default.'.end($extArr);
    		@copy($iconfile, $newicon);
    		$arrApkParam['icon'] = $newicon;
            $classname = $apktool::getClassData($arrApkParam['apkfold'].'/AndroidManifest.xml');             
            $classnameNew = $classname;
    		if($classname[0]==".")
    		{
    			$classnameNew = $arrApkParam['packagename'].$classname;
    		}    		

    		$arrApkParam['classname'] = $classnameNew;
    		$arrApkParam['apkfile']   = $apkurl;
			$len = strlen( $tempfile.$crc.'_default.'.end($extArr) );
			$mytempicon = substr( $tempfile.$crc.'_default.'.end($extArr), 1, $len);
    		$arrApkParam['imgicon'] = $mytempicon;
			die(json_encode($arrApkParam));    		
    	}
    	die("");
    }

    public function useimgAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";
    		if(empty($id) || $myval=='n')
    		{
    			die('error');
    		}
    		$imgArr = array(
    				'id'=>$id,
    				'is_using'=>$myval,
    		);
    		$this->getImgTable()->updateImgData($imgArr);
    		die('success');    		    		
    	}	    	
    }

    public function useiconAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";
    		if(empty($id) || $myval=='n')
    		{
    			die('error');
    		}
    		$imgArr = array(
    				'id'=>$id,
    				'is_using'=>$myval,
    		);

    		$this->getIconTable()->updateImgData($imgArr);
    		die('success');    		    		
    	}	    	
    }

    public function useAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$type = isset($postArr['t'])?$postArr['t']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";

                $mypack = isset($postArr['package'])?$postArr['package']:"";

    		if(empty($id) || empty($type) || $myval=='n')
    		{
    			die('error');
    		}
    		if($type=="use")
    		{

                  $widgetdata = $this->getWidgetTable()->getWidgetData(array('id'=>$id));
                  $tmpobj = $widgetdata->current();                  
                  
                  if(intval($myval)==0){

                        $widgetArr = array(
                                'id'=>$id,
                                'is_using'=>$myval,
                        );
                        
                        $this->getWidgetTable()->updateWidgetData($widgetArr);

                        $maxdata = $this->getWidgetTable()->getMaxID($mypack);
                        $maxidobj = $maxdata->current();
                        $maxid = $maxidobj->maxid;
                        /*if(intval($maxid)!=intval($id))
                        {
                             $newwidgetArr = array(
                                'id'=>$maxid,
                                'sequence'=>(int)$tmpobj->sequence,
                             );
                             $this->getWidgetTable()->updateWidgetData($newwidgetArr);
                             
                        }else{
                        */
                             $type = $tmpobj->type;
                             $currsequence = (int)$tmpobj->sequence;

                             $maxresult = $this->getWidgetTable()->getMaxWidget($type);
                             $maxobj = $maxresult->current();
                             $maxorder = $maxobj->maxorder;

                             $widgetArrnew = array();
                             for($i=$currsequence+1;$i<=$maxorder;$i++){
                                $widgetArrnew = array(
                                    'sequence'=>$i-1,
                                    'my'=>$i,
                                    'type'=>$type,
                                );
                                $this->getWidgetTable()->updateWidgetDataSequence($widgetArrnew);  
                                $this->tjorderAction();
                         
                             }
                        
                        //}
                        
                        die("success");                         
                  }
 
                  if(intval($myval)==1){
                        $type = $tmpobj->type;

                        $maxresult = $this->getWidgetTable()->getMaxWidget($type);
                        $maxobj = $maxresult->current();
                        $maxorder = $maxobj->maxorder;
                        $mycommend = $maxorder+1;

                        //echo $mycommend;exit;

    			$widgetArr = array(
    				'id'=>$id,
    				'is_using'=>$myval,
                                'sequence'=>$mycommend,
    			);

    			$this->getWidgetTable()->updateWidgetData($widgetArr);
                        $this->tjorderAction();
    			die('success');
                  }


    		}
    		if($type=="commend")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'commend'=>$myval,
    					//'sequence'=>((int)$myval==1)?1:0,
    			);
    			$this->getWidgetTable()->updateWidgetData($widgetArr);
    			die('success');
    		}    		
    		if($type=="upcommend")
    		{
    			$widgetArr = array(
    					'id'=>$id,
					
    					'sequence'=>(int)$myval,
    			);
    			$this->getWidgetTable()->updateWidgetData($widgetArr);
                        $this->tjorderAction();
    			die('success');
    		}    		
    		
    	}	 
    }

    
    public function deldir($dir) {
    	$dh=opendir($dir);
    	while ($file=readdir($dh)) {
    		if($file!="." && $file!='makeapk.php' && $file!="..") {
    			$fullpath=$dir."/".$file;
    			if(!is_dir($fullpath)) {
    				unlink($fullpath);
    			} else {
    				$this->deldir($fullpath);
    			}
    		}
    	}
    	closedir($dh);
    	if($dir!=$this->tempfolder){
	    	if(rmdir($dir)) {
	    		return true;
	    	} else {
	    		return false;
	    	}
    	}
    }
    

    public function productAction()
    {
    	$listsize = 2;
    	$pageSize = 20;
    	$uData = $this->checkLogin('product');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	
    	$countWidget = $this->getProductTable()->getProductCount();
    	 
    	 
    	$totalPage=ceil($countWidget/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getProductTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();
		
    	$businessArr = $params['params']['apkbussiness'];
    	 
    	//var_dump($listData);exit;
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'businessArr'=>$businessArr,'countWidget'=>$countWidget,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function addproductAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = $postArr['myid'];
    		$author = $postArr['author'];
    		$addtime = date('Y-m-d H:i:s');
//    		die(json_encode($postArr));exit;
    		if(empty($postArr['productheight']) || 
    		   empty($postArr['productwidth']) || empty($postArr['name']) || empty($postArr['business']))
    		{
    			die('error');
    		}
    		
    		
    		if($id=="")
    		{
    			$tempname = $this->getProductTable()->getProductData(array('name'=>$postArr['name']));
    			if($tempname>0)
    			{
    				die('exist');
    			}
    			 
    			$imgdata = array(
    					'name'=>$postArr['name'],
    					'height'=>$postArr['productheight'],
    					'width'=>$postArr['productwidth'],
    					'business'=>$postArr['business'],
    					'insert_time'=>$addtime,
    					'insert_user'=>$author,
    					'update_time'=>$addtime,
    					'update_user'=>$author,
    			);
    			$this->getProductTable()->saveProductArr($imgdata);
    			if( in_array(intval($postArr['business']), $this->productOperation) )
    			{
    				$widgetbusiness = $postArr['business'];
    				$widgetList = $this->getWidgetTable()->getBusinessWidget(array('business'=>$widgetbusiness));
    				foreach ($widgetList as $mywidget)
    				{
					if($mywidget->type == 9 || $mywidget->type == 10 || $mywidget->type == 11 || $mywidget->type == 12){
    						continue;
    					}
    					$this->getWidgetProductTable()->saveProductArr(array(
    							'product'=>$postArr['name'],
    							'widget' =>$mywidget->identity,
    							'insert_user'=>$author,
    					));    					
    				}
    			}    			
    			die('success');
    		}else{
    			$uparr = array(
    					'height'=>$postArr['productheight'],
    					'width'=>$postArr['productwidth'],
    					'name'=>$postArr['name'],
    					'update_user'=>$author,
    					'business'=>$postArr['business'],
    					'id'=>$id,
    			);
    			$this->getProductTable()->updateProductData($uparr);
    			die("success");
    		}
    		
    	}
    	die('');
    }

	
	public function addextendAction()
	{
		$uData = $this->checkLogin('addextend');
		if(!$uData)
		{
			die('nopower');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postArr = $request->getPost();
			if( empty($postArr['extend']) || empty($postArr['channelid']))
			{
				die('empty');
			}
			$id = $postArr['id'];
			$channel = $postArr['extend'];
			$identity = $postArr['channelid'];
			if($id)
			{
				$this->getExtendTable()->updateAppData(array('id'=>$id,'channel'=>$channel));
				die('success');
			}
			$result = $this->getExtendTable()->getExtendData(array('identity'=>$identity));
			if($result && $result->id)
			{
				die('exist');
			}
			$this->getExtendTable()->saveApp(array('identity'=>$identity,'channel'=>$channel,'insert_user'=>$uData->username));
			die('success');
		}
	}


    public function statisticsAction()
    {
		$uData = $this->checkLogin('right');
		$tempData = $this->getProductTable()->getProductAllDataList();
		
		$infoList = array();

		foreach($tempData as $list)
		{
			$infoList[] = (array)$list;
		}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();

    	return new ViewModel(array('infoData'=>$infoList,'params'=>$params));
    }


    public function exportdataAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];

			$product = isset($postArr['product'])?$postArr['product']:'';

			$appidentity = isset($postArr['identity'])?$postArr['identity']:'';

			$timeType = isset($postArr['timetype'])?$postArr['timetype']:'day';


    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59';
    		$t_start = strtotime($start);
    		$t_end   = strtotime($end);
    		$datelist = array();
    		
			if($timeType=='day'){
				for($i = $t_start;$i<=$t_end;$i=$i+86400)
				{
					$datelist[] = date('Y-m-d',$i);
				}
			}else if($timeType=='week'){
				$getWeekData = $this->getDownloadTable()->getAppWeekType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
				}
			}else if($timeType=='month'){
				$getWeekData = $this->getDownloadTable()->getAppMonthType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
				}
			}

			//var_dump($datelist);exit;
    		$infoList = array();
    		foreach ($datelist as $val)
    		{
    			$mystart = $val.' 00:00:00';
    			$myend   = $val.' 23:59:59';

				if(!empty($product))
				{					
					$myproduct = $product;

					if($timeType=='day'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
						}
					}else if($timeType=='week'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getWeekAppCount(array('week'=>$val,'product'=>$myproduct));
						}

					
					}else if($timeType=='month'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getMonthAppCount(array('week'=>$val,'product'=>$myproduct));
						}
					
					}



    				if($getInfo->count()==0)
    				{
    					$infoList[$val][] = array(
    								$myproduct=>array(),
    					);
    				}else
    				{
    						foreach ($getInfo as $mydata)
    						{
    							$infoList[$val][$myproduct][] = (array)$mydata;
    						}
    				}
				}

				if(empty($product))
				{

					if($timeType=='day'){
						$getData = $this->getDownloadTable()->getProduct(array('start'=>$mystart,'end'=>$myend));
					}else if($timeType=='week'){
						$getData = $this->getDownloadTable()->getProductWeek(array('week'=>$val));	
					}else if($timeType=='month'){
						$getData = $this->getDownloadTable()->getProductMonth(array('week'=>$val));	
					}
					//$getData = $this->getDownloadTable()->getProduct(array('start'=>$mystart,'end'=>$myend));
					//die($getData->count());
					if($getData->count()==0)
					{
						$infoList[$val][] = array();
					}else
					{
						
						foreach ($getData as $templist)
						{
							$myproduct = $templist->product;


							if($timeType=='day'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
								}
							}else if($timeType=='week'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getWeekAppCount(array('week'=>$val,'product'=>$myproduct));
								}

							
							}else if($timeType=='month'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getMonthAppCount(array('week'=>$val,'product'=>$myproduct));
								}
							
							}


							//$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));


							if($getInfo->count()==0)
							{
								$infoList[$val][] = array(
										$myproduct=>array(),
								);
							}else
							{
								foreach ($getInfo as $mydata)
								{
									$infoList[$val][$myproduct][] = (array)$mydata;
								}
							}
						}
					}


				}

    			
    		}
    		
    		
			$excelStr = '<?xml version="1.0"?>
						 <?mso-application progid="Excel.Sheet"?>
						 <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
							xmlns:o="urn:schemas-microsoft-com:office:office"
							xmlns:x="urn:schemas-microsoft-com:office:excel"
							xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
							xmlns:html="http://www.w3.org/TR/REC-html40">
						 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
							<Version>12.00</Version>
						 </DocumentProperties>
						 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
							<RemovePersonalInformation/>
						 </OfficeDocumentSettings>
						 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
							<WindowHeight>11640</WindowHeight>
							<WindowWidth>19200</WindowWidth>
							<WindowTopX>0</WindowTopX>
							<WindowTopY>90</WindowTopY>
							<ProtectStructure>False</ProtectStructure>
							<ProtectWindows>False</ProtectWindows>
						 </ExcelWorkbook>
						 <Styles>
							<Style ss:ID="Default" ss:Name="Normal">
								<Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
								<Borders/>
								<Font ss:FontName="宋体" x:CharSet="134" ss:Size="11" ss:Color="#000000"/>
								<Interior/>
								<NumberFormat/>
								<Protection/>
								</Style>
						 </Styles>';

    		$strHtml = '';
			$cnum = 0;
			$cnuminfo = 0;

			$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
								<td align="right" style="font-size:12px; background-color: #FFFFFF;"><a target="_blank" href="/export.php">导出数据文件</a></td>
							 </tr>
							 </table>
							 </td>
						</tr>';


			$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>';
    		foreach($infoList as $kinfo=>$vinfo)
			{
                $cnuminfo++;
				if($timeType=='week') $kinfo .= '周';
				if($timeType=='month') $kinfo .= '月';
				$stylestr = ((int)$cnuminfo==1)?'color:red;font-size:12px;cursor:pointer;':'font-size:12px;cursor:pointer;background-color: #FFFFFF;';
				$strHtml .= '<td onclick="showlistdata('.$cnuminfo.')" height="20" align="center" style="'.$stylestr.'" id="current_'.$cnuminfo.'">'.$kinfo.'</td>';
			}
			$strHtml .= '</tr></table></td></tr>';

			
    		foreach($infoList as $kinfo=>$vinfo)
			{
				$cnum++;
				if(count($vinfo)>0)
				{
					
					if($timeType=='week') $kinfo .= '周';
					if($timeType=='month') $kinfo .= '月';

					$excelStr .= '<Worksheet ss:Name="'.$kinfo.'">';
					$excelStr .= '<Table ss:ExpandedColumnCount="5" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="54" ss:DefaultRowHeight="13.5">
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
								  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>\n';

                    $excelStr .= '   <Row ss:AutoFitHeight="0">
    <Cell><Data ss:Type="String">机型</Data></Cell>
    <Cell><Data ss:Type="String">应用名</Data></Cell>
    <Cell><Data ss:Type="String">下载次数</Data></Cell>
    <Cell><Data ss:Type="String">包大小</Data></Cell>
	<Cell><Data ss:Type="String">下载流量</Data></Cell>
   </Row>\n'; 
                    $displaystr = ((int)$cnum==1)?'display:block;':'display:none;';
					

                    $strHtml .= '	  <tr id="info_'.$cnum.'" style="'.$displaystr.'">
	    <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	      <tr>
	        <td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">日期</span></div></td>
	        <td width="10%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">机型</span></div></td>
	        <td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">应用名</span></div></td>
	        <td width="10%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">下载量</span></div></td>
		<td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">文件大小</span></div></td>
		<td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">下载流量</span></div></td>
	      </tr>
	      <tbody id="showdatalist_'.$cnum.'">
';


					foreach($vinfo as $kkinfo=>$vvinfo)
					{
						if(count($vvinfo)>0)
						{
							foreach($vvinfo as $kkkinfo=>$vvvinfo)
							{
								$tempIdentity = $vvvinfo['identity'];
								$widgetResult = $this->getWidgetTable()->getWidgetData(array('identity'=>$tempIdentity));
								$apkResult = $this->getApkTable()->getApkData(array('identity'=>$tempIdentity));
								
								$widget_data = $widgetResult->current();
								$apk_data = $apkResult->current();
								$strHtml .= '<tr><td height="20" class="STYLE19" >'.$kinfo.'</td><td height="20" class="STYLE19">'.$kkinfo.'</td><td height="20" class="STYLE19">'.$widget_data->label.'</td><td height="20" class="STYLE19">'.$vvvinfo['countnum'].'</td><td height="20" class="STYLE19">'.$apk_data->size.'</td><td height="20" class="STYLE19">'.$apk_data->size*$vvvinfo['countnum'].'</td></tr>';

								$excelStr .= '   <Row ss:AutoFitHeight="0">
    <Cell><Data ss:Type="String">'.$kkinfo.'</Data></Cell>
    <Cell><Data ss:Type="String">'.$widget_data->label.'</Data></Cell>
    <Cell><Data ss:Type="String">'.$vvvinfo['countnum'].'</Data></Cell>
    <Cell><Data ss:Type="String">'.$apk_data->size.'</Data></Cell>
	<Cell><Data ss:Type="String">'.$apk_data->size*$vvvinfo['countnum'].'</Data></Cell>
   </Row>\n';



							}
						}
					}

					$excelStr .= '</Table>\n';
					$excelStr .= '</Worksheet>\n';

			$strHtml .= '</tbody>
	    </table></td>
	  </tr>';

				}
			}
			$excelStr .= '</Workbook>';
			@file_put_contents($this->dataxmlfile,$excelStr);

    		//var_dump($infoList);exit;
    		
    		die($strHtml);
			exit;
    		die(json_encode($postArr));
    		
    		
    	}    	
    }

	public function getapplistAction()
	{
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isGet())
    	{
    		$app = $_GET['app'];

    		$childData = $this->getWidgetTable()->getAppAll(array('type'=>$app));
    		$childList = array();
    		foreach($childData as $mychild)
    		{
    			$childList[] = array('identity'=>$mychild['identity'],'appshow'=>$mychild['label']);
    		}
    		die(json_encode($childList));    		
    	}    	
	
	}


    public function showflashAction()
    {
		$uData = $this->checkLogin('right');
		$tempData = $this->getProductTable()->getProductAllDataList();
		
		$infoList = array();

		foreach($tempData as $list)
		{
			$infoList[] = (array)$list;
		}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();

    	return new ViewModel(array('infoData'=>$infoList,'params'=>$params));
    }


    public function exportflashAction()
    {
	$uData = $this->checkLogin('right');
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];
			$productlist = isset($postArr['productlist'])?$postArr['productlist']:'';
			$appidentity = isset($postArr['identity'])?$postArr['identity']:'';
			$timeType = isset($postArr['timetype'])?$postArr['timetype']:'day';

			$productArr = explode(",",$productlist);
			if(count($productArr)==0)
			{
				die("");
			}
    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59';
    		$t_start = strtotime($start);
    		$t_end   = strtotime($end);
			if($t_start>$t_end)
			{
				die("");
			}
			$colorArr = array('0080C0','008040','808080','800080','FF8040','FFFF00','FF0080','FF2080','CC6000','DD0020','AA0150','CC0150','BB0100','DD0158','EE0150','660150','770150','550150','440150','330150','110150');

			$excelStr = "<chart caption='Site hits per hour' subCaption='In Thousands' numdivlines='9' lineThickness='2' showValues='0' numVDivLines='22' formatNumberScale='1' labelDisplay='ROTATE' slantLabels='1' anchorRadius='2' anchorBgAlpha='50' showAlternateVGridColor='1' anchorAlpha='100' animation='1' limitsDecimalPrecision='0' divLineDecimalPrecision='1'>\n";
			$excelStr .= "<categories>\n";

    		$datelist = array();
			if($timeType=='day'){
				for($i = $t_start;$i<=$t_end;$i=$i+86400)
				{
					$datelist[] = date('Y-m-d',$i);
                    $excelStr .= "<category label='".date('Y-m-d',$i)."' />\n";
				}
			}else if($timeType=='week'){
				$getWeekData = $this->getDownloadTable()->getAppWeekType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
					$excelStr .= "<category label='".$row->wk."' />\n";
				}
			}else if($timeType=='month'){
				$getWeekData = $this->getDownloadTable()->getAppMonthType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
					$excelStr .= "<category label='".$row->wk."' />\n";
				}
			}

			$excelStr .= "</categories>\n";

			$infoList = array();

			$tempCountnum = 0;
			foreach($productArr as $phoneval)
			{
				$exColor = $colorArr[$tempCountnum];
				$excelStr .= "<dataset seriesName='".$phoneval."' color='".$exColor."' anchorBorderColor='".$exColor."' >\n";
				$tempCountnum++;
				foreach ($datelist as $val)
				{
					$mystart = $val.' 00:00:00';
					$myend   = $val.' 23:59:59';

					if(!empty($phoneval))
					{					
						$myproduct = $phoneval;

						if($timeType=='day'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getAppCountAll(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
							}
						}else if($timeType=='week'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getWeekAppCountAll(array('week'=>$val,'product'=>$myproduct));
							}

						
						}else if($timeType=='month'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getMonthAppCountAll(array('week'=>$val,'product'=>$myproduct));
							}
						
						}
						if($getInfo->count()==0)
						{
							$excelStr .= "<set value='0' />\n";							
						}else
						{
							foreach ($getInfo as $mydata)
							{
								$excelStr .= "<set value='".$mydata->countnum."' />\n";							
							}
						}
					}
				}
				$excelStr .= "</dataset>\n";

			}
			$excelStr .= "</chart>\n";
			
			@file_put_contents($this->dataxmlfileflash,$excelStr);

    		//var_dump($infoList);exit;
    		
			exit;
    		
    		
    	}    	
    }

    public function linkproductAction()
    {
	$uData = $this->checkLogin('right');
    	$listsize = 8;
    	$id = $this->params('id');
    	$mybusiness = $_GET['mybusiness'];
    	$mybusiness = trim($mybusiness);  
//    	$mybusiness = $this->businessNumStr[$mybusiness];
//    	$mybusiness = str_replace(";", ",", $mybusiness);
    	$mybusiness = $this->productStr[$mybusiness];
    	if($id=='')
    	{
    		die('error');
    	}    	
    	$tempData = $this->getProductTable()->getDataProduct(array( 'business'=>$mybusiness,));    	    	
    	$widgetData = $this->getWidgetProductTable()->getProductSelect(array(
    			'valid'=>1,
    			'widget'=>$id,
    	));
    	
    	$productList = array();
    	foreach($widgetData as $row)
    	{
    		$productList[] = $row->product;
    	}
    	$infoList = array();
    	$module_temp = new Module();
    	$params = $module_temp->getParams();
    	 
    	foreach($tempData as $list)
    	{
    		$productInfo   = $this->getProductTable()->getProductInfo(array('name'=>$list->name));
    		$productData   = $productInfo->current();    		
    		$businessName  = $params['params']['apkbussiness'][$productData->business];
    		if(count($productList)>0){
    			$select = (in_array($list->name, $productList))?1:0;
    			$infoList[] = array('product'=>$list->name,'businessName'=>$businessName,'select'=>$select);
    		}else
    		{
    			$infoList[] = array('product'=>$list->name,'businessName'=>$businessName,'select'=>0);    			 
    		}
    	}
    	return new ViewModel(array(
    			'businessStr'=>$this->businessNumArray[$_GET['mybusiness']],'infoData'=>$infoList, 'listsize'=>$listsize, 'widgetid'=>$id, 'tempbusiness'=>$_GET['mybusiness'],
    	));
    }
    public function addproductwidgetAction()
    {	
    	$uData = $this->checkLogin('add');
    	$author = $uData->username;    	
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['productstr']) || empty($postArr['widgetid']) )
    		{
    			die('empty');
    		}
    		$widgetid = $postArr['widgetid'];
    		$productstr = $postArr['productstr'];
    		$productstr = urldecode($productstr);
    		$productArr = explode(";", $productstr);
    		$mydata = $this->getWidgetProductTable()->getProductSelect(array(
    				'widget'=>$widgetid,
    		));
    		if($mydata->count()>0){
	    		foreach($mydata as $myrow)
	    		{
	    			$tempProduct = $myrow->product;
	    			$tempId      = $myrow->id;
	    			if(in_array($tempProduct, $productArr))
	    			{
	    				$this->getWidgetProductTable()->updateProductData(array('id'=>$tempId,'valid'=>1));
	    			}else
	    			{
	    				$this->getWidgetProductTable()->updateProductData(array('id'=>$tempId,'valid'=>0));
	    			}
	    		}
    		}    		
    		foreach ($productArr as $myproduct)
    		{
    			$mytempdata = $this->getWidgetProductTable()->getProductSelect(array(
    					'widget'=>$widgetid,
    					'product'=>$myproduct,
    			));
    			if($mytempdata->count()==0)
    			{
    				$this->getWidgetProductTable()->saveProductArr(array(
    					'product'=>$myproduct,
    					'widget' =>$widgetid,
    					'insert_user'=>$author,				
    				));
    			}    			 
    		}
    		die('success');
    	}    	
    }

    public function getWidgetTable()
    {
    	if (!$this->widgetTable) {
    		$sm = $this->getServiceLocator();
    		$this->widgetTable = $sm->get('Recommend\Model\WidgetTable');
    	}
    	return $this->widgetTable;
    }
    
    public function getApkTable()
    {
    	if (!$this->apkTable) {
    		$sm = $this->getServiceLocator();
    		$this->apkTable = $sm->get('Recommend\Model\ApkTable');
    	}
    	return $this->apkTable;
    }
    
    public function getImgTable()
    {
    	if (!$this->imgTable) {
    		$sm = $this->getServiceLocator();
    		$this->imgTable = $sm->get('Recommend\Model\ImgTable');
    	}
    	return $this->imgTable;
    }

    public function getIconTable()
    {
    	if (!$this->iconTable) {
    		$sm = $this->getServiceLocator();
    		$this->iconTable = $sm->get('Recommend\Model\IconTable');
    	}
    	return $this->iconTable;
    }


    
    public function getProductTable()
    {
    	if (!$this->productTable) {
    		$sm = $this->getServiceLocator();
    		$this->productTable = $sm->get('Recommend\Model\ProductTable');
    	}
    	return $this->productTable;
    }
	
	public function getExtendTable()
	{
		if (!$this->extendTable) {
			$sm = $this->getServiceLocator();
			$this->extendTable = $sm->get('Recommend\Model\ExtendTable');
		}
		return $this->extendTable;
	}	

	public function getDownloadTable()
	{
		if (!$this->downloadTable) {
			$sm = $this->getServiceLocator();
			$this->downloadTable = $sm->get('Recommend\Model\DownloadTable');
		}
		return $this->downloadTable;
	}

	public function getWidgetProductTable()
	{
		if (!$this->widgetproductTable) {
			$sm = $this->getServiceLocator();
			$this->widgetproductTable = $sm->get('Recommend\Model\WidgetProductTable');
		}
		return $this->widgetproductTable;
	}
	

    public function adpicAction()
    {
    	$uData = $this->checkLogin('addextend');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['myproduct']) )
    		{
    			die('empty');
    		}
                //echo time();exit;
    		$queryUrl   = "http://192.168.30.61/likeapp.php?start=0&num=20&product=".$postArr['myproduct'];
    		//$queryUrl   = "http://widget.yulong.com/advert.php?product=Coolpad5890";
                
                //echo $queryurl;exit;
                
    		$urlContent = file_get_contents($queryUrl);

                //echo $urlContent;exit;


    		$conArray   = json_decode($urlContent,true);
    		$adArray    = $conArray['app_items'];
    		if(count($adArray)==0)
    		{
    			die('nodata');
    		}
    		$showHtml = '';
    		foreach ($adArray as $temparr)
    		{
    			$tempurl   = $temparr['apk_url'];
    			$tempimg   = $temparr['icon_url'];
    			$temptit   = $temparr['name'];
    			$showHtml .= '<li><a title="'.$temptit.'" href="'.$tempurl.'" target="_blank"><img border="0" src="'.$tempimg.'" /></a></li>';
    		}
    		$showHtml .= '~';
    		foreach ($adArray as $key=>$myarr)
    		{
    			$key++;
    			$tempclass = ($key==1)?'on':'';    			 
    			$showHtml .= '<li class="'.$tempclass.'">'.$key.'</li>';
    		}
    		die($showHtml);
    	}
        else{
               return new ViewModel();
        }
    	//return new ViewModel();  	 

    	
    }




    
}


