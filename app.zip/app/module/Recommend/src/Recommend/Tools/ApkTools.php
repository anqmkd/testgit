<?php
namespace Recommend\Tools;
use Recommend\Fnlib\Fnlib;
use Recommend\Logs\Logs;
use DOMDocument;
class ApkTools
{
	public function __construct(){
	}
        
	public static function unzip($dir, $apktools, $file){
		try{	
			$stringsXML_exists 	= false;
			$result 		= array();
                        system('/usr/coolpad/soft/jdk1.7.0_09/bin/java -jar '.$apktools.' d -f '.$file.' '.$dir.' > /home/wwwroot/app/public/apktool.log');
                        file_put_contents("/home/wwwroot/app/public/apktool.log",'/usr/coolpad/soft/jdk1.7.0_09/bin/java -jar '.$apktools.' d -f '.$file); 
		}catch(Exception $e){
			Logs::write('ApkTooks::unzip():exception error:'.$e->getMessage(),'log');
		}
		return true;
	}

	
	public static function parseXml($xmlContent, $arrField){
		$returnVal = array();
		foreach ($arrField as $field => $value){
			if(preg_match('/'.$value.'\"([^\"]*)\"/i',$xmlContent, $req)){			
				$returnVal[$field] = $req[1];
			}
		}
		return $returnVal;
	}
	
	public function getUnique(){
		list($msec,$sec) = explode(" ",microtime());
		return $sec.strval($msec*1000000).rand(100,999);
	}
	
	public static function getApkParam($dir, $apktools, $file){
		$xml_file 	= array();
                $mytarr         = explode('/',$file);
                $arrfile        = explode('.',end($mytarr));
                $ext            = end($arrfile);
                $apkfold        = str_replace(".".$ext,"",end($mytarr));
	        $xml_file       = self::unzip($dir.$apkfold, $apktools, $file);

		file_put_contents("/home/wwwroot/app/public/apktool.log",'mv /home/wwwroot/app/'.$apkfold.' '.$dir);
                //var_dump('mv /home/wwwroot/app/'.$apkfold.' '.$dir);exit; 
                //system('mv /home/wwwroot/app/'.$apkfold.' '.$dir);                                		
		$stringXmlFile = $dir.$apkfold.'/res/values/strings.xml';
                /*
		if (!file_exists($stringXmlFile)){
			Logs::write('ApkTooks::getApkParam():strings.xml is not exist'.$stringXmlFile, 'log');
			return false;
		}
                */		
		$mainfestXmlFile 	= $dir.$apkfold.'/AndroidManifest.xml';

                //var_dump($mainfestXmlFile);exit;
                /*
		if(!file_exists($mainfestXmlFile)){
			Logs::write('ApkTools::getApkParam():androidMainfest.xml is not exist ', 'log');
			return false;
		}
                */
		$arrApkConfig = array('packagename'		=> 'package=',
							'versionCode'	=> 'versionCode=',
							'versionName'	=> 'versionName=',);
		
		$AndroidManifestXML = file_get_contents($mainfestXmlFile);
		//提取版本信息
		$arrApkVerParam 	= self::parseXml($AndroidManifestXML, $arrApkConfig);
		//提取应用名称
		$label= null;
		if(preg_match('/<application[\s\S]*? android:label="@string\/([^"]*)"/i',$AndroidManifestXML, $label)){
			if(count($label) >= 2 ){
				$arrApkVerParam['lable'] = $label[1];
				$stringXml = file_get_contents($stringXmlFile);
				$name = null;
				if(preg_match('/<string name=\"'.$label[1].'\">([^<]*)<\/string>/',$stringXml, $name)){
					if(count($name) >= 2){
						$arrApkVerParam['name'] = $name[1];
					}
				}
			}
		}
		
		//提取图标
		if(preg_match('/<application[\s\S]*? android:icon="@drawable\/([^"]*)"/i',$AndroidManifestXML, $icon)){
			if(count($icon) >=2 ){
				$arrApkVerParam['icon'] = $icon[1];
			}
		}
                if($arrApkVerParam['icon']==""){
                        if(preg_match('/<application[\s\S]*? android:logo="@drawable\/([^"]*)"/i',$AndroidManifestXML, $icon)){
                                if(count($icon) >=2 ){
                                        $arrApkVerParam['icon'] = $icon[1];
                                }
                        }
                }           
                $arrApkVerParam['apkfold'] = $dir.$apkfold;
		return $arrApkVerParam;
	}
	
	public static function getAkpIcon($dir, $iconName)
	{
		$tmpArr[0]=0;
		$tmpArr[1]=0;
		$tmpArr[2]='drawable';		
		$dirs = opendir($dir.'/res');		
		//查找最大的图片
		while($file = readdir($dirs)){
			$drawable_folder = array();
			preg_match('/(drawable(-.*?dpi)?)/i', $file, $drawable_folder);
			if(count($drawable_folder) == 0){
				continue;
			}
			$iconPath = $dir.'/res/'.$drawable_folder[1].'/'.$iconName.'.png';
			if(!file_exists($iconPath)){
				continue;
			}
			
			$iconInfo = getimagesize($iconPath);
			if($iconInfo[0] > $tmpArr[0] 
				&& $iconInfo[1] > $tmpArr[1]){
				$tmpArr[0] = $iconInfo[0];
				$tmpArr[1] = $iconInfo[1];
				$tmpArr[2] = $drawable_folder[1];
			}
		}
		$iconFile = $dir.'/res/'.$tmpArr[2].'/'.$iconName.'.png';
		Logs::write('ApkTools::GetApkIcon():iconFile:'.$iconFile, 'log');
		if(!file_exists($iconFile)){
			Logs::write('ApkTools::GetApkIcon():iconFile is not exit', 'log');
			return false;
		}
		return $iconFile;
	}
	
	public static function getClassData($xmlurl)
	{
		$classname = '';
		$simple = file_get_contents($xmlurl);
		
		
		$dom = new DOMDocument(); 
		$dom->loadXML($simple);
		$data = self::getArray($dom->documentElement);
		$mydata = $data['application'][0]['activity'];
		foreach($mydata as $k=>$v)
		{
			if(isset($v['intent-filter'])){
				if($v['intent-filter'][0]['action'][0]['android:name']=='android.intent.action.MAIN')
				{
                                        //var_dump($v['intent-filter'][0]);exit;
					if($v['intent-filter'][0]['category'][0]['android:name']=='android.intent.category.LAUNCHER')
					{
						$classname = $v['android:name'];						
					}
				}
			}			
		}
		return $classname;
	}
	
	public static function getArray($node) {
		$array = false;	
		if ($node->hasAttributes()) {
			foreach ($node->attributes as $attr) {
				$array[$attr->nodeName] = $attr->nodeValue;
			}
		}	
		if ($node->hasChildNodes()) {
			if ($node->childNodes->length == 1) {
				$array[$node->firstChild->nodeName] = self::getArray($node->firstChild);
			} else {
				foreach ($node->childNodes as $childNode) {
					if ($childNode->nodeType != XML_TEXT_NODE) {
						$array[$childNode->nodeName][] = self::getArray($childNode);
					}
				}
			}
		} else {
                       if(property_exists($node,'attributes')){
			 if(is_array($node->attributes)){
	                	foreach ($node->attributes as $attr) {
    					$array[$attr->nodeName] = $attr->nodeValue;
				}			 
			}
		}	}
		return $array;
	}
	
	
}
