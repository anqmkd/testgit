<?php
namespace Recommend\Fnlib;

use Recommend\Logs\Logs;

class Fnlib
{
	const UPLOAD_ERR_OK 		= 1;
	const UPLOAD_ERR_FILE_NAME	= 2;
	const UPLOAD_ERR_FILE_SIZE 	= 3;
	const UPLOAD_ERR_FILE_TMP 	= 4;
	
	
	public static function remove_file_path($strDir){
		$handle = opendir($strDir);
		if($handle === false){
			return false;
		}
		
		while(false !== ($item = readdir($handle))){
			if($item != "." && $item != ".."){
				if(is_dir("$strDir/$item")){
					self::remove_file_path("$strDir/$item");
				}else{
					if(!unlink("$strDir/$item")){
						return false;
					}
				}
			}
		}
		closedir($handle);
		
		if(!rmdir($strDir)){
			return false;
		}
		return true;
	}
	
	public static function remove_path_file($strDir){
		if(!file_exists($strDir)){
			return true;
		}
		$handle = opendir($strDir);
		if($handle === false){
			return false;
		}
	
		while(false !== ($item = readdir($handle))){
			if($item != "." && $item != ".."){
				if(is_dir("$strDir/$item")){
					self::remove_file_path("$strDir/$item");
				}else{
					if(!unlink("$strDir/$item")){
						return false;
					}
				}
			}
		}
		closedir($handle);
		return true;
	}
	
	public static function get_rsp_result($value, $strErr = ''){
		$result = array('result'=>$value,
				'error'=>$strErr);
		return json_encode($result);
	}	
	
	public static function makeDesDir($strDir)
	{
		$dir_dest = iconv('utf-8', 'gb2312', $strDir);
		if(!is_dir($dir_dest)){
			$result = mkdir($dir_dest, 0700, true);
			if (!$result) {
				Logs::write("fnlib::makeDesDir():".$dir_dest." failed", "log");
				return false;
			}
		}
		return true;
	}
	
	public static function  get_file_info($input, $key, &$f_name, &$f_size, &$f_tmp_file){
		if ($key < 0){
			$f_name 	= $_FILES[$input]['name'];
			$f_size 	= $_FILES[$input]['size'];
			$f_tmp_file = $_FILES[$input]['tmp_name'];
		}else{
			$f_name 	= $_FILES[$input]['name'][$key];
			$f_size 	= $_FILES[$input]['size'][$key];
			$f_tmp_file = $_FILES[$input]['tmp_name'][$key];
		}
	
		$result = self::UPLOAD_ERR_OK;
		if($f_name == null){
			Logs::write("f_name is empty", "log");
			$result = self::UPLOAD_ERR_FILE_NAME;
			return $result;		//返回错误代码 107:主题文件名为空
		}
	
		if($f_size == null){
			Logs::write("f_size is empty", "log");
			$result = self::UPLOAD_ERR_FILE_SIZE;
			return $result;	//返回错误代码 108:文件大小为空
		}
	
		if($f_tmp_file == null){
			Logs::write("f_tmp_file is empty", "log");
			$result = self::UPLOAD_ERR_FILE_TMP;
			return $result;		//返回错误代码 109:文件上传缓存失败
		}
		return $result;
	}
	
	static function get_respond_by_url($url, $date, $methord = 0){
		try{
			$ch = curl_init();
				
			if(!empty($date)){
				$url = $url.'?'.$date;
			}
	
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
			$curl_result = curl_exec($ch);
	
			curl_close($ch);
		}catch(Exception $e){
			Logs::write("fnlib::get_respond_by_url() exception error:".$e->getMessage(), "log");
			return false;
		}
		return $curl_result;
	}
	
	static function post_respond_by_url($url, $date){
		try{
			$ch = curl_init();
			
			curl_setopt($ch, CURLOPT_URL, $url);
			curl_setopt($ch, CURLOPT_POSTFIELDS, $date);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	
			$curl_result = curl_exec($ch);
	
			curl_close($ch);
		}catch(Exception $e){
			Logs::write("fnlib::get_respond_by_url() exception error:".$e->getMessage(), "log");
			return false;
		}
		return $curl_result;
	}
	
}