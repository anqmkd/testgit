<?php
/**
 * 基础服务配置，配置数据库
 */
return array(
    'mydb' => array(
		'mongo' => array(				
					'summary' => array('host'=>'61.141.236.23',
								'port'=>50000,
								'db'  =>'db_yl_cpush_summary'
				),
			),	
			
	    'themes' => array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_themes_app; host=10.69.248.83:3336',
			'username'       => 'root',
			'password'       => '123456',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	     ),
	     
	     'androidesk' => array(
	    		'driver' => 'Pdo',
	    		'dsn'            => 'mysql:dbname=db_yl_androidesk;host=10.69.248.83:3336',
	    		'username'       => 'root',
	    		'password'       => '123456',
	    		'driver_options' => array(
	    				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
	    		),
	    ),  
		
		'themesrecords' => array(
	    		'driver' => 'Pdo',
	    		'dsn'            => 'mysql:dbname=db_yl_themes_records;host=10.69.248.83:3336',
	    		'username'       => 'root',
	    		'password'       => '123456',
	    		'driver_options' => array(
	    				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
	    		),
	    ),
	
	    'designer' => array(
	    		'driver' => 'Pdo',
	    		'dsn'            => 'mysql:dbname=db_yl_designer;host=10.69.248.83:3336',
	    		'username'       => 'root',
	    		'password'       => '123456',
	    		'driver_options' => array(
	    				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
	    		),
	    ),
	    
	    'recommend' => array(
	    		'driver' => 'Pdo',
	    		'dsn'            => 'mysql:dbname=db_yl_recommend;host=10.69.248.83:3336',
	    		'username'       => 'root',
	    		'password'       => '123456',
	    		'driver_options' => array(
	    				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
	    		),
	    ),
	    
	    'user' => array(
	    		'driver' => 'Pdo',
	    		'dsn'            => 'mysql:dbname=webuser;host=10.69.248.83:3336',
	    		'username'       => 'root',
	    		'password'       => '123456',
	    		'driver_options' => array(
	    				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
	    		),
	    ),
    ),
		
	'service_manager' => array(
		'factories' => array(
			'AppManager' => 'Service\ManagerFactory',
		),
	),
);