<?php
namespace Service\db_yl_themes_records;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Check\sqlcheck;

class ChargeTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_exorder_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
	public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->order('tb_yl_scene.id DESC')
    	         ->limit($pagesize)
    			 ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getMyCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
//		$sqlStr  = "SELECT COUNT(id) AS num FROM tb_yl_exorder_record ".
//    				"WHERE (STATUS = 1) AND cpid=".$data['cpid'];
//    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
//    	foreach ($result as $row){
//    		return $row['num'];
//    	}
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getAppDataAll($page, $pagesize, array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)    	         
    			->limit($pagesize)
    			->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;    
    }
    
    public function getMyAppDataAll( array $data)
    {
    	$result = $this->select($data);
    	return $result;  
    }
    
    public function getAppDataLike(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    } 
    public function deleteAlbum($id)
    {
    	$this->delete(array('id' => $id));
    }
    
    public function getOwnDifferences($startTime,$endTime,$page,$pageSize){
    	$skip    = ((int)$page-1) * $pageSize;
    	$sqlStr  = "SELECT t.exorderno AS exorderno,o.product AS product,o.meid AS meid,t.transid AS transid," .
    			"t.money AS money,t.appid AS appid,t.insert_time AS insert_time FROM tb_yl_coolpadtone_record t ".
      	           "LEFT JOIN tb_yl_exorder_record o ON   t.exorderno = o.exorder ".
    				"WHERE t.insert_time BETWEEN '".$startTime."' AND '".$endTime .
    				"'AND exorderno NOT IN (SELECT exorder FROM tb_yl_exorder_record WHERE STATUS = 1) LIMIT ".$skip." ,".$pageSize;
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function getToneDifferences($startTime,$endTime,$page,$pageSize){
    	$skip    = ((int)$page-1) * $pageSize;
    	$sqlStr  = "SELECT exorder,money,cpid,cooltype,product,meid,insert_time,update_time FROM tb_yl_exorder_record ".
    			"WHERE (STATUS = 1) AND update_time BETWEEN '".$startTime."' AND '".$endTime .
    			"' AND  exorder NOT IN (SELECT exorderno FROM tb_yl_coolpadtone_record )".
    			" ORDER BY update_time DESC"." LIMIT ".$skip." ,".$pageSize;
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function getToneDifNum($startTime,$endTime){
    	$sqlStr  = "SELECT COUNT(id) AS num FROM tb_yl_exorder_record ".
    				"WHERE (STATUS = 1) AND update_time BETWEEN '".$startTime."' AND '".$endTime .
    			"' AND  exorder NOT IN (SELECT exorderno FROM tb_yl_coolpadtone_record)";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row['num'];
    	}
    }
    
    public function getOwnSum($startTime,$endTime){
    	$sqlStr  = "SELECT COUNT(id) AS total,SUM(money) AS num FROM tb_yl_exorder_record WHERE STATUS =1  ".
    				"AND update_time BETWEEN '".$startTime."' AND '".$endTime."'";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}
    }
    
    public function getToneSum($startTime,$endTime){
    	$sqlStr  = "SELECT COUNT(id) AS total,SUM(money) AS num FROM tb_yl_coolpadtone_record ".
      				"WHERE insert_time BETWEEN '".$startTime."' AND '".$endTime."'";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}
    }
    
    public function getOrderNum($startTime,$endTime){
    	$sqlStr  = "SELECT COUNT(id) as num FROM tb_yl_exorder_record ".
    				"WHERE update_time BETWEEN '".$startTime."' AND '".$endTime."'";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}
    }

}