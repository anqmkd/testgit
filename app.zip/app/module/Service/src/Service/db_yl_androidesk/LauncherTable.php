<?php
namespace Service\db_yl_androidesk;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class LauncherTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_launcher';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    } 

}
