<?php
namespace Service\db_yl_androidesk;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\Sql;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;
use Zend\Db\Sql\Expression;

class WpcommendTable extends AbstractTableGateway
{
//    protected $table = 'commend';
    public function __construct(Adapter $adapter, $mytable)
    {
        $this->adapter = $adapter;
        $this->table   = $mytable;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getData($page=1, $pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
//    	order('asort, ad_rank DESC')
    	$myselect->order('asort, id')
    	         ->limit($pagesize)
    			 ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    }  
    
    public function getInputData(array $data)
    {
    	$sql = " SELECT * FROM commend WHERE asort = ".$data['asort'];
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		if((int)$data['asort']>(int)$data['oldsort'])
    		{
    			$sql = "UPDATE commend SET asort = asort - 1 WHERE asort > ".$data['oldsort']." AND asort <= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}else{
    			$sql = "UPDATE commend SET asort = asort + 1 WHERE asort < ".$data['oldsort']." AND asort >= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}  		  		
    	}
    	$sql = "UPDATE commend SET asort =".$data['asort']." WHERE id = ".$data['id'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }  
}
