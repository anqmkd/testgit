<?php
namespace Service\db_yl_androidesk;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class WplistAdTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_wallpaper_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
//     public function getData($page=1,$pagesize=2,array $data)
//     {
//     	$mysql = $this->getSql();
//     	$offset = ((int)$page-1)*$pagesize;
//     	$myselect = $mysql->select();
//     	$myselect->where($data)
//     			 ->order('tb_yl_wallpaper_info.id DESC')
//     	         ->limit($pagesize)
//     			 ->offset($offset);
//     	$myData = $this->selectWith($myselect);
//     	return $myData;
//     }

    public function getData($page=1,$pagesize=2,$adid)
    {
    	$skip    = ((int)$page -1)* $pagesize;
    	$sqlStr   = "SELECT * FROM tb_yl_wallpaper_info WHERE cpid in (SELECT id_wallpaper FROM ad_list where id_adid =".
    			$adid ." AND valid =1) AND valid =1 order by id desc LIMIT ".$skip.",".$pagesize;
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
//     public function getCountnum(array $data)
//     {
//     	$result = $this->select($data);
//     	return $result->count();
//     }

    public function getCountnum($adid)
    {
    	$sqlStr   = "SELECT COUNT(id) AS num FROM tb_yl_wallpaper_info where cpid in (SELECT id_wallpaper FROM ad_list where id_adid =".$adid
    	." AND valid =1) AND valid =1";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row['num'];
    	}
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    public function getAppDataList(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }    
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    } 
    public function deleteAlbum($id)
    {
    	$this->delete(array('id' => $id));
    }          
    
}
