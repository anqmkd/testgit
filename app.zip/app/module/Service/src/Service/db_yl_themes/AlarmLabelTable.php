<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class AlarmLabelTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_alarm_label';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->order('tb_yl_alarm_label.id DESC')
    	->limit($pagesize)
    	->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }    
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	$rows  = array();
		foreach($result as $row)
		{
			$rows[] = (array)$row;
		}
    	return $rows;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    }  
    
    public function getMaxSort()
    {
    	$sql = "SELECT MAX(code) AS num FROM tb_yl_alarm_label";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		return $row['num'];
    	}
    }  
    
}
