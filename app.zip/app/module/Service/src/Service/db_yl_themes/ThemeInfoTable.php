<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Check\sqlcheck;

class ThemeInfoTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getTheme($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->columns(array('name','cpid','intro','valid','insert_time'))
    	         ->order(array('insert_time DESC'))
    	         ->group('cpid')
    			->limit($pagesize)
    			->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }

    public function getData($page=1,$pagesize=2,array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->order(array('insert_time DESC'))
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getDistinctnum(){
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('cpid'))
    		     ->group('cpid');
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    
    public function getCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function updateOnline(array $data)
    {
    	$this->update($data, array('cpid' => $data['cpid']));
    }

    public function getThemeData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    public function getAllData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getThemeLikeData(array $data)
    {
    	$mysql    = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->group("cpid");
    	$myData   = $this->selectWith($myselect);
    	return $myData;    	
    }
    
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }

    public function updateDataArr(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
    public function getPayCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('SUM(ischarge)')))
    	->where(array( 'cpid=\''.$data["cpid"].'\'' ));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function updatePayData(array $data)
    {
    	$this->update($data, array('valid'=>1,'cpid' => $data['cpid']));
    }

    public function getAllInfo()
    {
       $sql=" select * from tb_yl_theme_info ";
        $rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
        return $rowset;
    }
    public function updatedlMd5Data($data,$where=null)
    {
       $this->update($data,array('cpid' =>$where['cpid']));
    }
    
}






