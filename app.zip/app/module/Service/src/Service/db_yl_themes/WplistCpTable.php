<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class WplistCpTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_wallpaper';
	public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
     public function getWPData($page=1,$pagesize=2,  array $data)
     {
     	$mysql = $this->getSql();
     	$offset = ((int)$page-1)*$pagesize;
     	$myselect = $mysql->select();
     	if($data !=  array('type'=>100)) {
     		$myselect->where($data);
     	}    	
     	$myselect->order('insert_time DESC')
     	         ->limit($pagesize)
     			 ->offset($offset);
     	$myData = $this->selectWith($myselect);
     	return $myData;
     }

    
    public function getData($page=1,$pagesize=2,$adid)
    {   
    	$skip    = ((int)$page -1)* $pagesize;
    	$sqlStr   = "SELECT a.* FROM tb_yl_wallpaper a INNER JOIN (SELECT cpid FROM tb_yl_banner_list where bannerid =".
    				$adid ." AND valid =1)b on a.cpid=b.cpid AND valid =1 order by id desc LIMIT ".$skip.",".$pagesize;
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function getSortData($page=1, $pagesize=2, $cate, $height, $width)
    {
    	$skip    = ((int)$page -1)* $pagesize;
    	$sqlStr  = '';
    	if($cate == 100){
    		$sqlStr   = sprintf("SELECT * FROM tb_yl_wallpaper where  height = '%s' " .
    							"and width = '%s' and valid=1 order by asort desc, insert_time desc limit %s, %s", $height, $width, $skip, $pagesize);
    	} else {
    		$sqlStr   = sprintf("SELECT * FROM tb_yl_wallpaper where  type = '%s' and height = '%s' " .
    							"and width = '%s' and valid=1 order by asort desc, insert_time desc limit %s, %s", $cate, $height, $width, $skip, $pagesize);
    	}
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    	
    }   
    
    public function getwholeData($page=1, $pagesize=2, $cate, $height, $width)
    {
    	$skip    = ((int)$page -1)* $pagesize;
    	$sqlStr  = '';
    	if($cate == 100){
    		$sqlStr   = sprintf("SELECT * FROM tb_yl_wallpaper where  height = '%s' " .
    				"and width = '%s'  order by asort desc, insert_time desc limit %s, %s", $height, $width, $skip, $pagesize);
    	} else {
    		$sqlStr   = sprintf("SELECT * FROM tb_yl_wallpaper where  type = '%s' and height = '%s' " .
    				"and width = '%s'  order by asort desc, insert_time desc limit %s, %s", $cate, $height, $width, $skip, $pagesize);
    	}
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    	 
    }
     public function getWPCountnum(array $data)
     {
     	if($data == array('type'=>'100')) {
     		$result = $this->select();
     	} else {
     		$result = $this->select($data);
     	}
     	return $result->count();
     }

    public function getCountnum($adid)
    {   
    	$sqlStr   = "SELECT COUNT(a.id) AS num FROM tb_yl_wallpaper a INNER JOIN (SELECT cpid FROM tb_yl_banner_list where bannerid =".$adid
    				." AND valid =1)b on a.cpid=b.cpid AND valid =1";
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row['num'];
    	}
    }
    
    public function getCountnumUp($cate, $height, $width)
    { 
    	$sqlStr = '';
    	if($cate == 100){
    		$sqlStr   = sprintf("SELECT COUNT(id) AS num FROM tb_yl_wallpaper where height = '%s' " .
    							"and width = '%s' and valid = 1", $height, $width);
    	} else {
    		$sqlStr   = sprintf("SELECT COUNT(id) AS num FROM tb_yl_wallpaper where type = '%s' and height = '%s' " .
    							"and width = '%s' and valid = 1", $cate, $height, $width);
    	}
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row['num'];
    	}
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    public function getAppDataList(array $data)
    {	
    	$sqlStr = "SELECT COUNT(*) AS num FROM tb_yl_wallpaper WHERE cpid = ".$data['cpid']." AND width=".$data['width']." AND height=".$data['height'];
    	$result  = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row['num'];
    	}
//     	$result = $this->select($data);var_dump($result->id);exit;
//     	return $result;
    }    
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {  
    	$this->update($data, array('id' => $data['id']));
    }
    public function  updateOnline(array $data){
    	$where=$data['cpid'];
    	$val=$data['valid'];
    	$sql="UPDATE `tb_yl_wallpaper` SET valid={$val} WHERE cpid={$where}";
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    public function updateType(array $data)
    {
    	$this->update($data, array('cpid' => $data['cpid']));
    }
    
    public function changeData(array $data)
    { 
    	$this->update($data, array('cpid' => $data['cpid'],'height'=>$data['height'],'width'=>$data['width']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    } 
    public function deleteAlbum($id)
    {
    	$this->delete(array('id' => $id));
    }
    
    public function getAppDataLike(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	    	  ->group('cpid');
//        echo $myselect->getSqlString();    	
    	$result = $this->selectWith($myselect);
    	return $result;
    }
    
    public function deleteInfo($widgetArr)
    {
    	$this->update(array('valid'=>0),array('name' => $widgetArr['name']));
    	$sqlStr     = "UPDATE  tb_yl_banner_list SET valid = 0  WHERE bannerid = '".$widgetArr['adid']."'";
    	$this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	$sqlStr     = "UPDATE  tb_yl_banner SET valid = 0  WHERE identity = '".$widgetArr['adid']."'";
    	$this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    }
    
    public function getInputData(array $data)
    {
    	$sql = "UPDATE tb_yl_wallpaper SET asort =".$data['asort']." WHERE cpid = ".$data['cpid'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    } 
     
    public function getAscData(array $data){
    	$sql = "SELECT * FROM tb_yl_wallpaper WHERE asort > ".$data['asort']." ORDER BY asort ASC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	var_dump($rowset);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_wallpaper SET asort = ".$row['asort']." WHERE cpid =".$data['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_wallpaper SET asort = ".$data['asort']." WHERE cpid =".$row['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}
    }
    
    public  function getDescData($data){
    	
    	$sql = "SELECT * FROM tb_yl_wallpaper WHERE asort < ".$data['asort']." ORDER BY asort DESC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_wallpaper SET asort = ".$row['asort']." WHERE cpid =".$data['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_wallpaper SET asort = ".$data['asort']." WHERE cpid =".$row['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}
    } 
    
    public function getMaxSort()
    {
    	$sql = "SELECT MAX(asort) AS num FROM tb_yl_wallpaper";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		return $row['num'];
    	}
    }
}
 




