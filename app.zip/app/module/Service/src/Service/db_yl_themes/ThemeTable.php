<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Service\Check\sqlcheck;

class ThemeTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getDataAll()
    {
    	$mysql = $this->getSql();    	
    	$myselect = $mysql->select();
    	$result = $this->selectWith($myselect);   
    	return $result;
    }
    
     public function getDistinctnum(){
    	$sql = "select count(distinct cpid) as num from tb_yl_theme ";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getKeywordnum($keyword){
    	$sql = "select count(distinct cpid) as num from tb_yl_theme where name like '%".$keyword."%'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getTheme($page=1,$pagesize=2,$order_phase)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->columns(array('*'))
    	         ->order($order_phase)
    			->limit($pagesize)
    			->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }
    
    public function getKeyData($keyword,$page=1,$pagesize=2)
    {
    	$offset = ((int)$page -1)*$pagesize;
    	$sql = "select * from tb_yl_theme where name like '%".$keyword.
      	       "%' order by asort desc limit ".$offset.",".$pagesize;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $rowset;
    }
    
    public function inputOrder(array $data)
    {
    	$sql = "UPDATE tb_yl_theme SET asort = asort + 1 WHERE asort >= ".$data['asort'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	$sql = "UPDATE tb_yl_theme SET asort =".$data['asort']." ,update_time = '".$data['update_time']
    	."',update_user='".$data['update_user']."' WHERE cpid = ".$data['cpid'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    
    public function getMaxSort()
    {
    	$sql = "SELECT MAX(asort) AS num FROM tb_yl_theme";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getInputData(array $data)
    {
    	$sql = " SELECT * FROM tb_yl_theme WHERE asort = ".$data['asort'];
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		if((int)$data['asort']>(int)$data['oldsort'])
    		{
    			$sql = "UPDATE tb_yl_theme SET asort = asort - 1 WHERE asort > ".$data['oldsort']." AND asort <= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}else{
    			$sql = "UPDATE tb_yl_theme SET asort = asort + 1 WHERE asort < ".$data['oldsort']." AND asort >= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}  		  		
    	}
    	$sql = "UPDATE tb_yl_theme SET asort =".$data['asort']." ,update_time = '".$data['update_time']
    	."',update_user='".$data['update_user']."' WHERE cpid = ".$data['cpid'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    
    public function getAscData(array $data)
    {
    	$sql = "SELECT * FROM tb_yl_theme WHERE asort > ".$data['asort']." ORDER BY asort ASC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_theme SET asort = ".$row['asort']." WHERE cpid =".$data['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_theme SET asort = ".$data['asort']." WHERE cpid =".$row['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}  		
    }
    
    public function getDescData(array $data)
    {
    	$sql = "SELECT * FROM tb_yl_theme WHERE asort < ".$data['asort']." ORDER BY asort DESC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_theme SET asort = ".$row['asort']." WHERE cpid =".$data['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_theme SET asort = ".$data['asort']." WHERE cpid =".$row['cpid'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}
    }

    public function getData($page=1,$pagesize=2,array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->order(array('insert_time DESC'))
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getSubType($typename){
    	$sql = "SELECT CODE FROM tb_yl_theme_label WHERE chname = '".$typename."'" ;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['CODE'];
    	}
    	return 0;
    }
    
    public function getFontWaresid($price){
    	$sql = "SELECT waresid FROM tb_yl_pay WHERE warename = '锁屏' AND price = ".(int)$price;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['waresid'];
    	}
    	return 5;
    }
    
    public function getPicUrl($cpid){
    	$sql = "SELECT icon FROM tb_yl_scene WHERE sceneCode = '".$cpid."'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['icon'];
    	}
    }
    
       
    public function getCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function updateOnline(array $data)
    {
    	$this->update($data, array('cpid' => $data['cpid']));
    }

    public function getThemeData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    public function getAllData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getThemeLikeData(array $data)
    {
    	$mysql    = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->group("cpid");
    	$myData   = $this->selectWith($myselect);
    	return $myData;    	
    }
    
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }

    public function updateDataArr(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
    public function getPayCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('SUM(ischarge)')))
    	->where(array( 'cpid=\''.$data["cpid"].'\'' ));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function updatePayData(array $data)
    {
    	$this->update($data, array('cpid' => $data['cpid']));
    }
    
}