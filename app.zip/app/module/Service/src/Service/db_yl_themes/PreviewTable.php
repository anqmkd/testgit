<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class PreviewTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_preview_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getInfo(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }

    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    

    public function updateData(array $data)
    {
        $this->update($data, array('id' => $data['id']));
    }
    
    public function updateUrl(array $data)
    {
        $this->update($data, array('identity' => $data['identity'], 'name'=>$data['name']));
    }
    
}
