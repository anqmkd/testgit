<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class FontPreviewTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_font_preview';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }    
    public function getInfo(array $data)
    {
    	$select = $this->getSql()->select();
    	$select->join(array("font"=>"tb_yl_font"),
    						'font.identity=tb_yl_font_preview.identity',
    						array('purl', 'url'),
    						$select::JOIN_INNER);
    	$select->where($data);
//   	var_dump($select->getSqlString());
     	$rowset = $this->selectWith($select);
    	$rows = array();
    	while($rowset->valid()){
    		$row = $rowset->current();
    		if(!$row){
    			continue;
    		}
    		array_push($rows, $row);
    		$rowset->next();
    	}
//     	var_dump($rows);exit;
    	return $rows;
    }

    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    
    public function updateData(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }    

    public function updateDataFont(array $data)
    {
    	$this->update($data, array('identity' => $data['identity'],'width'=>$data['width'],'height'=>$data['height']));
    }    
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
}