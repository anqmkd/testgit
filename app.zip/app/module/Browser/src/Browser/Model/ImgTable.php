<?php

namespace Browser\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class ImgTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_br_spread_imgs';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getImgData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    
    public function updateImgData(array $imgData)
    {
    	$this->update($imgData, array('id' => $imgData['id']));
    }    
    public function saveImgArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    
}
