<?php

namespace User\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class RoleTable extends AbstractTableGateway
{
    protected $table = 'role';

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getRoleData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    public function saveRole(array $role)
    {
    	foreach($role as $val){
	        $data = array(
	            'user_id' => $val['user_id'],
	            'app' => $val['app'],
	            'role' => $val['role'],
	        );
	        $this->insert($data);
    	}
    }
    public function deleteRole($id)
    {
        $this->delete(array('id' => $id));
    }
    public function updateRole(array $roleData)
    {
    	$data = array(
    			'app' => $roleData['app'],
    			'role' => $roleData['role'],
    	);    	
    	$this->update($data, array('id' => $roleData['id']));
    }
    
}
