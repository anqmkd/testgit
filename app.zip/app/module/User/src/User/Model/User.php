<?php

namespace User\Model;

use Zend\InputFilter\InputFilter;
use Zend\InputFilter\Factory as InputFactory;
use Zend\InputFilter\InputFilterAwareInterface;
use Zend\InputFilter\InputFilterInterface;

class User implements InputFilterAwareInterface
{
    public $userid;
    public $username;
    public $password;
    public $display_name;
    public $email;
    public $state;
    public $addtime;

    protected $inputFilter;

    /**
     * Used by ResultSet to pass each database row to the entity
     */
    public function exchangeArray($data)
    {
        $this->userid     = (isset($data['userid'])) ? $data['userid'] : null;
        $this->username = (isset($data['username'])) ? trim($data['username']) : null;
        $this->password  = (isset($data['password'])) ? $data['password'] : null;
        $this->display_name  = (isset($data['display_name'])) ? trim($data['display_name']) : null;
        $this->email  = (isset($data['email'])) ? $data['email'] : null;
        $this->state = (isset($data['state'])) ? $data['state'] : 1;
        $this->addtime = (isset($data['addtime'])) ? $data['addtime'] : date('Y-m-d H:i:s');
    }

    public function setParam($data)
    {
    	$this->insert_user = $data['insert_user'];
    	$this->ip          = $data['ip'];
    }

    public function getArrayCopy()
    {
        return get_object_vars($this);
    }

    public function setInputFilter(InputFilterInterface $inputFilter)
    {
        throw new \Exception("Not used");
    }

    public function getInputFilter()
    {
        if (!$this->inputFilter) {
            $inputFilter = new InputFilter();
            $factory = new InputFactory();
            $inputFilter->add($factory->createInput(array(
                'name'     => 'userid',
                'required' => true,
                'filters'  => array(
                    array('name' => 'Int'),
                ),
            )));
            $inputFilter->add($factory->createInput(array(
            		'name'     => 'display_name',
            		'required' => false,
            		'filters'  => array(
            				array('name' => 'StripTags'),
            				array('name' => 'StringTrim'),
            		),
            		'validators' => array(
            				array(
            						'name'    => 'StringLength',
            						'options' => array(
            								'encoding' => 'UTF-8',
            								'min'      => 1,
            								'max'      => 100,
            						),
            				),
            		),
            )));
            $this->inputFilter = $inputFilter;        
        }
        return $this->inputFilter;
    }
}
