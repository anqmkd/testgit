<?php

namespace User\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class UserTable extends AbstractTableGateway
{
    protected $table = 'user';

    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->resultSetPrototype->setArrayObjectPrototype(new User());
        $this->initialize();
    }
    public function fetchAll()
    {
        $resultSet = $this->select(array('state'=>1));
        return $resultSet;
    }
    public function getUser($id)
    {
        $id  = (int) $id;
        $rowset = $this->select(array('userid' => $id));
        $row = $rowset->current();
        if (!$row) {
            throw new \Exception("Could not find row $id");
        }
        return $row;
    }
    public function getUserData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	$row = $rowset->current();
    	return $row;
    }
    public function saveUser(User $user)
    {
        $data = array(
            'username' => $user->username,
            'password'  => md5($user->password),
            'email'  => $user->email,
        	'state'	 => $user->state,
        	'display_name' => $user->display_name,
        	'addtime' => date('Y-m-d H:i:s'),
            'insert_user'	=>$user->insert_user,
        	'ip'			=>$user->ip,	
        );
        $id = (int)$user->userid;
        if ($id == 0) {
            $this->insert($data);
            return $this->getLastInsertValue();            
        } else {
            if ($this->getUser($id)) {
                $this->update($data, array('userid' => $id));
                return $id;
            } else {
            	return 0;
            }
            
        }
    }
    public function deleteUser($id)
    {
        $this->delete(array('userid' => $id));
    }

    public function changeUser(array $data)
    {
    	$this->update($data,array('userid' => $data['userid']));
    }
    
}
