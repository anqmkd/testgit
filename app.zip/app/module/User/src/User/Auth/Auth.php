<?php
namespace User\Auth;

use Zend\Authentication;
use Zend\Authentication\AuthenticationService;
class Auth
{
	const YL_AUTH_NOT_LOGIN = 101;	//未登录
	const YL_AUTH_NO_POWER 	= 102;	//没有权限
	
	public $auth;
	public function __construct()
	{
		$this->auth = new AuthenticationService();
			
	}
	public function isLogin()
	{
		if(!$this->auth->hasIdentity())
		{	
			return false;
		}
		$strUser = $this->auth->getIdentity();
		if(!isset($strUser->username)){
			return false;
		}
		return $strUser;
	}
	public function authRead()
	{
		$arrStore = $this->auth->getStorage()->read();
		return $arrStore;
	}
	public function authStore($arrStore)
	{
		$this->auth->getStorage()->write((object)$arrStore);
	}
	
	public function logout()
	{
		$this->auth->getStorage()->clear();
	}
}
