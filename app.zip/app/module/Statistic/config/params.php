<?php
return array(
    'params' => array(
        'apkbussiness' => array(
            '0' => '全否',
        	'7' => '全部',
        	'1' => '电信',
        	'2' => '移动',
        	'4' => '联通',
        ),
    	'apktype' => array(
    		'0' => '工具',
    		'1' => '社交',
    		'2' => '娱乐',
    		'3' => '新闻',
    	),
    		
    	'apkextend' => array(
    		'coolyun' => '酷云',
    	),

    		
    ),
);