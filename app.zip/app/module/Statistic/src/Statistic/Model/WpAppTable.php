<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class WpAppTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_wpapply_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }



	public function getAllTypeUtime(array $data)
	{
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();

		$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' );

		if($data['phone']!="")
		{
			$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','product like \'%'.$data['phone'].'%\'','insert_time<=\''.$data["end"].'\'' );			
		}


    	$myselect->columns(array( 'countnum'=>new Expression('COUNT(id)')  ))
    	         ->where($tempWhere);    
    	//echo $myselect->getSqlString();
    
    	$myData = $this->selectWith($myselect);
    	return $myData;
	
	}




    
}
