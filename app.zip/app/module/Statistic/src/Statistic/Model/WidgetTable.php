<?php

namespace Statistic\Model;

use Zend\Console\Prompt\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class WidgetTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_widget';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2,$type="")
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('icon_url','apk_url','version','size'))
				 ->join(array('b'=>'tb_yl_widget_extend'), 'b.identity = tb_yl_widget.identity',array('channel'),'left')					
				 ->where(array('tb_yl_widget.type'=>$type))
    	         ->limit($pagesize)
    	         ->offset($offset)
    			 ->order(array('tb_yl_widget.sequence ASC','tb_yl_widget.insert_time DESC'));

		//$w = $myselect->getSqlString();
		//var_dump($w);exit;

    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum($type="")
    {
    	$result = $this->select(array('type'=>$type));
    	return $result->count();
    }

    public function getWidgetList($page=1,$pagesize=2,$type="")
    {
    	$mysql = $this->getSql();
		$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_apk'), 'tb_yl_widget.identity = a.identity',array('icon_url','version','size'))
    	         ->where(array('tb_yl_widget.is_using'=>1,'tb_yl_widget.type'=>$type))
    	         ->limit($pagesize)
    	         ->offset($offset)
    	         ->order(array('tb_yl_widget.sequence ASC','tb_yl_widget.insert_time DESC'));
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }

    public function getCountListnum($type="")
    {
    	$result = $this->select(array('type'=>$type,'is_using'=>1));
    	return $result->count();
    }


    
    
    public function getWidgetData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    public function saveWidget(array $widget)
    {
	    $data = array(
	    	'label' => $widget['label'],
	    	'identity' => $widget['identity'],	
	        'business' => $widget['business'],
	        'type' => $widget['type'],
			'note' => $widget['note'],
	    	'package' => $widget['packagename'],
	    	'class' => $widget['classname'],
	    	'folder' => $widget['folder'],
	    	'insert_time' => $widget['insert_time'],
	    	'insert_user' => $widget['author'],
	    	'update_time' => $widget['update_time'],
	    	'update_user' => $widget['author'],
	    	'commend' => (int)$widget['tj'],
	    	'sequence' => (int)$widget['tj'],		
	    );
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateWidgetData(array $widgetData)
    {
    	$this->update($widgetData, array('id' => $widgetData['id']));
    }
    
    public function updateWidget(array $widgetData)
    {
    	$this->update($widgetData, array('identity' => $widgetData['identity']));
    }

    public function getAppAll(array $select)
    {
    	$result = $this->select($select);
    	return $result;
    }

    
}
