<?php

namespace Launcher\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Launcher\Logs\Logs;


class IcontoolTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_icon';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getAppDataAll(array $data)
    {
    	$sqlStr   = "SELECT * FROM tb_yl_icon ORDER BY id DESC";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function startXml($id)
    {
    	$sqlStr   = "UPDATE tb_yl_icon SET valid = 0";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	$sqlStr   = "UPDATE tb_yl_icon SET valid = 1 WHERE id =".$id;
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    
    public function getFilePath(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('url'))
    			->where($data);
    	$myData = $this->selectWith($myselect);
    	return $myData->current();
    }
    
    public function saveArr(array $data)
    {
    	try{
    		$sqlStr   = "UPDATE tb_yl_icon SET valid = 0";
    		$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function updateData(array $data){
    	try{
    		return $this->update($data,array('id'=>$data['id']));
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }

    public function insertArr(array $data){
    	$sql = "INSERT INTO tb_yl_icon_list (cpid,packagename,filename,CRC32,valid,url,insert_time,update_time) VALUES";
    	$len = count($data);
    	for($i=0;$i<$len;$i++){
    		$sql .= "('".$data[$i]['cpid']."','".$data[$i]['package']."','".$data[$i]['filename']."','"
    				.$data[$i]['crc32']."',".$data[$i]['valid'].",'".$data[$i]['url']."','".$data[$i]['insert_time']."','".$data[$i]['update_time']."'),";
    	}
     	$sql   	  = rtrim($sql,",");
    	$result   = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }

       
}
