<?php

namespace Launcher\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Launcher\Logs\Logs;


class iconlistTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_icon_list';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getIdentity()
    {
    	$sql     = "SELECT identity,url FROM tb_yl_icon WHERE valid = 1 ORDER BY update_time DESC LIMIT 1";
    	$result   = $this->adapter->query($sql, Adapter::QUERY_MODE_EXECUTE);
    	return $result->current();
    }
    
    public function getAppDataAll($page,$pagesize,$identity)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where(array('cpid'=>$identity))
    	->columns(array('*'))
    	->order(array('update_time DESC'))
    	->limit($pagesize)
    	->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    
    public function getDistinctnum($identity){
    	$sql = "SELECT COUNT(id) as num FROM tb_yl_icon_list WHERE cpid = '".$identity."'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getKeywordAppDataAll($page,$pagesize,$identity,$keyword)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where(array("cpid = '".$identity."' AND filename LIKE '%".$keyword."%'"))
    	->columns(array('*'))
    	->order(array('update_time DESC'))
    	->limit($pagesize)
    	->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getKeywordnum($identity,$keyword)
    {
    	$sql = "SELECT COUNT(id) as num FROM tb_yl_icon_list WHERE cpid = '".$identity."' AND filename LIKE '%".$keyword."%'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function checkname($packagename,$cpid)
    {
    	$sql = "SELECT COUNT(id) as num FROM tb_yl_icon_list WHERE cpid = '".$cpid."' AND filename = '".$packagename."'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    	return 0;
    }
    
    public function checkupname($packagename,$cpid,$id)
    {
    	$sql = "SELECT COUNT(id) as num FROM tb_yl_icon_list WHERE cpid = '".$cpid."' AND filename = '".$packagename."' AND id != ".$id;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    	return 0;
    }
    
    public function saveArr(array $data)
    {
    	try{
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('iconlistTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function updateData(array $data){
    	try{
    		return $this->update($data,array('id'=>$data['id']));
    	}catch(Exception $e){
    		Logs::write('iconlistTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function getSelectData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getSelectAllData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
       
}
