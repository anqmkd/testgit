<?php

namespace Launcher\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Launcher\Logs\Logs;


class XmltoolTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_apk_add';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getAppDataAll(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getXmlType(){
    	$sqlStr   = "SELECT NAME,VALUE FROM tb_yl_xml_type ORDER BY VALUE ASC";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    public function getJudgeData($packageName){
    	$sqlStr   = "SELECT * FROM tb_yl_type_list WHERE packageName = '".$packageName."'";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}   		
    	return $result;
    }
    
    
    public function saveArr(array $data)
    {
    	try{
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function updateData(array $data){
    	try{
    		return $this->update($data,array('id'=>$data['id']));
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function delete($id){
    	$sqlStr   = "DELETE FROM tb_yl_apk_add WHERE id=".$id;
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }

       
}
