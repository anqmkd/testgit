<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Launcher\Controller\Site' => 'Launcher\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'launcher' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/launcher[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Launcher\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'launcher' => __DIR__ . '/../view',
        ),
    ),
);