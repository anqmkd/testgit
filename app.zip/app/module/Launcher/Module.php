<?php

namespace Launcher;

use Launcher\Model\XmltoolTable;
use Launcher\Model\IcontoolTable;
use Launcher\Model\iconlistTable;
use Launcher\Model\keyguardTable;
use Launcher\Model\keyguardPreviewTable;
use Launcher\Model\keyguardlistTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{	
//	public static $db = array(
//			'driver' => 'Pdo',
//			'dsn'            => 'mysql:dbname=db_yl_webapp;host=172.16.45.143',
//			'username'       => 'root',
//			'password'       => '1234',
//			'driver_options' => array(
//					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
//			),
//	);
	
	public static $db = array(
 			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_webapp;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
 	);

        public static $newdb = array(
 			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_keyguard;host=192.168.30.223',
			'username'       => 'coolshow_app',
			'password'       => '3edc$RFV',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
 	);



		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			
    			'Launcher\Model\XmltoolTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new XmltoolTable($dbAdapter);
    				return $table;
    			},
    			
    			'Launcher\Model\IcontoolTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new IcontoolTable($dbAdapter);
    				return $table;
    			},
                    
                        
    			'Launcher\Model\iconlistTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new iconlistTable($dbAdapter);
    				return $table;
    			},
    			
    			'Launcher\Model\keyguardTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$newdb);
    				$table = new keyguardTable($dbAdapter);
    				return $table;
    			},
    			
    			'Launcher\Model\keyguardPreviewTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$newdb);
    				$table = new keyguardPreviewTable($dbAdapter);
    				return $table;
    			},
    			
    			'Launcher\Model\keyguardlistTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$newdb);
    				$table = new keyguardlistTable($dbAdapter);
    				return $table;
    			},
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
