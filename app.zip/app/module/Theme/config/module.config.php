<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Theme\Controller\Site' => 'Theme\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'theme' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/theme[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Theme\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'theme' => __DIR__ . '/../view',
        ),
    ),
);