<?php
//phpinfo();

    function geturldata( $url )
    {
    	$ch     = curl_init($url) ;
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ;
    	$output = curl_exec($ch);
    	curl_close($ch);
    	return $output;
    }


    $url = 'http://192.168.30.54:8088/getmsg.php?action=getinfo&method=post&url=http://csm.coolyun.com/ss.php&data={"appkey":"kupai"}';
    $d = geturldata($url);
    var_dump($d);

?>
