<?php
namespace Widgetimg\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Widgetimg\Module;
use Widgetimg\Acl\Useracl;
use \ZipArchive;

use Widgetimg\Model\AppimgTable;
use Widgetimg\Model\AppzipTable;
use Widgetimg\Model\AppreginTable;
use Widgetimg\Model\ApplinkTable;
use Widgetimg\Model\ThemeTable;
use Widgetimg\Model\WidgetTable;
class SiteController extends AbstractActionController
{
	//public $filepath = '/home/wwwroot/app/public/tempfile/subjectAdd.txt';
	//public $healthfilepath = '/home/wwwroot/rsync/NetWidget/app/Health/Update/APK/healthInfo.txt';
	//public $temphealthfile = '/home/wwwroot/app/public/tempfile/appAdd.txt';
	public $tempfolder = '/home/wwwroot/rsync/';
	public $filepath   = '/home/wwwroot/app/public/tempfile/widgetimgAdd.txt';
        public $tempfoldernew = '/home/wwwroot/app/public/';
	public $temppath   = 'Widgetimg/';
	public $showurl    = 'http://download.coolyun.com/';	 	
	public $filepre    = 'Widgetimg/';
	public $templen    = 6;
	public $tempregion = array(
		'coolapp' => array('app_sort_four','app_anim','app_sort_zero','app_sort_one','app_sort_two','app_sort_three',),		
		'coolshow' => array('widget_theme','widget_anim','widget_wallpaper','widget_keyguard','widget_ringtone',),
				
	);
	
	public $myaction = array(
		'coolshow' => array(
				'widget_theme'=>'com.yulong.android.coolshow.online.theme.detail',
				'widget_anim'=>'',
				'widget_wallpaper'=>'com.yulong.android.coolshow.start',
				'widget_keyguard'=>'com.yulong.android.coolshow.start',
				'widget_ringtone'=>'com.yulong.android.coolshow.ring.activity',
		),

              
                'coolapp' => array(
					'app_sort_four'=>'open',
					'app_anim'=>'',
					'app_sort_zero'=>'applist',
					'app_sort_one'=>'applist',
					'app_sort_two'=>'applist',
					'app_sort_three'=>'applist',					
		),

	);
	
	public $tempwidget = array(
		'coolapp'  => 'com.yulong.android.network.widget',
		'coolshow' => 'com.yulong.android.coolshow.widget',			
	);
        public $getmsg        = 'http://192.168.30.54:8088/taskpush.php?action=getmsg';
	public $description= 'description.xml';
	public $zippath    = 'zip';
	public $createurl  = 'http://app.coolyun.com/zip/createzip.php?filestr=';
        public $pushurl       = 'http://192.168.30.54:8088/getmsg.php?action=push&task=';	
	
        public $taskmobile = 'http://192.168.30.54:8088/getmsg.php';			
	
	protected $appimgTable;
	protected $appzipTable;
	protected $appreginTable;
	protected $applinkTable;
        protected $themeTable;
        protected $widgetTable;


    public function getWidgetTable()
    {
    	if (!$this->widgetTable) {
    		$sm = $this->getServiceLocator();
    		$this->widgetTable = $sm->get('Widgetimg\Model\WidgetTable');
    	}
    	return $this->widgetTable;
    }    


    public function geturldatapost( $url,$post_data )
    {
    	$ch     = curl_init();
    	curl_setopt($ch, CURLOPT_POST, 1);
    	curl_setopt($ch, CURLOPT_URL,$url);
    	curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    	ob_start();
    	$result = curl_exec($ch);
    	$result = ob_get_contents() ;
    	ob_end_clean();    	
    	return $result;
    }
	
    public function indexAction()
    {
    	$uData = $this->checkLogin('index');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
        return new ViewModel();
    }
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }

    public function rightAction()
    {
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$id     = $_GET['id'];
        //echo time();exit;
    	if(intval($id)>0)
    	{
    		$myre   = $this->getApplinkTable()->getAppData(array('appname'=>'coolshow','widgetid'=>$id));
    		$myinfo = array();
    		foreach($myre as $myobj)
    		{
    			$imgid = $myobj->imgid;
    			$tre   = $this->getAppimgTable()->getAppData(array('imgid'=>$imgid));
    			$tobj  = (array)$tre->current();
    			$myinfo[$myobj->region] = array('imgid'=>$tobj['imgid'],'resid'=>$myobj->resid,'mark'=>$tobj['mark'],'showimg'=>$this->showurl.$tobj['url']);
    		}
    	}else{
    		$myinfo = array();
    	}
    	$post_data  = array(
                        'action=gettheme',
    	);
    	$post_data  = implode('&',$post_data);
    	//$result     = $this->geturldatapost($this->taskmobile, $post_data);
    	return new ViewModel(array('myinfo'=>$myinfo,'showurl'=>$this->showurl,'infoDataNew'=>$mydata,'folderStr'=>$this->tempfolder,'uData'=>$uData));    	 
    }
    public function querythemeAction()
    {
        $request = $this->getRequest();
        if ($request->isPost())
        {
                 $postArr  = $request->getPost();
                 if(empty($postArr['ratio']) || empty($postArr['keyword']))
                 {
                        die(json_encode(array()));
                 }
                 $ratioarr = explode("x",$postArr['ratio']);
                 $width    = $ratioarr[0]*2;
                 $height   = $ratioarr[1];
                 $keywd    = $postArr['keyword'];
                 $tdata    = $this->getThemeTable()->getAllData(array('valid'=>1,'width'=>$width,'height'=>$height,'word'=>$keywd,'key'=>"tb_yl_theme.name LIKE '%".$keywd."%'"));
                 $infoarr  = array();
                 foreach($tdata as $myobj)
                 {
                       $infoarr[] = array('id'=>$myobj->identity,'name'=>$myobj->name,'kernel'=>$myobj->kernel);
                 }
                 die(json_encode($infoarr));
        }
        
    }
    
    public function queryapkAction()
    {
        $request = $this->getRequest();
        if ($request->isPost())
        {
                 $postArr  = $request->getPost();
                 if(empty($postArr['keyword']))
                 {
                        die(json_encode(array("total"=>0)));
                 }
                 
                 $keywd    = $postArr['keyword'];
                 $tdata    = $this->getWidgetTable()->getWidgetData(array('is_using'=>1,"label LIKE '%".$keywd."%'"));
                 $infoarr  = array();
                 foreach($tdata as $myobj)
                 {
                       $infoarr[] = array('id'=>$myobj->identity,'name'=>$myobj->label);
                 }
                 die(json_encode(array("total"=>1,"list"=>$infoarr)));
        }

    }

    

    public function getimgdata($appname)
    {
    	$regionarr = $this->tempregion[$appname];
    	$infoData = array();
    	foreach($regionarr as $val)
    	{
    		$tempData = $this->getAppimgTable()->getAppMaxData(array('region'=>$val,'appname'=>$appname));
    		if($tempData && $tempData->count()==1)
    		{
    			foreach($tempData as $myobj)
    			{
    				$mydata            = (array)$myobj;
    				$mydata['showimg'] = $this->showurl.$mydata['url'];
    				$infoData[$val] = $mydata;
    			}
    		}
    	}
    	return $infoData;    	 
    }
    
    public function appAction()
    {
    	
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$id     = $_GET['id'];
    	if($id)
    	{
    		$myre   = $this->getApplinkTable()->getAppData(array('appname'=>'coolapp','widgetid'=>$id));
    		$myinfo = array();
    		foreach($myre as $myobj)
    		{
    			$imgid = $myobj->imgid;
    			$tre   = $this->getAppimgTable()->getAppData(array('imgid'=>$imgid));
    			$tobj  = (array)$tre->current();
    			$myinfo[$myobj->region] = array('imgid'=>$tobj['imgid'],'resid'=>$myobj->resid,'mark'=>$tobj['mark'],'showimg'=>$this->showurl.$tobj['url']);
    		}
    	}else{
    		$myinfo = array();
    	}
    	return new ViewModel(array('myinfo'=>$myinfo,'showurl'=>$this->showurl,'folderStr'=>$this->tempfolder,'uData'=>$uData));    	
    }
    
    public function makeappzipAction()
    {
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr  = $request->getPost();
    		$appname  = $postarr['appname'];
    		$widgetid = $postarr['wid']; 
    		if($appname=="" || $widgetid=="")
    		{
    			die('empty');
    		}
    		$regionarr = $this->tempregion[$appname];
    		$infoData = array();
    
    		$content = '<root>'."\r\n";
    		$filearr = array();
    		foreach($regionarr as $val)
    		{
                        
    			$myre     = $this->getApplinkTable()->getAppData(array('widgetid'=>$widgetid,'appname'=>$appname,'region'=>$val));
    			$imgidobj = $myre->current();
    			$imgid    = $imgidobj->imgid;
                        
    			$tempData = $this->getAppimgTable()->getAppData(array('imgid'=>$imgid));
                        
    			if($tempData && $tempData->count() > 0)
    			{
    				$myobj  = $tempData->current();
    				$mydata = (array)$myobj;
    				$picurl = explode("/", $mydata['url']);    
    				$img = end($picurl);
    				$act = $this->myaction[$appname][$val];
    				$con = $mydata['content'];
    				$ext = $mydata['mark'];

                                $ext1 = ""; 
                                
                                if($val=="app_sort_four"){
                                       $resid    = $imgidobj->resid;
                                       $infodata = $this->getWidgetTable()->getDataInfo($resid);
                                       $infoobj  = $infodata->current(); 
                                       
                                       $ext      = $infoobj->package;

                                       $ext1     = 'extend1="'.$resid.'"';
                                       $con      = (strpos($infoobj->apk_url,"http")===false)?"http://widget.yulong.com/widgetdl.php?id=".$infoobj->identity:$infoobj->apk_url;
                                }
                                
   				$content .= '            <item key="'.$val.'"';
    				$content .=	'	 imageName="'.$img.'"';
    				$content .=	'	 action="'.$act.'"';
    				$content .=	'	 content="'.$con.'" ';
    				$content .=	'	 extend="'.$ext.'" ';
                                $content .=     $ext1;
    				$content .=	'	  />'."\r\n";
    				$filearr[] = $this->tempfolder.$mydata['url'];
    			}
    			else
    			{
    				die("nodata");
    			}
    		}
    		$content .= '</root>';
    		$temppath = date('YmdHis').'_'.$this->num_rand($this->templen);
    		mkdir($this->tempfoldernew.$this->zippath.'/'.$temppath,0755,true);
    
                
    		file_put_contents($this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$this->description, $content);
    		$filearr[] = $this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$this->description;
    		$myfilearr['file']    = $filearr;
    		$myfilearr['zipfile'] = $temppath.'/'.$temppath.'.zip';
                
    		$filestr   = json_encode($myfilearr);
    		$filestr   = urlencode($filestr);

                $post_data  = array(
                                                    'action=makezip',
                                                    'filestr='.$filestr,
                );
                $post_data  = implode('&',$post_data);
                $output     = $this->geturldatapost($this->taskmobile, $post_data);
                
    		if($output=="success")
    		{
    			$tzipfile = $this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$temppath.'.zip';
                        $wzip     = $this->tempfolder.'widgetzip/'.$temppath.'.zip';
                        copy($tzipfile,$wzip);
    			$identity = sprintf("%u", crc32( file_get_contents( $tzipfile ) ) );
    			$filemd5  = md5_file($tzipfile);
    			$filesize = filesize($tzipfile);

    			$this->getAppzipTable()->saveApp(array(
    					'identity' => $identity,
    					'appname'  => $appname,
    					'widgetid' => $widgetid,
    					'url'      => 'widgetzip/'.$temppath.'.zip',
    					'size'     => $filesize,
    					'md5'      => $filemd5,
    					'insert_user' => $uData->username,
    					'update_user' => $uData->username,
    			));
    		}
    		die($output);
    	}
    }    

    
    public function makezipAction()
    {
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr  = $request->getPost();
    		$appname  = $postarr['appname'];
    		$widgetid = $postarr['wid']; 
    		if($appname=="" || $widgetid=="")
    		{
    			die('empty');
    		}
    		$regionarr = $this->tempregion[$appname];
    		$infoData = array();
    
    		$content = '<root>'."\r\n";
    		$filearr = array();
    		foreach($regionarr as $val)
    		{
                        //var_dump(array('widgetid'=>$widgetid,'appname'=>$appname,'region'=>$val));exit;
    			$myre     = $this->getApplinkTable()->getAppData(array('widgetid'=>$widgetid,'appname'=>$appname,'region'=>$val));
    			$imgidobj = $myre->current();
    			$imgid    = $imgidobj->imgid;
                        //var_dump($imgid);exit;
    			$tempData = $this->getAppimgTable()->getAppData(array('imgid'=>$imgid));
                        //var_dump($tempData);exit;
                        //var_dump($tempData->count());exit;
    			if($tempData && $tempData->count() > 0)
    			{
    				$myobj  = $tempData->current();
    				$mydata = (array)$myobj;
    				$picurl = explode("/", $mydata['url']);    
    				$img = end($picurl);
    				$act = $this->myaction[$appname][$val];
    				$con = '';
    				$ext = $mydata['mark'];    				
    				if($val=="widget_theme")
    				{
    					$resid    = $imgidobj->resid;
    					//$myres    = $this->geturldata($this->themeinfo.$resid);
                                        $post_data  = array(
                                                    'action=info',
                                                    'type=0',
                                                    'title=b',
                                                    'id='.$resid,
                                                    'content=a',
                                        );
                                        $post_data  = implode('&',$post_data);
                                        $result     = $this->geturldatapost($this->taskmobile, $post_data);
                                        //var_dump($result);exit;                                          
    					$myinfo     = json_decode($result,true);
                                        //var_dump($myinfo);exit;
    					$tinfo    = $myinfo['entity']['themes'];
    					$extend   = (is_array($tinfo))?htmlspecialchars(json_encode(array('themes'=>$tinfo))):''; 
                                        $ext        = $extend;   						
    				}
    				$content .= '<item key="'.$val.'"';
    				$content .=	'	 imageName="'.$img.'"';
    				$content .=	'	 action="'.$act.'"';
    				$content .=	'	 content="'.$con.'" ';
    				$content .=	'	 extend="'.$ext.'" ';
    				$content .=	'	  />'."\r\n";
    				$filearr[] = $this->tempfolder.$mydata['url'];
    			}
    			else
    			{
    				die("nodata");
    			}
    		}
    		$content .= '</root>';
    		$temppath = date('YmdHis').'_'.$this->num_rand($this->templen);
    		mkdir($this->tempfoldernew.$this->zippath.'/'.$temppath,0755,true);
    
                //var_dump($this->tempfoldernew.$this->zippath.'/'.$temppath);exit;
    		file_put_contents($this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$this->description, $content);
    		$filearr[] = $this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$this->description;
    		$myfilearr['file']    = $filearr;
    		$myfilearr['zipfile'] = $temppath.'/'.$temppath.'.zip';
                //var_dump($myfilearr);exit;
    		$filestr   = json_encode($myfilearr);
    		$filestr   = urlencode($filestr);
    
    		//$output    = $this->geturldata($this->createurl.$filestr);

                $post_data  = array(
                                                    'action=makezip',
                                                    'filestr='.$filestr,
                );
                $post_data  = implode('&',$post_data);
                $output     = $this->geturldatapost($this->taskmobile, $post_data);
                //var_dump($output);exit;
    		if($output=="success")
    		{
    			$tzipfile = $this->tempfoldernew.$this->zippath.'/'.$temppath.'/'.$temppath.'.zip';
                        $wzip     = $this->tempfolder.'widgetzip/'.$temppath.'.zip';
                        copy($tzipfile,$wzip);
    			$identity = sprintf("%u", crc32( file_get_contents( $tzipfile ) ) );
    			$filemd5  = md5_file($tzipfile);
    			$filesize = filesize($tzipfile);
    			//$maxversion = $this->getAppzipTable()->getAppMaxData(array('appname'=>$appname));
    			//$maxversion = intval($maxversion);
    			$this->getAppzipTable()->saveApp(array(
    					'identity' => $identity,
    					'appname'  => $appname,
    					//'version'  => $maxversion+1,
    					'url'      => 'widgetzip/'.$temppath.'.zip',
    					'size'     => $filesize,
    					'md5'      => $filemd5,
    					'insert_user' => $uData->username,
    					'update_user' => $uData->username,
    			));
    		}
    		die($output);
    	}
    }    
    
    
    
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    
    public function setpathAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr   = $request->getPost();
    		$version   = $postarr['version'];
    		$atime     = date('YmdHis');
    		$randnum   = $this->num_rand($this->templen);
    		$mycontent = $this->filepre.date('YmdH').'/'.$atime.'_'.$randnum;
    		@file_put_contents($this->filepath, $mycontent);
    		die($mycontent);
    	}
    }
    
    public function addwidgetlinkAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr   = $request->getPost();
    		if( empty($postarr['widget_theme_picid']) || empty($postarr['widget_anim_picid'])
    				|| empty($postarr['widget_wallpaper_picid']) || empty($postarr['widget_keyguard_picid'])
    				|| empty($postarr['widget_ringtone_picid']) )
    		{
    			die("empty");
    		}
    		$randnum    = $this->num_rand($this->templen);
    		$widgetid   = date('YmdHis').$randnum;    		
    		$r1 = $this->getApplinkTable()->saveApp(
    				array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'resid'=>$postarr['widget_res_picid'],'region'=>'widget_theme','imgid'=>$postarr['widget_theme_picid']) );
    		$r2 = $this->getApplinkTable()->saveApp(
    				array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'widget_anim','imgid'=>$postarr['widget_anim_picid']) );
    		$r3 = $this->getApplinkTable()->saveApp(
    				array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'widget_wallpaper','imgid'=>$postarr['widget_wallpaper_picid']) );
    		$r4 = $this->getApplinkTable()->saveApp(
    				array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'widget_keyguard','imgid'=>$postarr['widget_keyguard_picid']) );
    		$r5 = $this->getApplinkTable()->saveApp(
    				array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'widget_ringtone','imgid'=>$postarr['widget_ringtone_picid']) );
    		if($r1 && $r2 && $r3 && $r4 && $r5){ die('success'); }
    		else{die('error');}
    	}
    	
    }

    public function addapplinkAction()
    {
        $request = $this->getRequest();
        if ($request->isPost())
        {
                $postarr   = $request->getPost();
                if( empty($postarr['app_sort_four']) || empty($postarr['app_anim'])
                                || empty($postarr['app_sort_zero']) || empty($postarr['app_sort_one'])
                                || empty($postarr['app_sort_two']) || empty($postarr['app_sort_three']) || empty($postarr['app_res']) )
                {
                        die("empty");
                }
                $randnum    = $this->num_rand($this->templen);
                $widgetid   = date('YmdHis').$randnum;
                $r1 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'resid'=>$postarr['app_res'],'region'=>'app_sort_four','imgid'=>$postarr['app_sort_four']) );
                $r2 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'app_anim','imgid'=>$postarr['app_anim']) );
                $r3 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'app_sort_zero','imgid'=>$postarr['app_sort_zero']) );
                $r4 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'app_sort_one','imgid'=>$postarr['app_sort_one']) );
                $r5 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'app_sort_two','imgid'=>$postarr['app_sort_two']) );
                $r6 = $this->getApplinkTable()->saveApp(
                                array('widgetid'=>$widgetid,'appname'=>$postarr['appname'],'region'=>'app_sort_three','imgid'=>$postarr['app_sort_three']) );

                if($r1 && $r2 && $r3 && $r4 && $r5 && $r6){ die($widgetid); }
                else{die('error');}
        }
        
    }


    
    public function addappAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('nopower');
    	}    	
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr = $request->getPost();
    		if(empty($postarr['myregion']) || empty($postarr['pic']))
    		{
    			die("empty");
    		}
    		
    		$pic      = $postarr['pic'];
    		$identity = sprintf("%u", crc32( file_get_contents( $this->tempfolder.$pic ) ) );    		
    		$filearr  = explode("/", $pic);
    		$filemd5  = md5_file($this->tempfolder.$pic);
    		$filesize = filesize($this->tempfolder.$pic);
    		$themelist= $postarr['themelist'];
    		
    		/*
    		$version  = $postarr['version'];
    		$content  = ($postarr['myaction']=="url")?$postarr['neturl']:$postarr['showaction'];
    		if(isset($postarr['themelist']) && $postarr['themelist']!="")
    		{
    			
    			$myres    = $this->geturldata($this->themeinfo.$themelist);
    			$myinfo   = json_decode($myres,true);
    			$tinfo    = $myinfo['entity']['themes'];     			
    			$extend   = (is_array($tinfo))?htmlspecialchars(json_encode(array('themes'=>$tinfo))):'';
    		}else
    		{
    			$extend   = ($postarr['picmark'])?$postarr['picmark']:'';    			 
    		}    		
    		
    		$info     = array( 
    				'imageName' => end($filearr),
    				'action'    => $this->myaction[$postarr['appname']][$postarr['myregion']],
    				'content'   => '',
    				'extend'    => $extend,
    		);
    		*/

    		$result   = $this->getAppimgTable()->saveApp(array(
    				'appname' => $postarr['appname'],
    				'imgid'   => $identity,
    				'resid'   => $themelist,
    				'content' => isset($postarr['piccontent'])?$postarr['piccontent']:'',
    				'url'     => $pic,
    				'md5'     => $filemd5,
    				'size'    => $filesize,
    				'mark'    => isset($postarr['picmark'])?$postarr['picmark']:'',
    				'insert_user' => $uData->username,
    				'update_user' => $uData->username,
    		));
    		$resultstr = ($result)?$identity:"error";
    		die($resultstr);
    	}
    }
    
    public function pushAction()
    {
    	$pageSize = 15;
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$appname = isset($_GET['appname'])?$_GET['appname']:'';

        $wid     = isset($_GET['wid'])?$_GET['wid']:'';
        /*
    	if(empty($appname))
    	{
    		die('参数错误');
    	}
        */
    	
        if($appname!=""){
             $countApp = $this->getAppzipTable()->getCountnum(array('appname'=>$appname));
             $totalPage=ceil($countApp/$pageSize);
             if($page>$totalPage) $page = $totalPage;
             if($page==0) $page = 1;
             $tempData = $this->getAppzipTable()->getData($page,$pageSize,array('appname'=>$appname));
        }

        if($wid!=""){
             $countApp = $this->getAppzipTable()->getCountnum(array('widgetid'=>$wid));
             $totalPage=ceil($countApp/$pageSize);
             if($page>$totalPage) $page = $totalPage;
             if($page==0) $page = 1;
             $tempData = $this->getAppzipTable()->getData($page,$pageSize,array('widgetid'=>$wid));
        }

        /*
    	$countApp = $this->getAppzipTable()->getCountnum(array('appname'=>$appname));
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getAppzipTable()->getData($page,$pageSize,array('appname'=>$appname));
        */
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    

        //echo $appname;exit;        

    	return new ViewModel(array('page'=>$page,'myapp'=>$appname,'wid'=>$wid,'showurl'=>$this->showurl,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    
    }
    
    public function pushserverAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{   
    		$postarr = $request->getPost();    		    		    		
    		$url     = $postarr['url'];
			$pusharr = array(
				'appid'       => $postarr['appid'],
				'type'        => $postarr['sendtype'],
                                'appnote'     => $postarr['mynote'],
				'mobiles'     => (intval($postarr['sendtype'])==1)?explode(',',$postarr['mobile']):array(),
				'products'    => (intval($postarr['sendtype'])==2)?explode(',',$postarr['product']):array(),
				'appmsg'      => $postarr['appmsg'],
				'ispush'      => (int)$postarr['ispush'],
				'isoffline'   => (int)$postarr['ifoffline'],  
				'offtime'     => (intval($postarr['ifoffline'])==1)?$postarr['offlinetime']:'',
				'istimer'     => (int)$postarr['istimer'],
				'timerdetail' => (intval($postarr['istimer'])==1)?$postarr['timer']:'',
				'notify'  => array(
					'title'    => $postarr['title'],
					'activity' => $postarr['activity'],
					'content'  => $postarr['content'],
					'afterpush'=> $postarr['afterpush'],
					'isclean'  => $postarr['clean'],
					'isring'   => $postarr['ring'],
					'isshake'  => $postarr['shake'],						 	
				),						
			);
			$result    = $this->geturldata($this->pushurl.json_encode($pusharr));
			$resultarr = json_decode($result,true);
			$resultstr = $resultarr['result']?'success':'failed';
			die($resultstr);			
    	} 	
    }
    
    public function getmsgAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postarr = $request->getPost();
    		//$url     = $postarr['url'];
    		$url     = $postarr['url'];
                $url     = $this->getmsg.'&gourl='.$url;                
    		$result  = $this->geturldata($url);
    		die($result);
    	}
    		 
    }
    
    public function changeuseAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$type = isset($postArr['t'])?$postArr['t']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";
    		if(empty($id) || empty($type) || $myval=='n')
    		{
    			die('error');
    		}
    		$widgetArr = array(
    				'id'=>$id,
    				'valid'=>$myval,
    		);
    		$this->getAppzipTable()->updateAppData($widgetArr);
    		die('success');
    		
    	}else
    	{
    		die("");
    	}
    }
    
    public function widgetAction()
    {
    	$pageSize = 20;
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getApplinkTable()->getCountnumAll(array('appname'=>'coolshow'));
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getApplinkTable()->getDataAll($page,$pageSize,array('appname'=>'coolshow'));
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
                $tmparr     = (array)$mydata;
                $widgetid   = $tmparr['widgetid'];
                $onedata    = $this->getApplinkTable()->getAppData(array('widgetid'=>$widgetid,'region'=>'widget_theme'));
                $oneobj     = $onedata->current();
                $res        = $oneobj->resid;
                $ttdata     = $this->getThemeTable()->getThemeData(array('identity'=>$res));
                $themename  = $ttdata->name;
                $tmparr['theme'] = $themename;
    		//$infoData[] = (array)$mydata;
                $infoData[] = $tmparr;
    	}
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function recommendAction()
    {
    	$pageSize = 20;
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getApplinkTable()->getCountnumAll(array('appname'=>'coolapp'));
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getApplinkTable()->getDataAll($page,$pageSize,array('appname'=>'coolapp'));
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{

                $tmparr     = (array)$mydata;
                $widgetid   = $tmparr['widgetid'];
                $onedata    = $this->getApplinkTable()->getAppData(array('widgetid'=>$widgetid,'region'=>'app_sort_four'));
                $oneobj     = $onedata->current();
                $res        = $oneobj->resid;
                $tdata      = $this->getWidgetTable()->getWidgetData(array('identity'=>$res));
                $ttdata     = $tdata->current(); 
                $themename  = $ttdata->label;
                $tmparr['theme'] = $themename;
                $infoData[] = $tmparr;             
                
    	}
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function reginAction()
    {
    	$pageSize = 20;
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	 
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getAppreginTable()->getCountnum();
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getAppreginTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function addreginAction()
    {
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['mywidth']) || empty($postArr['myheight']) )
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$appname = $postArr['mywidth'];
    		$appshow = $postArr['myheight'];
    		if($id)
    		{
    			$this->getAppreginTable()->updateAppData(array('id'=>$id,'appname'=>$appname,'region'=>$appshow));
    			die('success');
    		}
    		$result = $this->getAppreginTable()->getAppData(array('appname'=>$appname,'region'=>$appshow));
    		$result = $result->current();
    		if($result && $result->id)
    		{
    			die('exist');
    		}
    		$this->getAppreginTable()->saveApp(array('appname'=>$appname,'region'=>$appshow));
    		die('success');
    	}
    }	    

    public function num_rand($lenth){
    	$randval = '';
    	mt_srand((double)microtime() * 1000000);
    	for($i=0;$i<$lenth;$i++){
    		$randval.= mt_rand(0,9);
    	}
    	$randval=substr(md5($randval),mt_rand(0,32-$lenth),$lenth);
    	return $randval;
    }
    
    public function checkLogin($action)
    {
    	$myAuth = new Auth();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr = json_decode($objUser->roleStr,true);
    		$roleData = isset($roleArr['widgetimg'])?$roleArr['widgetimg']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);    			
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }
    
    
    public function getId(array $data)
    {
    	$type = $data['type'];
    	$result = $this->getIdentityTable()->getAppData(array('type'=>$type));
    	if($result && $result->id)
    	{
    		$id = (int)$result->identity+1;
    		$this->getIdentityTable()->updateAppData(array('identity'=>$id,'id'=>$result->id));
    	}else
    	{
    		$data = array(  'identity' =>1,'type'=>$type  );
    		$this->getIdentityTable()->saveApp($data);    		
    		$id=1;
    	}
    	$num = sprintf('%06d', $id);
    	$newidentity = $this->pre.$type.'_'.$num;
    	return $newidentity;    	    	
    }
    
    public function geturldata( $url )
    {
    	$ch = curl_init($url) ;
    	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ;
    	$output = curl_exec($ch);    	 
    	return $output;
    }
    
    public function getAppimgTable()
    {
    	if (!$this->appimgTable) {
    		$sm = $this->getServiceLocator();
    		$this->appimgTable = $sm->get('Widgetimg\Model\AppimgTable');
    	}
    	return $this->appimgTable;
    }    
    
    public function getAppzipTable()
    {
    	if (!$this->appzipTable) {
    		$sm = $this->getServiceLocator();
    		$this->appzipTable = $sm->get('Widgetimg\Model\AppzipTable');
    	}
    	return $this->appzipTable;
    }

    public function getAppreginTable()
    {
    	if (!$this->appreginTable) {
    		$sm = $this->getServiceLocator();
    		$this->appreginTable = $sm->get('Widgetimg\Model\AppreginTable');
    	}
    	return $this->appreginTable;
    }    
    
    public function getApplinkTable()
    {
    	if (!$this->applinkTable) {
    		$sm = $this->getServiceLocator();
    		$this->applinkTable = $sm->get('Widgetimg\Model\ApplinkTable');
    	}
    	return $this->applinkTable;
    }    
    public function getThemeTable()
    {
        if (!$this->themeTable) {
                $sm = $this->getServiceLocator();
                $this->themeTable = $sm->get('Widgetimg\Model\ThemeTable');
        }
        return $this->themeTable;
    }

    
}
