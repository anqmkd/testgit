<?php
namespace Widgetimg\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class ThemeTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getTheme()
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('name','cpid'))
    	         ->order(array('insert_time DESC'))
    	         ->group('cpid');
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }

    public function getData($page=1,$pagesize=2,array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->order(array('insert_time DESC'))
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function getAllData(array $data)
    {
        $mysql = $this->getSql();
        
        $myselect = $mysql->select();
        $myselect->columns(array('identity','kernel',))
                 ->join(array('a'=>'tb_yl_theme'),'tb_yl_theme_info.cpid = a.cpid',array('name'),'left')
                 ->where(array('tb_yl_theme_info.width'=>$data['width'],'tb_yl_theme_info.height'=>$data['height'],'tb_yl_theme_info.valid'=>1,'a.name like \'%'.$data['word'].'%\'' ));
        //echo $myselect->getSqlString();exit;
        $myData = $this->selectWith($myselect);
        return $myData;


        $result = $this->select($data);
        return $result;
    }
    public function getThemeData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
	
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }

    public function updateDataArr(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
}
