<?php

namespace Widgetimg\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class AppreginTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_apps_region';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData( $page=1,$pagesize=10 )
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->limit($pagesize)
    	->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateAppData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    public function getAppData(array $data)
    {
    	$result = $this->select($data);    	
    	return $result;
    }        
    public function getAppMaxData(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->limit(1)
    			 ->offset(0)
    			 ->order(array('version DESC'));    	 
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }    
}
