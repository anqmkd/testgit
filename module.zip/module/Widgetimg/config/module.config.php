<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Widgetimg\Controller\Site' => 'Widgetimg\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array( 
        	'widgetimg' => array(
        		'type'    => 'segment',
        		'options' => array(
        			'route'    => '/widgetimg',
        			'defaults' => array(
        				'__NAMESPACE__' => 'Widgetimg\Controller',
        				'controller'    => 'Site',
        				'action'        => 'index',
        			),
        		),
        		'may_terminate' => true,
        		'child_routes' => array(
        			'default' => array(
        				'type'    => 'Segment',
        				'options' => array(
        					'route'    => '/[:controller[/:action]][/:id][/:page]',
        					'constraints' => array(
        						'controller' => '[a-zA-Z][a-zA-Z0-9_-]*',
        						'action'     => '[a-zA-Z][a-zA-Z0-9_-]*',
        						'id'         => '[0-9]+',
        						'page'       => '[0-9]+',
        					),
        					'defaults' => array(
        					),
        				),
        			),
        		),
        	),
        		
        		
        		
        		
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'widgetimg' => __DIR__ . '/../view',
        ),
    ),
);