<?php
namespace Widgetimg;

use Widgetimg\Model\AppimgTable;
use Widgetimg\Model\AppzipTable;
use Widgetimg\Model\AppreginTable;
use Widgetimg\Model\ApplinkTable;
use Widgetimg\Model\ThemeTable;
use Widgetimg\Model\WidgetTable;
use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
	
	public static $db = array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_widget_image;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);	

       public static $newdb = array(
                        'driver' => 'Pdo',
                        'dsn'            => 'mysql:dbname=db_yl_themes;host=172.16.45.152:3336',
                        'username'       => 'root',
                        'password'       => '',
                        'driver_options' => array(
                                        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                        ),
        );

       public static $appdb = array(
       		'driver' => 'Pdo',
       		'dsn'            => 'mysql:dbname=db_yl_network_widget;host=172.16.45.152:3336',
       		'username'       => 'root',
       		'password'       => '',
       
       		'driver_options' => array(
       				PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
       		),
       );


	
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    			
    		'factories' => array(
    				
    			'Widgetimg\Model\AppimgTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new AppimgTable($dbAdapter);
    				return $table;
    			},
    			
    			'Widgetimg\Model\AppzipTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new AppzipTable($dbAdapter);
    				return $table;
    			},
    			
    			'Widgetimg\Model\AppreginTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new AppreginTable($dbAdapter);
    				return $table;
    			},		 
    			'Widgetimg\Model\ApplinkTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ApplinkTable($dbAdapter);
    				return $table;
    			},
                        'Widgetimg\Model\ThemeTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$newdb);
                                $table = new ThemeTable($dbAdapter);
                                return $table;
                        },

                        'Widgetimg\Model\WidgetTable' =>  function($sm) {
                        	$dbAdapter = new Adapter(self::$appdb);
                        	$table = new WidgetTable($dbAdapter);
                        	return $table;
                        },

    			
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
