<?php
namespace Designer;

use Designer\Model\TemplateTable;
use Designer\Model\MainTable;
use Designer\Model\UserTable;
use Designer\Model\UserinfoTable;
use Designer\Model\PreviewTable;
use Designer\Model\PayTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
    public static $db = array(
                        'driver' => 'Pdo',
                        'dsn'            => 'mysql:dbname=db_yl_designer;host=172.16.45.152:3336',
                        'username'       => 'root',
                        'password'       => '',
                        'driver_options' => array(
                                        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                        ),
    );

    public static $newdb = array(
                        'driver' => 'Pdo',
                        'dsn'            => 'mysql:dbname=db_yl_themes;host=172.16.45.152:3336',
                        'username'       => 'root',
                        'password'       => '',
                        'driver_options' => array(
                                        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                        ),
    );

		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			'Designer\Model\TemplateTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new TemplateTable($dbAdapter);
    				return $table;
    			},

                        'Designer\Model\MainTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MainTable($dbAdapter);
                                return $table;
                        },

                        'Designer\Model\UserTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$db);
                                $table = new UserTable($dbAdapter);
                                return $table;
                        },

                        'Designer\Model\UserinfoTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$db);
                                $table = new UserinfoTable($dbAdapter);
                                return $table;
                        },

                        'Designer\Model\PreviewTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$db);
                                $table = new PreviewTable($dbAdapter);
                                return $table;
                        },

                        'Designer\Model\PayTable' =>  function($sm) {
                                $dbAdapter = new Adapter(self::$newdb);
                                $table = new PayTable($dbAdapter);
                                return $table;
                        },

    			
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
