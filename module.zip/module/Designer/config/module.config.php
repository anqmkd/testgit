<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Designer\Controller\Api' => 'Designer\Controller\ApiController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'designer' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/designer[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Designer\Controller\Api',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            //'designer' => __DIR__ . '/../view',
        ),
    ),
);