<?php
namespace Service\Check;

use Service\Logs\Logs;

class sqlcheck
{
	static function check($str, $len = 0)
	{
	    if($len > 0){
	       if (strlen($str) > $len) 
	       	  $str = substr($str, 0, $len);
	    }
	    $strKeyword = "and | and| and | or|or | or |select|update|from|where|order| by|by | by |* | *| * |delete|'|insert| into |values|create|table|database|truncate|grant";
	    $arrKeyword = explode('|', $strKeyword);
	    $str = strtolower($str);
	    foreach ($arrKeyword as $keyword){
//	    	var_dump($keyword);
	       $str = str_replace($keyword, ' ', $str);
	    }
//	    var_dump($str);
//	    exit;
	    return $str;
	}	
	
}