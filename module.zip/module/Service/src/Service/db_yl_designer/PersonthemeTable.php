<?php
namespace Service\db_yl_designer;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class PersonthemeTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_main';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2,$typeid=0)
    {
    	if($typeid == 3)$and = array();
    	else $and = array('status'=>$typeid);
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($and)
    	         ->order('update_time DESC')
    			 ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum($typeid)
    {
    	if($typeid == 3)$data =array();
    	else $data = array('status'=>$typeid);
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }    
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {	
    	$result = $this->update($data, array('cpid' => $data['cpid']));
    	
    	if($data['status']==1){
    		$sql = "UPDATE tb_yl_template SET valid = 0 WHERE tid = '".$data['cpid']."'";
    	}else{
    		$sql = "UPDATE tb_yl_template SET valid = 1 WHERE tid = '".$data['cpid']."'";
    	}
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    
    public function getselecttype($cyname)
    {
    	$sql = "SELECT selecttype,userid FROM tb_yl_coolyun_user WHERE username = '".$cyname."'";
    	$result = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $result->current();
    }
    
    public function getUserInfo($selecttype,$userid)
    {
    	if($selecttype == 2)$table="tb_yl_company_userinfo";
    	else $table="tb_yl_coolyun_userinfo";
    	$sql = "SELECT devname,email FROM ".$table ." WHERE userid =".$userid;
    	$result = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $result->current();
    }
    public function updateDataArr(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }    
        
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    
    public function updateOnline(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
}