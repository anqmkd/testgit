<?php

namespace Service;

use Zend\ServiceManager\FactoryInterface;
use Zend\ServiceManager\ServiceLocatorInterface;

/**
 * AtWeather service manager factory
 */
class ManagerFactory implements FactoryInterface
{
	public static $params = null;
    /**
     * Factory method for AtWeather Manager service
     *
     * @param \Zend\ServiceManager\ServiceLocatorInterface $serviceLocator
     * @return \AtWeather\Manager
     */
    public function createService(ServiceLocatorInterface $serviceLocator)
    {
        $config = $serviceLocator->get('Config');
        self::$params = $config['mydb'];     //用于获取config文件中数组action-file，可以改为其他数组
        return true;
    }
}
