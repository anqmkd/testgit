<?php
namespace Service\db_yl_androidesk;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class CateInfoTable extends AbstractTableGateway
{
    protected $table = 'cate_info';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getCateInfo()
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('cate_table_name', 'cate_name'));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

}
