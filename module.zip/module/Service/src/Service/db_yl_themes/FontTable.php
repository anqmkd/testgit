<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class FontTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_font';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->order('tb_yl_font.asort DESC')
    	         ->limit($pagesize)
    			 ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getKeyData($keyword,$page=1,$pagesize=2)
    {
    	$offset = ((int)$page -1)*$pagesize;
    	$sql = "select * from tb_yl_font where name like '%".$keyword.
      	       "%' order by asort desc limit ".$offset.",".$pagesize;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $rowset;
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getKeyCountnum($keyword){
    	$sql = "select count(id) as num from tb_yl_font where name like '%".$keyword."%'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    public function getAppDataLike(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function updatePreviewData(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    }

    public function updateOnline(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
    public function getMaxSort()
    {
    	$sql = "SELECT MAX(asort) AS num FROM tb_yl_font";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getInputData(array $data)
    {
    	$sql = " SELECT * FROM tb_yl_font WHERE asort = ".$data['asort'];
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		if((int)$data['asort']>(int)$data['oldsort'])
    		{
    			$sql = "UPDATE tb_yl_font SET asort = asort - 1 WHERE asort > ".$data['oldsort']." AND asort <= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}else{
    			$sql = "UPDATE tb_yl_font SET asort = asort + 1 WHERE asort < ".$data['oldsort']." AND asort >= ".$data['asort'];
    			$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		}  		  		
    	}
    	$sql = "UPDATE tb_yl_font SET asort =".$data['asort']." ,update_time = '".$data['update_time']
    	."',update_user='".$data['update_user']."' WHERE identity = ".$data['identity'];
    	$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    
    public function getAscData(array $data)
    {
    	$sql = "SELECT * FROM tb_yl_font WHERE asort > ".$data['asort']." ORDER BY asort ASC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_font SET asort = ".$row['asort']." WHERE identity =".$data['identity'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_font SET asort = ".$data['asort']." WHERE identity =".$row['identity'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}  		
    }
    
    public function getDescData(array $data)
    {
    	$sql = "SELECT * FROM tb_yl_font WHERE asort < ".$data['asort']." ORDER BY asort DESC LIMIT 1";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		$sql = "UPDATE tb_yl_font SET asort = ".$row['asort']." WHERE identity =".$data['identity'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    		$sql = "UPDATE tb_yl_font SET asort = ".$data['asort']." WHERE identity =".$row['identity'];
    		$this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}
    }

}
