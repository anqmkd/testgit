<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class MarkListTable extends AbstractTableGateway{
    protected $table = 'tb_qiku_mark_list';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

    public function saveArr(array $data)
    {
        $this->insert($data);
    }

    public function getInfoData(array $data)
    {
        $result = $this->select($data);
        return $result;
    }
}
?>