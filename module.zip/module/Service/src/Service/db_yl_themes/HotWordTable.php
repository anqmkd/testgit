<?php
/**
 * Created by PhpStorm.
 * User: zhouyuhong
 * Date: 2015/11/26
 * Time: 18:59
 */
namespace Service\db_yl_themes;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class HotWordTable extends AbstractTableGateway
{
    protected  $table = 'tb_yl_hotword';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

    public function  saveArr(array $data)
    {
        $this->insert($data);
        return $this->getLastInsertValue();
    }

    public function getAllData()
    {
        $sql = $this->getSql();
        $select = $sql->select();
        $result = $this->selectWith($select);
        return $result;
    }
    public function getCount()
    {
        $result= $this->select();
      return $result->count();
    }
    public function getHotWord($page =1,$pagesize=2)
    {
       $mysql = $this->getSql();
       $offset =((int)$page-1)*$pagesize;
       $myselect = $mysql->select();
        $myselect->columns( array('*'))
                        ->order("insert_time desc")
                       ->limit($pagesize)
                      ->offset($offset);
        $myData = $this->selectWith($myselect);
        return $myData;
    }

    public function updateOnline(array $data)
    {
        $this->update($data,array('id'=> $data['id']));
    }
}