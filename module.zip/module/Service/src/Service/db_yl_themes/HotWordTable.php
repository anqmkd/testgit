<?php
/**
 * Created by PhpStorm.
 * User: zhouyuhong
 * Date: 2015/11/26
 * Time: 18:59
 */
namespace Service\db_yl_themes;
use Service\Logs\Logs;
use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
class HotWordTable extends AbstractTableGateway
{
    protected  $table = 'tb_yl_hotword';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

    public function  saveArr(array $data)
    {
        $this->insert($data);
        return $this->getLastInsertValue();
    }
}