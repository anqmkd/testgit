<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class ProductTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_product';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->limit($pagesize)
    	         ->order(array('insert_time DESC'))
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getKeyData($keyword,$page=1,$pagesize=2)
    {
    	$offset = ((int)$page -1)*$pagesize;
    	$sql = "select * from tb_yl_product where product like '%".$keyword.
      	       "%' order by insert_time desc limit ".$offset.",".$pagesize;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	return $rowset;
    }
    
    public function getProduct(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getKeyCountnum($keyword){
    	$sql = "select count(id) as num from tb_yl_product where product like '%".$keyword."%'";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach($rowset as $row){
    		return $row['num'];
    	}
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }    
    
    public function getAppDataAll()
    {
    	$result = $this->select();
    	return $result;
    }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
        
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    
}
