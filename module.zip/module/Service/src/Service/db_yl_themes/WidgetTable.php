<?php
namespace Service\db_yl_themes;
use Service\Logs\Logs;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Service\Check\sqlcheck;

class WidgetTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_widget';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2,array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)
    	         ->order(array('insert_time DESC'))
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function getDataWidget(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
        
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
        
    public function saveArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    
}
