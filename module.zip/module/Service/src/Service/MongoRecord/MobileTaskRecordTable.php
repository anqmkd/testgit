<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;
use Service\Mobile\Mobile;

class MobileTaskRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_mobile_tasks';
	}
	
	public function saveRecord(Mobile $mobile, $strTasksid)
	{
		try {
			$datetime = date('Y-m-d H:i:s');
			$this->addIndex(array('product'=>1, 'cid'=>1, 'meid'=>1, 'cyid'=>1, 'tasks.taskid'=>1, 'tasks.time'=>1));
			$result = $this->_mongo->count($this->_collection, array('cid'=>$mobile->strCid));
			if(!$result || $result <= 0){
				$result = $this->_mongo->save($this->_collection,
												array('product'=>$mobile->strProduct,
													  'cid'=>$mobile->strCid,
													  'meid'=>$mobile->strMeid,
													  'cyid'=>$mobile->strCyid,
													  'tasks'=>array(array('taskid'=>$strTasksid, 
													  						'time'=>$datetime)))
											  );
			}else{
				$result = $this->_mongo->update($this->_collection,
												array('tasks'=>array('taskid'=>$strTasksid, 'time'=>$datetime)),
												array('cid'=>$mobile->strCid),
												'push');
			}
			
			if(!$result){
				Logs::write('MobileTaskRecordTable::saveRecord():update() failed', 'log');
				return false;
			}
			return true;
		}catch (Exception $e){
			Logs::write('MobileTaskRecordTable::saveRecord() exception, mongErr:'.$this->_getMongo()->getError()
				.' err:'
				.' file:'.$e->getFile()
				.' line:'.$e->getLine()
				.' message:'.$e->getMessage()
				.' trace:'.$e->getTraceAsString(), 'log');
			return false;
		}
	}
	
	public function getMobibeTaskRecord($strCyId, $strCid, 
					                    $strMeid, $tSTime, $tETime, $nStart, $nLimit){
		try {
			$arrCondition = $this->_getCondition($strCyId, $strCid, $strMeid);

			$result 	= $this->_mongo->select($this->_collection,
													$arrCondition,
													array('tasks','cid'));
			if(is_array($result)){
				return $result;
			}
			return false;
				
		}catch (Exception $e){
			Logs::write('MobileTaskRecordTable::getMobibeTaskRecord() exception, mongErr:'.$this->_getMongo()->getError()
			.' err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
	}
	
	private function _getCondition($strCyId, $strCid, $strMeid){
		$arrCondition = array();
		if (!empty($strCid)){
			$arrCondition['cid'] = $strCid;
		}
		
		if (!empty($strCyId)){
			$arrCondition['cyid'] = $strCyId;
		}
		
		if (!empty($strMeid)){
			$arrCondition['meid'] = $strMeid;
		}
		
		return $arrCondition;
	}
}