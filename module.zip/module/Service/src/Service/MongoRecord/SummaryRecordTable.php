<?php
namespace Service\MongoRecord;

use Service\Mongo\MongoPHP;
use Service\Logs\Logs;
use Service\ManagerFactory;
//use Service\Task\Task;

class SummaryRecordTable extends MongoRecordTable
{
	public function __construct($arrConfig)
	{
		parent::__construct($arrConfig);
		$this->_collection = 'yl_cl_summary_data';
	}	
		
	public function getSummaryData($strTaskid)
	{
		try {
			$result = $this->_mongo->select($this->_collection,
					array('taskid'=>$strTaskid));
			
			return $result;				
		}catch (Exception $e){
			Logs::write('SummaryRecordTable::getSummaryData() exception, mongErr:'.$this->_getMongo()->getError()
			.' err:'
					.' file:'.$e->getFile()
					.' line:'.$e->getLine()
					.' message:'.$e->getMessage()
					.' trace:'.$e->getTraceAsString(), 'log');
					return false;
		}
	}
}