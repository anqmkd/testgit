<?php
namespace Service;
use Zend\Db\Adapter\Adapter;
use \PDO;
use Service\ManagerFactory;
//db_yl_themes
use Service\db_yl_themes\AlarmLabelTable;
use Service\db_yl_themes\AlarmTable;
use Service\db_yl_themes\AlbumsresTable;
use Service\db_yl_themes\AlbumsTable;
use Service\db_yl_themes\BannerlistTable;
use Service\db_yl_themes\BannerTable;
use Service\db_yl_themes\FontPreviewTable;
use Service\db_yl_themes\FontTable;
use Service\db_yl_themes\PayTable;
use Service\db_yl_themes\PreviewTable;
use Service\db_yl_themes\ProductTable;
use Service\db_yl_themes\RatioTable;
use Service\db_yl_themes\RingSubTypeTable;
use Service\db_yl_themes\RingTable;
use Service\db_yl_themes\RingTypeTable;
use Service\db_yl_themes\SceneTable;
use Service\db_yl_themes\TaskTable;
use Service\db_yl_themes\ThemeInfoTable;
use Service\db_yl_themes\ThemeTable;
use Service\db_yl_themes\WebbannerTable;
use Service\db_yl_themes\WidgetTable;
use Service\db_yl_themes\WplistCpTable;
use Service\db_yl_themes\HotWordTable;
use Service\db_yl_themes\MarkListTable;
//db_yl_designer
use Service\db_yl_designer\PersonthemepreviewTable;
use Service\db_yl_designer\PersonthemeTable;
//db_yl_androidesk
use Service\db_yl_androidesk\WallpaperTable;
use Service\db_yl_androidesk\WplistAdTable;
use Service\db_yl_androidesk\WpcommendTable;
use Service\db_yl_androidesk\CateInfoTable;
use Service\db_yl_androidesk\LauncherTable;
//db_yl_themes_records
use Service\db_yl_themes_records\ChargeTable;
//webuser
use Service\webuser\AclTable;
use Service\webuser\RoleTable;
use Service\webuser\UserTable;
//db_yl_recommend
use Service\db_yl_recommend\RecommendTable;


class Module
{	
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
    			//db_yl_themes
    			'Service\db_yl_themes\AlarmLabelTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new AlarmLabelTable($dbAdapter);
    				return $table;
    			},	    			
    			
    			'Service\db_yl_themes\AlarmTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new AlarmTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\AlbumsresTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new AlbumsresTable($dbAdapter);
    				return $table;
    			}, 
    			
    			'Service\db_yl_themes\AlbumsTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new AlbumsTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\BannerlistTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new BannerlistTable($dbAdapter);
    				return $table;
    			},    			
    			
    			'Service\db_yl_themes\BannerTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new BannerTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\FontPreviewTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new FontPreviewTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\FontTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new FontTable($dbAdapter);
    				return $table;
    			},   
    			 			
    			'Service\db_yl_themes\PayTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new PayTable($dbAdapter);
    				return $table;
    			},   
    			 
    			'Service\db_yl_themes\PreviewTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new PreviewTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\ProductTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new ProductTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\RatioTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new RatioTable($dbAdapter);
    				return $table;
    			}, 		
    			
    			 'Service\db_yl_themes\RingSubTypeTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new RingSubTypeTable($dbAdapter);
    				return $table;
    			},	
    						
    			'Service\db_yl_themes\RingTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new RingTable($dbAdapter);
    				return $table;
    			},
    			 
    			'Service\db_yl_themes\RingTypeTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new RingTypeTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\SceneTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new SceneTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\TaskTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new TaskTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\ThemeInfoTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new ThemeInfoTable($dbAdapter);
    				return $table;
    			},    			 
    			
    			'Service\db_yl_themes\ThemeTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new ThemeTable($dbAdapter);
    				return $table;
    			},
                'Service\db_yl_themes\HotWordTable' =>  function($sm) {
                    $module = new Module();
                    $arrConfig = $module->getConfig();
                    $dbAdapter = new Adapter($arrConfig['mydb']['themes']);
                    $table = new HotWordTable($dbAdapter);
                    return $table;
                },
                'Service\db_yl_themes\MarkListTable' =>  function($sm) {
                    $module = new Module();
                    $arrConfig = $module->getConfig();
                    $dbAdapter = new Adapter($arrConfig['mydb']['themes']);
                    $table = new MarkListTable($dbAdapter);
                    return $table;
                },
    			'Service\db_yl_themes\WebbannerTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new WebbannerTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_themes\WidgetTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new WidgetTable($dbAdapter);
    				return $table;
    			},
    			'Service\db_yl_themes\WplistCpTable' => function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themes']);
    				$table = new WplistCpTable($dbAdapter);
    				return $table;
    			},  
				
    			//db_yl_designer
    			'Service\db_yl_designer\PersonthemeTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['designer']);
    				$table = new PersonthemeTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_designer\PersonthemepreviewTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['designer']);
    				$table = new PersonthemepreviewTable($dbAdapter);
    				return $table;
    			},
    			
    			//db_yl_androidesk
    			'Service\db_yl_androidesk\WallpaperTable' => function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['androidesk']);
    				$table = new WallpaperTable($dbAdapter);
    				return $table;
    			},
    			
    		    'Service\db_yl_androidesk\WplistAdTable' => function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['androidesk']);
    				$table = new WplistAdTable($dbAdapter);
    				return $table;
    			},
    			
//    			'Service\db_yl_androidesk\WpcommendTable' => function($sm) {
//    				$module = new Module();
//            		$arrConfig = $module->getConfig();
//            		$dbAdapter = new Adapter($arrConfig['mydb']['androidesk']);
//    				$table = new WpcommendTable($dbAdapter, $table);
//    				return $table;
//    			},
    			
    			'Service\db_yl_androidesk\CateInfoTable' => function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['androidesk']);
    				$table = new CateInfoTable($dbAdapter);
    				return $table;
    			},
    			
    			'Service\db_yl_androidesk\LauncherTable' => function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['androidesk']);
    				$table = new LauncherTable($dbAdapter);
    				return $table;
    			},
    			
    			//db_yl_themes_records
    			'Service\db_yl_themes_records\ChargeTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['themesrecords']);
    				$table = new ChargeTable($dbAdapter);
    				return $table;
    			},
    			
    			//db_yl_recommend
				'Service\db_yl_recommend\RecommendTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['recommend']);
    				$table = new RecommendTable($dbAdapter);
    				return $table;
    			},
               	
               	//user
    			'Service\webuser\AclTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['user']);
    				$table = new AclTable($dbAdapter);
    				return $table;
    			},	 
    			
    			'Service\webuser\RoleTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['user']);
    				$table = new RoleTable($dbAdapter);
    				return $table;
    			},	
    			
    			'Service\webuser\UserTable' =>  function($sm) {
    				$module = new Module();
            		$arrConfig = $module->getConfig();
            		$dbAdapter = new Adapter($arrConfig['mydb']['user']);
    				$table = new UserTable($dbAdapter);
    				return $table;
    			},

    			
    		),
        );
    }    

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
}