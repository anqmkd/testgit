<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Audit\Controller\Site' => 'Audit\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'audit' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/audit[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Audit\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'Audit' => __DIR__ . '/../view',
        ),
    ),
);