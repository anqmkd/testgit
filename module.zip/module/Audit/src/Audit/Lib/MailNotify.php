<?php
namespace Audit\Lib;

use Zend\Http\Header\Server;

use Audit\Lib\Email;
use Theme\Logs\Logs;

defined("YL_THEME_AUDIT_NOTIFY")
	or define("YL_THEME_AUDIT_NOTIFY", "<div>酷秀设计师，%s 您好！<br />"
				."<br />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;您的实名认证%s"."</div>");

class MailNotify
{
	private $mail;
	public function __construct($mailConfig)
	{
		$this->mail = new Email($mailConfig);
	}
	
	public function notify($email,$strSubject, $strBody, $arrAttachment = null)
	{
		$bResult = $this->mail->sendEmail($email,$strSubject, $strBody, $arrAttachment);
//                Logs::write('MailNotify::Notify():SendEmail() result:'.$bResult, 'log');
		if(!$bResult){
			Logs::write('MailNotify::Notify():SendEmail() failed', 'log');
			return  false;			
		}
		return true;
	}
	
	public function getNotifySubject()
	{
		$strSubject = '酷派设计师审核结果通知!';
		return $strSubject;
	}
	
	public function getNotifyBody($devname,$authenType,$reason)
	{
		if($authenType == 2) $status = '<b>通过了</b>。谢谢您的支持，点击链接<a href="http://developer.coolyun.com">http://developer.coolyun.com'.
		'</a>，赶紧上传自己的主题吧！';
		else $status = '<b>审核未通过</b>，原因是：'.$reason.'。不要气馁，点击链接<a href="http://developer.coolyun.com">http://developer.coolyun.com'.
		'</a>，重新提交资料吧!';
		$strBody = sprintf(YL_THEME_AUDIT_NOTIFY, $devname, $status);
		return $strBody;
	}
}
