<?php
namespace Audit\Lib;

use Zend\Mail\Message;
use Zend\Mail\Transport\Smtp as SmtpTransport;
use Zend\Mail\Transport\SmtpOptions;

use Zend\Mime\Mime;
use Zend\Mime\Message as MimeMessage;
use Zend\Mime\Part;

use Designer\Logs\Logs;

class Email
{
	public $transport;
	public $configOpt;
	public function __construct($configOpt)
	{
		$this->configOpt = $configOpt;
		$this->transport = new SmtpTransport();
		$options   = new SmtpOptions($configOpt['smtp']);
		$this->transport->setOptions($options);
	}
	
	public function sendEmail($email,$strSubject, $strBody, $arrAttachment = null)
	{
		try{
			$message = new Message();
			$message->addFrom($this->configOpt['from'], $this->configOpt['sender']);
  			$message->addTo($email,$email);
//  			$message->addCc('lijie1@yulong.com', '李杰');
//			$message->addCc($email,$email);			
 			$message->addBcc('chengjie@yulong.com','程杰');

			$mimeMessage = new MimeMessage();
			
			$messageText = new Part($strBody);
			$messageText->type = 'text/html';
			$arrContent = array();
			
			array_push($arrContent, $messageText);
			
			if($arrAttachment != null){
				foreach ($arrAttachment as $attachment){
					foreach ($attachment as $key=>$value){
							
						$data = fopen($value, 'r');
							
						$messageAttachment = new Part($data);
						$messageAttachment->type = 'image/jpg';
						$messageAttachment->filename = $key;
						$messageAttachment->encoding = Mime::ENCODING_BASE64;
						$messageAttachment->disposition = Mime::DISPOSITION_ATTACHMENT;
							
						array_push($arrContent, $messageAttachment);
					}
				}
			}
			
			$mimeMessage->setParts($arrContent);
			
			$message->setSubject($strSubject)
					->setBody($mimeMessage);
			$this->transport->send($message);
		}catch (Exception $e){
			Logs::write('Email::sendEmail() Exception Error:'.$e->getMessage(), 'log');
			return false;
		}
		return true;
	}
}