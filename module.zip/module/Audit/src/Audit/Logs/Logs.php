<?php
namespace Audit\Logs;

use Zend\Log\Logger;
use Zend\Log\Writer;
use Zend\Log\Writer\Stream;

class Logs
{
	/**
	 * 单个日志文件大小限制
	 *
	 * @var int 字节数
	 */
	private static $i_log_size = 5242880; // 1024 * 1024 * 5 = 5M
	private static $s_log_path = "Logs/";
	
    public function __construct()
	{
	}
	
	/**
	 * 设置单个日志文件大小限制
	 *
	 * @param int $i_size 字节数
	 */
	public static function set_size($i_size)
	{
		if( is_numeric($i_size) ){
			self::$i_log_size = $i_size;
		}
	}
	
	public static function write($msg, $type)
	{
 		if( !file_exists(self::$s_log_path) ) {
 			//echo("logs not exists");
 			@mkdir(self::$s_log_path);
 		}
 		$s_now_time = date('[Y-m-d H:i:s]');
 		$s_now_day  = date('Y_m_d');
 		// 根据类型设置日志目标位置
 		$s_target   = self::$s_log_path;
 		switch($type)
 		{
 			case 'debug':
 				$s_target .= 'Out_' . $s_now_day . '.log';
 				break;
 			case 'error':
 				$s_target .= 'Err_' . $s_now_day . '.log';
 				break;
 			case 'log':
 				$s_target .= 'Log_' . $s_now_day . '.log';
 				break;
 			default:
 				$s_target .= 'Log_' . $s_now_day . '.log';
 				break;
 		}
 		//echo($s_target);
 		//检测日志文件大小, 超过配置大小则重命名
 		if (file_exists($s_target) && self::$i_log_size <= filesize($s_target)) {
 			$s_file_name = substr(basename($s_target), 0, strrpos(basename($s_target), '.log')). '_' . time() . '.log';
 			rename($s_target, dirname($s_target) . DS . $s_file_name);
 		}
 		clearstatcache();
 		// 写日志, 返回成功与否
 		
 		$writer = new Stream($s_target);
 		$logger = new Logger();
 		$logger->addWriter($writer);
 		
 		switch($type)
 		{
 			case 'debug':
 				$logger->debug($msg);
 				break;
 			case 'error':
 				$logger->err($msg);
 				break;
 			case 'log':
 				$logger->log(1, $msg);
 				break;
 			default:
 				$logger->log(1, $msg);
 				break;
 		} 		
 			
  		return true;//error_log("$s_now_time $s_message \n\n",  3,  $s_target);
	}
}