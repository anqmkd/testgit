<?php
namespace Audit\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Audit\Acl\Useracl;
use Audit\Module;
use Audit\Model\XmltoolTable;
use Audit\Model\IcontoolTable;
use Audit\Model\ChargeRecordTable;
use Audit\Lib\MailNotify;
use Theme\Logs\Logs;
use Zend\Db\Adapter\Adapter;
use \PDO;
use \ZipArchive;

class SiteController extends AbstractActionController
{
	public $basepushurl = 'http://download.coolyun.com';
		
	protected $xmltoolTable;
	protected $companyTable;
	protected $financeTable;
	protected $chargeRecordTable;
	protected $mailNotify;
	
        public $mail =           array(                                                                         //邮件配置信息
                        'smtp' =>       array(
                                        'name'              => 'smtp.yeah.net',
                                'host'              => '123.58.177.132',
                                'port'              => 25,
                                'connection_class'  => 'login',
                                'connection_config' => array(
                                                'username' => 'coolshowcj',
                                                'password' => '1q2w3e4r5t',
                                                'ssl'      => 'tls',
                                                ),
                                                ),
                        'sender' => 'coolshow',
                        'from'   => 'coolshowcj@yeah.net',
                        );	
	
	public function idcardAction()
	{		
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$pageSize = 10;
		$page = isset($_GET['page'])?$_GET['page']:1;
		$typeid = isset($_GET['typeid'])?$_GET['typeid']:1;
		$size = $this->getIDCardTabele()->getCountnum($typeid);
		$totalPage      = ceil($size/$pageSize);
		if($page>$totalPage){$page = $totalPage;}
		if($page == 0){$page = 1;}
		$result = $this->getIDCardTabele()->getData($page,$pageSize,$typeid);
		$infoArr = array();
		foreach($result as $row){
			$infoArr[] = (array)$row;
		}
		$authMode = array('未提交','待审核','审核通过','审核不通过');
		return new ViewModel(array('mycount'=>$size,'pagesize'=>$pageSize,'totalPage'=>$totalPage,
								'page'=>$page,'infoArr'=>$infoArr,'showurl'=>$this->basepushurl,
								'authMode'=>$authMode,'mytypevalue'=>$typeid));
	}
	
	public function updateauthenmodeAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr = $request->getPost();
			$authenType = $postArr['status'];
			$id         = $postArr['id'];
			$reason     = $postArr['reason'];
			$email      = $postArr['email'];
			$devname    = $postArr['devname'];		
			$this->getIDCardTabele()->updateData(array('userid'=>(int)$id,'authentype'=>(int)$authenType,'reason'=>$reason));
			if($authenType == 2 || $authenType == 3){
				$this->_mailNotify($email,$devname,$authenType,$reason);
			}			
		}
		die("success");
	}
	
	public function _mailNotify($email,$devname,$authenType,$reason)
	{	
		$strSubject = $this->getMailNotify()->getNotifySubject();
		$strBody = $this->getMailNotify()->getNotifyBody($devname,$authenType,$reason);
		$bResult = $this->getMailNotify()->notify($email,$strSubject, $strBody);
//                Logs::write('ApiController::_mailNotify() result:'.$bResult, 'log');
		if(!$bResult){
			Logs::write('ApiController::_mailNotify() failed', 'log');
			return false;
		}
		return true;
	}
	
	public function getMailNotify()
	{
		if(!$this->mailNotify){
			$this->mailNotify = new MailNotify($this->mail);
		}
		return $this->mailNotify;
	}
	
	public function companycardAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$pageSize = 10;
		$page = isset($_GET['page'])?$_GET['page']:1;
		$typeid = isset($_GET['typeid'])?$_GET['typeid']:1;
		$size = $this->getCompanyCardTabele()->getCountnum($typeid);
		$totalPage      = ceil($size/$pageSize);
		if($page>$totalPage){$page = $totalPage;}
		if($page == 0){$page = 1;}
		$result = $this->getCompanyCardTabele()->getData($page,$pageSize,$typeid);
		$infoArr = array();
		foreach($result as $row){
			$infoArr[] = (array)$row;
		}
		$authMode = array('未提交','待审核','审核通过','审核不通过');
		return new ViewModel(array('mycount'=>$size,'pagesize'=>$pageSize,'totalPage'=>$totalPage,
				'page'=>$page,'infoArr'=>$infoArr,'showurl'=>$this->basepushurl,
				'authMode'=>$authMode,'mytypevalue'=>$typeid));
	}
	
	public function companyupdateauthenmodeAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr = $request->getPost();
			$authenType = $postArr['status'];
			$id         = $postArr['id'];
			$reason     = $postArr['reason'];
			$email      = $postArr['email'];
			$devname    = $postArr['devname'];
			$this->getCompanyCardTabele()->updateData(array('userid'=>(int)$id,'authentype'=>(int)$authenType,'reason'=>$reason));
			if($authenType == 2 || $authenType == 3){
				$this->_mailNotify($email,$devname,$authenType,$reason);
			}
		}
		die("success");
	}
	
	public function financeAction()
	{
	
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$pageSize = 10;
		$page = isset($_GET['page'])?$_GET['page']:1;
		$size = $this->getFinanceTabele()->getCountnum();
		$totalPage      = ceil($size/$pageSize);
		if($page>$totalPage){$page = $totalPage;}
		if($page == 0){$page = 1;}
		$result = $this->getFinanceTabele()->getAppData($page,$pageSize);
		$infoArr = array();
		foreach($result as $row){
			$infoArr[]          =(array)$row;
		}
		$authMode = array('提现待审核','提现审核通过,打款中','打款成功','审核不通过,请重新提交');
		return new ViewModel(array('mycount'=>$size,'pagesize'=>$pageSize,'totalPage'=>$totalPage,
				'page'=>$page,'infoArr'=>$infoArr,'showurl'=>$this->basepushurl,'authMode'=>$authMode,));
	}
	
	public function getauditinfoAction()
	{
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr = $request->getPost();
			$strcp     = $postArr['cpv'];
			$auditInfo = $this->getChargeRecordTable()->getAuditInfo($strcp);
			$havecash  = $this->getFinanceTabele()->gethavecash($strcp);
			$auditInfo['havecash'] = (int)$havecash;
		}
		die(json_encode($auditInfo));
	}
	
	public function updatepricemodeAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr = $request->getPost();
			$authenType = $postArr['status'];
			$id         = $postArr['id'];
			$this->getFinanceTabele()->updateData(array('deposit_number'=>$id,'status'=>(int)$authenType));
		}
		die("success");
	}
	
	public function getIDCardTabele()
	{
		if (!$this->xmltoolTable) {
			$sm = $this->getServiceLocator();
			$this->xmltoolTable = $sm->get('Audit\Model\IDCardTable');
		}
		return $this->xmltoolTable;
	}
	
	public function getCompanyCardTabele()
	{
		if (!$this->companyTable) {
			$sm = $this->getServiceLocator();
			$this->companyTable = $sm->get('Audit\Model\CompanyCardTable');
		}
		return $this->companyTable;
	}
	
	public function getFinanceTabele()
	{
		if (!$this->financeTable) {
			$sm = $this->getServiceLocator();
			$this->financeTable = $sm->get('Audit\Model\FinanceTable');
		}
		return $this->financeTable;
	}
	
	public function getChargeRecordTable()
	{
		if (!$this->chargeRecordTable) {
			$sm = $this->getServiceLocator();
			$this->chargeRecordTable = $sm->get('Audit\Model\ChargeRecordTable');
		}
		return $this->chargeRecordTable;
	}

	public function delcontentAction()
	{
		try{
			$request     = $this->getRequest();
			$postArr     = $request->getPost();
			$id          = $postArr['id'];
			$this->getIDCardTabele()->delete($id);
	
			die('success');
		}catch(Exception $e){
			Logs::write('delcontentAction() error:'.$e->getMessage(),'log');
			die('error');
		}
	
	}
	
	public function indexAction()
	{
		/*
		 $aaa = 'D:\webserver\easyphp\www\MyApplication\public\upload\Files\tool\20130503174315\duomiyinle.apk';
		$crc = sprintf("%u", crc32(file_get_contents($aaa)));
		var_dump($crc);exit;
		*/
		$uData = $this->checkLogin('index');
		if(!$uData)
		{
			die('没有权限');
		}
		return new ViewModel();
	}
	public function topAction()
	{
		$uData = $this->checkLogin('top');
		if(!$uData)
		{
			die('没有权限');
		}
		return new ViewModel(array('uData'=>$uData));
	}
	public function leftAction()
	{
		$uData = $this->checkLogin('left');
		if(!$uData)
		{
			die('没有权限');
		}
	
		$module_temp = new Module();
		$params = $module_temp->getParams();
	
	
		return new ViewModel( array('params'=>$params['params']) );
	}
	public function downAction()
	{
		$uData = $this->checkLogin('down');
		if(!$uData)
		{
			die('没有权限');
		}
		return new ViewModel();
	}
	
	
	public function centerAction()
	{
		$uData = $this->checkLogin('center');
		if(!$uData)
		{
			die('没有权限');
		}
		return new ViewModel();
	}
	
	public function checkLogin($action)
	{
		$myAuth  = new Auth();
		$objUser = $myAuth->isLogin();
		if(!$objUser)
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
		}
		if($objUser)
		{
			$roleArr  = json_decode($objUser->roleStr,true);
			$roleData = isset($roleArr['audit'])?$roleArr['audit']:"";
			if($roleData=="")
			{
				return false;
			}
			else
			{
				$userAcl   = new Useracl();
				$allowData = $userAcl->checkAction($roleData, $action);
				if(!$allowData)
				{
					return false;
				}else{
					return $objUser;
				}
			}
		}
	}
	
	
	
    
}
