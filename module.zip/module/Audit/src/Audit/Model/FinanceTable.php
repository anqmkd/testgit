<?php

namespace Audit\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Audit\Logs\Logs;


class FinanceTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_user_deposit';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppData($page=1,$pagesize=1)
    {
    	$limit = $pagesize;
    	$offset = ((int)$page -1)*$pagesize;
    	$select = $this->getSql()->select();
    	$select->join(array('user'=>'tb_yl_coolyun_userinfo'),
    			             'user.userid=tb_yl_user_deposit.cyid',array('*'),
    						$select::JOIN_INNER);
    	$select->order('tb_yl_user_deposit.insert_time DESC');
    	$select->limit($pagesize);
    	$select->offset($offset);
    	$rowset = $this->selectWith($select);
    	$rows = array();
    	while($rowset->valid()){
    		$row = $rowset->current();
    		if(!$row){
    			continue;
    		}
    		array_push($rows, $row);
    		$rowset->next();
    	}
    	
    	return $rows;
    }
    
    public function updateData(array $data){
    	try{
//     		Logs::write(json_encode($data), 'log');
    		return $this->update($data,array('deposit_number'=>$data['deposit_number']));
    	}catch(Exception $e){
    		Logs::write('FinanceTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function getAuditInfo($cyid)
    {
    	$sql = "SELECT * FROM tb_yl_user_summary WHERE cyid ='".$cyid."'";
    	$result = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}
    }
    
    public function getAppDataAll(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
//     public function getAppData(array $data)
//     {
//     	$result = $this->select($data);
//     	return $result->current();
//     }

    
    public function gethavecash($strChannel)
    {
    	$sql = "SELECT SUM(deposit_money) AS havedmoney FROM tb_yl_user_deposit WHERE CP = '".$strChannel."' AND STATUS = 2";
    	$resultSceneOpe = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	$havecash = 0;
    	foreach ($resultSceneOpe as $row){
    		$havecash =  $row['havedmoney'];
    		break;
    	}
    	return $havecash;
    }
    
    public function getXmlType(){
    	$sqlStr   = "SELECT NAME,VALUE FROM tb_yl_xml_type ORDER BY VALUE ASC";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    public function getJudgeData($packageName){
    	$sqlStr   = "SELECT * FROM tb_yl_type_list WHERE packageName = '".$packageName."'";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}   		
    	return $result;
    }
    
    
    public function saveArr(array $data)
    {
    	try{
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
   
    
    public function delete($id){
    	$sqlStr   = "DELETE FROM tb_yl_apk_add WHERE id=".$id;
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }

       
}
