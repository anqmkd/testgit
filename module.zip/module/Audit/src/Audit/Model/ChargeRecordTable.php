<?php

namespace Audit\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;
use Audit\Logs\Logs;


class ChargeRecordTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_theme_day_exorder';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppData()
    {
    	$select = $this->getSql()->select();
    	$select->join(array('user'=>'tb_yl_coolyun_userinfo'),
    			             'user.userid=tb_yl_user_deposit.cyid',array('*'),
    						$select::JOIN_INNER);
    	$rowset = $this->selectWith($select);
    	$rows = array();
    	while($rowset->valid()){
    		$row = $rowset->current();
    		if(!$row){
    			continue;
    		}
    		array_push($rows, $row);
    		$rowset->next();
    	}
    	
    	return $rows;
    }
    
    public function updateData(array $data){
    	try{
    		return $this->update($data,array('deposit_number'=>$data['deposit_number']));
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::updateData() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
    public function getAuditInfo($strChannel)
    {
    	$arrRation = array('移动'=>0.45,'联通'=>0.42,'电信'=>0.50);//支付成本
    	$date = date('Y-m').'-01';
    	$totalVolume = 0;
    	$cost   = 0;
    	$gain   = 0;
    	$profit = 0;
    	$tableArr    = array('tb_yl_theme_day_op_charge','tb_yl_scene_day_op_charge');
    	foreach ($tableArr as $table){
    		$sql = "SELECT operators,SUM(smoney) AS smoney,SUM(success) AS turnover FROM ".$table." WHERE cp = '".$strChannel
    				."' AND tdate<'".$date."' GROUP BY operators";
    		$resultOpe = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
			foreach($resultOpe as $row){
    			$oName = $row['operators'];
    			if(array_key_exists($oName, $arrRation)){
    				$smoney = (int)$row['smoney']/100;
    				$r = $arrRation[$oName];
    				$totalVolume += $smoney;
    				$tempcost = ceil($smoney*$r);
    				$cost += $tempcost;
    				$tempgain = floor($smoney - $tempcost);
    				$gain += $tempgain;
    				$profit += floor($tempgain*0.7);
    			}
    		}
    	}   	
    	return array('totalmoney'=>$totalVolume,'profit'=>$gain,'divide'=>$profit);
    }
    
    public function getAppDataAll(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
//     public function getAppData(array $data)
//     {
//     	$result = $this->select($data);
//     	return $result->current();
//     }
    
    public function getXmlType(){
    	$sqlStr   = "SELECT NAME,VALUE FROM tb_yl_xml_type ORDER BY VALUE ASC";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }
    public function getJudgeData($packageName){
    	$sqlStr   = "SELECT * FROM tb_yl_type_list WHERE packageName = '".$packageName."'";
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	foreach ($result as $row){
    		return $row;
    	}   		
    	return $result;
    }
    
    
    public function saveArr(array $data)
    {
    	try{
    		$this->insert($data);
    		return $this->getLastInsertValue();
    	}catch(Exception $e){
    		Logs::write('XmltoolTable::saveArr() error:'.$e->getMessage(), 'log');
    		return false;
    	}
    }
    
   
    
    public function delete($id){
    	$sqlStr   = "DELETE FROM tb_yl_apk_add WHERE id=".$id;
    	$result   = $this->adapter->query($sqlStr, Adapter::QUERY_MODE_EXECUTE);
    	return $result;
    }

       
}
