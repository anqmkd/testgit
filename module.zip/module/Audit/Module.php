<?php

namespace Audit;

use Audit\Model\IDCardTable;
use Audit\Model\FinanceTable;
use Audit\Model\ChargeRecordTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
// 	public static $db = array(
// 			'driver' => 'Pdo',
// 			'dsn'            => 'mysql:dbname=db_yl_designer;host=172.16.45.143',
// 			'username'       => 'root',
// 			'password'       => '1234',
// 			'driver_options' => array(
// 					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
// 			),
// 	);
	
// 	public static $chargedb = array(
// 			'driver' => 'Pdo',
// 			'dsn'            => 'mysql:dbname=db_yl_charge_record;host=172.16.45.143',
// 			'username'       => 'root',
// 			'password'       => '1234',
// 			'driver_options' => array(
// 					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
// 			),
// 	);
	
	public static $db = array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_designer;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);
	
	public static $chargedb = array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_coolshow_charge_data;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);
	




		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			
    			'Audit\Model\IDCardTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new IDCardTable($dbAdapter);
    				return $table;
    			},

                        'Audit\Model\CompanyCardTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new CompanyCardTable($dbAdapter);
    				return $table;
    			},
    			
    			'Audit\Model\FinanceTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new FinanceTable($dbAdapter);
    				return $table;
    			},
    			'Audit\Model\ChargeRecordTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$chargedb);
    				$table = new ChargeRecordTable($dbAdapter);
    				return $table;
    			},
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
