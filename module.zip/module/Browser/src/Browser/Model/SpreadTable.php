<?php

namespace Browser\Model;

use Zend\Console\Prompt\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class SpreadTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_br_spread';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=10)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_br_spread_imgs'), 'tb_yl_br_spread.identity = a.identity',array('filename','url','size'))
    	         //->where(array('tb_yl_br_spread.valid'=>1))
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getCountnum()
    {
    	$result = $this->select(array('valid'=>1));
    	return $result->count();
    }
    
    public function saveSpread(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateSpreadData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    
    
}
