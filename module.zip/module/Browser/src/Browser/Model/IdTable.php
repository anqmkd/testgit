<?php

namespace Browser\Model;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class IdTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_br_spread_id';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getIdData()
    {
    	$rowset = $this->select();
    	return $rowset;
    }
    public function saveId(array $dataArr)
    {
	    $data = array(
	    	'identity' => $dataArr['identity'],
	    );
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    public function updateId(array $apk)
    {
    	$data = array(
    			'identity' => $apk['identity'],
    	);
    	
    	$this->update($data, array('id' => $apk['id']));
    }
    
}
