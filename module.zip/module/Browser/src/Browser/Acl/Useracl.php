<?php
namespace Browser\Acl;

use Zend\Permissions\Acl\Acl;
use Zend\Permissions\Acl\Role\GenericRole as Role;
use Zend\Permissions\Acl\Resource\GenericResource as Resource;
class Useracl
{
	public $useracl;
	public function __construct()
	{
		$this->useracl = new Acl();			
	}
	public function init()
	{
		$this->useracl->addRole(new Role('user'))
			          ->addRole(new Role('admin'));
		$this->useracl->addResource(new Resource('browser'));
		$this->useracl->allow('user','browser',array('index','top','edit','left','right','down'));
		//$this->useracl->allow('manager');
		$this->useracl->allow('admin','browser',array('index','center','edit','top','left','right','down','add'));
	}
	public function checkAction($role,$action)
	{
		$this->init();
		return $this->useracl->isAllowed($role,'browser',$action);
	}
}
