<?php

namespace Browser\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Browser\Module;
use Browser\Acl\Useracl;
use Browser\Model\SpreadTable;
use Browser\Model\IdTable;
use Browser\Model\ImgTable;

class SiteController extends AbstractActionController
{
	public $filepath = '/home/wwwroot/rsync';
	public $tempfile = '/home/wwwroot/app/public/tempfile/browserAdd.txt';
	public $replacestr = '/home/wwwroot/rsync/';
	public $showurl = 'http://125.76.226.205/rsync/';

	protected $spreadTable;
	protected $idTable;
	protected $imgTable;
    public function indexAction()
    {
    	$uData = $this->checkLogin('index');
    	
    	if(!$uData)
    	{
    		die('没有权限');
    	}
        return new ViewModel();
    }
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    public function changeAction()
    {
    	$temp_time = date('Ymd');
    	$temp_time_h = date('His');
    	$temp_str = $temp_time.'/'.$temp_time_h;
    	@file_put_contents($this->tempfile, $temp_str);
    	die("");
    }
    public function rightAction()
    {
    	$pageSize = 10;
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countSpread = $this->getSpreadTable()->getCountnum();
    	
    	$totalPage=ceil($countSpread/$pageSize);
    	if($page>$totalPage) $page = $totalPage; 
    	if($page==0) $page = 1;
    	$tempData = $this->getSpreadTable()->getData($page,$pageSize);    	
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    	
    	//var_dump($listData);exit;
    	return new ViewModel(array('uData'=>$uData,'countSpread'=>$countSpread,'showurl'=>$this->showurl,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }  
        
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限center');
    	}
    	return new ViewModel();
    }
    
    
    public function addAction()
    {
    	$uData = $this->checkLogin('add');
    	if(!$uData)
    	{
    		die('没有权限');
    	}    	
    	$request = $this->getRequest();
    	if ($request->isPost()) {
    		$postArr = $request->getPost();
    		if($postArr['label']=="" || $postArr['start']=="" || $postArr['end']=="" || ($postArr['pic_a']==""&&$postArr['pic_b']==""&&$postArr['pic_c']==""&&$postArr['pic_d']=="")){
    			die('empty');
    		}
    		
    		if($postArr['pic_a'])
    		{
    			$id_a = $this->getID();
    			$tempimg_a = explode("/",$postArr['pic_a']);
    			$img_a_arr = array(
    				'identity' => $id_a,
    				'size' => filesize($this->filepath.$postArr['pic_a']),
    				'filename' => end($tempimg_a),
    				'md5'=>md5_file($this->filepath.$postArr['pic_a']),
    				'url'=>$postArr['pic_a'],					
    			);     			
    			$w_a = 480;
    			$h_a = 800;
    			$spread_a_arr = array(
    					'identity' => $id_a,
    					'subject' => $postArr['label'],
    					'height' => $h_a,
    					'width'=>$w_a,
    					'start'=>$postArr['start'],
    					'end'=>$postArr['end'],
    					'note'=>$postArr['note'],
    					'valid'=>1,
    					'insert_user'=>$postArr['author'],
    			);
    			
    			$this->getImgTable()->saveImgArr($img_a_arr);
    			$this->getSpreadTable()->saveSpread($spread_a_arr);
    			
    		}
    		if($postArr['pic_b'])
    		{
    			$id_b = $this->getID();
    			$tempimg_b = explode("/",$postArr['pic_b']);
    			$img_b_arr = array(
    					'identity' => $id_b,
    					'size' => filesize($this->filepath.$postArr['pic_b']),
    					'filename' => end($tempimg_b),
    					'md5'=>md5_file($this->filepath.$postArr['pic_b']),
    					'url'=>$postArr['pic_b'],
    			);
    			$w_b = 480;
    			$h_b = 960;
    			$spread_b_arr = array(
    					'identity' => $id_b,
    					'subject' => $postArr['label'],
    					'height' => $h_b,
    					'width'=>$w_b,
    					'start'=>$postArr['start'],
    					'end'=>$postArr['end'],
    					'note'=>$postArr['note'],
    					'valid'=>1,
    					'insert_user'=>$postArr['author'],
    			);
    			 
    			$this->getImgTable()->saveImgArr($img_b_arr);
    			$this->getSpreadTable()->saveSpread($spread_b_arr);
    			//die("");
    			 
    		}
    		if($postArr['pic_c'])
    		{
    			$id_c = $this->getID();
    			$tempimg_c = explode("/",$postArr['pic_c']);
    			$img_c_arr = array(
    					'identity' => $id_c,
    					'size' => filesize($this->filepath.$postArr['pic_c']),
    					'filename' => end($tempimg_c),
    					'md5'=>md5_file($this->filepath.$postArr['pic_c']),
    					'url'=>$postArr['pic_c'],
    			);
    			$w_c = 540;
    			$h_c = 960;
    			$spread_c_arr = array(
    					'identity' => $id_c,
    					'subject' => $postArr['label'],
    					'height' => $h_c,
    					'width'=>$w_c,
    					'start'=>$postArr['start'],
    					'end'=>$postArr['end'],
    					'note'=>$postArr['note'],
    					'valid'=>1,
    					'insert_user'=>$postArr['author'],
    			);
    			
    			$this->getImgTable()->saveImgArr($img_c_arr);
    			$this->getSpreadTable()->saveSpread($spread_c_arr);
    			 
    		}

    		if($postArr['pic_d'])
    		{
    			$id_d = $this->getID();
    			$tempimg_d = explode("/",$postArr['pic_d']);
    			$img_d_arr = array(
    					'identity' => $id_d,
    					'size' => filesize($this->filepath.$postArr['pic_d']),
    					'filename' => end($tempimg_d),
    					'md5'=>md5_file($this->filepath.$postArr['pic_d']),
    					'url'=>$postArr['pic_d'],
    			);
    			$w_d = 720;
    			$h_d = 1280;
    			$spread_d_arr = array(
    					'identity' => $id_d,
    					'subject' => $postArr['label'],
    					'height' => $h_d,
    					'width'=>$w_d,
    					'start'=>$postArr['start'],
    					'end'=>$postArr['end'],
    					'note'=>$postArr['note'],
    					'valid'=>1,
    					'insert_user'=>$postArr['author'],
    			);
    			 
    			$this->getImgTable()->saveImgArr($img_d_arr);
    			$this->getSpreadTable()->saveSpread($spread_d_arr);
    			 
    		}

    		if($postArr['pic_e'])
    		{
    			$id_e = $this->getID();
    			$tempimg_e = explode("/",$postArr['pic_e']);
    			$img_e_arr = array(
    					'identity' => $id_e,
    					'size' => filesize($this->filepath.$postArr['pic_e']),
    					'filename' => end($tempimg_e),
    					'md5'=>md5_file($this->filepath.$postArr['pic_e']),
    					'url'=>$postArr['pic_e'],
    			);
    			$w_e = 1920;
    			$h_e = 1080;
    			$spread_e_arr = array(
    					'identity' => $id_e,
    					'subject' => $postArr['label'],
    					'height' => $h_e,
    					'width'=>$w_e,
    					'start'=>$postArr['start'],
    					'end'=>$postArr['end'],
    					'note'=>$postArr['note'],
    					'valid'=>1,
    					'insert_user'=>$postArr['author'],
    			);
    			 
    			$this->getImgTable()->saveImgArr($img_e_arr);
    			$this->getSpreadTable()->saveSpread($spread_e_arr);
    			 
    		}


    		die('success');
    		
    	}    	 
    	$module_temp = new Module();
    	$params = $module_temp->getParams();
    	return new ViewModel(array('fenbianlv'=>$params['params']['wh'], 'replacestr'=>$this->replacestr, 'uData'=>$uData));
    }
    
    
    public function checkLogin($action)
    {
    	$myAuth = new Auth();
    	//$myAuth->logout();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr = json_decode($objUser->roleStr,true);
    		
    		$roleData = isset($roleArr['browser'])?$roleArr['browser']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }
    
    public function useAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$type = isset($postArr['t'])?$postArr['t']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";
    		if(empty($id) || empty($type) || $myval=='n')
    		{
    			die('error');
    		}
    		if($type=="use")
    		{
    			$widgetArr = array(
    				'id'=>$id,
    				'valid'=>$myval,
    			);
    			$this->getSpreadTable()->updateSpreadData($widgetArr);
    			die('success');
    		}
    		
    	}	 
    }
    public function getSpreadTable()
    {
    	if (!$this->spreadTable) {
    		$sm = $this->getServiceLocator();
    		$this->spreadTable = $sm->get('Browser\Model\SpreadTable');
    	}
    	return $this->spreadTable;
    }
    
    public function getIdTable()
    {
    	if (!$this->idTable) {
    		$sm = $this->getServiceLocator();
    		$this->idTable = $sm->get('Browser\Model\IdTable');
    	}
    	return $this->idTable;
    }
    
    public function getImgTable()
    {
    	if (!$this->imgTable) {
    		$sm = $this->getServiceLocator();
    		$this->imgTable = $sm->get('Browser\Model\ImgTable');
    	}
    	return $this->imgTable;
    }
    
    
    public function getID()
    {
    	$tempArr = array();
    	$row = $this->getIdTable()->getIdData();
    	foreach($row as $array)
    	{
    		$tempArr[] = $array;
    	}
    	if(count($tempArr)==0)
    	{
    		$data = array(  'identity' =>1  );
    		$this->getIdTable()->saveId($data);
    		$id = 1;
    	}else
    	{
    		$id = $tempArr[0]['identity'];
    		$id = (int)$id + 1;
    		$this->getIdTable()->updateId(array('id'=>$tempArr[0]['id'],'identity'=>$id)); 
    	}
    	$num = sprintf('%06d', $id);
    	$identity = 'BRSP'.$num;
    	return $identity;
    }
    
    
    
}
