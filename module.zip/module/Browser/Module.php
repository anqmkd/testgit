<?php

namespace Browser;

use Browser\Model\SpreadTable;
use Browser\Model\IdTable;
use Browser\Model\ImgTable;
use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
	public static $db = array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=browser;hostname=localhost',
			'username'       => 'wenlt',
			'password'       => 'wenlt!qaz',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);
		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			'Browser\Model\SpreadTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new SpreadTable($dbAdapter);
    				return $table;
    			},
    			'Browser\Model\IdTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new IdTable($dbAdapter);
    				return $table;
    			},
    			'Browser\Model\ImgTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ImgTable($dbAdapter);
    				return $table;
    			},
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}