<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Browser\Controller\Site' => 'Browser\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'browser' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/browser[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Browser\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'browser' => __DIR__ . '/../view',
        ),
    ),
);