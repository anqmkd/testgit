<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Statistic\Controller\Site' => 'Statistic\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'statistic' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/statistic[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Statistic\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'statistic' => __DIR__ . '/../view',
        ),
    ),
);