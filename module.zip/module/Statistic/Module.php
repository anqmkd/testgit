<?php

namespace Statistic;



use Statistic\Model\ProductTable;
use Statistic\Model\DownloadTable;
use Statistic\Model\WidgetTable;
use Statistic\Model\ApkTable;
use Statistic\Model\TempTable;
use Statistic\Model\ReqTable;

use Statistic\Model\WpReqTable;
use Statistic\Model\WpPreviewTable;
use Statistic\Model\WpDownloadTable;
use Statistic\Model\WpAppTable;
use Statistic\Model\LabelTable;

use Statistic\Model\TempthemeTable;
use Statistic\Model\ThemeinfoTable;

use Statistic\Model\ThemeReqTable;
use Statistic\Model\ThemePreviewTable;
use Statistic\Model\ThemeDownloadTable;
use Statistic\Model\ThemeAppTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{

	public static $db = array(
			'driver' => 'Pdo',
			//'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',
	        'dsn'            => 'mysql:dbname=db_yl_network_widget;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);

			 


	public static $db_new = array(
			'driver' => 'Pdo',
			//'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',
	        'dsn'            => 'mysql:dbname=db_yl_widget_records;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);

	public static $db_wp = array(
			'driver' => 'Pdo',
			//'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',   
	        'dsn'            => 'mysql:dbname=db_yl_themes_records;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);


	public static $db_theme = array(
			'driver' => 'Pdo',
			//'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',      
	        'dsn'            => 'mysql:dbname=db_yl_themes;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);


		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(


    			'Statistic\Model\ProductTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ProductTable($dbAdapter);
    				return $table;
    			},

    			'Statistic\Model\DownloadTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db_new);
    				$table = new DownloadTable($dbAdapter);
    				return $table;
    			},

    			'Statistic\Model\WidgetTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new WidgetTable($dbAdapter);
    				return $table;
    			},

    			'Statistic\Model\ApkTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ApkTable($dbAdapter);
    				return $table;
    			},

    			'Statistic\Model\TempTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_new);
    				$table = new TempTable($dbAdapter);
    				return $table;
    			},    			 

    			'Statistic\Model\ReqTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_new);
    				$table = new ReqTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\WpReqTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new WpReqTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\WpPreviewTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new WpPreviewTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\WpDownloadTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new WpDownloadTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\WpAppTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new WpAppTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\LabelTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_theme);
    				$table = new LabelTable($dbAdapter);
    				return $table;
    			},    			 



    			'Statistic\Model\TempthemeTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new TempthemeTable($dbAdapter);
    				return $table;
    			},    			 

    			'Statistic\Model\ThemeinfoTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_theme);
    				$table = new ThemeinfoTable($dbAdapter);
    				return $table;
    			}, 
					

    			'Statistic\Model\ThemeReqTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new ThemeReqTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\ThemePreviewTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new ThemePreviewTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\ThemeDownloadTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new ThemeDownloadTable($dbAdapter);
    				return $table;
    			},    			 


    			'Statistic\Model\ThemeAppTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db_wp);
    				$table = new ThemeAppTable($dbAdapter);
    				return $table;
    			},    			 



    			
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
