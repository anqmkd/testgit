<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class ThemePreviewTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_thbrowse_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }



	public function getAllTypeUtime(array $data)
	{
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();

		$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' );

		if($data['phone']!="")
		{
			$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','product like \'%'.$data['phone'].'%\'','insert_time<=\''.$data["end"].'\'' );			
		}


    	$myselect->columns(array( 'countnum'=>new Expression('COUNT(id)')  ))
    	         ->where($tempWhere);    
    	//echo $myselect->getSqlString();

    
    	$myData = $this->selectWith($myselect);
    	return $myData;
	
	}


	public function gettypeAllTypeUtime(array $data)
	{
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();

		$tempWhere = array( 'tb_yl_thbrowse_record.insert_time>=\''.$data["start"].'\'','tb_yl_thbrowse_record.insert_time<=\''.$data["end"].'\'' );

		if($data['phone']!="")
		{
			$tempWhere = array( 'tb_yl_thbrowse_record.insert_time>=\''.$data["start"].'\'','tb_yl_thbrowse_record.product like \'%'.$data['phone'].'%\'','tb_yl_thbrowse_record.insert_time<=\''.$data["end"].'\'' );			
		}


    	$myselect->columns(array( 'countnum'=>new Expression('COUNT(tb_yl_thbrowse_record.id)')  ))
			     ->join(array('a'=>'tb_yl_temp_theme'), 'tb_yl_thbrowse_record.identity = a.identity',array('cname'),'left')
    	         ->where($tempWhere)
			     ->group('a.cpid')
			     ->order('countnum DESC');    
    	//echo $myselect->getSqlString();

		//die("");

    
    	$myData = $this->selectWith($myselect);
    	return $myData;
	
	}


    public function getWeekAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'', 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }




    
}
