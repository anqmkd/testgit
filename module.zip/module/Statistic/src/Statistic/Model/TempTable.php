<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class TempTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_temp_widget';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function delData()
    {
    	$this->delete(array('1=1'));
    }


    public function saveArr(array $data)
    {
		$rowset = $this->select($data);
		$result = $rowset->current();
		
		if(!$result)
		{
			$this->insert($data);
		}
	    //return $this->getLastInsertValue();
    }



    
    
}
