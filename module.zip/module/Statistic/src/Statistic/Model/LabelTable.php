<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class LabelTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_adwp_label';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

	public function getData(array $data)
	{
    	$result = $this->select($data);
    	return $result->current();
	}

    
}
