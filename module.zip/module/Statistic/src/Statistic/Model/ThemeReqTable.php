<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class ThemeReqTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_threq_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }



	public function getAllTypeUtime(array $data)
	{
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();

		$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' );

		if($data['phone']!="")
		{
			$tempWhere = array( 'insert_time>=\''.$data["start"].'\'','product like \'%'.$data['phone'].'%\'','insert_time<=\''.$data["end"].'\'' );			
		}


    	$myselect->columns(array( 'countnum'=>new Expression('COUNT(id)')  ))
    	         ->where($tempWhere);    
    	//echo $myselect->getSqlString();

    
    	$myData = $this->selectWith($myselect);
    	return $myData;
	
	}



    public function getAppWeekType(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('wk'=>new Expression('WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )')))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('wk');

    	$myData = $this->selectWith($myselect);
    	return $myData;
    }


    public function getWeekAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'', 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }



    
}
