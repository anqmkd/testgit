<?php

namespace Statistic\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class DownloadTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_apkdl_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }

    public function getProduct(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('product'))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('product');
		
		//echo $myselect->getSqlString();
		
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

	

    public function getAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(identity)'),'identity'))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'','product=\''.$data["product"].'\'' ))
    	         ->group('identity')
			     ->order(array('countnum DESC'));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getAppCountAll(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'','product=\''.$data["product"].'\'' ));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    

    public function getAppIdentityCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(identity)'),'identity'))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'','identity=\''.$data["identity"].'\'','product=\''.$data["product"].'\'' ))
			     ->order(array('countnum DESC'));
    	         
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
	

    
    public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getProductCount()
    {
    	$rowset = $this->select();
    	return $rowset->count();
    }

    public function getProductData(array $select)
    {
    	$rowset = $this->select($select);
    	return $rowset->count();
    }
    
    public function updateProductData(array $productData)
    {
    	$this->update($productData, array('id' => $productData['id']));
    }    
    public function saveProductArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }


    public function getAppWeekType(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('wk'=>new Expression('WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )')))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('wk');

    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getAppMonthType(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('wk'=>new Expression('MONTH( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )')))
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('wk');
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
	



    public function getWeekAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(identity)'),'identity'))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'','product=\''.$data["product"].'\'' , 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('identity')
			     ->order(array('countnum DESC'));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getWeekAppCountAll(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'','product=\''.$data["product"].'\'' , 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));

		//$s = $myselect->getSqlString();
		//var_dump($s);
		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    

    public function getWeekAppIdentityCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'', 'identity=\''.$data["identity"].'\'','product=\''.$data["product"].'\'','insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
			     ->order(array('countnum DESC'));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;    	         
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getMonthAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(identity)'),'identity'))
    	         ->where(array( 'MONTH( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'','product=\''.$data["product"].'\'' ,'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('identity')
			     ->order(array('countnum DESC'));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getMonthAppCountAll(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'MONTH( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'','product=\''.$data["product"].'\'' ,'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    

    public function getMonthAppIdentityCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	         ->where(array( 'MONTH( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'', 'identity=\''.$data["identity"].'\'','product=\''.$data["product"].'\'' ,'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));

		//$s = $myselect->getSqlString();
		//var_dump($s);exit;    	         
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getUtimeAppCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(identity)'),'identity'))
    	->where(array( 'product=\''.$data["product"].'\'' ,'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	->group('identity')
    	->order(array('countnum DESC'));
    
    	//$s = $myselect->getSqlString();
    	//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getUtimeAppIdentityCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
    	->where(array(  'identity=\''.$data["identity"].'\'','product=\''.$data["product"].'\'' ,'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ));
    
    	//$s = $myselect->getSqlString();
    	//var_dump($s);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }    
    


    public function getProductWeek(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('product'))
    	         ->where(array( 'WEEK( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'' , 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('product');
		
		//echo $myselect->getSqlString();
		
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }


    public function getProductMonth(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('product'))
    	         ->where(array( 'MONTH( DATE_FORMAT( insert_time, "%Y-%m-%d" ) )=\''.$data["week"].'\'' , 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('product');
		
		//echo $myselect->getSqlString();
		
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }


    public function getProductUtime(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('product'))
    	->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	->group('product');
    
    	//echo $myselect->getSqlString();
    
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

	public function getAllTypeUtime(array $data)
	{
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('COUNT(id)')))
			     ->join(array('a'=>'tb_yl_temp_widget'), 'tb_yl_apkdl_record.identity = a.identity',array('type'),'left')
    	         ->where(array( 'insert_time>=\''.$data["start"].'\'','insert_time<=\''.$data["end"].'\'' ))
    	         ->group('a.type');
    
    	echo $myselect->getSqlString();
    
    	$myData = $this->selectWith($myselect);
    	return $myData;
	
	}




    
}
