<?php

namespace Statistic\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Statistic\Acl\Useracl;
use Statistic\Module;


use Statistic\Model\ProductTable;
use Statistic\Model\WidgetTable;
use Statistic\Model\ApkTable;
use Statistic\Model\DownloadTable;
use Statistic\Model\TempTable;
use Statistic\Model\ReqTable;

use Statistic\Model\WpReqTable;
use Statistic\Model\WpPreviewTable;
use Statistic\Model\WpDownloadTable;
use Statistic\Model\WpAppTable;
use Statistic\Model\LabelTable;

use Statistic\Model\ThemeinfoTable;
use Statistic\Model\TempthemeTable;

use Statistic\Model\ThemeReqTable;
use Statistic\Model\ThemePreviewTable;
use Statistic\Model\ThemeDownloadTable;
use Statistic\Model\ThemeAppTable;


use Zend\Db\Adapter\Adapter;
use \PDO;

class SiteController extends AbstractActionController
{
	
	public $dataxmlfile = '/home/wwwroot/app/public/tempfile/data.xml';
	public $dataxmlfileflash = '/home/wwwroot/app/public/FusionChartsFree/Data.xml';

	protected $productTable;
	protected $downloadTable;

	protected $widgetTable;
	protected $apkTable;
	protected $tempTable;
	protected $reqTable;

	protected $wpreqTable;
	protected $wppreviewTable;
	protected $wpdownloadTable;
	protected $wpappTable;
	protected $labelTable;

	protected $themeinfoTable;
	protected $tempthemeTable;

	protected $themereqTable;
	protected $themepreviewTable;
	protected $themedownloadTable;
	protected $themeappTable;

    public function indexAction()
    {
    	$uData = $this->checkLogin('index');
    	if(!$uData)
    	{
    		die('没有权限');
    	}		 
        return new ViewModel();
    }
    
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }

    public function dataAction()
    {
		$tempData = $this->getProductTable()->getProductAllDataList();

		
		$infoList = array();

		foreach($tempData as $list)
		{
			$infoList[] = (array)$list;
		}


    	$module_temp = new Module();
    	$params = $module_temp->getParams();

		

    	return new ViewModel(array('infoData'=>$infoList,'params'=>$params));
    }



    public function exportdataAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];

			$product = isset($postArr['product'])?$postArr['product']:'';

			$appidentity = isset($postArr['identity'])?$postArr['identity']:'';

			$timeType = isset($postArr['timetype'])?$postArr['timetype']:'day';

			$flagpage = 0;

			if($timeType=='daypage')
			{
				$timeType = 'day';
				$flagpage = 1;
			}


			
			$tempstart = $start;
			$tempend   = $end;




    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59';
    		$t_start = strtotime($start);
    		$t_end   = strtotime($end);
    		$datelist = array();


    		
			if($timeType=='day'){
				for($i = $t_start;$i<=$t_end;$i=$i+86400)
				{
					$datelist[] = date('Y-m-d',$i);
				}
			}else if($timeType=='week'){
				$getWeekData = $this->getDownloadTable()->getAppWeekType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
				}
			}else if($timeType=='month'){
				$getWeekData = $this->getDownloadTable()->getAppMonthType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
				}
			}else if($timeType=='utime')
			{
				$datelist[] = $tempstart.'-'.$tempend;
			}

    		$infoList = array();


    		foreach ($datelist as $val)
    		{
    			$mystart = $val.' 00:00:00';
    			$myend   = $val.' 23:59:59';

				if(!empty($product))
				{					
					$myproduct = $product;

					if($timeType=='day'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
						}
					}else if($timeType=='week'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
						}

					
					}else if($timeType=='month'){
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
						}

						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getMonthAppCount(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
						}
					
					}else if($timeType=='utime')
					{
						if($appidentity)
						{
							$getInfo = $this->getDownloadTable()->getUtimeAppIdentityCount(array('start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
						}
						
						if(empty($appidentity))
						{
							$getInfo = $this->getDownloadTable()->getUtimeAppCount(array('start'=>$start,'end'=>$end,'product'=>$myproduct));
						}						
					}


    				if($getInfo->count()==0)
    				{
    					$infoList[$val][] = array(
    								$myproduct=>array(),
    					);
    				}else
    				{
    						foreach ($getInfo as $mydata)
    						{
    							$infoList[$val][$myproduct][] = (array)$mydata;
    						}
    				}
				}

				if(empty($product))
				{

					if($timeType=='day'){
						$getData = $this->getDownloadTable()->getProduct(array('start'=>$mystart,'end'=>$myend));
					}else if($timeType=='week'){
						$getData = $this->getDownloadTable()->getProductWeek(array('week'=>$val,'start'=>$start,'end'=>$end));	
					}else if($timeType=='month'){
						$getData = $this->getDownloadTable()->getProductMonth(array('week'=>$val,'start'=>$start,'end'=>$end));	
					}else if($timeType=='utime'){
						$getData = $this->getDownloadTable()->getProductUtime(array('start'=>$start,'end'=>$end));
					}

					//$getData = $this->getDownloadTable()->getProduct(array('start'=>$mystart,'end'=>$myend));
					//die($getData->count());
					if($getData->count()==0)
					{
						$infoList[$val][] = array();
					}else
					{
						
						foreach ($getData as $templist)
						{
							$myproduct = $templist->product;




							if($timeType=='day'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
								}
							}else if($timeType=='week'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
								}

							
							}else if($timeType=='month'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
								}

								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getMonthAppCount(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
								}

							}else if($timeType=='utime'){
								if($appidentity)
								{
									$getInfo = $this->getDownloadTable()->getUtimeAppIdentityCount(array('start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
								}
							
								if(empty($appidentity))
								{
									$getInfo = $this->getDownloadTable()->getUtimeAppCount(array('start'=>$start,'end'=>$end,'product'=>$myproduct));
								}
									
							}
								


							//$getInfo = $this->getDownloadTable()->getAppCount(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));


							if($getInfo->count()==0)
							{
								$infoList[$val][] = array(
										$myproduct=>array(),
								);
							}else
							{
								foreach ($getInfo as $mydata)
								{
									$infoList[$val][$myproduct][] = (array)$mydata;
								}
							}
						}
					}


				}

    			
    		}



			
    		
    		
			$excelStr = '<?xml version="1.0"?>
						 <?mso-application progid="Excel.Sheet"?>
						 <Workbook xmlns="urn:schemas-microsoft-com:office:spreadsheet"
							xmlns:o="urn:schemas-microsoft-com:office:office"
							xmlns:x="urn:schemas-microsoft-com:office:excel"
							xmlns:ss="urn:schemas-microsoft-com:office:spreadsheet"
							xmlns:html="http://www.w3.org/TR/REC-html40">
						 <DocumentProperties xmlns="urn:schemas-microsoft-com:office:office">
							<Version>12.00</Version>
						 </DocumentProperties>
						 <OfficeDocumentSettings xmlns="urn:schemas-microsoft-com:office:office">
							<RemovePersonalInformation/>
						 </OfficeDocumentSettings>
						 <ExcelWorkbook xmlns="urn:schemas-microsoft-com:office:excel">
							<WindowHeight>11640</WindowHeight>
							<WindowWidth>19200</WindowWidth>
							<WindowTopX>0</WindowTopX>
							<WindowTopY>90</WindowTopY>
							<ProtectStructure>False</ProtectStructure>
							<ProtectWindows>False</ProtectWindows>
						 </ExcelWorkbook>
						 <Styles>
							<Style ss:ID="Default" ss:Name="Normal">
								<Alignment ss:Horizontal="Center" ss:Vertical="Center"/>
								<Borders/>
								<Font ss:FontName="宋体" x:CharSet="134" ss:Size="11" ss:Color="#000000"/>
								<Interior/>
								<NumberFormat/>
								<Protection/>
								</Style>
						 </Styles>';

    		$strHtml = '';
			$cnum = 0;
			$cnuminfo = 0;

			$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
								<td align="right" style="font-size:12px; background-color: #FFFFFF;"><a target="_blank" href="/export.php">导出数据文件</a></td>
							 </tr>
							 </table>
							 </td>
						</tr>';


			$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>';
    		foreach($infoList as $kinfo=>$vinfo)
			{
                $cnuminfo++;
				if($timeType=='week') $kinfo .= '周';
				if($timeType=='month') $kinfo .= '月';
				$stylestr = ((int)$cnuminfo==1)?'color:red;font-size:12px;cursor:pointer;':'font-size:12px;cursor:pointer;background-color: #FFFFFF;';
				$strHtml .= '<td onclick="showlistdata('.$cnuminfo.')" height="20" align="center" style="'.$stylestr.'" id="current_'.$cnuminfo.'">'.$kinfo.'</td>';
			}
			$strHtml .= '</tr></table></td></tr>';


			
			if($timeType=='day' && $flagpage==1){
				$excelStr .= '<Worksheet ss:Name="data">';


					$excelStr .= '<Table ss:ExpandedColumnCount="6" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="54" ss:DefaultRowHeight="13.5">
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
								  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>\n';

                    $excelStr .= '   <Row ss:AutoFitHeight="0">
    <Cell><Data ss:Type="String">日期</Data></Cell>
    <Cell><Data ss:Type="String">机型</Data></Cell>
    <Cell><Data ss:Type="String">应用名</Data></Cell>
    <Cell><Data ss:Type="String">下载次数</Data></Cell>
    <Cell><Data ss:Type="String">包大小</Data></Cell>
	<Cell><Data ss:Type="String">下载流量</Data></Cell>
   </Row>\n'; 



			}

    		foreach($infoList as $kinfo=>$vinfo)
			{
				$cnum++;
				if(count($vinfo)>0)
				{
					
					if($timeType=='week') $kinfo .= '周';
					if($timeType=='month') $kinfo .= '月';

					if($flagpage==0){
						$excelStr .= '<Worksheet ss:Name="'.$kinfo.'">';



					$excelStr .= '<Table ss:ExpandedColumnCount="6" x:FullColumns="1"
   x:FullRows="1" ss:DefaultColumnWidth="54" ss:DefaultRowHeight="13.5">
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>
								  <Column ss:AutoFitWidth="0" ss:Width="150"/>
                                  <Column ss:AutoFitWidth="0" ss:Width="150"/>\n';

                    $excelStr .= '   <Row ss:AutoFitHeight="0">
    <Cell><Data ss:Type="String">日期</Data></Cell>
    <Cell><Data ss:Type="String">机型</Data></Cell>
    <Cell><Data ss:Type="String">应用名</Data></Cell>
    <Cell><Data ss:Type="String">下载次数</Data></Cell>
    <Cell><Data ss:Type="String">包大小</Data></Cell>
	<Cell><Data ss:Type="String">下载流量</Data></Cell>
   </Row>\n'; 

					}



                    $displaystr = ((int)$cnum==1)?'display:block;':'display:none;';
					

                    $strHtml .= '	  <tr id="info_'.$cnum.'" style="'.$displaystr.'">
	    <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	      <tr>
	        <td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">日期</span></div></td>
	        <td width="10%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">机型</span></div></td>
	        <td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">应用名</span></div></td>
	        <td width="10%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">下载量</span></div></td>
		<td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">文件大小</span></div></td>
		<td width="20%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">下载流量</span></div></td>
	      </tr>
	      <tbody id="showdatalist_'.$cnum.'">
';


					foreach($vinfo as $kkinfo=>$vvinfo)
					{
						if(count($vvinfo)>0)
						{
							foreach($vvinfo as $kkkinfo=>$vvvinfo)
							{
								$tempIdentity = $vvvinfo['identity'];
								$widgetResult = $this->getWidgetTable()->getWidgetData(array('identity'=>$tempIdentity));



								$apkResult = $this->getApkTable()->getApkData(array('identity'=>$tempIdentity));
								
								$widget_data = $widgetResult->current();
								$apk_data = $apkResult->current();
								$strHtml .= '<tr><td height="20" class="STYLE19" >'.$kinfo.'</td><td height="20" class="STYLE19">'.$kkinfo.'</td><td height="20" class="STYLE19">'.$widget_data->label.'</td><td height="20" class="STYLE19">'.$vvvinfo['countnum'].'</td><td height="20" class="STYLE19">'.$apk_data->size.'</td><td height="20" class="STYLE19">'.$apk_data->size*$vvvinfo['countnum'].'</td></tr>';

								$excelStr .= '   <Row ss:AutoFitHeight="0">
    <Cell><Data ss:Type="String">'.$kinfo.'</Data></Cell>
	<Cell><Data ss:Type="String">'.$kkinfo.'</Data></Cell>
    <Cell><Data ss:Type="String">'.$widget_data->label.'</Data></Cell>
    <Cell><Data ss:Type="String">'.$vvvinfo['countnum'].'</Data></Cell>
    <Cell><Data ss:Type="String">'.$apk_data->size.'</Data></Cell>
	<Cell><Data ss:Type="String">'.$apk_data->size*$vvvinfo['countnum'].'</Data></Cell>
   </Row>\n';



							}
						}
					}

					


					if($flagpage==0){
						//$excelStr .= '<Worksheet ss:Name="'.$kinfo.'">';
						$excelStr .= '</Table>\n';

						$excelStr .= '</Worksheet>\n';
					}

					

			$strHtml .= '</tbody>
	    </table></td>
	  </tr>';

				}
			}


			if($timeType=='day' && $flagpage==1){

				$excelStr .= '</Table>\n';

				$excelStr .= '</Worksheet>\n';
			}


			$excelStr .= '</Workbook>';






			@file_put_contents($this->dataxmlfile,$excelStr);

    		//var_dump($infoList);exit;
    		
    		die($strHtml);
			exit;
    		//die(json_encode($postArr));
    		
    		
    	}    	
    }




	public function getapplistAction()
	{
    	$request = $this->getRequest();
    	if ($request->isGet())
    	{
    		$app = $_GET['app'];

    		$childData = $this->getWidgetTable()->getAppAll(array('type'=>$app));
    		$childList = array();
    		foreach($childData as $mychild)
    		{
    			$childList[] = array('identity'=>$mychild['identity'],'appshow'=>$mychild['label']);
    		}
    		die(json_encode($childList));    		
    	}    	
	
	}


    public function showflashAction()
    {
		$tempData = $this->getProductTable()->getProductAllDataList();
		
		$infoList = array();

		foreach($tempData as $list)
		{
			$infoList[] = (array)$list;
		}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();

    	return new ViewModel(array('infoData'=>$infoList,'params'=>$params));
    }


    public function exportflashAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];
			$productlist = isset($postArr['productlist'])?$postArr['productlist']:'';
			$appidentity = isset($postArr['identity'])?$postArr['identity']:'';
			$timeType = isset($postArr['timetype'])?$postArr['timetype']:'day';

			$productArr = explode(",",$productlist);
			if(count($productArr)==0)
			{
				die("");
			}
    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59';
    		$t_start = strtotime($start);
    		$t_end   = strtotime($end);
			if($t_start>$t_end)
			{
				die("");
			}
			$colorArr = array('0080C0','008040','808080','800080','FF8040','FFFF00','FF0080','FF2080','CC6000','DD0020','AA0150','CC0150','BB0100','DD0158','EE0150','660150','770150','550150','440150','330150','110150');

			$excelStr = "<chart caption='App download countnum per ".$timeType."' subCaption='In Thousands' numdivlines='9' lineThickness='2' showValues='0' numVDivLines='22' formatNumberScale='1' labelDisplay='ROTATE' slantLabels='1' anchorRadius='2' anchorBgAlpha='50' showAlternateVGridColor='1' anchorAlpha='100' animation='1' limitsDecimalPrecision='0' divLineDecimalPrecision='1'>\n";
			$excelStr .= "<categories>\n";

    		$datelist = array();
			if($timeType=='day'){
				for($i = $t_start;$i<=$t_end;$i=$i+86400)
				{
					$datelist[] = date('Y-m-d',$i);
                    $excelStr .= "<category label='".date('Y-m-d',$i)."' />\n";
				}
			}else if($timeType=='week'){
				$getWeekData = $this->getDownloadTable()->getAppWeekType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
					$excelStr .= "<category label='".$row->wk."' />\n";
				}
			}else if($timeType=='month'){
				$getWeekData = $this->getDownloadTable()->getAppMonthType(array('start'=>$start,'end'=>$end));
				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;
					$excelStr .= "<category label='".$row->wk."' />\n";
				}
			}

			$excelStr .= "</categories>\n";

			$infoList = array();

			$tempCountnum = 0;
			foreach($productArr as $phoneval)
			{
				$exColor = $colorArr[$tempCountnum];
				$excelStr .= "<dataset seriesName='".$phoneval."' color='".$exColor."' anchorBorderColor='".$exColor."' >\n";
				$tempCountnum++;
				foreach ($datelist as $val)
				{
					$mystart = $val.' 00:00:00';
					$myend   = $val.' 23:59:59';

					if(!empty($phoneval))
					{					
						$myproduct = $phoneval;

						if($timeType=='day'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getAppIdentityCount(array('start'=>$mystart,'end'=>$myend,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getAppCountAll(array('start'=>$mystart,'end'=>$myend,'product'=>$myproduct));
							}
						}else if($timeType=='week'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getWeekAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getWeekAppCountAll(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
							}

						
						}else if($timeType=='month'){
							if($appidentity)
							{
								$getInfo = $this->getDownloadTable()->getMonthAppIdentityCount(array('week'=>$val,'start'=>$start,'end'=>$end,'identity'=>$appidentity,'product'=>$myproduct));
							}

							if(empty($appidentity))
							{
								$getInfo = $this->getDownloadTable()->getMonthAppCountAll(array('week'=>$val,'start'=>$start,'end'=>$end,'product'=>$myproduct));
							}
						
						}

						if($getInfo->count()==0)
						{
							$excelStr .= "<set value='0' />\n";							
						}else
						{
							foreach ($getInfo as $mydata)
							{
								$excelStr .= "<set value='".$mydata->countnum."' />\n";							
							}
						}
					}
				}
				$excelStr .= "</dataset>\n";

			}
			$excelStr .= "</chart>\n";

			//var_dump($excelStr);exit;
			
			@file_put_contents($this->dataxmlfileflash,$excelStr);

    		//var_dump($infoList);exit;
    		
			exit;
    		
    		
    	}    	
    }
    




    public function apktypeAction()
    {
    	return new ViewModel();
    }
	

    public function alltypeAction()
    {

		$t_Arr  = array('工具','社交','娱乐','新闻');

		$numArr = array(47499,55633,459567,91750);

		$numreqArr = array(2996702,260551,416384,254195);



    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];    
    		$timeType = isset($postArr['timetype'])?$postArr['timetype']:'day';


    		$allType = isset($postArr['alltype'])?$postArr['alltype']:'reqtype';

			//$this->getTempTable()->delData();

			$widgetObj = $this->getWidgetTable()->getAppAll(array('1'=>1));
			foreach($widgetObj as $rowObj)
			{
				$this->getTempTable()->saveArr(array( 'identity'=>$rowObj->identity,'type'=>$rowObj->type ));	
			}

    		
    		$tempstart = $start;
    		$tempend   = $end;
    
    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59'; 
			
			if($allType=='reqtype')
			{
				$numArr = $numreqArr;

				if($timeType=='day'){
					$getInfo = $this->getReqTable()->getAllTypeUtime(array('start'=>'2013-05-27 21:45:00','end'=>$end));  
				}else if($timeType=='utime'){
					$getInfo = $this->getReqTable()->getAllTypeUtime(array('start'=>$start,'end'=>$end));    			
				}
				
			}else if($allType=='downloadtype')
			{
				if($timeType=='day'){
					$getInfo = $this->getDownloadTable()->getAllTypeUtime(array('start'=>'2013-05-27 21:45:00','end'=>$end));
				}else if($timeType=='utime'){
					$getInfo = $this->getDownloadTable()->getAllTypeUtime(array('start'=>$start,'end'=>$end));    			
				}
			}
    		
    		$strHtml = '';
    		
    		$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
								<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
							 </tr>
							 </table>
							 </td>
						 </tr>';
    		
    		$strHtml .= '<tr>
	                         <td><table id="showdatalist_1" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型</span></div></td>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
	                         </tr>';
    		foreach($getInfo as $obj)
    		{

				if( $timeType=='day' ) $obj->countnum = $obj->countnum+$numArr[$obj->type];
    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >'.$t_Arr[$obj->type].'</td>
    					     	<td height="20" class="STYLE19">'.$obj->countnum.'</td>
    					     </tr>';
    		}
    		$strHtml .= '    </table>
    				         </td>
	                     </tr>';
    
    		die($strHtml);
    		exit;
    
    
    	}
    }
	

    public function wpdataAction()
    {
    	return new ViewModel();
    }


    public function querywpdataAction()
    {

    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];    
    
    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59'; 

			$mytype = $postArr['mytype'];

			if($mytype == 'type')
			{
				$getReqtype = $this->getWpReqTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

				$getPreviewtype = $this->getWpPreviewTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
			
				$getDownloadtype = $this->getWpDownloadTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

				$strHtml = '';

				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>
									<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
								 </tr>
								 </table>
								 </td>
							</tr>';


				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>';
                $strHtml .= '    <td onclick="showlistdata(1)" height="20" align="center" style="color:red;font-size:12px;cursor:pointer;" id="current_1">请求次数</td>';
                $strHtml .= '    <td onclick="showlistdata(2)" height="20" align="center" style="font-size:12px;cursor:pointer;background-color: #FFFFFF;" id="current_2">预览次数</td>';
                $strHtml .= '    <td onclick="showlistdata(3)" height="20" align="center" style="font-size:12px;cursor:pointer;background-color: #FFFFFF;" id="current_3">下载次数</td>';

				$strHtml .= '</tr></table></td></tr>';
                $strHtml .= '	  <tr id="info_1" style="display:block;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_1"> ';
                foreach($getReqtype as $myrow){
					$labelObj = $this->getLabelTable()->getData(array('code'=>$myrow->type));
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$labelObj->chname.'</td><td height="20" class="STYLE19">'.$myrow->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';

                $strHtml .= '	  <tr id="info_2" style="display:none;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_2"> ';
                foreach($getPreviewtype as $mypreview){
					$labelPreObj = $this->getLabelTable()->getData(array('code'=>$mypreview->type));
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$labelPreObj->chname.'</td><td height="20" class="STYLE19">'.$mypreview->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';

                $strHtml .= '	  <tr id="info_3" style="display:none;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_3"> ';
                foreach($getDownloadtype as $mydownload){
					$labelDwObj = $this->getLabelTable()->getData(array('code'=>$mydownload->type));
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$labelDwObj->chname.'</td><td height="20" class="STYLE19">'.$mydownload->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';


                die($strHtml);
    		    exit;



			
			}

			

			$getReq = $this->getWpReqTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

			$getPreview = $this->getWpPreviewTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
			
			$getDownload = $this->getWpDownloadTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

			$getApp = $this->getWpAppTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
    		
    		$strHtml = '';
    		
    		$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
								<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
							 </tr>
							 </table>
							 </td>
						 </tr>';
    		
    		$strHtml .= '<tr>
	                         <td><table id="showdatalist_1" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型</span></div></td>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
	                         </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >请求次数</td>
    					     	<td height="20" class="STYLE19">'.$getReq->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >预览次数</td>
    					     	<td height="20" class="STYLE19">'.$getPreview->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >下载次数</td>
    					     	<td height="20" class="STYLE19">'.$getDownload->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >应用次数</td>
    					     	<td height="20" class="STYLE19">'.$getApp->current()->countnum.'</td>
    					     </tr>';


    		$strHtml .= '    </table>
    				         </td>
	                     </tr>';
    
    		die($strHtml);
    		exit;
    
    
    	}
    }



    public function themedataAction()
    {
    	return new ViewModel();
    }


    public function querythemedataAction()
    {
		$themeData = $this->getThemeinfoTable()->getData();
		foreach($themeData as $objData)
		{
			$this->getTempthemeTable()->saveArr( array('identity'=>$objData->identity,'cpid'=>$objData->cpid,'cname'=>$objData->name )  );
		}

    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$start = $postArr['start'];
    		$end   = $postArr['end'];    
    
    		$start .= ' 00:00:00';
    		$end   .= ' 23:59:59'; 

			$mytime = $postArr['mytime'];
			if($mytime=='weektime')
			{
				$datelist = array();				
				$getWeekData = $this->getThemeReqTable()->getAppWeekType(array('start'=>$start,'end'=>$end));


				$strHtml = '';
				$cnum = 0;
				$cnuminfo = 0;

				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>
									<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
								 </tr>
								 </table>
								 </td>
							</tr>';


				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>';


				foreach($getWeekData as $row)
				{
					$datelist[] = $row->wk;

					$cnuminfo++;
					$kinfo = $row->wk.'周';

					$stylestr = ((int)$cnuminfo==1)?'color:red;font-size:12px;cursor:pointer;':'font-size:12px;cursor:pointer;background-color: #FFFFFF;';
					$strHtml .= '<td onclick="showlistdata('.$cnuminfo.')" height="20" align="center" style="'.$stylestr.'" id="current_'.$cnuminfo.'">'.$kinfo.'</td>';

				}

				$strHtml .= '</tr></table></td></tr>';

				foreach ($datelist as $val)
				{
					$cnum++;


                    $displaystr = ((int)$cnum==1)?'display:block;':'display:none;';
					

                    $strHtml .= '	  <tr id="info_'.$cnum.'" style="'.$displaystr.'">
								<td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								  <tr>
									<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型</span></div></td>
									<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
								  </tr>
								  <tbody id="showdatalist_'.$cnum.'">
						';

					$getInfoReq = $this->getThemeReqTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end));
					$getInfoPre = $this->getThemePreviewTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end));
					$getInfoDw = $this->getThemeDownloadTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end));
					$getInfoApp = $this->getThemeAppTable()->getWeekAppCount(array('week'=>$val,'start'=>$start,'end'=>$end));

					$strHtml .= '<tr>
									<td height="20" class="STYLE19" >主题请求次数</td>
									<td height="20" class="STYLE19">'.$getInfoReq->current()->countnum.'</td>
								 </tr>';

					$strHtml .= '<tr>
									<td height="20" class="STYLE19" >主题预览次数</td>
									<td height="20" class="STYLE19">'.$getInfoPre->current()->countnum.'</td>
								 </tr>';

					$strHtml .= '<tr>
									<td height="20" class="STYLE19" >主题下载次数</td>
									<td height="20" class="STYLE19">'.$getInfoDw->current()->countnum.'</td>
								 </tr>';

					$strHtml .= '<tr>
									<td height="20" class="STYLE19" >应用次数</td>
									<td height="20" class="STYLE19">'.$getInfoApp->current()->countnum.'</td>
								 </tr>';

					$strHtml .= '    </table>
									 </td>
								 </tr>';

				}

				die($strHtml);
    		    exit;


			}


			$mytype = $postArr['mytype'];

			if($mytype == 'type')
			{
				$getReqtype = $this->getThemePreviewTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

				$getPreviewtype = $this->getThemeDownloadTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
			
				$getDownloadtype = $this->getThemeAppTable()->gettypeAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

				$strHtml = '';

				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>
									<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
								 </tr>
								 </table>
								 </td>
							</tr>';


				$strHtml .= '<tr>
								 <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
								 <tr>';
                $strHtml .= '    <td onclick="showlistdata(1)" height="20" align="center" style="color:red;font-size:12px;cursor:pointer;" id="current_1">预览次数</td>';
                $strHtml .= '    <td onclick="showlistdata(2)" height="20" align="center" style="font-size:12px;cursor:pointer;background-color: #FFFFFF;" id="current_2">下载次数</td>';
                $strHtml .= '    <td onclick="showlistdata(3)" height="20" align="center" style="font-size:12px;cursor:pointer;background-color: #FFFFFF;" id="current_3">应用次数</td>';

				$strHtml .= '</tr></table></td></tr>';
                $strHtml .= '	  <tr id="info_1" style="display:block;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_1"> ';
                foreach($getReqtype as $myrow){
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$myrow->cname.'</td><td height="20" class="STYLE19">'.$myrow->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';

                $strHtml .= '	  <tr id="info_2" style="display:none;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_2"> ';
                foreach($getPreviewtype as $mypreview){
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$mypreview->cname.'</td><td height="20" class="STYLE19">'.$mypreview->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';

                $strHtml .= '	  <tr id="info_3" style="display:none;">
									<td><table id="tab" width="400" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
									  <tr>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型名称</span></div></td>
										<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
									  </tr>
									  <tbody id="showdatalist_3"> ';
                foreach($getDownloadtype as $mydownload){
					$strHtml .= '<tr><td height="20" class="STYLE19" >'.$mydownload->cname.'</td><td height="20" class="STYLE19">'.$mydownload->countnum.'</td></tr>';
				}


			    $strHtml .= '</tbody>
							</table></td>
						  </tr>';


                die($strHtml);
    		    exit;



			
			}















			$getReq = $this->getThemeReqTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

			$getPreview = $this->getThemePreviewTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
			
			$getDownload = $this->getThemeDownloadTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  

			$getApp = $this->getThemeAppTable()->getAllTypeUtime( array('start'=>$start,'phone'=>$postArr['myphone'],'end'=>$end) );  
    		
    		$strHtml = '';
    		
    		$strHtml .= '<tr>
	                         <td><table id="tab" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
								<td align="right" style="font-size:12px; background-color: #FFFFFF;">查询结果</td>
							 </tr>
							 </table>
							 </td>
						 </tr>';
    		
    		$strHtml .= '<tr>
	                         <td><table id="showdatalist_1" width="800" border="0" cellpadding="0" cellspacing="1" bgcolor="#a8c7ce">
	                         <tr>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">类型</span></div></td>
	                         	<td width="50%" height="20" bgcolor="d3eaef" class="STYLE6"><div align="center"><span class="STYLE10">次数</span></div></td>
	                         </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >主题请求次数</td>
    					     	<td height="20" class="STYLE19">'.$getReq->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >主题预览次数</td>
    					     	<td height="20" class="STYLE19">'.$getPreview->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >主题下载次数</td>
    					     	<td height="20" class="STYLE19">'.$getDownload->current()->countnum.'</td>
    					     </tr>';

    			$strHtml .= '<tr>
    					     	<td height="20" class="STYLE19" >应用次数</td>
    					     	<td height="20" class="STYLE19">'.$getApp->current()->countnum.'</td>
    					     </tr>';


    		$strHtml .= '    </table>
    				         </td>
	                     </tr>';
    
    		die($strHtml);
    		exit;
    
    
    	}
    }














    
    public function checkLogin($action)
    {
    	$myAuth = new Auth();
    	//$myAuth->logout();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr = json_decode($objUser->roleStr,true);
    		$roleData = isset($roleArr['statistic'])?$roleArr['statistic']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }


    public function getProductTable()
    {
    	if (!$this->productTable) {
    		$sm = $this->getServiceLocator();
    		$this->productTable = $sm->get('Statistic\Model\ProductTable');
    	}
    	return $this->productTable;
    } 
	

	public function getDownloadTable()
	{
		if (!$this->downloadTable) {
			$sm = $this->getServiceLocator();
			$this->downloadTable = $sm->get('Statistic\Model\DownloadTable');
		}
		return $this->downloadTable;
	}

    public function getWidgetTable()
    {
    	if (!$this->widgetTable) {
    		$sm = $this->getServiceLocator();
    		$this->widgetTable = $sm->get('Statistic\Model\WidgetTable');
    	}
    	return $this->widgetTable;
    }
    
    public function getApkTable()
    {
    	if (!$this->apkTable) {
    		$sm = $this->getServiceLocator();
    		$this->apkTable = $sm->get('Statistic\Model\ApkTable');
    	}
    	return $this->apkTable;
    }

    public function getTempTable()
    {
    	if (!$this->tempTable) {
    		$sm = $this->getServiceLocator();
    		$this->tempTable = $sm->get('Statistic\Model\TempTable');
    	}
    	return $this->tempTable;
    }

    public function getReqTable()
    {
    	if (!$this->reqTable) {
    		$sm = $this->getServiceLocator();
    		$this->reqTable = $sm->get('Statistic\Model\ReqTable');
    	}
    	return $this->reqTable;
    }


    public function getWpReqTable()
    {
    	if (!$this->wpreqTable) {
    		$sm = $this->getServiceLocator();
    		$this->wpreqTable = $sm->get('Statistic\Model\WpReqTable');
    	}
    	return $this->wpreqTable;
    }

    public function getWpPreviewTable()
    {
    	if (!$this->wppreviewTable) {
    		$sm = $this->getServiceLocator();
    		$this->wppreviewTable = $sm->get('Statistic\Model\WpPreviewTable');
    	}
    	return $this->wppreviewTable;
    }

    public function getWpDownloadTable()
    {
    	if (!$this->wpdownloadTable) {
    		$sm = $this->getServiceLocator();
    		$this->wpdownloadTable = $sm->get('Statistic\Model\WpDownloadTable');
    	}
    	return $this->wpdownloadTable;
    }

    public function getWpAppTable()
    {
    	if (!$this->wpappTable) {
    		$sm = $this->getServiceLocator();
    		$this->wpappTable = $sm->get('Statistic\Model\WpAppTable');
    	}
    	return $this->wpappTable;
    }

    public function getLabelTable()
    {
    	if (!$this->labelTable) {
    		$sm = $this->getServiceLocator();
    		$this->labelTable = $sm->get('Statistic\Model\LabelTable');
    	}
    	return $this->labelTable;
    }

    public function getThemeinfoTable()
    {
    	if (!$this->themeinfoTable) {
    		$sm = $this->getServiceLocator();
    		$this->themeinfoTable = $sm->get('Statistic\Model\ThemeinfoTable');
    	}
    	return $this->themeinfoTable;
    }

    public function getTempthemeTable()
    {
    	if (!$this->tempthemeTable) {
    		$sm = $this->getServiceLocator();
    		$this->tempthemeTable = $sm->get('Statistic\Model\TempthemeTable');
    	}
    	return $this->tempthemeTable;
    }



    public function getThemeReqTable()
    {
    	if (!$this->themereqTable) {
    		$sm = $this->getServiceLocator();
    		$this->themereqTable = $sm->get('Statistic\Model\ThemeReqTable');
    	}
    	return $this->themereqTable;
    }

    public function getThemePreviewTable()
    {
    	if (!$this->themepreviewTable) {
    		$sm = $this->getServiceLocator();
    		$this->themepreviewTable = $sm->get('Statistic\Model\ThemePreviewTable');
    	}
    	return $this->themepreviewTable;
    }

    public function getThemeDownloadTable()
    {
    	if (!$this->themedownloadTable) {
    		$sm = $this->getServiceLocator();
    		$this->themedownloadTable = $sm->get('Statistic\Model\ThemeDownloadTable');
    	}
    	return $this->themedownloadTable;
    }

    public function getThemeAppTable()
    {
    	if (!$this->themeappTable) {
    		$sm = $this->getServiceLocator();
    		$this->themeappTable = $sm->get('Statistic\Model\ThemeAppTable');
    	}
    	return $this->themeappTable;
    }


















    
}
