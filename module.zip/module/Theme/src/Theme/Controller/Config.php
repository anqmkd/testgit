<?php
namespace Theme\Controller;
//路径配置，此文件不起任何作用，和siteController.php中配置一样，为了方便查看代码

class Config
{
//    public $filepath    = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public/tempfile/themeAdd.txt';
//    public $folderStr   = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public/themes/widget/';
//    public $repalceStr  = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public';
//    public $tempFolder  = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public';
//    public $showUrl     = 'http://test.coolyun.com';    
//    public $themefolder = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public/temp/';
//    public $configFile  = 'description.xml';
//    public $resFolder   = 'res';
//    public $preFolder   = 'preview';
//    public $temp_theme  = '/themes/';
//    public $large_theme = '/large/';
//    public $templen     = 6;
//    public $themefontfolder = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public/tempfont/';
//    public $scenefontfolder = 'D:/Program Files/Apache Software Foundation/Apache2.2/htdocs/app2/public/tempscene/';    
//    public $infourl       = 'http://cpush.coolyun.com/taskpush.php?id=%s&type=%s&title=%s&content=%s&action=info';
//    public $albumsurl     = 'http://61.141.236.11/service/albums.php?type=8';
//    public $pushurl       = 'http://cpush.coolyun.com/taskpush.php?action=push&task=';
//    public $taskdetail    = 'http://cpush.coolyun.com/taskpush.php?taskid=%s&action=detail';	
//    public $getmsg        = 'http://cpush.coolyun.com/taskpush.php?action=getmsg';
//    public $taskmobile    = 'http://cpush.coolyun.com/taskpush.php';
//    public $infourl       = 'http://192.168.30.54:8088/taskpush.php?id=%s&type=%s&title=%s&content=%s&action=info';
//    public $pushurl       = 'http://192.168.30.57/push/index?task=';
//    public $pushurl       = 'http://192.168.30.54:8088/taskpush.php?action=push&task=';
//    public $pushurl       = 'http://192.168.30.57/push/index';
//    public $taskdetail    = 'http://192.168.30.54:8088/taskpush.php?taskid=%s&action=detail';	
//    public $getmsg        = 'http://192.168.30.54:8088/taskpush.php?action=getmsg';
//    public $taskmobile    = 'http://192.168.30.54:8088/taskpush.php';


     const FILE_PATH    = 'E:/Users/zhouyuhong/workspace/app/public/tempfile/themeAdd.txt';
     const FOLDER_STR   = 'E:/Users/zhouyuhong/workspace/app/public/themes/widget/';
     //第二个ckfinder, 上传到正式目录     
     const REPALCE_STR  = 'E:/Users/zhouyuhong/workspace/app_resource';
     const TEMP_FOLDER   = 'E:/Users/zhouyuhong/workspace/app_resource';
     const WALLPAPER_FOLDER   = 'E:/Users/zhouyuhong/workspace/app_resource';
     const REPALCE_STR_WP  = 'E:/Users/zhouyuhong/workspace/app_resource';
     
     const PAY_QUERY_PATH= 'E:/Users/zhouyuhong/workspace/pay_query/public';
     //第一个ckfinder, 主题、锁屏等中转目录
     const TEMP_REPALCE_STR = 'E:/Users/zhouyuhong/workspace/app/public';
     const TEMP_UPLOAD_FOLDER = 'E:/Users/zhouyuhong/workspace/app/public';
     
     const SHOW_URL     = 'http://test_download.coolyun.com:80';      //下载地址
     const SHOW_URL2    = 'http://coolshowdl.coolyun.com';
     const BASE_URL     = 'http://pay_querycj.coolyun.com';
     const BASE_PATH    = 'E:/Users/zhouyuhong/workspace/app/public';
     const OLD_URL      = 'http://coolshowdl.coolyun.com';
     const NEW_URL      = 'http://d.res.zhuti.qiku.com';
     //主题上传temp目录
     const THEME_FOLDER = 'E:/Users/zhouyuhong/workspace/app/public/temptheme/';
     const RES_TEMP_FOLDER = 'E:/Users/zhouyuhong/workspace/app/public';
     const CONFIG_FILE  = 'description.xml';
     const RES_FOLDER   = 'res';
     const PRE_FOLDER   = 'preview';
     const TEMP_THEME   = '/themes/';
     const LARGE_THEME  = '/large/';
     const TEMPLEN      = 6;
     const THEME_FONT_FOLDER = 'E:/Users/zhouyuhong/workspace/app/public/tempfont/';
     const SCENE_FONT_FOLDER = 'E:/Users/zhouyuhong/workspace/app/public/tempscene/';
     const WALLPAPER_URL     = 'http://download.coolyun.com';
     const FONT_FOLDER       = 'fonts';
     const SCENE_FOLDER     = 'scene';
     
     const INFO_URL       = 'http://113.142.37.244/service/rsc.php?id=%s&type=%s&title=%s&content=%s';
     const ALBUMS_URL     = 'http://61.141.236.11/service/albums.php?type=8';
     const PUSH_URL       = 'http://cpush.yl.com/push/index';
     
     const TASK_DETAIL   	= 'http://cpush.yl.com/api/tdetails';
     const TASK_VALID     	= 'http://cpush.yl.com/api/tvalid';
     const TASK_MOBILE    	= 'http://cpush.yl.com/api/usearch';
     const TASK_PRODUCT   	= 'http://cpush.yl.com/api/psearch';
     const TASK_MVALID      = 'http://cpush.yl.com/api/tmvalid';
     const TASK_PVALID    	= 'http://cpush.yl.com/api/tpvalid';
     const TASK_AGAIN    	= 'http://cpush.yl.com/api/mresend';
     const TASK_PAGAIN    	= 'http://cpush.yl.com/api/presend';
     const TASK_TP_VERSION  = 'http://cpush.yl.com/api/tpversion';
     const TP_CHANGEVER     = 'http://cpush.yl.com/api/tpchangever';
     const PRODUCT_LIST     = 'http://cpush.yl.com/api/productlist';
     const TPADD            = 'http://cpush.yl.com/api/tpadd';
     const MDETAILS         = 'http://cpush.yl.com/api/mdetails';
     const TMADD            = 'http://cpush.yl.com/api/tmadd';
     const TASK_REPORT      = 'http://cpush.yl.com/api/treport';
     
     
    
     const TEMP_FONT   = '/fonts/ch/';	
	 const TEMP_RING   = '/rings';
	 const TEMP_ALARM  = '/alarms';
	 const TEMP_SCENE  = '/lockscreen/temp/';
	 const TEMP_LIVEWP = '/livewp/temp/';
	 const TEMP_BANNER = '/banner/';
	 const TEMP_ALBUMS = '/albums/';
	 const TEMP_WALLPAPER= '/wallpaper/banner/';   
	 const TEMP_WPUPLOAD = '/wpupload/';
	 //预览图导出路径
	 const PREVIEW_EXPORT = 'D://preview_export/';
	 const PREVIEW_IMPORT = '/min_preview/';
     const TEMP_SCRIPT    ='/superscript/';
	 const THEME_AD       = '/themesss/ad/';
	 const TEMP_NAME = 'upload';
    //主题更改预览图
   // const  THEME_PREVIEW ='/edit_preview/';
	 static $MAILS =           array(                                                                         //邮件配置信息
                        'smtp' =>       array(
                                        'name'              => 'smtp.yeah.net',
                                'host'              => '123.58.177.132',
                                'port'              => 25,
                                'connection_class'  => 'login',
                                'connection_config' => array(
                                                'username' => 'coolshowcj',
                                                'password' => '1q2w3e4r5t',
                                                'ssl'      => 'tls',
                                                ),
                                                ),
                        'sender' => 'coolshow',
                        'from'   => 'coolshowcj@yeah.net',
                        );	
     
}