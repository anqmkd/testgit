<?php
namespace Theme\Acl;

use Zend\Permissions\Acl\Acl;
use Zend\Permissions\Acl\Role\GenericRole as Role;
use Zend\Permissions\Acl\Resource\GenericResource as Resource;
class Useracl
{
	public $useracl;
	
	public function __construct()
	{
		$this->useracl = new Acl();			
	}
	
	public function init()
	{
		//权限列表：  (view:查看，最基本权限)  (edit:编辑权限，增删改)  (push:推送权限)  (base：左侧栏目权限，仅用于细分权限管理)
		//(pay:收入明细相关的权限)  (management:主题师管理等其他相关权限)
		$this->useracl->addRole(new Role('visitor'))
					  ->addRole(new Role('wallpaper'))
					  ->addRole(new Role('editor'))
					  ->addRole(new Role('pusher'))
			          ->addRole(new Role('manager'));
		$this->useracl->addResource(new Resource('theme'));
		$this->useracl->allow('visitor','theme',array('base', 'view', 'wallpaper'));
		$this->useracl->allow('wallpaper','theme',array('base', 'wallpaper', 'edit'));
		$this->useracl->allow('editor','theme',array('base', 'view', 'edit', 'pay'));
		$this->useracl->allow('pusher','theme',array('base', 'view', 'push', 'pay'));
		$this->useracl->allow('manager','theme',array('base', 'wallpaper', 'view', 'edit', 'push', 'pay', 'management'));
		
	}
	
	public function checkAction($role,$action)
	{
		$this->init();
		return $this->useracl->isAllowed($role,'theme',$action);
	}
}
