<?php

namespace Activate;

use Activate\Model\AppTable;
use Activate\Model\RecordTable;
use Activate\Model\ChildappTable;
use Activate\Model\IdentityTable;
use Activate\Model\ResolutionTable;
use Activate\Model\PhoneTable;
use Activate\Model\ApppicTable;
use Activate\Model\MusictypeTable;
use Activate\Model\MusicpicTable;
use Activate\Model\MusicrecordTable;
use Activate\Model\MusicclassTable;
use Activate\Model\PhonepicTable;
use Activate\Model\CityTable;
use Activate\Model\MediaTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
	public static $db = array(
			'driver' => 'Pdo',
			'dsn'            => 'mysql:dbname=db_yl_activate_page;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);
		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			'Activate\Model\AppTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new AppTable($dbAdapter);
    				return $table;
    			},
    			
    			'Activate\Model\IdentityTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new IdentityTable($dbAdapter);
    				return $table;
    			},
    			 
    			'Activate\Model\ChildappTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ChildappTable($dbAdapter);
    				return $table;
    			},
    			
    			'Activate\Model\ResolutionTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ResolutionTable($dbAdapter);
    				return $table;
    			}, 

    			'Activate\Model\PhoneTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new PhoneTable($dbAdapter);
    				return $table;
    			},
    			

    			'Activate\Model\RecordTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new RecordTable($dbAdapter);
    				return $table;
    			},


    			'Activate\Model\ApppicTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ApppicTable($dbAdapter);
    				return $table;
    			},


                        'Activate\Model\MusictypeTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MusictypeTable($dbAdapter);
                                return $table;
                        },


                        'Activate\Model\MusicpicTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MusicpicTable($dbAdapter);
                                return $table;
                        },


                        'Activate\Model\MusicrecordTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MusicrecordTable($dbAdapter);
                                return $table;
                        },


                        'Activate\Model\MusicclassTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MusicclassTable($dbAdapter);
                                return $table;
                        },

                        'Activate\Model\PhonepicTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new PhonepicTable($dbAdapter);
                                return $table;
                        },

                        'Activate\Model\CityTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new CityTable($dbAdapter);
                                return $table;
                        },
						
						'Activate\Model\MediaTable' =>  function($sm) {
                                //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                                $dbAdapter = new Adapter(self::$db);
                                $table = new MediaTable($dbAdapter);
                                return $table;
                        },
				
				
    			
    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
