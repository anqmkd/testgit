<?php

namespace Activate\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class MusicpicTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_music_pic';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData( $page=1,$pagesize=10,array $data )
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->where($data)
                 ->order(array('picname ASC'))
                 ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
//    	$myData = $this->select($data);
    	return $myData;
    }
    
    public function getCountnum(array $data)
    {
    	$result = $this->select($data);
    	return $result->count();
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateAppData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);    	
    	return $result->current();
    }    
    
    public function getAllData()
    {
    	$result = $this->select();
    	return $result;
    }    
    
}
