<?php

namespace Activate\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class CityTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_city';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);    	
    	return $result->current();
    }    
    
    public function getCountry()
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();        
        $myselect->columns(array('country'))->group('country');
        $mydata = $this->selectWith($myselect);
        return $mydata;
    }

    public function getProvince(array $data)
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
        $myselect->columns(array('province'))->where(array('country'=>$data['country']))->group('province');
        $mydata = $this->selectWith($myselect);
        return $mydata;

    }   

    public function getCity(array $data)
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
        $myselect->columns(array('city','newcityid'))->where(array('province'=>$data['province'],'town'=>"",'country'=>$data['country']))->group('city');
        $mydata = $this->selectWith($myselect);
        return $mydata;

    }

    public function getTown(array $data)
    {
        $mysql = $this->getSql();
        $myselect = $mysql->select();
        $myselect->columns(array('town','newcityid'))->where(array('province'=>$data['province'],"town!=''",'city'=>$data['city'],'country'=>$data['country']));
        $mydata = $this->selectWith($myselect);
        return $mydata;

    }





    
}
