<?php

namespace Activate\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class IdentityTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_control_id';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateAppData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);    	
    	return $result->current();
    }    
    
}
