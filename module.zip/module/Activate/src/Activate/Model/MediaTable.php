<?php

namespace Activate\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class MediaTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_media';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
	public function getData( $page=1,$pagesize=10 )
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->order(array('insert_time DESC'))
    			 ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
//    	$myData = $this->select($data);
    	return $myData;
    }
    
    public function setfirst($id,$isfirst){
    	$sql = "UPDATE tb_yl_media SET isfirst = 0";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	if($isfirst != 1){
    		$sql = "UPDATE tb_yl_media SET isfirst = 1 WHERE id = ".$id;
    		$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	}  	
    }
    
    public function getIson()
    {
    	$sql = "SELECT ison FROM tb_yl_media_control";
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    	foreach ($rowset as $row){
    		return (int)$row['ison'];
    	}
    }
    
    public function setison($val){
    	$sql = "UPDATE tb_yl_media_control SET ison = ".$val;
    	$rowset = $this->adapter->query($sql,Adapter::QUERY_MODE_EXECUTE);
    }
    
 	public function getCountnum()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    public function updateAppData(array $spreadData)
    {
    	$this->update($spreadData, array('id' => $spreadData['id']));
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);    	
    	return $result->current();
    }    
    
    public function getAllData()
    {
    	$result = $this->select();
    	return $result;
    }    
    
    public function getAllDataList(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->join(array('a'=>'tb_yl_subject'), 'tb_yl_pic.subjectidentity = a.identity',array('start','end'))
    	         ->where( 'tb_yl_pic.business IN ('.$data['business'].') AND tb_yl_pic.width='.$data['width'].' AND tb_yl_pic.height='.$data['height'].' AND tb_yl_pic.is_using=1 AND tb_yl_pic.subjectidentity IN ('.$data['subjectidentity'].')' );
    	$myData = $this->selectWith($myselect);
//    	$myData = $this->select($data);
    	return $myData;
    }
	
	
    public function getAllApp(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
		
    	//$starttime = time()+86400; 
		$starttime = time() + 604800;
			
    	$start = date('Y-m-d H:i:s',$starttime);

		$ttend = date('Y-m-d H:i:s');
		
    	$myselect->columns(array('childappidentity'))
		         ->where( 'tb_yl_app_pic.appidentity=\''.$data['appidentity'].'\' AND tb_yl_app_pic.business IN ('.$data['business'].') AND tb_yl_app_pic.start <= \''.$start.'\' AND tb_yl_app_pic.end >= \''.$ttend.'\' AND tb_yl_app_pic.height='.$data['height'].' AND tb_yl_app_pic.width='.$data['width'].' AND tb_yl_app_pic.is_using=1 ' )
		         ->group('childappidentity');
		//$ws = $myselect->getSqlString();
		//var_dump($ws);exit;
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getAllAppPic(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
		
    	//$starttime = time()+86400;
		$orderArr = array('tb_yl_app_pic.insert_time DESC');
		if($data['childappidentity']=='ACPA_CAPP_000020')
		{
			$orderArr = array('tb_yl_app_pic.url ASC');
		}
		
    	$starttime = time() + 604800;
    	$start = date('Y-m-d H:i:s',$starttime);
		
		$ttend = date('Y-m-d H:i:s');
		if(isset($data['mydate']) && $data['mydate']!="")
		{
			$mydate = $data['mydate'];
			if(strlen($mydate)==6)
			{
				$y = substr($mydate,0,4).'';
				$m = substr($mydate,4,2);
				$likedate = $y.$m;
			}
			
			if(strlen($mydate)==8)
			{
				$y = substr($mydate,0,4).'';
				$m = substr($mydate,4,2).'';
				$d = substr($mydate,6,2);
				$likedate = $y.$m.$d;
			}
			

			$myselect->where( 'SUBSTRING_INDEX(tb_yl_app_pic.url,\'/\',-2) LIKE \'%'.$likedate.'%\' AND tb_yl_app_pic.childappidentity=\''.$data['childappidentity'].'\' AND tb_yl_app_pic.business IN ('.$data['business'].')  AND tb_yl_app_pic.height='.$data['height'].' AND tb_yl_app_pic.width='.$data['width'].' AND tb_yl_app_pic.is_using=1 ' )
		         ->order($orderArr);		
			
		}else{  

                        if($data['cityid']!='')
                        {

                        $myselect->where( 'tb_yl_app_pic.childappidentity=\''.$data['childappidentity'].'\' AND tb_yl_app_pic.business IN ('.$data['business'].') AND tb_yl_app_pic.start <= \''.$start.'\' AND tb_yl_app_pic.end >= \''.$ttend.'\' AND tb_yl_app_pic.height='.$data['height'].' AND tb_yl_app_pic.width='.$data['width'].'  AND tb_yl_app_pic.cityid='.$data['cityid'].'   AND tb_yl_app_pic.is_using=1 ' )
                         ->order($orderArr);

                        }else if($data['newcityid']!=''){

                        $myselect->where( 'tb_yl_app_pic.childappidentity=\''.$data['childappidentity'].'\' AND tb_yl_app_pic.business IN ('.$data['business'].') AND tb_yl_app_pic.start <= \''.$start.'\' AND tb_yl_app_pic.end >= \''.$ttend.'\' AND tb_yl_app_pic.height='.$data['height'].' AND tb_yl_app_pic.width='.$data['width'].'  AND tb_yl_app_pic.newcityid='.$data['newcityid'].'   AND tb_yl_app_pic.is_using=1 ' )
                         ->order($orderArr);

                        }else{


			$myselect->where( 'tb_yl_app_pic.childappidentity=\''.$data['childappidentity'].'\' AND tb_yl_app_pic.business IN ('.$data['business'].') AND tb_yl_app_pic.start <= \''.$start.'\' AND tb_yl_app_pic.end >= \''.$ttend.'\' AND tb_yl_app_pic.height='.$data['height'].' AND tb_yl_app_pic.width='.$data['width'].' AND tb_yl_app_pic.is_using=1 ' )
		         ->order($orderArr);


                        }		
		}	

		//$ws = $myselect->getSqlString();
		//var_dump($ws);exit;

    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
}
