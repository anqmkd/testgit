<?php

namespace Activate\Model;

use Zend\Console\Prompt\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class RecordTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_activate_record';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function saveApp(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }    
    
    
}
