<?php

namespace Activate\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Activate\Module;
use Activate\Acl\Useracl;
use Activate\Model\AppTable;
use Activate\Model\IdentityTable;
use Activate\Model\ChildappTable;
use Activate\Model\ResolutionTable;
use Activate\Model\PhoneTable;
use Activate\Model\ApppicTable;
use Activate\Model\MusictypeTable;
use Activate\Model\MusicpicTable;
use Activate\Model\MusicrecordTable;
use Activate\Model\MusicclassTable;
use Activate\Model\PhonepicTable;
use Activate\Model\CityTable;

class SiteController extends AbstractActionController
{
	protected $appTable;
	protected $identityTable;
	protected $childappTable;
	protected $resolutionTable;
	protected $phoneTable;
	protected $subjectTable;
	protected $picTable;
	protected $linkTable;
        protected $apppicTable;
	protected $musictypeTable;
        protected $musicpicTable;
        protected $musicrecordTable;
        protected $musicclassTable;
        protected $phonepicTable;
		protected $mediaTable;

        protected $cityTable;

	protected $pre = 'ACPA_';
	public $filepath = '/home/wwwroot/app/public/tempfile/subjectAdd.txt';
	public $healthfilepath = '/home/wwwroot/rsync/NetWidget/app/Health/Update/APK/healthInfo.txt';
	public $temphealthfile = '/home/wwwroot/app/public/tempfile/appAdd.txt';

	public $tempfolder = '/home/wwwroot/rsync/';
        public $jarPath    = '/home/wwwroot/app/public/tools/ColorExtra.jar';
	public $temppath = 'Activate/';

	public $showurl = 'http://download.coolyun.com/';

	public function getproductAction()
	{	
			$tempData = $this->getPhoneTable()->getPhoneData(array());
			$tempArr  = array();
			foreach($tempData as $row){
				$tarr = array('product'=>$row['phonename'],'ratio'=>$row['width'].'x'.$row['height']);
				$tempArr[] = $tarr;
			}
			$json_rsp = array(
					'result'   => true,
					'products' => $tempArr,
			);
			die(json_encode($json_rsp));
	}
	
    public function myprovinceAction()
    {
        $request = $this->getRequest();
        if ($request->isGet())
        {
              //$postarr = $request->getPost();
              if(empty($_GET['country']))
              {
                   die('empty');
              }
              $tempData = $this->getCityTable()->getProvince(array('country'=>$_GET['country']));

              $infoData = array();

              foreach($tempData as $mydata)
              {
                   $infoData[] = (array)$mydata;
              }
              die(json_encode($infoData));
        }
    }


    public function mycityAction()
    {
        $request = $this->getRequest();
        if ($request->isGet())
        {
              
              //$postarr = $request->getPost();
              if(empty($_GET['country'])||empty($_GET['province']))
              {
                   die('empty');
              }
              $tempData = $this->getCityTable()->getCity(array('province'=>$_GET['province'],'country'=>$_GET['country']));

              $infoData = array();

              foreach($tempData as $mydata)
              {
                   $infoData[] = (array)$mydata;
              }
              die(json_encode($infoData));
        }
    }


    public function mytownAction()
    {
        $request = $this->getRequest();
        if ($request->isGet())
        {

              //$postarr = $request->getPost();
              if(empty($_GET['country'])||empty($_GET['province']))
              {
                   die('empty');
              }
              $tempData = $this->getCityTable()->getTown(array('province'=>$_GET['province'],'city'=>$_GET['city'],'country'=>$_GET['country']));

              $infoData = array();

              foreach($tempData as $mydata)
              {
                   $infoData[] = (array)$mydata;
              }
              die(json_encode($infoData));
        }
    }



    public function indexAction()
    {
    	$uData = $this->checkLogin('index');
    	
    	if(!$uData)
    	{
    		die('没有权限');
    	}
        return new ViewModel();
    }
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
		
    	$appData = $this->getAppTable()->getAppAllData(array('is_using'=>1));
    	$appList = array();
    	foreach($appData as $mylist)
    	{
    		$appList[] = (array)$mylist;
    	}
		
    	return new ViewModel(array('applist'=>$appList,'uData'=>$uData));
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }

    public function rightAction()
    {
    	$pageSize = 10;
    	$uData = $this->checkLogin('right');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getAppTable()->getCountnum();
    	 
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getAppTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    	 
    	//var_dump($listData);exit;
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function childappAction()
    {
    	$pageSize = 10;
    	$uData = $this->checkLogin('childapp');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$identity = isset($_GET['id'])?$_GET['id']:"";
    	if(!$identity)
    	{
    		die('参数非法');
    	}
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$myresult = $this->getAppTable()->getAppData(array('identity'=>$identity));
    	$appshow = $myresult->appshow;
    	$countApp = $this->getChildappTable()->getCountnum(array('identity'=>$identity));
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getChildappTable()->getData($page,$pageSize,array('identity'=>$identity));
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    	
    	//var_dump($listData);exit;
    	return new ViewModel(array('uData'=>$uData,'id'=>$identity,'appshow'=>$appshow,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    	 
    }
    
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    
    public function addchildappAction()
    {
    	$uData = $this->checkLogin('addchildapp');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['appname']) || empty($postArr['appshow']) || empty($postArr['identity']))
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$appname = $postArr['appname'];
    		$appshow = $postArr['appshow'];
    		$identity = $postArr['identity'];
    
    		if($id)
    		{
    			$this->getChildappTable()->updateAppData(array('id'=>$id,'appshow'=>$appshow,'appname'=>$appname));
    			die('success');
    		}
    
    		$result = $this->getChildappTable()->getAppData(array('appname'=>$appname));
    		if($result && $result->id)
    		{
    			die('nameexist');
    		}
    		$newresult = $this->getChildappTable()->getAppData(array('appshow'=>$appshow));
    		if($newresult && $newresult->id)
    		{
    			die('showexist');
    		}
    
    		$childidentity = $this->getId(array('type'=>'CAPP'));
    		$this->getChildappTable()->saveApp(array('appname'=>$appname,'appshow'=>$appshow,'identity'=>$identity,'childidentity'=>$childidentity,'insert_user'=>$uData->username));
    		die('success');
    	}
    	 
    	 
    	//return new ViewModel();
    }
    
    

    public function addappAction()
    {
    	$uData = $this->checkLogin('addapp');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['appname']) || empty($postArr['appshow']) )
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$appname = $postArr['appname'];
    		$appshow = $postArr['appshow'];
    		
    		if($id)
    		{
    			$this->getAppTable()->updateAppData(array('id'=>$id,'appshow'=>$appshow,'appname'=>$appname));
    			die('success');
    		}

    		$result = $this->getAppTable()->getAppData(array('appname'=>$appname));
    		if($result && $result->id)
    		{
    			die('nameexist');
    		}
    		$newresult = $this->getAppTable()->getAppData(array('appshow'=>$appshow));
    		if($newresult && $newresult->id)
    		{
    			die('showexist');
    		}
    		
    		$identity = $this->getId(array('type'=>'APP'));
    		$this->getAppTable()->saveApp(array('appname'=>$appname,'appshow'=>$appshow,'identity'=>$identity,'insert_user'=>$uData->username));
    		die('success');    		
    	}
    		 
    	
    	//return new ViewModel();
    }



    public function musictypeAction()
    {
        $pageSize = 10;
        $uData = $this->checkLogin('resolution');
        if(!$uData)
        {
                die('没有权限');
        }

        $page = isset($_GET['page'])?(int)$_GET['page']:0;
        $countApp = $this->getMusictypeTable()->getCountnum();

        $totalPage=ceil($countApp/$pageSize);
        if($page>$totalPage) $page = $totalPage;
        if($page==0) $page = 1;
        $tempData = $this->getMusictypeTable()->getData($page,$pageSize);
        $infoData = array();
        foreach($tempData as $mydata)
        {
                $infoData[] = (array)$mydata;
        }

        
        return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }



    public function musicclassAction()
    {
        $pageSize = 30;
        $uData = $this->checkLogin('resolution');
        if(!$uData)
        {
                die('没有权限');
        }

        $page = isset($_GET['page'])?(int)$_GET['page']:0;
        $countApp = $this->getMusicclassTable()->getCountnum();

        $totalPage=ceil($countApp/$pageSize);
        if($page>$totalPage) $page = $totalPage;
        if($page==0) $page = 1;
        $tempData = $this->getMusicclassTable()->getData($page,$pageSize);
        $infoData = array();
        foreach($tempData as $mydata)
        {

                $tempArr = (array)$mydata;
                $mytype = $mydata->type;
                $typedata = $this->getMusictypeTable()->getAppData(array('pictype'=>$mytype));
                $tempArr['typename']=$typedata->name;
                $infoData[] = $tempArr;

                //$infoData[] = (array)$mydata;
        }


        $allmusictype = $this->getMusictypeTable()->getAllData();
        $alltype = array();
        foreach($allmusictype as $mytypeobject)
        {
               $alltype[] = (array)$mytypeobject;
        }


        return new ViewModel(array('uData'=>$uData,'alltype'=>$alltype,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }


    public function addmusicclassAction()
    {
        $uData = $this->checkLogin('addresolution');
        if(!$uData)
        {
                die('nopower');
        }
        $request = $this->getRequest();
        if ($request->isPost())
        {
                $postArr = $request->getPost();
                if( empty($postArr['myname'])  )
                {
                        die('empty');
                }
                $id = $postArr['id'];
                $appname = $postArr['mytype'];
                $appshow = $postArr['myname'];
                $enname  = $postArr['mymark'];


                if($id)
                {
                        $this->getMusicclassTable()->updateAppData(array('id'=>$id,'type'=>$appname,'mark'=>$enname,'name'=>$appshow));
                        die('success');
                }

                $result = $this->getMusicclassTable()->getAppData(array('type'=>$appname,'name'=>$appshow));
                if($result && $result->id)
                {
                        die('exist');
                }
                
                $identity = $this->getId(array('type'=>'MUSIC'));

                $this->getMusicclassTable()->saveApp(array('type'=>$appname,'mark'=>$enname,'identity'=>$identity,'name'=>$appshow,'insert_user'=>$uData->username));
                die('success');
        }

        //return new ViewModel();
    }
	
	public function videourlAction()
    {
    	$pageSize = 10;
    	$uData = $this->checkLogin('resolution');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    
    	$identity = $_GET['id'];
    
    	$countApp = $this->getMediaListTable()->getCountnum( array('identity'=>$identity ));
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getMediaListTable()->getData($page,$pageSize,array('identity'=>$identity));
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$tempArr = (array)$mydata;
    
    		$infoData[] = $tempArr;
    
    	}
   
    	return new ViewModel(array('page'=>$page,'showurl'=>$this->showurl,'identity'=>$identity,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function videobannerAction()
    {
    	$pageSize = 30;
    	$uData = $this->checkLogin('resolution');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getMediaTable()->getCountnum();
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getMediaTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{

    		$infoData[] = (array)$mydata;  
    		//$infoData[] = (array)$mydata;
    	}
    	$ison  =  $this->getMediaTable()->getIson();

    	return new ViewModel(array('page'=>$page,
    								'showurl'=>$this->showurl,
    								'replace'=>$this->tempfolder,
    								'ison'=> $ison,
    								'countApp'=>$countApp,  								
    								'totalPage'=>$totalPage,
    								'infoData'=>$infoData));
    }   
    
    public function addvideobannerAction()
    {
    	$uData = $this->checkLogin('addresolution');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['lsubjectpic'])  )
    		{
    			die('empty');
    		}
    		$id   = isset($postArr['id'])?$postArr['id']:'';
    		$name = $postArr['myname'];
    		$pic  = $postArr['lsubjectpic'];
    		$vurl = $postArr['vurl'];
    		$identity = sprintf("%u",crc32(file_get_contents($this->tempfolder.$pic)));
    		
    		if($id)
    		{
    			$this->getMediaTable()->updateAppData(array('id'=>$id,
    														'identity'=>$identity,
    														'note'=>$name,
    														'picurl'=>$pic,
    														'videourl'=>$vurl,
    														'update_user'=>$uData->username,
    														'update_time'=>date('Y-m-d H:i:s')));
    			die('success');
    		}
    		
    		
    		
    		$result = $this->getMediaTable()->getAppData(array('identity'=>$identity));
    		if($result && $result->id)
    		{
    			die('exist');
    		}
  		
    		$this->getMediaTable()->saveApp(array('identity'=>$identity,
    												'note'=>$name,
    												'picurl'=>$pic,
    												'videourl'=>$vurl,
    												'valid'=>1,
    												'isfirst'=>0,
    												'insert_user'=>$uData->username,
    												'insert_time'=>date('Y-m-d H:i:s'),));
    

    		die('success');
    	}
    }
    
    public function setfirstAction(){
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id      = $postArr['id'];
    		$isfirst = $postArr['isfirst'];
    		$this->getMediaTable()->setfirst($id,$isfirst);
    		die('success');
    	}
    }
    
	public function isonAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$val      = $postArr['val'];
    		$this->getMediaTable()->setison($val);
    		die('success');
    	}
    } 
    
    public function changevalidAction(){
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id      = $postArr['id'];
    		$val     = $postArr['v'];
    		$this->getMediaTable()->updateAppData(array('id'=>$id,'valid'=>$val,));
    		die('success');
    	}
    }
    
    public function setvideopathAction()
    {
    	$request = $this->getRequest();
    	if($request->isPost()){
    		$daytime = date('Ymd');
    		$atime   = date('YmdHis');
    		$mycontent = 'Musicpic/video/'.$daytime.'/'.$atime;
 
    		@file_put_contents($this->filepath, $mycontent);
    		die("");
    	}
    }


    public function musicpicAction()
    {
        $pageSize = 10;
        $uData = $this->checkLogin('resolution');
        if(!$uData)
        {
                die('没有权限');
        }

        $page = isset($_GET['page'])?(int)$_GET['page']:0;

        $classid = $_GET['id'];
        $name    = $_GET['name'];        

        $countApp = $this->getMusicpicTable()->getCountnum( array('classidentity'=>$classid ));

        $totalPage=ceil($countApp/$pageSize);
        if($page>$totalPage) $page = $totalPage;
        if($page==0) $page = 1;
        $tempData = $this->getMusicpicTable()->getData($page,$pageSize,array('classidentity'=>$classid));
        $infoData = array();
        foreach($tempData as $mydata)
        {
                $tempArr = (array)$mydata;
                
                $infoData[] = $tempArr;

        }

        $allmusictype = $this->getMusictypeTable()->getAllData();
        $alltype = array();
        foreach($allmusictype as $mytypeobject)
        {
               $alltype[] = (array)$mytypeobject;
        }
     
        return new ViewModel(array('uData'=>$uData,'page'=>$page,'showurl'=>$this->showurl,
        							'id'=>$classid,'countApp'=>$countApp,'totalPage'=>$totalPage,
        							'alltype'=>$alltype,'infoData'=>$infoData,'name'=>$name));
    }



    public function addmusicpicAction()
    {
        $uData = $this->checkLogin('addresolution');
        if(!$uData)
        {
                die('nopower');
        }
        $request = $this->getRequest();
        if ($request->isPost())
        {
                $postArr = $request->getPost();
                if( empty($postArr['myfb']) )
                {
                        die('empty');
                }
                $id = $postArr['picid'];

                $classid = $postArr['identity'];
                $mname   = $postArr['mname'];
                
                $myfb    = $postArr['myfb'];

                $myfbarr = explode('-',$myfb);
                
                


                if($id!="")
                {

                        $pic      = $postArr['subjectpic'];

                        $pic      = urldecode($pic);
                        $tempStrFile  = iconv('utf-8', 'gbk',  $this->tempfolder.$pic);

                        $picArr       = explode("/", $pic);
                        $picfile      = end($picArr);
                        $extarr       = explode(".", $picfile);
                        $ext          = end($extarr);

                        $tempStr      = str_replace($picfile, date('YmdHis').'.'.$ext, $pic);
                        copy($this->tempfolder.$pic, $this->tempfolder.$tempStr);

                        $filesize     = filesize( $this->tempfolder.$tempStr );
                        $ring_md5     = md5_file( $this->tempfolder.$tempStr );
                         //在这里添加计算色值
                 		$color = '-1';
                   		$strCmd    = "java -jar ".$this->jarPath." ".'"'.$this->tempfolder.$tempStr.'"';
                   		$r = exec($strCmd,$out,$status);
	                   	if($status == 0){
	                   		$color = $out[0];	
	                    }




                        $this->getMusicpicTable()->updateAppData(array('id'=>$id,
                              'picname'=>$extarr[0],'name'=>$mname,
                              'picurl'=>$pic,'width'=>$myfbarr[0],'height'=>$myfbarr[1],
                              'size'=>$filesize,'md5'=>$ring_md5,'extractcolor'=>$color,
                              'insert_user'=>$uData->username,'classidentity'=>$classid,
                        ));
                        die('success');
                }
        


                $musicfolder = file_get_contents($this->filepath);
                $musichandle = opendir($this->tempfolder.$musicfolder);
                $filenum = 0;
                while(false!==($myfile=readdir($musichandle))){
                
                  if($myfile!='Thumbs.db' && $myfile!='.' && $myfile!='..' && $myfile!=''){
                   //$myfile   = iconv('gbk', 'utf-8', $myfile); 
                   $pic      = $musicfolder.'/'.$myfile;
         
                   $tempStrFile  = iconv('utf-8', 'gbk',  $this->tempfolder.$pic);
                
                   $picArr       = explode("/", $pic);
                   $picfile      = end($picArr);
                   $extarr       = explode(".", $picfile);
                   $ext          = end($extarr);  
                
                   $tempStr      = str_replace($picfile, rand().date('YmdHis').'.'.$ext, $pic);
                   copy($this->tempfolder.$pic, $this->tempfolder.$tempStr);
                
                   $filesize     = filesize( $this->tempfolder.$tempStr );
                   $ring_md5     = md5_file( $this->tempfolder.$tempStr );
                    //在这里添加计算色值
                 		$color = '-1';
                   		$strCmd    = "java -jar ".$this->jarPath." ".'"'.$this->tempfolder.$tempStr.'"';
                   		$r = exec($strCmd,$out,$status);
	                   	if($status == 0){
	                   		$color = $out[0];	
	                    }

                   //echo $this->tempfolder.$tempStr;

                

                   $result = $this->getMusicpicTable()->getAppData(array('picname'=>$extarr[0],
                                                                      'md5'=>$ring_md5,'width'=>$myfbarr[0],'height'=>$myfbarr[1],                                                                               
                                                                    ));
                   if($result && $result->id)
                   {
                       
                   }
                   else{
                      $this->getMusicpicTable()->saveApp(array(
                              'picname'=>$extarr[0],
                              'picurl'=>$pic,'width'=>$myfbarr[0],'height'=>$myfbarr[1],
                              'size'=>$filesize,'md5'=>$ring_md5,'extractcolor'=>$color,
                              'insert_user'=>$uData->username, 'classidentity'=>$classid,'name'=>$mname,                
                      ));
                   }
                  }

                }
                die('success');
        }

        //return new ViewModel();
    }


    public function addmusictypeAction()
    {
        $uData = $this->checkLogin('addresolution');
        if(!$uData)
        {
                die('nopower');
        }
        $request = $this->getRequest();
        if ($request->isPost())
        {
                $postArr = $request->getPost();
                if( empty($postArr['myname']) || empty($postArr['myenname']) )
                {
                        die('empty');
                }
                $id = $postArr['id'];
                $appname = $postArr['mytype'];
                $appshow = $postArr['myname'];
                $enname  = $postArr['myenname'];
              
    
                if($id)
                {
                        $this->getMusictypeTable()->updateAppData(array('id'=>$id,'pictype'=>$appname,'enname'=>$enname,'name'=>$appshow));
                        die('success');
                }
    
                $result = $this->getMusictypeTable()->getAppData(array('pictype'=>$appname,'enname'=>$enname,'name'=>$appshow));
                if($result && $result->id)
                {
                        die('exist');
                }
    
                
                $this->getMusictypeTable()->saveApp(array('pictype'=>$appname,'enname'=>$enname,'name'=>$appshow,'insert_user'=>$uData->username));
                die('success');
        }

        //return new ViewModel();
    }


    
    public function resolutionAction()
    {
    	$pageSize = 10;
    	$uData = $this->checkLogin('resolution');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getResolutionTable()->getCountnum();
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getResolutionTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}
    
    	//var_dump($listData);exit;
    	return new ViewModel(array('uData'=>$uData,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function addresolutionAction()
    {
    	$uData = $this->checkLogin('addresolution');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['mywidth']) || empty($postArr['myheight']) )
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$appname = $postArr['mywidth'];
    		$appshow = $postArr['myheight'];
    
    		if($id)
    		{
    			$this->getResolutionTable()->updateAppData(array('id'=>$id,'width'=>$appname,'height'=>$appshow));
    			die('success');
    		}
    
    		$result = $this->getResolutionTable()->getAppData(array('width'=>$appname,'height'=>$appshow));
    		if($result && $result->id)
    		{
    			die('exist');
    		}
    
    		$identity = $this->getId(array('type'=>'RESO'));
    		$this->getResolutionTable()->saveApp(array('width'=>$appname,'height'=>$appshow,'identity'=>$identity,'insert_user'=>$uData->username));
    		die('success');
    	}
    	 
    	 
    	//return new ViewModel();
    }
    
    public function phoneAction()
    {
    	$pageSize = 30;
    	$uData = $this->checkLogin('phone');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	 
    	$page = isset($_GET['page'])?(int)$_GET['page']:0;
    	$countApp = $this->getPhoneTable()->getCountnum();
    
    	$totalPage=ceil($countApp/$pageSize);
    	if($page>$totalPage) $page = $totalPage;
    	if($page==0) $page = 1;
    	$tempData = $this->getPhoneTable()->getData($page,$pageSize);
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = (array)$mydata;
    	}

        $resolutionarr = array();
        $resolutiondata = $this->getResolutionTable()->getAllData();
        foreach($resolutiondata as $mytemparr)
        {
                $resolutionarr[] = (array)$mytemparr;
        }

    	
    	$module_temp = new Module();
    	$params = $module_temp->getParams();
    	//var_dump($listData);exit;
    	return new ViewModel(array('params'=>$params,'uData'=>$uData,'resolutionlist'=>$resolutionarr,'page'=>$page,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
    }
    
    public function addphoneAction()
    {
    	$uData = $this->checkLogin('addphone');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['mywidth']) || empty($postArr['business']))
    		{
    			die('empty');
    		}
    		$id = $postArr['id'];
    		$appname = $postArr['mywidth'];
    		$business = $postArr['business'];
    		//$appshow = $postArr['myheight'];

                $myfb = explode('-',$postArr['resolution']);
    
    		if($id)
    		{
    			$this->getPhoneTable()->updateAppData(array('id'=>$id,'width'=>$myfb[0],'height'=>$myfb[1],'business'=>$business,'phonename'=>$appname));
    			die('success');
    		}
    
    		$result = $this->getPhoneTable()->getAppData(array('phonename'=>$appname));
    		if($result && $result->id)
    		{
    			die('exist');
    		}
    
    		$identity = $this->getId(array('type'=>'PHON'));
    		$this->getPhoneTable()->saveApp(array('phonename'=>$appname,'width'=>$myfb[0],'height'=>$myfb[1],'business'=>$business,'identity'=>$identity,'insert_user'=>$uData->username));
    		die('success');
    	}
    
    
    	//return new ViewModel();
    }


    
    
    public function changeuseAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$id = isset($postArr['id'])?$postArr['id']:"";
    		$type = isset($postArr['t'])?$postArr['t']:"";
    		$myval = isset($postArr['v'])?$postArr['v']:"n";
    		if(empty($id) || empty($type) || $myval=='n')
    		{
    			die('error');
    		}
    		if($type=="use")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'valid'=>$myval,
    			);
    			$this->getSubjectTable()->updateAppData($widgetArr);
    			die('success');
    		}
    		if($type=="pic")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'is_using'=>$myval,
    			);
    			$this->getPicTable()->updateAppData($widgetArr);
    			die('success');
    		}
    		
    		if($type=="link")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'is_using'=>$myval,
    			);
    			$this->getLinkTable()->updateAppData($widgetArr);
    			die('success');
    		}
			
    		if($type=="apppic")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'is_using'=>$myval,
    			);
    			$this->getApppicTable()->updateAppData($widgetArr);
    			die('success');
    		}
    		
    		if($type=="usestatus")
    		{
    			$widgetArr = array(
    					'id'=>$id,
    					'is_status'=>$myval,
    			);
    			$this->getChildappTable()->updateAppData($widgetArr);
    			die('success');
    		}
    		
    	}else
    	{
    		die("");
    	}	 
    }
    
    
    
    
    
    public function getchildAction()
    {
    	$request = $this->getRequest();
    	if ($request->isGet())
    	{
    		$app = $_GET['app'];
    		$childData = $this->getChildappTable()->getAppAllData(array('identity'=>$app,'is_using'=>1));
    		$childList = array();
    		foreach($childData as $mychild)
    		{
    			$childList[] = array('childidentity'=>$mychild['childidentity'],'appshow'=>$mychild['appshow']);
    		}
    		die(json_encode($childList));    		
    	}    	
    }

    
    
    public function setfolderAction()
    {
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$app = $postArr['app'];
    		$childapp = $postArr['childapp'];
    		//$addtime = date('YmdH');
                $addtime = date('YmdHis');
    		//$mycontent = $app.'/'.$childapp.'/'.$addtime;
    		
    		$mycontent = 'Activate/'.$app.'/'.$childapp.'/'.$addtime;
    		    		    		
    		@file_put_contents($this->filepath, $mycontent);
    		die($mycontent);
    	}
    }    
    

    public function changemusicfolderAction()
    {
        $request = $this->getRequest();
        if ($request->isPost())
        {
                $postArr = $request->getPost();
                $classid = $postArr['myclassid'];

                $tdata   = $this->getMusicclassTable()->getAppData(array('identity'=>$classid));

                $app     = $tdata->type;

                $childapp = $postArr['myfb'];
                $typedata = $this->getMusictypeTable()->getAppData(array('pictype'=>$app));

                $enname = $typedata->enname;

                $myfb = str_replace("-","x",$childapp);
                
                //$addtime = date('YmdH');
                $addtime = date('YmdHis');
                //$mycontent = $app.'/'.$childapp.'/'.$addtime;

                $mycontent = 'Musicpic/'.$enname.'/'.$myfb.'/'.$addtime;

                @file_put_contents($this->filepath, $mycontent);
                die($mycontent);
        }
    }


    
    
    public function checkLogin($action)
    {
    	$myAuth = new Auth();
    	//$myAuth->logout();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr = json_decode($objUser->roleStr,true);
    
    		$roleData = isset($roleArr['activate'])?$roleArr['activate']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }
    
	public function previewAction()
	{
		$appData = $this->getAppTable()->getAppAllData(array('is_using'=>1));
		$appList = array();
		foreach($appData as $mylist)
		{
			$appList[] = (array)$mylist;
		}
		
		$phoneData = $this->getPhoneTable()->getAllData();
		$phoneList = array();
		foreach($phoneData as $myphone)
		{
			$phoneList[] = (array)$myphone;
		}
		 
		$resolutionData = $this->getResolutionTable()->getAllData();
		$resolutionList = array();
		foreach($resolutionData as $myresolution)
		{
			$resolutionList[] = (array)$myresolution;
		}
		
		return new ViewModel( array('applist'=>$appList,'phonelist'=>$phoneList,'resolutionlist'=>$resolutionList) );
	}
	
	public function addapppicAction()
	{
		$uData = $this->checkLogin('addapppic');
		if(!$uData)
		{
			die('没有权限');
		}
		$appData = $this->getAppTable()->getAppAllData(array('is_using'=>1));
		$appList = array();
		foreach($appData as $mylist)
		{
			$appList[] = (array)$mylist;
		}
		$module_temp = new Module();
		$params = $module_temp->getParams();

                $tempdata = $this->getCityTable()->getCountry();
                $countryinfo = array();
		foreach($tempdata as $mydata)
                {
                        $countryinfo[] = (array)$mydata;
                }
		return new ViewModel(array('countryinfo'=>$countryinfo,'applist'=>$appList,'params'=>$params));
	}

	
	public function insertapppicAction()
	{
		$uData = $this->checkLogin('insertapppic');
		if(!$uData)
		{
			die('nopower');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postArr = $request->getPost();
			if( empty($postArr['app']) || empty($postArr['childapp']) || empty($postArr['business']) || empty($postArr['datestart']) || empty($postArr['dateend']))
			{
				die('empty');
			}
			$app = $postArr['app'];
			$childapp = $postArr['childapp'];
			$business = $postArr['business'];
			$start = $postArr['datestart'];
			$end = $postArr['dateend'];
			$linkurl = $postArr['linkurl'];
			$selectpro = $postArr['proselect'];
			if($selectpro == 1)$product=$postArr['product'];
			else $product = '';
			$folder = file_get_contents($this->filepath);

			//var_dump($folder);exit;
                        //var_dump($this->tempfolder.$this->temppath.$folder);
			$handle = opendir($this->tempfolder.$folder);
			
			if(strlen($start)==16)
			{
				$start = $start.':00';
			}
			if(strlen($end)==16)
			{
				$end = $end.':59';
			}
                        
                        $newcityid = '';
                        if($postArr['cityid']!='' && $postArr['townid']!=''){
                        	$newcityid = $postArr['townid'];
                        }
                        else if($postArr['cityid']!='' && $postArr['townid']==''){
                                $newcityid = $postArr['cityid'];
                        }

                        //die($newcityid);

                        //var_dump($handle);
                        //$i=0;
			while(false!==($myfile=readdir($handle)))
			{
                                //$i = $i+1;
                                //var_dump($myfile.'sdsd');
                                

                                
				if($myfile!='Thumbs.db' && $myfile!='.' && $myfile!='..' && $myfile!='')
				{
                                        
					$filemd5 = md5_file($this->tempfolder.$folder.'/'.$myfile);
					$filesize = filesize($this->tempfolder.$folder.'/'.$myfile);
					$temp = explode(".", $myfile);
					$filename = $temp[0];
					$tempArr = explode("_", $filename);
					$fbl = $tempArr[1];
					$whArr = explode("x", $fbl);
					$width = $whArr[0];
					$height = $whArr[1];
                                        
                                        
                                       

					$identity = $this->getId(array('type'=>'APIC'));
					
					$tempMyData = $this->getApppicTable()->getAppData(array(
						'appidentity'=>$app,
						'childappidentity'=>$childapp,
						'business'=>$business,
                                                'start'=>$start,
                                                'end'=>$end,
 
						'url'=>$folder.'/'.$myfile,
					) );
					if(!$tempMyData)
					{
						$this->getApppicTable()->saveApp(array(
							'identity'=>$identity,
							'appidentity'=>$app,
							'childappidentity'=>$childapp,
							'business'=>$business,
							'width'=>$width,
							'height'=>$height,
							'md5'=>$filemd5,
							'size'=>$filesize,
							'url'=>$folder.'/'.$myfile,
							'start'=>$start,
							'end'=>$end,
							'linkurl'=>$linkurl,
							'is_using'=>1,
                                                        'cityid'=>'',
                                                        
							'insert_user'=>$uData->username,
							'selectproduct'=>$product,
						));
					}
					
				}

                                
			}
			die('success');
		}
	}
	
    public function resolutionlistAction()
    {
    	$tempData = $this->getResolutionTable()->getAllData();
    	$infoData = array();
    	foreach($tempData as $mydata)
    	{
    		$infoData[] = $mydata->width.'x'.$mydata->height;
    	}
    	die(implode(',',$infoData));    	 
    }
	
	public function apppiclistAction()
	{
		$pageSize = 15;
		$uData = $this->checkLogin('apppiclist');
		if(!$uData)
		{
			die('没有权限');
		}		
		$page = isset($_GET['page'])?(int)$_GET['page']:0;
		$appid = isset($_GET['id'])?$_GET['id']:'';		
		if(empty($appid))
		{
			die('参数错误');
		}
		$appdata = $this->getAppTable()->getAppData(array('identity'=>$appid));
		$appname = $appdata->appshow;
		$countApp = $this->getApppicTable()->getCountnum(array('appidentity'=>$appid));		
		$totalPage=ceil($countApp/$pageSize);
		if($page>$totalPage) $page = $totalPage;
		if($page==0) $page = 1;
		$tempData = $this->getApppicTable()->getData($page,$pageSize,array('tb_yl_app_pic.appidentity'=>$appid));
		$infoData = array();
                
                $myflag = 0;
                if($appid=="ACPA_APP_000008"){ $myflag = 1;  }

		foreach($tempData as $mydata)
		{
                        $wwwdata = (array)$mydata;
                        if($myflag)
                        {
                            $cityid = $wwwdata['cityid'];

                            $cityinfo = $this->getCityTable()->getAppData(array('cityid'=>$cityid));

                            if($cityinfo)
                            {
                                   $wwwdata['province'] = $cityinfo->province;
                                   $wwwdata['city'] = $cityinfo->city;
                            }
                        }

                        //$wwwdata = (array)$mydata;  
			$infoData[] = $wwwdata;
		}
    	$module_temp = new Module();
    	$params = $module_temp->getParams(); 

		return new ViewModel(array('page'=>$page,'id'=>$appid,'appname'=>$appname,'params'=>$params,'showurl'=>$this->showurl,'countApp'=>$countApp,'totalPage'=>$totalPage,'infoData'=>$infoData));
	
	}

	
	public function changefolderAction()
	{
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		$pic = $postArr['pic'];
			$tempArr = explode('/',$pic);
    		//$mycontent = $app.'/'.$childapp.'/'.$addtime; 
			
    		//$mycontent = $tempArr[1].'/'.$tempArr[2].'/'.$tempArr[3];
			
			$mycontent = $tempArr[0].'/'.$tempArr[1].'/'.$tempArr[2].'/'.$tempArr[3];
					
    		@file_put_contents($this->filepath, $mycontent);
    		die($mycontent);
    	}	
	}



	public function editapppicAction()
	{
    	$uData = $this->checkLogin('editapppic');
    	if(!$uData)
    	{
    		die('nopower');
    	}
    	$request = $this->getRequest();
    	if ($request->isPost())
    	{
    		$postArr = $request->getPost();
    		if( empty($postArr['subjectpic']) || empty($postArr['start']) || empty($postArr['end']) || empty($postArr['business']) )
    		{
    			die('empty');
    		}
			$pic = $postArr['subjectpic'];
			$linkurl = $postArr['linkurl'];
			$picid = $postArr['picid'];
			$start = $postArr['start'];
			$end = $postArr['end'];
			$selectpro = $postArr['proselect'];
			if($selectpro == 1)$product=$postArr['product'];
			else $product = '';
			
			if(strlen($start)==16)
			{
				$start = $start.':00';
			}
			if(strlen($end)==16)
			{
				$end = $end.':59';
			}
			
			$dataArr = array(
				'linkurl'=>$linkurl,
				'url'=>$pic,
				'id'=>$picid,
				'start'=>$start,
				'end'=>$end,
                                'order'=>$postArr['myorder'],
				'business'=>$postArr['business'],
				'selectproduct'=>$product,
			);
    		$this->getApppicTable()->updateAppData($dataArr);
    		die('success');			
		}	
	
	}


	public function healthAction()
	{
		$content = file_get_contents($this->healthfilepath);
		$content = json_decode($content,true);
		//var_dump($content);exit;
		return new ViewModel(array('info'=>$content));

	}

	public function healthfolderAction()
	{
		$mycontent = 'Health/Update/APK';
		@file_put_contents($this->temphealthfile,$mycontent);
		die("");
	}

	public function addhealthAction()
	{
    	$request = $this->getRequest();
    	if ($request->isPost())
		{
			$postArr = $request->getPost();
    		if( empty($postArr['version']) || empty($postArr['apkversion']) || empty($postArr['apkurl']) )
    		{
    			die('empty');
    		}
			//$s = explode("\n",$postArr['description']);
			//var_dump($s);exit;
			//die(json_encode($postArr));
			$dataArr = array(
				'config_time'=>time().'000',
				'min_android_ver'=>$postArr['version'],
				'apk_ver'=>$postArr['apkversion'],

				'apk_size'=>filesize( str_replace('http://download.coolyun.com','/home/wwwroot/rsync',$postArr['apkurl']) ),
				'apk_md5' =>md5_file( str_replace('http://download.coolyun.com','/home/wwwroot/rsync',$postArr['apkurl']) ),
				'apk_url' =>$postArr['apkurl'],
				'apk_disc'=>explode("\n",$postArr['description']),

			);
			@file_put_contents( $this->healthfilepath,json_encode($dataArr) );
			die("success~".date('Y-m-d H:i:s',$dataArr['config_time']/1000)."~".$dataArr['apk_size']."~".$dataArr['apk_md5']);
			die(json_encode($dataArr));
		}		
	}


    
    public function getId(array $data)
    {
    	$type = $data['type'];
    	$result = $this->getIdentityTable()->getAppData(array('type'=>$type));
    	if($result && $result->id)
    	{
    		$id = (int)$result->identity+1;
    		$this->getIdentityTable()->updateAppData(array('identity'=>$id,'id'=>$result->id));
    	}else
    	{
    		$data = array(  'identity' =>1,'type'=>$type  );
    		$this->getIdentityTable()->saveApp($data);    		
    		$id=1;
    	}
    	$num = sprintf('%06d', $id);

        if($type=='APIC'){ $num = sprintf('%08d', $id);   }        

    	$newidentity = $this->pre.$type.'_'.$num;
    	return $newidentity;    	    	
    }
    
    
    
    public function getAppTable()
    {
    	if (!$this->appTable) {
    		$sm = $this->getServiceLocator();
    		$this->appTable = $sm->get('Activate\Model\AppTable');
    	}
    	return $this->appTable;
    }    
    public function getIdentityTable()
    {
    	if (!$this->identityTable) {
    		$sm = $this->getServiceLocator();
    		$this->identityTable = $sm->get('Activate\Model\IdentityTable');
    	}
    	return $this->identityTable;
    }
    
    public function getChildappTable()
    {
    	if (!$this->childappTable) {
    		$sm = $this->getServiceLocator();
    		$this->childappTable = $sm->get('Activate\Model\ChildappTable');
    	}
    	return $this->childappTable;
    }
    
    public function getResolutionTable()
    {
    	if (!$this->resolutionTable) {
    		$sm = $this->getServiceLocator();
    		$this->resolutionTable = $sm->get('Activate\Model\ResolutionTable');
    	}
    	return $this->resolutionTable;
    }    

    public function getPhoneTable()
    {
    	if (!$this->phoneTable) {
    		$sm = $this->getServiceLocator();
    		$this->phoneTable = $sm->get('Activate\Model\PhoneTable');
    	}
    	return $this->phoneTable;
    }    


	
    public function getApppicTable()
    {
    	if (!$this->apppicTable) {
    		$sm = $this->getServiceLocator();
    		$this->apppicTable = $sm->get('Activate\Model\ApppicTable');
    	}
    	return $this->apppicTable;
    }

    public function getMusictypeTable()
    {
        if (!$this->musictypeTable) {
                $sm = $this->getServiceLocator();
                $this->musictypeTable = $sm->get('Activate\Model\MusictypeTable');
        }
        return $this->musictypeTable;
    }


    public function getMusicpicTable()
    {
        if (!$this->musicpicTable) {
                $sm = $this->getServiceLocator();
                $this->musicpicTable = $sm->get('Activate\Model\MusicpicTable');
        }
        return $this->musicpicTable;
    }

    public function getMusicrecordTable()
    {
        if (!$this->musicrecordTable) {
                $sm = $this->getServiceLocator();
                $this->musicrecordTable = $sm->get('Activate\Model\MusicrecordTable');
        }
        return $this->musicrecordTable;
    }

    public function getMusicclassTable()
    {
        if (!$this->musicclassTable) {
                $sm = $this->getServiceLocator();
                $this->musicclassTable = $sm->get('Activate\Model\MusicclassTable');
        }
        return $this->musicclassTable;
    }
	
	    public function getMediaTable()
    {
    	if (!$this->mediaTable) {
    		$sm = $this->getServiceLocator();
    		$this->mediaTable = $sm->get('Activate\Model\MediaTable');
    	}
    	return $this->mediaTable;
    }

    public function getPhonepicTable()
    {
        if (!$this->phonepicTable) {
                $sm = $this->getServiceLocator();
                $this->phonepicTable = $sm->get('Activate\Model\PhonepicTable');
        }
        return $this->phonepicTable;
    }


    public function getCityTable()
    {
        if (!$this->cityTable) {
                $sm = $this->getServiceLocator();
                $this->cityTable = $sm->get('Activate\Model\CityTable');
        }
        return $this->cityTable;
    }





    
}
