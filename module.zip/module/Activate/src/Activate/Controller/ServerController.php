<?php

namespace Activate\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Activate\Model\RecordTable;

class ServerController extends AbstractActionController
{
	protected $recordTable;
	
    public function putrecordAction()
    {
    	$app = isset($_POST['app'])?$_POST['app']:'';
    	$feature = isset($_POST['feature'])?$_POST['feature']:'all';
    	$pic_md5 = isset($_POST['md5'])?$_POST['md5']:'';
    	//$subject = isset($_POST['subject'])?$_POST['subject']:'';
    	$phone = isset($_POST['product'])?urldecode($_POST['product']):'';
		$net_type = isset($_POST['nettype'])?$_POST['nettype']:'wifi';
    	if(empty($pic_md5) || empty($phone) || empty($app))
    	{
    		die("");
    	}
    	$this->getRecordTable()->saveApp(array(
    			'app'=>$app,
    			'feature'=>$feature,
    			'pic_md5'=>$pic_md5,
    			//'subjectidentity'=>$subject,
    			'product'=>$phone,
				'net_type'=>$net_type,
				//'ip' => $_SERVER['REMOTE_ADDR'],
                        'ip'=>isset($_SERVER['HTTP_X_REAL_IP'])?$_SERVER['HTTP_X_REAL_IP']:$_SERVER['REMOTE_ADDR'],
    			'flag'=>1,//����
    			));
    	die("");
    	
    }	

    public function putsuccessAction()
    {
    	$app = isset($_POST['app'])?$_POST['app']:'';
    	$feature = isset($_POST['feature'])?$_POST['feature']:'all';
    	$pic_md5 = isset($_POST['md5'])?$_POST['md5']:'';
    	//$subject = isset($_POST['subject'])?$_POST['subject']:'';
    	$phone = isset($_POST['product'])?urldecode($_POST['product']):'';
		$net_type = isset($_POST['nettype'])?$_POST['nettype']:'wifi';
    	if(empty($pic_md5) || empty($phone) || empty($app))
    	{
    		die("");
    	}
    	$this->getRecordTable()->saveApp(array(
    			'app'=>$app,
    			'feature'=>$feature,
    			'pic_md5'=>$pic_md5,
    			//'subjectidentity'=>$subject,
    			'product'=>$phone,
				'net_type'=>$net_type,
				//'ip' => $_SERVER['REMOTE_ADDR'],
                        'ip'=>isset($_SERVER['HTTP_X_REAL_IP'])?$_SERVER['HTTP_X_REAL_IP']:$_SERVER['REMOTE_ADDR'],
    			'flag'=>2,//�ɹ�����ҳ
    			));
		die("");		
    	    	 
    }
    
    
    
    public function getRecordTable()
    {
    	if (!$this->recordTable) {
    		$sm = $this->getServiceLocator();
    		$this->recordTable = $sm->get('Activate\Model\RecordTable');
    	}
    	return $this->recordTable;
    }
    
    
}
