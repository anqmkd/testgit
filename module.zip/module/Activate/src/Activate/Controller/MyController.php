<?php

namespace Activate\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use Activate\Model\AppTable;
use Activate\Model\ChildappTable;
use Activate\Model\PhoneTable;
use Activate\Model\PicTable;
use Activate\Model\LinkTable;
use Activate\Model\SubjectTable;

use Activate\Model\ApppicTable;

class MyController extends AbstractActionController
{
	protected $appTable;
	protected $childappTable;
	protected $phoneTable;
	protected $subjectTable;
	protected $picTable;
	protected $linkTable;
	protected $apppicTable;
	
	//public $picurl = "http://bgcenter.coolpadsoft.com";
	public $picurl = "http://download.coolyun.com/";

	
    public function getlistAction()
    {
    	$app = isset($_POST['app'])?$_POST['app']:'';
    	$feature = isset($_POST['feature'])?$_POST['feature']:'all';
    	$width = isset($_POST['width'])?$_POST['width']:'';
    	$height = isset($_POST['height'])?$_POST['height']:'';
    	$phone = isset($_POST['product'])?$_POST['product']:'';
		$mydate = isset($_POST['date'])?$_POST['date']:'';
		
    	$app = isset($_REQUEST['app'])?$_REQUEST['app']:'';
    	$feature = isset($_REQUEST['feature'])?$_REQUEST['feature']:'all';
    	$width = isset($_REQUEST['width'])?$_REQUEST['width']:'';
    	$height = isset($_REQUEST['height'])?$_REQUEST['height']:'';
    	$phone = isset($_REQUEST['product'])?$_REQUEST['product']:'';
		$mydate = isset($_REQUEST['date'])?$_REQUEST['date']:'';
		
		$AppName = $app;
		
		
	
    	if(empty($width) || empty($height) || empty($phone) || empty($app))
    	{
    		$dataArr = array('flag'=>0,'data'=>array());
    		die(json_encode($dataArr));	
    	}
		
		if( $feature=='all' )
    	{
    		$linkData = $this->getAppTable()->getAppAllData(array('appname'=>$app,'is_using'=>1));
    	}else
    	{
    		$linkData = $this->getChildappTable()->getAppAllData(array('appname'=>$feature,'is_using'=>1));
    	}
		$phone = urldecode($phone);
    	$phoneData = $this->getPhoneTable()->getPhoneData(array('phonename'=>$phone));
    	if($phoneData->count()==0)
    	{
			$business = 7;
    	}
    	if($phoneData->count()>0)
    	{
    		$phoneinfo = $phoneData->current();
    		$business = $phoneinfo->business;
    		if (in_array((int)$business,array(1,2,4)))
    		{
    			$business = $business.',7';
    		}
    		if((int)$business==7)
    		{
    			$business = '1,2,4,7';
    		}				
    	}
    	if($linkData->count()==0)
    	{	
    		$dataArr = array('flag'=>0,'data'=>array());
    		die(json_encode($dataArr));
    	}
    	 
    	if($linkData->count()>0)
    	{
		    $subList = array();
    		$linkData = $linkData->current();
    		if($feature=='all')
    		{
    			$tempArr = array(
    					'business'=>$business,
    					'width'=>$width,
    					'height'=>$height,
						'appidentity'=>$linkData->identity,
    			);				
				$getApp = $this->getApppicTable()->getAllApp( $tempArr );				
    		}else
			{
				$subList[$feature] = $linkData->childidentity;
			}
			
			if($feature=='all' && $getApp->count()==0)
			{
    			$dataArr = array('flag'=>0,'data'=>array());
    			die(json_encode($dataArr));    			
			}			
    		if($feature=='all')
			{
				foreach($getApp as $templist)
				{
					$childapp = $templist->childappidentity;
					$linkData = $this->getChildappTable()->getAppAllData(array('childidentity'=>$childapp,'is_using'=>1));
					$data = $linkData->current();	
					$subList[$data->appname] = $data->childidentity;
				}
			}
    		$listData = array();
    		foreach ($subList as $app=>$tempSub)
    		{
    			$tempArrData = array(
    					'business'=>$business,
    					'width'=>$width,
    					'height'=>$height,
    					'childappidentity'=>$tempSub,
    			);
				
				
				if($mydate!="")
				{
					$tempArrData['mydate'] = $mydate;
 				}
				
				
    			$picData = $this->getApppicTable()->getAllAppPic($tempArrData);
    			if($picData->count()==0)
    			{				
    				$listData[] = array('feature'=>$app,'content'=>array());	
    			}
    			if($picData->count()>0)
    			{
    				$temppiclist = array();
    				foreach ($picData as $pic)
    				{
						if($AppName=="CP_CalendarUI")
						{
							$urlArrTemp = explode("/",$pic->url);						
							$temppiclist[] = array(
									'start'=>strtotime($pic->start).'000',
									'end'=>strtotime($pic->end).'000',
									'md5'=>$pic->md5,
									'picurl'=>$this->picurl.$pic->url,
									'action'=>$pic->linkurl,
                                                                        'order'=>$pic->order,
									'picname'=>end($urlArrTemp),
							);
						
						}else
						{
							$temppiclist[] = array(
									'start'=>strtotime($pic->start).'000',
									'end'=>strtotime($pic->end).'000',
									'md5'=>$pic->md5,
                                                                        'order'=>$pic->order,
									'picurl'=>$this->picurl.$pic->url,
									'action'=>$pic->linkurl,
							);
						
						}					

    				}
    				$listData[] = array('feature'=>$app,'content'=>$temppiclist);
    			} 
    		}
    		$dataArr = array('flag'=>1,'data'=>$listData);
    		die(json_encode($dataArr));    		
    		
    	}
    	/*
    	$subjectData = $this->getSubjectTable()->getAllDataUse();
    	if($subjectData->count()==0)
    	{
    		$dataArr = array('flag'=>0,'data'=>array());
    		die(json_encode($dataArr));
    	}    	 
    	$subjectList = array();    	
    	foreach($subjectData as $mysub)
    	{
    		$subjectList[] = (array)$mysub;
    	}
		*/
    	
    }

	






    
    public function getChildappTable()
    {
    	if (!$this->childappTable) {
    		$sm = $this->getServiceLocator();
    		$this->childappTable = $sm->get('Activate\Model\ChildappTable');
    	}
    	return $this->childappTable;
    }
    
    public function getPhoneTable()
    {
    	if (!$this->phoneTable) {
    		$sm = $this->getServiceLocator();
    		$this->phoneTable = $sm->get('Activate\Model\PhoneTable');
    	}
    	return $this->phoneTable;
    }
    public function getSubjectTable()
    {
    	if (!$this->subjectTable) {
    		$sm = $this->getServiceLocator();
    		$this->subjectTable = $sm->get('Activate\Model\SubjectTable');
    	}
    	return $this->subjectTable;
    }
    
    public function getPicTable()
    {
    	if (!$this->picTable) {
    		$sm = $this->getServiceLocator();
    		$this->picTable = $sm->get('Activate\Model\PicTable');
    	}
    	return $this->picTable;
    }
    public function getLinkTable()
    {
    	if (!$this->linkTable) {
    		$sm = $this->getServiceLocator();
    		$this->linkTable = $sm->get('Activate\Model\LinkTable');
    	}
    	return $this->linkTable;
    }
    public function getAppTable()
    {
    	if (!$this->appTable) {
    		$sm = $this->getServiceLocator();
    		$this->appTable = $sm->get('Activate\Model\AppTable');
    	}
    	return $this->appTable;
    }  
	
    public function getApppicTable()
    {
    	if (!$this->apppicTable) {
    		$sm = $this->getServiceLocator();
    		$this->apppicTable = $sm->get('Activate\Model\ApppicTable');
    	}
    	return $this->apppicTable;
    }
	
    
    
}
