<?php
namespace Launcher\Controller;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Auth\Auth;
use Launcher\Acl\Useracl;
use Launcher\Module;
use Launcher\Model\XmltoolTable;
use Launcher\Model\IcontoolTable;
use Launcher\Model\iconlistTable;
use Launcher\Model\keyguardTable;
use Zend\Db\Adapter\Adapter;
use \PDO;
use \ZipArchive;

class SiteController extends AbstractActionController
{
	public $filepath    = 'E:/Users/zhouyuhong/workspace/app/public/tempfile/launcherAdd.txt';
	public $repalceStr  = 'E:/Users/zhouyuhong/workspace/app/public';
	public $tempFolder  = 'E:/Users/zhouyuhong/workspace/app/public';
 	public $basepushurl = 'http://download.coolyun.com';
// 	public $pushurl     = 'http://192.168.30.54:8088/taskpush.php?action=push&task=';
	public $pushurl     = 'http://coolpush.coolyun.com/push/index?task=';
 	public $getmsg      = 'http://192.168.30.54:8088/taskpush.php?action=getmsg';
	public $iconFinal   = '/widgetapplist/push_zip/icon/';
	public $textpath    = 'E:/Users/zhouyuhong/workspace/app/public/widgetapplist/icon_update.txt';
	public $texturl     = 'http://download.coolyun.com/widgetapplist/icon_update.txt';
	public $rationArr   = array('1080x1960','1440x2560','720x1280','540x960','1200x1920');	
	
	protected $xmltoolTable;
	protected $icontoolTable;
	protected $iconlistTable;
	protected $keyguardTable;
	protected $keyguardPreviewTable;
	protected $keyguardlistTable;
	
	public function addpreviewAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr 	= $request->getPost();
			$id      	= $postArr['id'];
			$linkurl	= $postArr['linkurl'];
			$ratio      = $postArr['ratio'];
			$imgid		= $postArr['imgid'];
			$pic        = trim($postArr['subjectpic']);
			$pic		= urldecode($pic);
			if(empty($ratio) || empty($pic)){
				die('empty');
			}
			$rationArr	=	explode('x', $ratio);
			list($width,$height)		= $rationArr;
			$flag		=	false;
			if(substr($pic,0,14)=='/widgetapplist'){
				$flag		 = true;
				$filemd5     = md5_file($this->repalceStr.$pic);
				$filesize    = filesize($this->repalceStr.$pic);
				$pic	= $this->basepushurl.$pic;
			}
			$dataArr = array('imgid'=>$imgid,'width'=>$width,'height'=>$height,
							'linkurl'=>$linkurl,'imgurl'=>$pic);
			if($flag == true){
				$dataArr['size']		=	$filesize;
				$dataArr['md5']			=	$filemd5;
			}
			if($id){
				$dataArr['update_time']	=	date('Y-m-d H:i:s');
				$dataArr['update_user']	=	$uData->username;
				$dataArr['id']			=	$id;
				$this->getKeyguardPreviewTable()->updateData($dataArr);
			}else{
				$nResult	=	$this->getKeyguardPreviewTable()->getAppData(array('imgid'=>$imgid,'width'=>$width,'height'=>$height));
				if($nResult)die('exist');
				$dataArr['insert_time'] = 	date('Y-m-d H:i:s');
				$dataArr['insert_user'] =	$uData->username;
				$dataArr['valid']		=	1;
				$this->getKeyguardPreviewTable()->saveArr($dataArr);
			}
			die('success');			
		}
	}
	
	public function keyguardpreviewAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$imgid = isset($_GET['id'])?$_GET['id']:'';
		if($imgid){
			$tempData = $this->getKeyguardPreviewTable()->getAllData(array('imgid'=>$imgid));
			$dataArr = array();
			foreach ($tempData as $row){
				$dataArr[] = $row;
			}
			return new ViewModel(array('infoData'=>$dataArr,'imgid'=>$imgid,'folderStr'=>$this->repalceStr,
					'ratioInfo'=>$this->rationArr));
		}
	}
	
	public function addkeyguardlistAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr		=	$request->getPost();
			$title			=	$postArr['title'];
			$content		=	$postArr['content'];;
			$id				=	$postArr['id'];
			$type			=	$postArr['keyguardtype'];
			$typename		=	$postArr['typename'];
			$cpid			=	$postArr['cpid'];
			$dataArr		=	array('title'=>$title,'content'=>$content,'type'=>$typename,'typeid'=>$type);
			if($id){
				$dataArr['id']	=	$id;
				$dataArr['update_time']	=	date('Y-m-d H:i:s');
				$dataArr['update_user']	=	$uData->username;
				$this->getKeyguardlistTable()->updateData($dataArr);
			}else{
				$dataArr['cpid']		=	$cpid;
				$dataArr['valid']		=	1;
				$dataArr['imgid']       = 	sprintf("%u", crc32($cpid.$typename.$title.$content));
				$dataArr['insert_time']	=	date('Y-m-d H:i:s');
				$dataArr['insert_user']	=	$uData->username;
				$this->getKeyguardlistTable()->saveArr($dataArr);
			}
			die('success');			
		}
	}
	
	public function keyguardlistAction()
	{
		$uData	=	$this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isGet()){
			$postArr = $request->getQuery();
			$cpid    	= $postArr['id'];
			$page		=	isset($postArr['page'])?$postArr['page']:1;
			$tempType= $this->getKeyguardlistTable()->getTypeList();
			$typeArr = array();
			foreach($tempType as $row){
				$typeArr[] = $row;
			}
			$count		=	$this->getKeyguardlistTable()->getCountData(array('cpid'=>$cpid));
			$pageSize	=	10;
			$totalPage      = ceil($count/$pageSize);
			if($page>$totalPage){$page = $totalPage;}
			if($page == 0){$page = 1;}
			$tempData = $this->getKeyguardlistTable()->getData($page,$pageSize,array('cpid'=>$cpid));
			$dataArr = array();
			foreach ($tempData as $row){
				$dataArr[] = $row;
			}
			return new ViewModel(array('infoData'=>$dataArr,'cpid'=>$cpid,'typeArr'=>$typeArr,
					'mycount'=>$count,'pagesize'=>$pageSize,'totalPage'=>$totalPage,'page'=>$page,));
		}
	}
	
	public function addkeyguardAction()
	{
		$uData	=	$this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr	=	$request->getPost();
			$title		=	$postArr['title'];
			$count		=	$postArr['count'];
			$id			=	$postArr['id'];
			$dataArr	=	array('title'=>$title,'ncount'=>$count);
			if($id){
				$dataArr['insert_time']	=	date('Y-m-d H:i:s');
				$dataArr['insert_user']	=	$uData->username;
				$dataArr['id']	=	$id;
				$this->getKeyguardTable()->updateData($dataArr);
			}else{
				$dataArr['update_time']	=	date('Y-m-d H:i:s');
				$dataArr['update_user']	=	$uData->username;
				$dataArr['cpid']		=	sprintf("%u", crc32($title.$count.date('YmdHis')));
				$dataArr['valid']		=	1;
				$this->getKeyguardTable()->saveArr($dataArr);
			}
			die('success');
		}
	}
	
	public function keyguardAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$pageSize = 20;
		$page           = isset($_GET['page'])?$_GET['page']:1;
		$countWidget    = $this->getKeyguardTable()->getCountData();
		$totalPage      = ceil($countWidget/$pageSize);
		if($page>$totalPage){$page = $totalPage;}
		if($page == 0){$page = 1;}
		$tempData = $this->getKeyguardTable()->getAppDataAll($page,$pageSize);
		$arrlist	= array();
		foreach($tempData as $row){
			$arrlist[] = (array)$row;
		}
		return new ViewModel(array('mycount'=>$countWidget,'pagesize'=>$pageSize,'totalPage'=>$totalPage,'page'=>$page,
									'infoData'=>$arrlist,'folderStr'=>$this->repalceStr));
	}
	
	public function iconlistAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$pageSize = 20;
		$keyword        = isset($_GET['keyword'])?$_GET['keyword']:'';
		$page           = isset($_GET['page'])?$_GET['page']:1;
		$obj       		= $this->getIconlistTable()->getIdentity();
		$arrlist = array();
		$identity 		= '';
		$countWidget 	= 0;
		$totalPage   	= 0;
		$dirurl      	= '';
		if($obj){
			$identity       = $obj->identity;
			$dirurl         = $obj->url;
				
			if($keyword == ''){
				$countWidget    = $this->getIconlistTable()->getDistinctnum($identity);
			}else{
				$countWidget    = $this->getIconlistTable()->getKeywordnum($identity,$keyword);
			}
			$totalPage      = ceil($countWidget/$pageSize);
			if($page>$totalPage){$page = $totalPage;}
			if($page == 0){$page = 1;}
			if($keyword == ''){
				$tempData = $this->getIconlistTable()->getAppDataAll($page,$pageSize,$identity);
			}else{
				$tempData = $this->getIconlistTable()->getKeywordAppDataAll($page,$pageSize,$identity,$keyword);
			}
				
				
			foreach($tempData as $row){
				$arrlist[] = (array)$row;
			}
		}else{
			die("First,please upload ICON material package!");
		}
		return new ViewModel(array('arrlist'=>$arrlist,'basepushurl'=>$this->basepushurl,'keyword'=>$keyword,'cpid'=>$identity,
				'mycount'=>$countWidget,'pagesize'=>$pageSize,'totalPage'=>$totalPage,'page'=>$page,
				'dirurl'=>$dirurl,'folderStr'=>$this->repalceStr));
	}
	public function iconupdateAction()
	{
		$uData = $this->checkLogin('index');
		if(!$uData)
		{
			die('nopower');
		}
		
		$pageSize = 20;
		
		$page 		= isset($_GET['page'])?$_GET['page']:1;
		$keyword 	= isset($_GET['keyword'])?$_GET['keyword']:'';
		$obj       		= $this->getIconlistTable()->getIdentity();
		$arrlist = array();
		$identity 		= '';
		$countWidget 	= 0;
		$totalPage   	= 0;
		if($obj){
			$identity       = $obj->identity;
			if($keyword == ''){
				$countWidget    = $this->getIconlistTable()->getDistinctnum($identity);
			}else{
				$countWidget    = $this->getIconlistTable()->getKeywordnum($identity,$keyword);
			}
			$totalPage      = ceil($countWidget/$pageSize);
			if($page>$totalPage){$page = $totalPage;}
			if($page == 0){$page = 1;}
			if($keyword == ''){
				$tempData = $this->getIconlistTable()->getAppDataAll($page,$pageSize,$identity);
			}else{
				$tempData = $this->getIconlistTable()->getKeywordAppDataAll($page,$pageSize,$identity,$keyword);
			}
			$arrlist = array();
			foreach($tempData as $row){
				$arrlist[] = (array)$row;
			}
		}
		
		return new ViewModel(array('fileArr'=>$arrlist,'basepushurl'=>$this->basepushurl,'identity'=>$identity,
									'mycount'=>$countWidget,'page'=>$page,'totalPage'=>$totalPage,'keyword'=>$keyword));
	}
	
	public function addiconAction()
	{
		$uData = $this->checkLogin('index');
		if(!$uData)
		{
			die('nopower');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postArr = $request->getPost();

	
			$pic          = $postArr['subjectpic'];
			$pic          = urldecode($pic);
			
			
			$identity        = sprintf("%u", crc32( file_get_contents($this->tempFolder.$pic)));
			$result          = $this->getIcontoolTable()->getAppData(array('identity'=>$identity));
			if($result && $result->id)
			{
				die('exist');
			}
			
			$picArr       = explode("/", $pic);
			$picfile      = end($picArr);
			$extrafolder  = str_replace($picfile, '',$pic);
			
			$zip = new ZipArchive;
			if (  $zip->open($this->tempFolder.$pic ) === TRUE  )
			{
				$zip->extractTo( $this->tempFolder.$extrafolder.'icon/');
				$zip->close();
			}
			
			
			$this->getIcontoolTable()->saveArr(array(
					'identity'         => $identity,
					'valid'            => 1,
					'url'              => $extrafolder.'icon/',
					'insert_user'      => $uData->username,
					'insert_time'      => date("Y-m-d H:i:s"),
			));
			
			$insertArr  = array();
			$time       = date('Y-m-d H:i:s');
			$absdir 	= $this->repalceStr.$extrafolder.'icon/';
			$handle = opendir($absdir);
			while(false !== ($myfile=readdir($handle))){
				if(strstr($myfile, '.png')){
					$fileArr = explode('.', $myfile);
					$packagename 	= $fileArr[0];
					$url     		= $extrafolder.'icon/'.$myfile;
					$crc32     		= sprintf("%u", crc32( file_get_contents($this->repalceStr.$url)));
					$insertArr[]    = array('cpid'=>$identity,
											'package'=>$packagename,
											'filename'=>$myfile,
											'crc32'=>$crc32,
											'url'=>$url,
											'valid'=>1,
											'insert_time'=>$time,
											'update_time'=>$time);
				}
			}
			$this->getIcontoolTable()->insertArr($insertArr);
			die('success');
		}
	}
	
	public function addiconlistAction()
	{
		$uData    = $this->checkLogin('index');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postArr 	= $request->getPost();
			if(empty($postArr['subjectpic'])&& empty($postArr['id']))
			{
				die('empty');
			}
			$id         	= $postArr['id'];
			$packagename    = $postArr['packagename'];
			$cpid           = $postArr['cpid'];
			$pic        	= $postArr['subjectpic'];
			$pic        	= urldecode($pic);
			$arrName    	= explode('/', $pic);
			$name       	= end($arrName);
			$dirurl         = $postArr['dirurl'];
			if($packagename != $name)die('nameerror');			
			if(!strstr($name, '_') || !strstr($name, '.png'))die("error");
			$crc32          = sprintf("%u", crc32( file_get_contents($this->repalceStr.$pic)));
			$data = $this->getIconlistTable()->getSelectData(array(
					'cpid'=>$cpid,
					'crc32'=>$crc32,
			));
			if($data)die("exist");
			copy($this->repalceStr.$pic, $this->repalceStr.$dirurl.$name);
			$arrType        = explode('.',$name);
			if($id){
				$this->getIconlistTable()->updateData(array(
						'id'            => $id,
						'cpid'			=> $cpid,
						'packagename' 	=> $arrType[0],
						'filename' 		=> $name,
						'crc32'    		=> $crc32,
						'url'      		=> $dirurl.$name,
						'update_time' 	=> date('Y-m-d H:i:s'),
				));
			}else{
				$this->getIconlistTable()->saveArr(array(
						'cpid'			=> $cpid,
						'packagename' 	=> $arrType[0],
						'filename' 		=> $name,
						'crc32'    		=> $crc32,
						'url'      		=> $dirurl.$name,
						'valid'    		=> 1,
						'update_time' 	=> date('Y-m-d H:i:s'),
						'insert_time' 	=> date('Y-m-d H:i:s'),
				));
			}
			die('success');
		}
	}
	
	public function pushserverAction()
	{
		$uData    = $this->checkLogin('index');
		if(!$uData)
		{
			die('没有权限');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postarr = $request->getPost();
			$pusharr = array(
					'appid'       => 6001,
					'appnote'     => $postarr['mynote'],
					'type'        => $postarr['sendtype'],
					'mobiles'     => (intval($postarr['sendtype'])==1)?explode(',',$postarr['mobile']):array(),
					'products'    => (intval($postarr['sendtype'])==2)?explode(',',$postarr['product']):array(),
					'appmsg'      => $postarr['appmsg'],
					'ispush'      => (int)$postarr['ispush'],
					'notify'  => array(
							'title'    => 'icon test',
							'content'  => 'icon test',
					),
			);
			$newmydata = json_encode($pusharr);
			$newmydata = str_replace('&', '%26', $newmydata);
			$urldata   = $this->pushurl.$newmydata;
			//$urldata   = str_replace('&', '%26', $urldata);
			$result    = $this->geturldata($urldata);
			$resultarr = json_decode($result,true);
			$resultstr = $resultarr['result']?'success':'failed';
			die($resultstr);
		}
	}
	
	public function getmsgAction()
	{
		$request = $this->getRequest();
		if ($request->isPost())
		{
			$postarr = $request->getPost();
			$url     = $postarr['url'];
// 			$url     = $this->getmsg.'&gourl='.$url;
			$result  = $this->geturldata($url);
			die($result);
		}
	}
	
	public function geturldata( $url )
	{
		$ch     = curl_init($url) ;
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true) ;
		$output = curl_exec($ch);
		curl_close($ch);
		return $output;
	}
	
	public function pushAction()
    {
    	$uData    = $this->checkLogin('index');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	$url = $_GET['downurl'];
    	$downurl = $this->basepushurl.$url;
    	$msgarr  = array('type'=>'downloadProxy','content'=>array('assign'=>'launcher_app_classification',
    			'url'=>$downurl,'texturl'=>$this->texturl));
    	$msgarr  = json_encode($msgarr);
    	return new ViewModel(array('infodata'=>$msgarr));
    }
	
	public function makeiconxmlAction()
	{
		$uData = $this->checkLogin('index');
		if(!$uData)
		{
			die('nopower');
		}
		$request = $this->getRequest();
		if ($request->isPost())
		{
 			$postArr = $request->getPost();
 			$id      = $postArr['id'];
 			$cpid    = $postArr['cpid'];
 			$this->getIcontoolTable()->startXml($id);
 			$relpath    = $this->getIconlistTable()->getSelectAllData(array('cpid'=>$cpid,'valid'=>1));
 			
 			$xml        = "<?xml version='1.0' encoding='utf-8'?>\n<root>\n<head>\n<item key='density' value='xxhdpi' />\n<item key='suffix' value='.png' />\n</head>\n<content>\n";
 			foreach ($relpath as $row){
 				$tmpxml       = "<icon name='".$row['packagename']."' url='".$this->basepushurl.$row['url']."' crc32='".$row['crc32']."'/>\n";
 				$xml .= $tmpxml;				
 			}
 												
  			$xml .= "</content>\n</root>";
 			$targetFile = 'icon_'.date('YmdHis');
 			$targetDir  = $this->repalceStr.$this->iconFinal.date('Ymd');
 			if(is_dir($targetDir) === false)
 			{
 				$result = mkdir($targetDir,0755);
 				if($result === false)
				{
 					die('error');
 				}
 			}
 			$makerelpath = $targetDir.'/'.$targetFile.'.xml';
 			file_put_contents($makerelpath,$xml);
 			
 			
 			$destination = $targetDir.'/'.$targetFile.'.zip';
 			if(fopen("$destination",'w+') === false)
 			{
 				die('error');
 			}
 			$zip = new ZipArchive();
 			if($zip->open($destination) !== true) {
 				die('error');
 			}
 			
 			$localName = 'perfect_icons_remote.xml';
 			$zip->addFile($makerelpath,$localName);
 			
 			$downurl = $this->iconFinal.date('Ymd').'/'.$targetFile.'.zip';
 			$this->getIcontoolTable()->updateData(array('id'=>$id,'downurl'=>$downurl));
 			
 			$textUrl = $this->basepushurl.$downurl;
 			$dataArr = array('update_time'=>time().'000','url'=>$textUrl);
 			file_put_contents($this->textpath, json_encode($dataArr));
		}
		die("success");		
	}
	
	public function seticonpathAction()
	{
		$type      = isset($_POST['type'])?$_POST['type']:'';
		$atime     = date('YmdHis');
		$randnum   = $this->num_rand(6);
		$mycontent = '/widgetapplist/'.$type.'/'.date('Ymd').'/'.$atime.'_'.$randnum;
		file_put_contents($this->filepath, $mycontent);
		die("");
	}
	
	public function num_rand($lenth){
		mt_srand((double)microtime() * 1000000);
		$randval   = '';
		for($i=0;$i<$lenth;$i++){
			$randval.= mt_rand(0,9);
		}
		$randval=substr(md5($randval),mt_rand(0,32-$lenth),$lenth);
		return $randval;
	}
	
	public function icontoolAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		
		$result = $this->getIcontoolTable()->getAppDataAll(array());
		$infoData = array();
		foreach($result as $row){
			$infoData[] = (array)$row;
		}
		return new ViewModel(array('folderStr'=>$this->repalceStr,'infoData'=>$infoData,'showurl'=>$this->basepushurl));
	}
	
	public function xmltoolAction()
	{
		$uData = $this->checkLogin('right');
		if(!$uData)
		{
			die('没有权限');
		}
		$result = $this->getXmltoolTable()->getXmlType();
		$xmlTypeList = array();
		foreach($result as $row){
			$xmlTypeList[] = (array)$row;
		}
	
		$result = $this->getXmltoolTable()->getAppDataAll(array());
		$addApkList = array();
		foreach($result as $row){
			$addApkList[] = (array)$row;
		}
		return new ViewModel(array('xmlTypeList'=>$xmlTypeList,'addApkList'=>$addApkList));
	}
	
	
	
	public function checknameAction()
	{
		$request = $this->getRequest();
		if($request->isPost()){
			$postArr = $request->getPost();
			$packagename = $postArr['packagename'];
			if(!strstr($packagename, '.png')|| !strstr($packagename, '_'))die("fileerror");
			$cpid        = $postArr['cpid'];
			$id          = $postArr['id'];
			if($id){
				$result      = $this->getIconlistTable()->checkupname($packagename,$cpid,$id);
				if($result)die("updateexist");
			}else{
				$result      = $this->getIconlistTable()->checkname($packagename,$cpid);
				if($result)die("addexist");
			}			
		}
	}
	
	public function getIconlistTable()
	{
		if (!$this->iconlistTable) {
			$sm = $this->getServiceLocator();
			$this->iconlistTable = $sm->get('Launcher\Model\iconlistTable');
		}
		return $this->iconlistTable;
	}
	
	public function getXmltoolTable()
	{
		if (!$this->xmltoolTable) {
			$sm = $this->getServiceLocator();
			$this->xmltoolTable = $sm->get('Launcher\Model\XmltoolTable');
		}
		return $this->xmltoolTable;
	}
	
	public function getIcontoolTable()
	{
		if (!$this->icontoolTable) {
			$sm = $this->getServiceLocator();
			$this->icontoolTable = $sm->get('Launcher\Model\IcontoolTable');
		}
		return $this->icontoolTable;
	}
	
	public function addxmlapkAction()
	{
		$request 		= $this->getRequest();
		$postArr 		= $request->getPost();
		$id      		= isset($postArr['id'])?$postArr['id']:'';
		$packageName 	= $postArr['packagename'];		
		
			
		if($id){
			$this->getXmltoolTable()->updateData(array(
					'id'           => $id,
					'name'         => $postArr['apkname'],
					'packageName'  => $packageName,
					'type'         => $postArr['type'],
					'typeid'       => $postArr['typeid'],  
			));
		}else{
			$result         = $this->getXmltoolTable()->getJudgeData($packageName);
			if($result && $result->id)
			{
				die('exist');
			}
			$result         = $this->getXmltoolTable()->getAppData(array('packageName'=>$packageName));
			if($result && $result->id)
			{
				die('exist');
			}
			$this->getXmltoolTable()->saveArr(array(
					'name'         => $postArr['apkname'],
					'packageName'  => $packageName,
					'type'         => $postArr['type'],
					'typeid'       => $postArr['typeid'],
					'insert_time'  => date("Y-m-d H:i:s"),
			));
		}
		die('success');		
	}
	
	public function delcontentAction()
	{
		try{
			$request     = $this->getRequest();
			$postArr     = $request->getPost();
			$id          = $postArr['id'];
			$type        = isset($postArr['type'])?$postArr['type']:'';
			$valid   	 = isset($postArr['valid'])?$postArr['valid']:'';
			if($type == 'iconlist'){				
				$this->getIconlistTable()->updateData(array('id'=>$id,'valid'=>$valid,'update_time'=>date('Y-m-d H:i:s')));
			}elseif($type == 'keyguardpreview'){
				$this->getKeyguardPreviewTable()->updateData(array('id'=>$id,'valid'=>$valid,'update_time'=>date('Y-m-d H:i:s')));
			}elseif($type == 'keyguardlist'){
				$this->getKeyguardListTable()->updateData(array('id'=>$id,'valid'=>$valid,'update_time'=>date('Y-m-d H:i:s')));
			}elseif($type == 'keyguard'){
				$this->getKeyguardTable()->updateData(array('id'=>$id,'valid'=>$valid,'update_time'=>date('Y-m-d H:i:s')));
			}else{
				$this->getXmltoolTable()->delete($id);
			}
			die('success');
		}catch(Exception $e){
			Logs::write('delcontentAction() error:'.$e->getMessage(),'log');
			die('error');
		}
	
	}
	
    public function indexAction()
    {
    	/*
    	$aaa = 'D:\webserver\easyphp\www\MyApplication\public\upload\Files\tool\20130503174315\duomiyinle.apk';
    	$crc = sprintf("%u", crc32(file_get_contents($aaa)));
    	var_dump($crc);exit;
    	*/
    	$uData = $this->checkLogin('index');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
        return new ViewModel();
    }
    public function topAction()
    {
    	$uData = $this->checkLogin('top');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel(array('uData'=>$uData));    	
    }
    public function leftAction()
    {
    	$uData = $this->checkLogin('left');
    	if(!$uData)
    	{
    		die('没有权限');
    	}

    	$module_temp = new Module();
    	$params = $module_temp->getParams();


    	return new ViewModel( array('params'=>$params['params']) );
    }
    public function downAction()
    {
    	$uData = $this->checkLogin('down');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }

      
    public function centerAction()
    {
    	$uData = $this->checkLogin('center');
    	if(!$uData)
    	{
    		die('没有权限');
    	}
    	return new ViewModel();
    }
    
    public function checkLogin($action)
    {
    	$myAuth  = new Auth();
    	$objUser = $myAuth->isLogin();
    	if(!$objUser)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($objUser)
    	{
    		$roleArr  = json_decode($objUser->roleStr,true);
    		$roleData = isset($roleArr['launcher'])?$roleArr['launcher']:"";
    		if($roleData=="")
    		{
    			return false;
    		}
    		else
    		{
    			$userAcl   = new Useracl();
    			$allowData = $userAcl->checkAction($roleData, $action);
    			if(!$allowData)
    			{
    				return false;
    			}else{
    				return $objUser;
    			}
    		}
    	}
    }
    
	public function getKeyguardTable()
	{
		if (!$this->keyguardTable) {
			$sm = $this->getServiceLocator();
			$this->keyguardTable = $sm->get('Launcher\Model\keyguardTable');
		}
		return $this->keyguardTable;
	}

	public function getKeyguardPreviewTable()
	{
		if (!$this->keyguardPreviewTable) {
			$sm = $this->getServiceLocator();
			$this->keyguardPreviewTable = $sm->get('Launcher\Model\keyguardPreviewTable');
		}
		return $this->keyguardPreviewTable;
	}
	
	public function getKeyguardlistTable()
	{
		if (!$this->keyguardlistTable) {
			$sm = $this->getServiceLocator();
			$this->keyguardlistTable = $sm->get('Launcher\Model\keyguardlistTable');
		}
		return $this->keyguardlistTable;
	}
}