<?php
namespace Launcher\Model;

use Zend\Db\Sql\Select;
use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;
use Zend\Db\Sql\Expression;

class keyguardPreviewTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_keyguard_img';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
//     public function getCountData()
//     {
//     	$result = $this->select();
//     	return $result->current();
//     }
    
    public function updateData(array $data)
    {
    	$this->update($data, array('id' => $data['id']));
    }
    
    public function saveArr(array $data)
    {
    	$this->insert($data);
    	return $this->getLastInsertValue();
    }
    
    public function getAllData(array $data)
    {
    	$result = $this->select($data);
    	return $result;
    }
    
    public function getAppData(array $data)
    {
    	$result = $this->select($data);
    	return $result->current();
    }
    
    
    
    
    
    
    
    
    
    
    public function getCountData()
    {
    	$result = $this->select();
    	return $result->count();
    }
    
    public function getAppDataAll($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->columns(array('*'))
    	->order(array('insert_time DESC'))
    	->limit($pagesize)
    	->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }

    public function getData($page=1,$pagesize=2,array $data)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->columns(array('*'))
    			 ->where($data)
    	         ->order(array('insert_time DESC'))
    	         ->group('cpid')
    	         ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }   

    public function updateDataArr(array $data)
    {
    	$this->update($data, array('identity' => $data['identity']));
    }
    
    public function getPayCount(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->columns(array('countnum'=>new Expression('SUM(ischarge)')))
    	->where(array( 'cpid=\''.$data["cpid"].'\'' ));
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function updatePayData(array $data)
    {
    	$this->update($data, array('cpid' => $data['cpid']));
    }
    
}