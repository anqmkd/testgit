<?php

namespace Recommend\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class IconTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_likeapp_icon';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    public function getImgData(array $select_array)
    {
    	$rowset = $this->select($select_array);
    	return $rowset;
    }
    
    public function updateImgData(array $imgData)
    {
    	$this->update($imgData, array('id' => $imgData['id']));
    }    
    public function saveImgArr(array $img)
    {
	    $data = array(
	    	'identity' => $img['identity'],
	        'height' => $img['height'],
	        'width' => $img['width'],
	    	'img_url' => $img['img_url'],
	    	'insert_time' => $img['insert_time'],
	    	'insert_user' => $img['author'],
	    	'update_time' => $img['update_time'],
	    	'update_user' => $img['author'],
	    );
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    public function updateImg(array $img)
    {
    	$data = array(
	    	'widgetid' => $img['widgetid'],
	        'height' => $img['height'],
	        'width' => $img['width'],
	    	'img_url' => $img['img_url'],
	    	'update_time' => $img['update_time'],
	    	'update_user' => $img['author'],    			
    	);
    	$this->update($data, array('id' => $img['id']));
    }
    
}
