<?php

namespace Recommend\Model;

use Zend\Db\Sql\Select;

use Zend\Db\TableGateway\AbstractTableGateway;
use Zend\Db\Adapter\Adapter;
use Zend\Db\ResultSet\ResultSet;

class ProductTable extends AbstractTableGateway
{
    protected $table = 'tb_yl_product';
    public function __construct(Adapter $adapter)
    {
        $this->adapter = $adapter;
        $this->resultSetPrototype = new ResultSet();
        $this->initialize();
    }
    
    public function getData($page=1,$pagesize=2)
    {
    	$mysql = $this->getSql();
    	$offset = ((int)$page-1)*$pagesize;
    	$myselect = $mysql->select();
    	$myselect->order(array('insert_time DESC'))
			     ->limit($pagesize)
    	         ->offset($offset);
    	$myData = $this->selectWith($myselect);
    	return $myData;
    }
    
    public function getProductCount()
    {
    	$rowset = $this->select();
    	return $rowset->count();
    }

    public function getProductData(array $select)
    {
    	$rowset = $this->select($select);
    	return $rowset->count();
    }
    
    public function updateProductData(array $productData)
    {
    	$this->update($productData, array('id' => $productData['id']));
    }    
    public function saveProductArr(array $data)
    {
	    $this->insert($data);
	    return $this->getLastInsertValue();
    }
    public function getProductAllDataList()
    {
    	$rowset = $this->select();
    	return $rowset;
    }
    public function getDataProduct(array $data)
    {
    	$mysql = $this->getSql();
    	$myselect = $mysql->select();
    	$myselect->where( 'tb_yl_product.business IN ('.$data['business'].') AND tb_yl_product.valid=1 ' )
                 ->order(array("business ASC"));
    	$myData = $this->selectWith($myselect);
    	return $myData;    	
    }
    
    public function getProductInfo(array $select)
    {
    	$rowset = $this->select($select);
    	return $rowset;
    }    
    
    
}
