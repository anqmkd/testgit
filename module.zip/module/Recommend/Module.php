<?php

namespace Recommend;

use Recommend\Model\WidgetTable;
use Recommend\Model\ApkTable;
use Recommend\Model\ImgTable;
use Recommend\Model\IconTable;
use Recommend\Model\ProductTable;
use Recommend\Model\ExtendTable;
use Recommend\Model\DownloadTable;
use Recommend\Model\WidgetProductTable;
use Recommend\Model\XmltoolTable;

use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{

	public static $db = array(
			'driver' => 'Pdo',
			//'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',
	        'dsn'            => 'mysql:dbname=db_yl_network_widget;host=172.16.45.152:3336',
			'username'       => 'root',
			'password'       => '',
			'driver_options' => array(
					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
			),
	);

        public static $db2 = array(
                        'driver' => 'Pdo',
                        //'dsn'            => 'mysql:dbname=db_yl_network_widget;hostname=192.168.0.223',
                'dsn'            => 'mysql:dbname=db_yl_webapp;host=172.16.45.152:3336',
                        'username'       =>'root',
                        'password'       => '',
                        'driver_options' => array(
                                        PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
                        ),
        );



		
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    public function getServiceConfig()
    {
    	return array(
    		'factories' => array(
    			'Recommend\Model\ImgTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ImgTable($dbAdapter);
    				return $table;
    			},
    			'Recommend\Model\WidgetTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new WidgetTable($dbAdapter);
    				return $table;
    			},
    			'Recommend\Model\ApkTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ApkTable($dbAdapter);
    				return $table;
    			},

    			'Recommend\Model\IconTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new IconTable($dbAdapter);
    				return $table;
    			},

    			'Recommend\Model\ProductTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ProductTable($dbAdapter);
    				return $table;
    			},

    			'Recommend\Model\ExtendTable' =>  function($sm) {
    				$dbAdapter = new Adapter(self::$db);
    				$table = new ExtendTable($dbAdapter);
    				return $table;
    			},

    			'Recommend\Model\DownloadTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new DownloadTable($dbAdapter);
    				return $table;
    			},
    			'Recommend\Model\WidgetProductTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db);
    				$table = new WidgetProductTable($dbAdapter);
    				return $table;
    			},
                        'Recommend\Model\XmltoolTable' =>  function($sm) {
    				//$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
    				$dbAdapter = new Adapter(self::$db2);
    				$table = new XmltoolTable($dbAdapter);
    				return $table;
    			},
    			 



    		),
    	);
    }
    
    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
    public function getParams()
    {
    	return include __DIR__ . '/config/params.php';
    } 
}
