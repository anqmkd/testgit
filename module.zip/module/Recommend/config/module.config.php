<?php
return array(
    'controllers' => array(
        'invokables' => array(
            'Recommend\Controller\Site' => 'Recommend\Controller\SiteController',
        ),
    ),    
    'router' => array(
        'routes' => array(
            'recommend' => array(
                'type'    => 'segment',
                'options' => array(
                    'route'    => '/recommend[/:action][/:id]',
                    'constraints' => array(
                        'action' => '[a-zA-Z][a-zA-Z0-9_-]*',
                        'id'     => '[0-9]+',

                    ),
                    'defaults' => array(
                        'controller' => 'Recommend\Controller\Site',
                        'action'     => 'index',
                    ),
                ),
            ),
        ),
    ),

    'view_manager' => array(
        'template_path_stack' => array(
            'recommend' => __DIR__ . '/../view',
        ),
    ),
);