<?php

namespace User\Controller;

use User\Module;

use Zend\Mvc\Controller\AbstractActionController;
use Zend\View\Model\ViewModel;
use User\Model\User;
use User\Form\UserForm;
use User\Auth\Auth;
use Service\Logs\Logs;


class UserController extends AbstractActionController
{
	protected $userTable;
	protected $roleTable;
	public function indexAction()
	{
//		Logs::write('UserController::indexAction(): ispost() failed', 'log');
		$userLogin = $this->checkLogin();
		if(!$userLogin)
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
		}
		
		if($userLogin && $userLogin->username!='admin')
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'app'));
		}
				
		$userData = $this->getUserTable()->fetchAll();
		$userArr = array();
		if(!$userData)
		{
			return new ViewModel(array('userArr'=>''));
		}
		foreach($userData as $u)
		{
			$userid = $u->userid;
			$roleData = $this->getRoleTable()->getRoleData(array('user_id'=>$userid));
			$roleStr = array();
			if($roleData)
			{
				foreach($roleData as $role)
				{
					$roleStr[$role->app] = $role->role;
				}
				$userArr[] = array('userObject'=>$u,'roleStr'=>json_encode($roleStr));
			}else
			{
				$userArr[] = array('userObject'=>$u,'roleStr'=>"");	
			}
		}
		$temp = new Module();
		$appArr = $temp->appArr;		
		return new ViewModel(array(
				'userArr' => $userArr,
				'appArr' => $appArr,
		));		
	}


        public function apiloginoutAction()
        {
                $_SESSION['mylogin'] = '';
                die('ok');
        }
	
	public function delAction()
	{
		$id = (int)$this->params('id');
		if (!$id) {
			die("");
		}
		$request = $this->getRequest();
		if ($request->isPost()) {
			$this->getUserTable()->changeUser(array('userid'=>$id,'state'=>0));
			die("");
		}
	}
	
	public function editAction()
	{
		$request = $this->getRequest();
		if ($request->isPost()) {
			$postArr = $request->getPost();
			if($postArr['display_name']=="" || $postArr['email']==""){
				die('empty');
			}
			$userData = array(
				'display_name' => $postArr['display_name'],
				'email' => $postArr['email'],
				'userid' => $postArr['uid'],				
			);
			if($postArr['newpass']!="")
			{
				$userData['password'] = md5($postArr['newpass']);
			}
			$this->getUserTable()->changeUser($userData);
			die('success');
		}
	}
	
	public function appAction()
	{
		$userLogin = $this->checkLogin();
		if(!$userLogin)
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
		}
		
		
		$appList = json_decode($userLogin->roleStr,true);		
		return new ViewModel(array(
				'appList' => $appList,
		));		
	}

        public function ckloginAction()
        {
                $userLogin = $this->checkLogin();

                if($userLogin && $userLogin->username!=""){ die('1'); }
                if(!$userLogin){ die('0'); }
                
        }

	public function loginAction()
	{
		$userLogin = $this->checkLogin();
		//echo time();exit;
	
                //var_dump($userLogin);
	
		if($userLogin && $userLogin->username=='admin')
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'index'));
		}
		if($userLogin && $userLogin->username!='admin')
		{
			return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'app'));
		}		
		$request = $this->getRequest();
		if ($request->isPost()) {
			$postArr = $request->getPost();
			if($postArr['username']=="" || $postArr['password']=="" || $postArr['verifycode']==""){
				die('empty');
			}
			if($_SESSION['ck_num'] != trim($postArr['verifycode']) )
			{
				die('err');
			}
                        
			$result = $this->getUserTable()->getUserData(array('username'=>trim($postArr['username']),'password'=>md5($postArr['password'])));
                       // echo('cj');var_dump($result);
			if($result)
			{

//                                setcookie("session_id",session_id(),time()+86400,"/",".coolyun.com");
                                setcookie("myjudge",$postArr['username'],time()+3600,"/",".coolyun.com");
                                $_SESSION['mylogin'] = trim($result->display_name);

				if((int)$result->state == 0)
				{
					die('status');
				}
				$userid = $result->userid;
				$userArr = array(
					'userid' => $userid,
					'username' => $result->username,
					'display_name' => $result->display_name,
					'email' => $result->email,
				);
				$roleData = $this->getRoleTable()->getRoleData(array('user_id'=>$userid));
				$roleStr = array();
				if($roleData)
				{
					foreach($roleData as $role)
					{
						$roleStr[$role->app] = $role->role;
					}
					$userArr['roleStr'] = json_encode($roleStr);
				}else
				{
					$userArr['roleStr'] = '';
				}				
				$auth = new Auth();
				$auth->authStore($userArr);
				die('success');
			}else
			{
				die('fail');
			}
		}
		return new ViewModel();
	}
	
    
    public function addAction()
    {
    	$userLogin = $this->checkLogin();
    	if(!$userLogin)
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    	}
    	if($userLogin && $userLogin->username!='admin')
    	{
    		return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'app'));
    	}    	    	 
    	$form = new UserForm();
    	$request = $this->getRequest();
    	if ($request->isPost()) {
    		$user = new User();
    		$form->setInputFilter($user->getInputFilter());
    		$postArr = $request->getPost();
    		if($postArr['username']=="" || $postArr['password']==""){
    			die('empty');
    		}
    		$result = $this->getUserTable()->getUserData(array('username'=>trim($postArr['username'])));
    		if($result){
    			die('exist');
    		}
    		$form->setData($request->getPost());
    		if ($form->isValid()) {
    			$user->exchangeArray($form->getData());
    			$pdata = array();
    			$pdata['insert_user'] = $userLogin->username;
    			$pdata['ip']          = isset($_SERVER['HTTP_X_REAL_IP'])?$_SERVER['HTTP_X_REAL_IP']:$_SERVER['REMOTE_ADDR'];
    			$user->setParam($pdata);
    			$adduserid = $this->getUserTable()->saveUser($user);
    			$roleArr = array();
    			$appArr = explode(';',$postArr['myapp']);
    			$roleArrData = explode(';', $postArr['myrole']);
    			foreach($appArr as $key=>$val){
    				$roleArr[] = array('user_id'=>$adduserid,'app'=>$val,'role'=>$roleArrData[$key]);
    			}
    			$this->getRoleTable()->saveRole($roleArr);
    			die('success');
    		}
    	}
    	$temp = new Module();
    	$appArr = $temp->appArr;
    	
    	return array('form' => $form,'appArr'=>$appArr);
    }


    /*
    public function getAction()
    {
    	$app = isset($_GET['app'])?trim($_GET['app']):"";
    	if($app)
    	{
    		$myAuth = new Auth();
    		$objUser = $myAuth->isLogin();
    		if($objUser)
    		{
    			 $flag = 't';
    			 $roleArr = json_decode($objUser->roleStr,true);
    			 $roleData = isset($roleArr[$app])?$roleArr[$app]:"";
    			 if($roleData=="")
    			 {
    			 	die(json_encode(array('flag'=>'t','status'=>'t','role'=>'f')));
    			 }else
    			 {
    			 	die(json_encode(array('flag'=>'t','status'=>'t','role'=>'t','userid'=>$objUser->userid,'username'=>$objUser->username,'display_name'=>$objUser->display_name,'email'=>$objUser->email)));
    			 }    			 
    		}else
    		{
    			die(json_encode(array('flag'=>'t','status'=>'f')));
    		}    		
    	}else
    	{
    		die(json_encode(array('flag'=>'f')));
    	}
    }
    */
    public function checkLogin()
    {
    	$myAuth = new Auth();
    	//$myAuth->logout();
    	$strUser = $myAuth->isLogin();
    	return $strUser;
    }
    
    public function loginoutAction()
    {
    	$myAuth = new Auth();
    	$myAuth->logout();
        $_SESSION['mylogin'] = '';
    	return $this->redirect()->toRoute('user', array('controller'=>'user','action' => 'login'));
    }
    
    public function getUserTable()
    {
    	if (!$this->userTable) {
    		$sm = $this->getServiceLocator();
    		$this->userTable = $sm->get('User\Model\UserTable');
    	}
    	return $this->userTable;
    }    
    public function getRoleTable()
    {
    	if (!$this->roleTable) {
    		$sm = $this->getServiceLocator();
    		$this->roleTable = $sm->get('User\Model\RoleTable');
    	}
    	return $this->roleTable;
    }    
    
}
