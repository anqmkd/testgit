<?php

namespace User;

use User\Model\UserTable;
use User\Model\RoleTable;
use Zend\Db\Adapter\Adapter;
use \PDO;

class Module
{
	public static $db = array(
    			'driver' => 'Pdo',
    			'dsn'            => 'mysql:dbname=webuser;host=localhost:3306',
    			'username'       => 'root',
    			'password'       => '',
//                         'username'       => 'autoupdate',
//                        'password'       => '1qaz!QAZ',
    			'driver_options' => array(
    					PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\''
    			),
    	); 
	
	public $appArr = array(

    		array('app'=>'recommend','name'=>'应用推荐','role'=>array(
    				array('info'=>'member','infoname'=>'普通用户'),
    				array('info'=>'manager','infoname'=>'管理员'),
    		)),
    		array('app'=>'browser','name'=>'浏览器','role'=>array(
    				array('info'=>'user','infoname'=>'浏览用户'),
    				array('info'=>'admin','infoname'=>'管理者'),
    		)),

			array('app'=>'activate','name'=>'启动页','role'=>array(
					array('info'=>'user','infoname'=>'浏览用户'),
					array('info'=>'admin','infoname'=>'管理者'),
			)),			

    		array('app'=>'statistic','name'=>'统计工具','role'=>array(
    				array('info'=>'member','infoname'=>'普通用户'),
    				array('info'=>'manager','infoname'=>'管理员'),
    		)),

			array('app'=>'theme','name'=>'主题','role'=>array(
					array('info'=>'member','infoname'=>'浏览用户'),
					array('info'=>'manager','infoname'=>'管理者'),
			)),


                        array('app'=>'report','name'=>'运营报表','role'=>array(
                                        array('info'=>'member','infoname'=>'浏览用户'),
                                        array('info'=>'manager','infoname'=>'管理者'),
                        )),
			array('app'=>'widgetimg','name'=>'桌面图片','role'=>array(
					array('info'=>'user','infoname'=>'浏览用户'),
					array('info'=>'admin','infoname'=>'管理者'),
			)),



    	);
	
    public function getAutoloaderConfig()
    {
        return array(
            'Zend\Loader\ClassMapAutoloader' => array(
                __DIR__ . '/autoload_classmap.php',
            ),
            'Zend\Loader\StandardAutoloader' => array(
                'namespaces' => array(
                    __NAMESPACE__ => __DIR__ . '/src/' . __NAMESPACE__,
                ),
            ),
        );
    }
    
    public function getServiceConfig()
    {
        return array(
            'factories' => array(
                'User\Model\UserTable' =>  function($sm) {
                    //$dbAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                    $dbAdapter = new Adapter(self::$db);
                    $table = new UserTable($dbAdapter);
                    return $table;
                },
                'User\Model\RoleTable' =>  function($sm) {
                	//$roleAdapter = $sm->get('Zend\Db\Adapter\Adapter');
                	$roleAdapter = new Adapter(self::$db);
                	$roletable = new RoleTable($roleAdapter);
                	return $roletable;
                },
                
            ),
        );
    }    

    public function getConfig()
    {
        return include __DIR__ . '/config/module.config.php';
    }
}
